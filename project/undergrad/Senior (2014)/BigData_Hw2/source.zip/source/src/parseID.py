#!/bin/python

with open('EHC_1st_round.log', 'r') as inF, open('EHC_1st_round.list', 'w') as outF:
    for line in inF.readlines():
        cnt = line.strip().split('\"')
        inst = cnt[1].split(';')
        
        if inst[1] == 'act=view':
            outF.write(cnt[0].split()[0] + '\n')
