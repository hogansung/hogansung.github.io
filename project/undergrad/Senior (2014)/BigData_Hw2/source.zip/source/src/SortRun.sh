#!/bin/bash

if [ "$#" -ne 2 ]; then
   echo 'illegal number of parameters'
   exit
fi
  
hadoop fs -rm /$1
hadoop fs -rm -r /count.txt
hadoop fs -rm -r /sort.txt

hadoop fs -put $1 /
hadoop jar my.jar WordCount /$1 /count.txt
hadoop jar my.jar Sort /count.txt /sort.txt
hadoop fs -get /sort.txt $2
