#!/bin/bash
if [ ! -d 'my.class' ]; then
   mkdir 'my.class'
fi
  
javac -cp $CLASSPATH -d my.class WordCount.java Sort.java CountFilter.java
jar cvf my.jar -C my.class .

