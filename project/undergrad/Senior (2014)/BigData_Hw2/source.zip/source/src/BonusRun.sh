#!/bin/bash

if [ "$#" -ne 3 ]; then
   echo 'illegal number of parameters'
   exit
fi
  
hadoop fs -rm /$1
hadoop fs -rm -r /filter.txt

hadoop fs -put $1 /
hadoop jar my.jar CountFilter /$1 /filter.txt $3
hadoop fs -get /filter.txt $2
