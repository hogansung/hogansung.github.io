#!/bin/python

with open('EHC_1st_round.log', 'r') as inF, open('EHC_1st_round.pair', 'w') as outF:
    for line in inF.readlines():
        cnt = line.strip().split('\"')
        inst = cnt[1].split(';')
        
        if inst[1] == 'act=order':
            plist = inst[3][6:].split(',')
            for i in xrange(len(plist)):
                for j in xrange(i + 1, len(plist)):
                    if plist[i] < plist[j]:
                        outF.write(plist[i] + ' ' + plist[j] + '\n')
                    else:
                        outF.write(plist[j] + ' ' + plist[i] + '\n')
