###############################################
# THIS IS A BRIEF INTRODUCTION TO MY HOMEWORK #
###############################################


lab1_b00902064
├── ans1-1.txt
├── ans1-2.txt
├── ans2-1.csv
├── ans2-2.csv
├── code1-1.py
├── code1-2.py
├── code2-1.py
├── code2-2.py
├── code3-1.cpp
├── code3-2.py
├── code4-1.py
├── code4-2.py
├── fixed4-1.cpp
├── input3-1.txt
└── input3-2.txt


CONTENTS:
1. ans1-1.txt, ans1-2.txt, ans2-1.csv, ans2-2.csv are the required answer files.
2. code1-1.py, code1-2.py  are easy and straightforward.
3. code2-1.py and code2-2.py are similar. Both of them require python package "gmpy2". The algorithm of Baby-step giant-step was referred from http://en.wikipedia.org/wiki/Baby-step_giant-step.
4. code3-1.cpp utilizes the property of bucket extension to enhance the collision when inserting new items.
5. code3-2.py first creates n/2 lookup chain, and then repeatly inserts specific items for n/2 times to maximize the lookup cost.
6. code4-1.py and code4-2.py requires an open source tool, called "pin". I assumed that the root folder of pin should be inside lab1_b00902064. After finding the keys with brute force, the key length and key will be outputed in stdout.

