import os

# PASSWORD: {[[<<<T0p5ecret>>>]]}

# TWO WAYS TO SOLVE THIS PROBLEM:
# FIRST: type "strings prob4-1" in command line, and find out the key easily.
# SECOND: use this code to perform the timing attack


def sendPassword(s):
    # open a temp password file to record information
    with open('pwd4-1.txt', 'w') as f:
        f.write(s + '\n')

    os.system('./pin-2.14-71313-gcc.4.4.7-linux/pin -t ./pin-2.14-71313-gcc.4.4.7-linux/source/tools/ManualExamples/obj-intel64/inscount0.so -o prob4-1.out -- ./prob4-1 < ./pwd4-1.txt > /dev/null 2>&1')

    with open('prob4-1.out') as f:
        _, cnt = f.readline().strip().split()

    return cnt


# first check the password length
def tryLength():
    past = sendPassword('')

    # assume key length ranges from 1 to 32
    for i in range(1, 33):
        now = sendPassword('.' * i)
        if now < past:
            return i - 1
        else:
            past = now
    return -1


# then check the password by brute force
def tryPassword(pwdLen):
    pwdList = ['.' for i in xrange(pwdLen)]

    for i in range(pwdLen):
        maxv = -1
        idx = -1
        for j in range(256):
            pwdList[i] = chr(j)
            pwd = ''.join(pwdList)

            ret = sendPassword(pwd)
            if ret > maxv:
                maxv = ret
                idx = j
        
        pwdList[i] = chr(idx)
    return ''.join(pwdList)


pwdLen = tryLength()
print 'Length of password:', pwdLen

pwd = tryPassword(pwdLen)
print 'Password:', pwd
