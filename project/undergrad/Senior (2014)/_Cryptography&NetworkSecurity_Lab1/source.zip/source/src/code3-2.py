#!/usr/bin/python

m = (1 << 17) - 1
n = 50000
numCnt = 0

def dfs(j, p, nodeList):
    if p == 0:
        if j == 0: return True
        else: return False

    nodeList.append(j)

    if dfs((5 * j + 1 + p) & m, p >> 5, nodeList): return True
    else: return False


with open('input3-2.txt', 'w') as f:
    f.write(str(n) + '\n')


    # add half of instances into lookup chain,
    # which starts from j = 0, p = 0
    st = 0
    f.write(str(st) + '\n')
    numCnt += 1
    for i in xrange(25000):
        st = (5 * st + 1) & m
        f.write(str(st) + '\n')
        numCnt += 1


    # start consecutive lookup on a magic number
    # which will finally stuck at j = 0, p = 0
    magicNumber = -1
    nodeList = []
    for i in xrange(1, 1 << 30):
        if dfs(i & m, i, nodeList):
            magicNumber = i
            break
        else: nodeList = []

    print magicNumber
    print nodeList
    
    f.write('\n'.join(map(str, nodeList)) + '\n')
    numCnt += len(nodeList)

    for i in xrange(n - numCnt):
        f.write(str(magicNumber) + '\n')
