#!/bin/python

from Crypto.Cipher import AES
import string

ct = '18897416b14e8d539a8ffc23490a39b8'.decode('hex')
key = ['' for i in xrange(16)]

def dfs(depth):
    if depth == 16:
        cipher = AES.new(''.join(key), AES.MODE_ECB)
        pt = cipher.decrypt(ct)
        if pt[0] == 'C' and pt[1] == 'N' and pt[2] == 'S' and all(c in string.printable for c in pt):
            with open('ans1-2.txt', 'w') as f:
                f.write(pt + '\n')
        return

    for c in ['C', 'N', 'S']:
        key[depth] = c
        dfs(depth + 1)

dfs(0)
#with open('ans1-1.txt', 'w') as f:
#    f.write(pt + '\n')

