#!/bin/bash

import gmpy2
import math


def fastIntersection(listA, listB):
    listA = sorted(set(listA))
    listB = sorted(set(listB))

    flagA = 0
    flagB = 0
    ret = []
    while flagA < len(listA) and flagB < len(listB):
        if listA[flagA] < listB[flagB]:
            flagA += 1
        elif listA[flagA] > listB[flagB]:
            flagB += 1
        else: 
            ret.append(listA[flagA])
            flagA += 1
            flagB += 1
    return ret


def bsgs(g, x, p):
    # g ^ a % p == x
    s = int(math.ceil(gmpy2.sqrt(p)))

    bs = {}
    gs = {}
    ng = x
    for i in range(s):
        bs['%s' % gmpy2.mpz(ng)] = int(i)
        ng = ng * g % p

    g = g ** s % p
    ng = g 
    for i in range(s): 
        gs['%s' % gmpy2.mpz(ng)] = int(i)
        ng = ng * g % p

    # find x
    #keySet = fastIntersection(bs.keys(), gs.keys())
    keySet = set(bs.keys()).intersection(gs.keys())
    if len(keySet) == 0: return 'impossible'

    for key in keySet:
        b = bs[key]
        g = gs[key]
        return (g + 1) * s - b


with open('../prob2-1.csv') as fin, open('ans2-1.csv', 'w') as fout:
    fin.readline()
    for line in fin.readlines():
        p, g, x = map(int, line.strip().split(',')[:3])
        a = bsgs(g, x, p)
        fout.write(str(a) + '\n')
