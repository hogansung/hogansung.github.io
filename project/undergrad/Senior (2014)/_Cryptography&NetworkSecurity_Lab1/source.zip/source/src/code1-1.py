#!/bin/python

from Crypto.Cipher import AES

ct = '4e17b6ffd22c19db31a47df663d31763'
key = 'CNS~CNS!CNS?CNS!'

cipher = AES.new(key, AES.MODE_ECB)
pt = cipher.decrypt(ct.decode('hex'))

with open('ans1-1.txt', 'w') as f:
    f.write(pt + '\n')

