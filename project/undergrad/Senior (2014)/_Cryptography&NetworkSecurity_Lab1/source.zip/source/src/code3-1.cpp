#include <cstdio>
#include <unordered_map>

using namespace std;

unordered_map<int, int> myMap;

int main() {
    freopen("input3-1.txt", "w", stdout);

    int n = 50000;
    printf("%d\n", n);

    int flag = 1;
    int ps = -1;
    for (int i = 0; i < n; i++) {
        int ns = myMap.bucket_count();
        if (ps != ns) {
            ps = ns;
            flag = 1;
        }

        int v = ns * flag;
        myMap[v] = i;

        printf("%d\n", v);
        flag++;
    }
}
