#!/bin/python

from collections import defaultdict
import sys
sys.path.append('../tools/neural-networks-and-deep-learning-master/src')

from network import Network
from bisect import bisect_left
import numpy as np


def readMap():
    map_fe_tn = {}
    map_st_tn = {}
    with open('../dat/MLDS_HW1_RELEASE_v1/phones/state_48_39.map') as f:
        for line in f.readlines():
            st, fe, tn = line.strip().split('\t')
            map_st_tn[st] = tn
            map_fe_tn[fe] = tn
    return map_fe_tn, map_st_tn


def readFbank():
    tn_id = []
    tn_x = []
    with open('../dat/MLDS_HW1_RELEASE_v1/fbank/train.ark') as f:
        for line in f.readlines():
            inst = line.strip().split()
            tn_id.append(inst[0])
            tn_x.append(np.array(map(float, inst[1:]), ndmin = 2).T)

    tt_id = []
    tt_x = []
    with open('../dat/MLDS_HW1_RELEASE_v1/fbank/test.ark') as f:
        for line in f.readlines():
            inst = line.strip().split()
            tt_id.append(inst[0])
            tt_x.append(np.array(map(float, inst[1:]), ndmin = 2).T)

    return tn_id, tn_x, tt_id, tt_x


def readLabel(order_fe):
    tn_id_y = {}
    with open('../dat/MLDS_HW1_RELEASE_v1/label/train.lab') as f:
        for line in f.readlines():
            instID, label = line.strip().split(',')
            y = [0 for i in range(48)]
            y[bisect_left(order_fe, label)] = 1
            tn_id_y[instID] = y
    return tn_id_y


# main
def main():
    map_fe_tn, map_st_tn = readMap()
    order_fe = list(sorted(map_fe_tn.keys()))
    order_st = list(sorted(map_st_tn.keys()))
    print order_fe
    tn_id, tn_x, tt_id, tt_x = readFbank()
    #tn_x, tt_x = readMfcc()
    tn_id_y = readLabel(order_fe)
    #tn_y = readStLabel()
    print 'finish loading data'

    
    tn_y = [np.array(tn_id_y[x], ndmin = 2).T for x in tn_id]
    print len(tn_x[0]), len(tn_y[0])

    nt = Network([69, 128, 48])
    nt.SGD(zip(tn_x, tn_y), 100, 100, 0.1)
    


if __name__ == '__main__':
    main()
