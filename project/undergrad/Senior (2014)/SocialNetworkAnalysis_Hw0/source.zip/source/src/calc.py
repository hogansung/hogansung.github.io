#!/bin/bash

import nx
import networkx


