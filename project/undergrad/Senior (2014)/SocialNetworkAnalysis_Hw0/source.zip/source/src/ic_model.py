import networkx as nx
import sys
from Queue import Queue
from random import randrange
from multiprocessing import Pool
import numpy as np


graph = nx.DiGraph()
T = 10000


def icModel(seeds):
    q = Queue()
    s = set()

    for v in seeds:
        q.put(v)
        while q.qsize():
            n = q.get()
            for pn in graph.neighbors(n):
                if randrange(1e6) < graph[n][pn]['weight'] * 1e6 and pn not in s: 
                    s.add(n)
                    q.put(pn)

    return len(s) - len(seeds)
                    

def main():
    # Read graph
    global graph
    graph = nx.read_weighted_edgelist('partB_egofb_ic_edges.txt', create_using = nx.DiGraph(), nodetype = int)
    print 'Finish reading graph'


    # Read seeds
    with open('partB_egofb_ic_seeds.txt', 'r') as f:
        seeds = [int(v) for v in f.readline().split()]
    print 'Finish reading seeds'


    # Run Independent Cascade Model T times
    print 'Begin to run Independent Cascade Model'

    pool = Pool()
    retList = np.zeros(T)

    retList = np.array(pool.map(icModel, [seeds] * T))
    ave = float(retList.sum(0)) / T

    print '\nAverage activated nodes number:', ave


if __name__ == '__main__':
    main()
