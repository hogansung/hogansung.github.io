#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <utility>
#include <algorithm>
#include <assert.h>

using namespace std;

set<int> node;
set<pair<int, int>> edge;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./parse [filename]\n");
        exit(EXIT_FAILURE);
    }

    freopen(argv[1], "r", stdin);

    char title[100];
    scanf("%s", title);

    bool di = false;
    if (title[0] == 'D') di = true;

    int a, b;
    int num = 0;
    while (scanf("%d%d", &a, &b) != EOF) {
        node.insert(a);
        node.insert(b);

        if (di) {
            edge.insert(make_pair(a, b));
        }
        else {
            edge.insert(make_pair(min(a, b), max(a, b)));
        }

        num++;
        //assert(a != b);
    }

    assert(edge.size() == (unsigned long)num);

    fprintf(stderr, "Num of nodes: %lu\n", node.size());
    fprintf(stderr, "Num of edges: %lu\n", edge.size());
}
