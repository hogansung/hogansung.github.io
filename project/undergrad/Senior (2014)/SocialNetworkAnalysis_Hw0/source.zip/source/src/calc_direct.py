import networkx as nx
import math
import operator

graph = nx.DiGraph()
eps = 1e-10

def calcAlpha():
    xmin = 1e10
    for key, val in graph.degree().iteritems():
        xmin = min(xmin, val)
    
    total = 0.0
    for key, value in graph.degree().iteritems():
        total += math.log(1.0 * value / xmin)
    
    return 1 + graph.number_of_nodes() / total


def sliceItvl(valDict):
    valList = valDict.values()
    retList = [0.0] * 20
    maxv = max(valList)
    minv = min(valList)
    itvl = (maxv - minv) / 20
    pit = 1.0 / graph.number_of_nodes()

    for v in valList:
        retList[int((v - minv - eps) / itvl)] += pit
    return retList


def large10(valDict):
    return sorted(valDict.items(), key = operator.itemgetter(1), reverse = True)[:10]


def main():
    # Read graph
    global graph
    graph = nx.read_edgelist('partA_hepth.txt', create_using = nx.DiGraph(), nodetype = int)

    
    # 1. Calculate alpha 
    print 'Start calculating alpha for maximization...'
    #alpha = calcAlpha();
    #print 'Best alpha is', alpha


    # 2. Calculate average shortest path length
    print 'Find largest connected component'
    graph = sorted(nx.weakly_connected_component_subgraphs(graph), key = len, reverse = True)[0]

    print 'Start calculating average shortest path length...'
    
    ave = 0.0;
    num = 0.0;
    for u in nx.nodes(graph):
        single_source_path = nx.single_source_shortest_path_length(graph, u)
        ave += sum(single_source_path.values())
        num += sum(map(lambda x: x != 0, single_source_path))

    #average_shortest_path = nx.average_shortest_path_length(graph)
    print 'Average shortest path length is', ave / num 
    print 'Ratio is', num / (nx.number_of_nodes(graph) * (nx.number_of_nodes(graph) - 1) * 0.5)


    # 3-1. Calculate closeness centralities
    print 'Start calculating closeness centralities...'
    cc = nx.closeness_centrality(graph)
    itvlList = sliceItvl(cc)
    topList = large10(cc)
    with open('partA_hepth_closeness_centralities.txt', 'w') as f:
        f.write(' '.join([str(v) for v in itvlList]) + '\n')
        f.write(' '.join([str(v) for v in topList]) + '\n')


    # 3-2. Calculate betweenness centralities
    print 'Start calculating betweenness centralities...'
    bc = nx.betweenness_centrality(graph)
    itvlList = sliceItvl(bc)
    topList = large10(bc)
    with open('partA_hepth_betweenness_centralities.txt', 'w') as f:
        f.write(' '.join([str(v) for v in itvlList]) + '\n')
        f.write(' '.join([str(v) for v in topList]) + '\n')


if __name__ == '__main__':
    main()
