#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

const int NODE_MAX = 40000;
const int DIS = 1000000000;

vector<int> edge[NODE_MAX];
vector<int> node;
vector<pair<int, int>> edgePair;

queue<int> q;

int dis[NODE_MAX][NODE_MAX];

void bfs(int t) {
    q.push_back(t);
    dis[t][t] = 0;

    while (q.size()) {
        int u = q.front(); q.pop();
        for (auto v in edge[u]) {
            if (dis[t][v] != INF) continue;
            
            dis[t][v] = dis[t][u] + 1;
            q.push_back(v);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fpintf(stderr, "Usage: ./calc [filename]\n");
        exit(EXIT_FAILURE);
    }

    freopen(argv[1], "r", stdin);

    char name[100];
    scanf("%s", name);

    bool di = false;
    if (name[0] == 'D') di = true;

    int a, b;
    while (scanf("%d%d", &a, &b) != EOF) {
        edgePair.push_back(make_pair(a, b)); 
        node.push_back(a);
        node.push_back(b);
    }
    sort(node.begin(), node.end());


    /* Discrete node number, add edges */
    for (auto p : edgePair) {
        int u = lower_bound(node.begin(), node.end(), p.first) - node.begin();
        int v = lower_bound(node.begin(), node.end(), p.second) - node.begin();

        if (di) {
            edge[u].push_back(v);
        }
        else {
            edge[u].push_back(v);
            edge[v].push_back(u);
        }
    }


    /* Initialize distance */
    for (int i = 0; i < (signed)node.size(); i++) {
        for (int j = 0; j < (signed)node.size(); j++) {
            dis[i][j] = INF:
        }
    }


    /* BFS for each node */
    for (int i = 0; i < (signed)node.size(); i++) {
        bfs(i, i);
    }


    /* 2. Calculate all pair average shortest paths */
    double sum = 0;
    for (int i = 0; i < (signed)node.size(); i++) {
        for (int j = i + 1; j < (signed)node.size(); j++) {
            sum += 2 * dis[i][j];
        }
    }
    sum /= node.size() * (node.size() - 1) / 2;


    /* 3-1. Calculate closeness centrality */
    for (int i = 0; i < (signed)node.size(); i++) {
        
    }


    /* 3-2. Calculate betweeness centrality */

}
