import networkx as nx
from Queue import Queue
import pickle


graph = nx.DiGraph()


def ltModel(seeds):
    q = Queue()
    actList = []
    
    for v in seeds:
        q.put(v)
        while q.qsize():
            n = q.get()
            for pn in graph.neighbors(n):
                graph.add_node(pn, current = graph.node[pn]['current'] + graph[n][pn]['weight'])
                if graph.node[pn]['current'] >= graph.node[pn]['threshold'] and graph.node[pn]['stat'] == 'inactive':
                    graph.add_node(pn, stat = 'active')
                    q.put(pn)
                    actList.append(pn)

    return sorted(actList)



def main():
    # Read graph
    global graph
    graph = nx.read_weighted_edgelist('partB_egofb_lt_edges.txt', create_using = nx.DiGraph(), nodetype = int)
    print 'Finish reading graph'


    # Read node threshold
    with open('partB_egofb_lt_nodes.txt', 'r') as f:
        f.readline()
        for line in f.readlines():
            n, t = int(line.split()[0]), float(line.split()[1])
            graph.add_node(n, threshold=t)
            graph.add_node(n, current = 0.0)
            graph.add_node(n, stat = 'inactive')


    # Read seeds
    with open('partB_egofb_lt_seeds.txt', 'r') as f:
        seeds = [int(v) for v in f.readline().split()]
        map(lambda n: graph.add_node(n, stat = 'seed'), seeds)
    print 'Finish reading seeds'


    # Run Linear Threshold Model
    actList = ltModel(seeds)


    # Write result into file
    with open('partB_egofb_lt.txt', 'w') as f:
        f.write(' '.join([str(n) for n in actList]) + '\n')




if __name__ == '__main__':
    main()
