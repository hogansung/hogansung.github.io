#include <cstdio>
#include <cstdlib>
#include <map>

using namespace std;

const int BUF_SIZE = 1000000;
char buf[BUF_SIZE];

map<int, int> ans;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "arg error\n");
        exit(EXIT_FAILURE);
    }

    FILE *pfile = fopen(argv[1], "r");
    if (pfile == NULL) {
        fprintf(stderr, "file cannot open\n");
        exit(EXIT_FAILURE);
    }

    int d;
    while (fgets(buf, BUF_SIZE, pfile) != NULL) {
        sscanf(buf, "%d", &d);
        ans[d]++;
    }

    fprintf(stdout, "Category: %d\n", (int)ans.size());
    for (auto e : ans) {
        fprintf(stdout, "%d: %d\n", e.first, e.second);
    }

    fclose(pfile);
}
