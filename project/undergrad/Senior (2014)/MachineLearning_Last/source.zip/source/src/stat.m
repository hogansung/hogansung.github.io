% include libsvmread
addpath('../liblinear-1.96/matlab/');

% data definition
dataPath = '../data/test.dat';
ndataPath = '../data/ntest.dat';

[data_y, data_x] = libsvmread(dataPath);
[row_num, col_num] = size(data_x);

info_sum = zeros(row_num, 1);

fid = fopen('noise_id_test', 'w');
for i = 1 : row_num
    info_sum(i) = sum(data_x(i, :));
    if (info_sum(i) < 50) 
        fprintf(fid, '%d %d\n', i, info_sum(i));
    end   
end
fclose(fid);

data_nx = data_x(info_sum >= 50, :);
data_ny = data_y(info_sum >= 50);

libsvmwrite(ndataPath, data_ny, data_nx);
