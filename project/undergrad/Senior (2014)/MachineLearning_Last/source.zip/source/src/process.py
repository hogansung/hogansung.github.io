import sys
from svmutil import *
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_svmlight_file

TRAIN = '../data/pptrain.dat'
TEST = '../data/pptest.dat'
TRAIN_OUT = '../pred/train.out'
TEST_OUT = '../pred/test.out'

SUBTRAIN = '../data/subtrain.dat'
SUBTEST = '../data/subtest.dat'
SUBTRAIN_OUT = '../pred/subtrain.out'
SUBTEST_OUT = '../pred/subtest.out'

gbm_model = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=0, verbose=2)


def learn(data_y, data_x):
    global gbm_model
    gbm_model.fit(data_x, data_y)


def predict(data_y, data_x, data_p):
    data_p = gbm_model.predict(data_x)
    print(accuracy_score(data_y, data_p))
    print(confusion_matrix(data_y, data_p))


def perror():
    print('Usage: ./process [OPTION]\n')
    
    print('OPTION :')
    print('full : train model, predict train, test')
    print('part : subtrain model, predict subtrain, subtest')


def main(argv = sys.argv):

    # argument check
    if (len(argv) != 2):
        perror()
    else: 
        if argv[1] == 'full':
            TN_IN = TRAIN
            TT_IN = TEST
            TN_OUT = TRAIN_OUT
            TT_OUT = TEST_OUT
        elif argv[1] == 'part':
            TN_IN = SUBTRAIN
            TT_IN = SUBTEST
            TN_OUT = SUBTRAIN_OUT
            TT_OUT = SUBTEST_OUT

        train_x, train_y = load_svmlight_file(TN_IN)
        test_x, test_y = load_svmlight_file(TT_IN)
        print('read finish')

        train_x = train_x.toarray()
        #test_x = test_x.toarray()

        learn(train_y, train_x)
        print('learn finish')

        #train_p = predict(train_x, train_y)
        test_p = predict(test_x, test_y)
        print('predict finish')



if __name__ == '__main__':
    main()
