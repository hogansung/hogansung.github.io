% include libsvmread
addpath('../liblinear-1.96/matlab/');

% data definition
dataPath = '../data/pptrain.dat';
filePath = '../temp/image_';

[data_y, data_x] = libsvmread(dataPath);
[row_num, col_num] = size(data_x);

row_num = 30;

fprintf('create start\n');
for i = 1 : row_num
    inst = full(reshape(data_x(i, :), 40, 35));
    imwrite(inst, strcat(filePath, int2str(i), '.png'));
end
fprintf('create finish\n');
