% Parameter Setting
addpath('../liblinear-1.96/matlab/');
addpath('../DropConnect-master/NN/');

trainFile = ('../data/train.dat');
testFile = ('../data/test.dat');

NUM_LABELS = 32;


% Read Data
[train_y, train_x] = libsvmread(trainFile);
[test_y, test_x] = libsvmread(testFile);



% Main Process
opts.numepochs = 1000;
opts.batchsize = 25;
opts.plot = 0;
opts.validation = 1;
[~, nIn] = size(train_x);
[~, nOut] = size(train_y);

pred_ny = zeros(size(train_y, 1), NUM_LABELS);
parfor label = 1 : NUM_LABELS
    fprintf('start: %d\n', label);
    train_ny = train_y == (label - 1);
    test_ny = test_y == (label - 1);
    
    nn = nnsetup([nIn, 80, nOut]);
    [nn, L] = nntrain(nn, train_x, train_ny, opts, test_x, test_ny);
    
    nn.testing = 1;
    nn = nnff(nn, x, zeros(size(x,1), nn.size(end)));
    nn.testing = 0;
    
    pred_ny(:, label) = nn.a{end};
    fprintf('end: %d\n', label);
end

pred_y = zeros(size(train_y, 1), 1);
for inst = 1 : size(train_y, 1)
    pred_y(inst, 1) = find(pred_ny(inst, :)) == max(pred_ny(inst, :))
end 
