#include <cstdio>
#include <string>
#include <vector>
#include <assert.h>

using namespace std;

const int BUF_SIZE = 1000000;
char buf[BUF_SIZE];

void readFile(string FILENAME, vector<int> &vct) {
    FILE *pfile = fopen(FILENAME.c_str(), "r");
    if (pfile == NULL) {
        fprintf(stderr, "open %s failed\n", FILENAME.c_str());
        exit(EXIT_FAILURE);
    }

    int label;
    while (fgets(buf, BUF_SIZE, pfile) != NULL) {
        sscanf(buf, "%d", &label);
        vct.push_back(label);
    }

    fclose(pfile);
}

int main(int argc, char *argv[]) {

    string FILENAME; 
    if (argc == 2) {
        FILENAME = argv[1];
    }
    else {
        fprintf(stderr, "Usage: ./findError [FILENAME]\n\nFILENAME = train, subtrain, subtest\n");
        exit(EXIT_FAILURE);
    }


    string ANS_FILE = string("../data/") + FILENAME  + string(".dat");
    string PRED_FILE = string("../pred/") + FILENAME  + string(".out");

    auto ansList = vector<int>();
    readFile(ANS_FILE, ansList);

    auto predList = vector<int>();
    readFile(PRED_FILE, predList);


    assert(ansList.size() == predList.size());

    int stat[32][32] = {{0}};
    int sum[32] = {0};
    int correct = 0;
    for (int i = 0; i < int(ansList.size()); i++) {
        stat[ansList[i]][predList[i]]++;
        sum[ansList[i]]++;
        if (ansList[i] == predList[i]) correct++;
    }

    for (int i = 0; i < 32; i++) {
        for (int j = 0; j < 32; j++) {
            printf("%2d ", stat[i][j]);
            if (j == 11 || j == 21) printf("\t");
        }
        printf("\t%f\n", (float)stat[i][i] / sum[i]);
        if (i == 11 || i == 21) printf("\n");
    }
    printf("%f\n", (float)correct / ansList.size());
}
