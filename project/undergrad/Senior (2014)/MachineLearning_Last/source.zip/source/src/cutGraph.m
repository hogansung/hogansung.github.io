% include libsvmread
addpath('../liblinear-1.96/matlab/');

% data definition
dataPath = '../data/train.dat';
filePath = '../temp/image_';
ndataPath = '../data/train_122_105.dat';

[data_y, data_x] = libsvmread(dataPath);
[row_num, col_num] = size(data_x);

fprintf('%d %d\n', row_num, col_num);

nr = 122;
nc = 105;

nnr = 122;
nnc = 105;

data_nx = sparse(row_num, nnr * nnc);
data_ny = data_y;
info_sum = zeros(row_num, 1);

% start processing
fprintf('create start\n');


fspecialMask = fspecial('motion');

%parpool();
parfor i = 1 : row_num
    inst = full(reshape(data_x(i, :), nc, nr))';
    
    inst = medfilt2(inst);
    back = inst;
    info_sum(i) = sum(data_x(i, :));

    fprintf('now is at %d\n', i);

    if (info_sum(i) >= 50)
        inst = imfilter(inst, fspecialMask);
        inst = imadjust(inst);

        for lb = 1 : nc
            if sum(inst(:, lb))
                break
            end
        end

        for rb = nc : -1 : 1
            if sum(inst(:, rb))
                break
            end
        end

        for tb = 1 : nr
            if sum(inst(tb, :))
                break
            end
        end

        for bb = nr : -1 : 1
            if sum(inst(bb, :))
                break
            end
        end

        hv = bb - tb + 1;
        wv = rb - lb + 1;

        %fprintf('%d %d %d %d %d %d\n', lb, rb, tb, bb, hv, wv);

        inst = imcrop(inst, [lb tb wv hv]);
        if (sum(inst(:)) > 1e-18) 
            inst = imresize(inst, [nnr nnc]);
            %imwrite(inst, strcat(filePath, int2str(i), '.png'));
            data_nx(i, :) = sparse(reshape(inst, 1, nnr * nnc));
        end
    end
end

%data_nx = data_nx(info_sum >= 50, :);
%data_ny = data_y(info_sum >= 50);

libsvmwrite(ndataPath, data_ny, data_nx);

fprintf('create finish\n');
