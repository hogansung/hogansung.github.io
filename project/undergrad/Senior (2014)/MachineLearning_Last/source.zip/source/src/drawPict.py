#!/usr/bin/python

import sys
import math
import matplotlib.pyplot as plt

DATA = ['Origin', '122 X 105', '60 X 50', '40 X 35', '30 X 25']
DEEP_DATA = ['Origin', '40 X 35']

SVML_TRAIN = [1-0.506918, 1-0.630901, 1-0.585594, 1-0.566061, 1-0.551953]
SVMR_TRAIN = [1-0.991725, 1-0.950692, 1-0.950692, 1-0.950692, 1-0.950081]
GBM_TRAIN  = []
RF_TRAIN   = [1-0.995116657623, 1-0.950691806837, 1-0.950691806837, 1-0.950691806837, 1-0.950691806837]
DEEP_TRAIN   = [0.1648, 0.1369]

SVML_TEST  = [1-0.18923, 1-0.492675, 1-0.503663, 1-0.510852, 1-0.511259]
SVMR_TEST  = [1-0.26153, 1-0.0881715, 1-0.674715, 1-0.682854, 1-0.663592]
GBM_TEST   = []
RF_TEST    = [1-0.345632121541, 1-0.584644601194, 1-0.59590341834, 1-0.602957135106, 1-0.619099294628]
DEEP_TEST   = [0.232, 0.136]


def draw_TEST():
    plt.plot(range(len(SVML_TEST)), SVML_TEST, 'o-', lw = 6, markersize = 15, label = 'SVML')
    plt.plot(range(len(SVMR_TEST)), SVMR_TEST, '^-', lw = 6, markersize = 15, label = 'SVMR')
    #plt.plot(range(len(GBM_TEST)) , GBM_TRAIN , 's-', lw = 6, markersize = 15, label = 'GBM')
    plt.plot(range(len(RF_TEST))  , RF_TEST  , 'D-', lw = 6, markersize = 15, label = 'RF')
    plt.plot([0, 3]  , DEEP_TEST  , 's-', lw = 6, markersize = 15, label = 'RF')
    plt.xticks(range(len(RF_TEST)), DATA)
    plt.title('Four models Performance Compare')
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def draw_SVML():
    plt.plot(range(len(SVML_TRAIN)), SVML_TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot(range(len(SVML_TEST)) , SVML_TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(SVML_TRAIN)), DATA)
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def draw_SVMR():
    plt.plot(range(len(SVMR_TRAIN)), SVMR_TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot(range(len(SVMR_TEST)) , SVMR_TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(SVMR_TRAIN)), DATA)
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def draw_GBM():
    plt.plot(range(len(GBM_TRAIN)), GBM_TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot(range(len(GBM_TEST)) , GBM_TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(GBM_TRAIN)), DATA)
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def draw_RF():
    plt.plot(range(len(RF_TRAIN)), RF_TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot(range(len(RF_TEST)), RF_TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(RF_TRAIN)), DATA)
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def draw_DEEP():
    plt.plot([0, 3], DEEP_TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot([0, 3], DEEP_TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(RF_TRAIN)), DATA)
    plt.legend()
    plt.xlabel('Origin Data and Four Preprocessing Data')
    plt.ylabel('0-1 Error')
    plt.show()


def main():
    #draw_SVML()
    #draw_SVMR()
    #draw_GBM()
    #draw_RF()
    draw_DEEP()
    
    draw_TEST()


if __name__ == '__main__':
    main()
