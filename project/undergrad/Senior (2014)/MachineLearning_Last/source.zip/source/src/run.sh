#!/bin/bash

# definition
TRAIN='../data/pptrain.dat'
TEST='../data/pptest.dat'
SUBTRAIN='../data/subtrain.dat'
SUBTEST='../data/subtest.dat'

TRAIN_SIZE=`wc -l $TRAIN | awk {'print $1'}`
SUBTRAIN_SIZE=$(printf "%.0f" `echo $TRAIN_SIZE '* 0.632' | bc`)
SUBTRAIN_SIZE_P1=`echo $(($SUBTRAIN_SIZE + 1))`


if [ "$#" -eq 0 ]; then
    printf 'Usage: ./run.sh [OPTION] [ARGUMENTS]\n\n'
    
    printf 'OPTION :\n'
    printf 'split : split data into subtrain and subtest\n'

    printf 'cn : create train model\n'
    printf 'pn : train predict train\n'
    printf 'pt : train predict test\n'
    printf 'csn : create subtrain model\n'
    printf 'psn : subtrain predict subtrain\n'
    printf 'pst : subtrain predict subtest\n'

    printf '\nARGUMENT :\nPlease refer to README of LiblineaR or LibSVM\n'
fi

FIRST_ARG=$1
shift
REST_ARG=$*

if [ "$FIRST_ARG" == 'split' ]; then
    time head -n $SUBTRAIN_SIZE $TRAIN > $SUBTRAIN
    time tail -n "+$SUBTRAIN_SIZE_P1" $TRAIN > $SUBTEST
elif [ "$FIRST_ARG" == 'cn' ]; then
    echo 'start learn train'
    time ../libsvm-3.20/svm-train $REST_ARG $TRAIN '../model/train.model'
    echo 'end learn train'
elif [ "$FIRST_ARG" == 'csn' ]; then
    echo 'start learn subtrain'
    time ../libsvm-3.20/svm-train $REST_ARG $SUBTRAIN '../model/subtrain.model'
    echo 'end learn subtrain'
elif [ "$FIRST_ARG" == 'pn' ]; then
    echo 'start train predict train'
    time ../libsvm-3.20/svm-predict $REST_ARG $TRAIN '../model/train.model' '../pred/train.out'
    echo 'end train predict train'
elif [ "$FIRST_ARG" == 'pt' ]; then
    echo 'start train predict test'
    time ../libsvm-3.20/svm-predict $REST_ARG $TEST '../model/train.model' '../pred/test.out'
    echo 'end train predict test'
elif [ "$FIRST_ARG" == 'psn' ]; then
    echo 'start subtrain predict subtrain'
    time ../libsvm-3.20/svm-predict $REST_ARG $SUBTRAIN '../model/subtrain.model' '../pred/subtrain.out'
    echo 'end subtrain predict subtrain'
elif [ "$FIRST_ARG" == 'pst' ]; then
    echo 'start subtrain predict subtest'
    time ../libsvm-3.20/svm-predict $REST_ARG $SUBTEST '../model/subtrain.model' '../pred/subtest.out'
    echo 'end subtrain predict subtest'
fi
