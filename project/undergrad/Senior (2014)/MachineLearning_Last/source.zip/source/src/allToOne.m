% include libsvmread
addpath('../liblinear-1.96/matlab/');

% data definition
dataPath = '../data/pptrain.dat';
ndataPath = '../data/onetrain.dat';

[data_y, data_x] = libsvmread(dataPath);
data_x(data_x ~= 0) = 1;

libsvmwrite(ndataPath, data_y, data_x);
