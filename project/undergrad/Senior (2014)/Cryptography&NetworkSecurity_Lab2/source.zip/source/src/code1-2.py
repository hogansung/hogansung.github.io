#!/bin/bash

from itertools import product
import binascii

target = ['84a02e26', 'a359afc1', '5d1e3567', 'ad02f20f', '551d976d', 'e3f20a9d']
tarLen = [4, 4, 4, 4, 4, 2]

plain = []
for i in xrange(0, 6):
    plain += [''.join(w) for w in product(map(chr, range(128)), repeat=tarLen[i]) if hex(binascii.crc32(''.join(w)) & 0xffffffff)[2:].strip('L') == target[i]]

print ''.join(plain)
