#!/usr/bin/python

import networkx as nx

KV = 4
KE = 0

def loadLocalGraph(LG):
    with open('../public_nodes.txt', 'r') as f:
        for line in f.readlines():
            lineSplit = line.strip().split(',')
            nodeID = int(lineSplit[0])
            nodeInfo = [int(val) for val in lineSplit[1:]]
            LG.add_node(nodeID)
            LG.node[nodeID]['wi'] = 1.0
            for j in range(0, KV):
                LG.node[nodeID]['v' + str(j)] = nodeInfo[j]
    print 'finish read nodes'

    with open('../public_edges.txt', 'r') as f:
        for line in f.readlines():
            lineSplit = line.strip().split(',')
            u, v = [int(val) for val in lineSplit[:2]]
            edgeInfo = [int(val) for val in lineSplit[2:]]
            LG.add_edge(u, v)
            for j in range(0, KE):
                LG[u][v]['e' + str(j)] = edgeInfo[j]
    print 'finish read edges'

    for n in LG.nodes_iter():
        LG.node[n]['deg'] = nx.degree(LG, n)


def getLocalSeedGraph(LSG):
    with open('../data/g_200', 'r') as f:
        teamID = int(f.readline().strip())
        queryID = int(f.readline().strip())

        KV, KE = [int(val) for val in f.readline().strip().split()]
        num_nodes = int(f.readline().strip().split()[0])
        print num_nodes

        for i in range(0, num_nodes):
            lineSplit = f.readline().strip().split()
            print i, lineSplit
            nodeID, nodeDeg = [int(val) for val in lineSplit[:2]]
            nodeInfo = [int(val) for val in lineSplit[2:]]
            LSG.add_node(nodeID)
            LSG.node[nodeID]['deg'] = nodeDeg
            LSG.node[nodeID]['wi'] = 1.0
            for j in range(0, KV):
                LSG.node[nodeID]['v' + str(j)] = nodeInfo[j]

        for line in f.readlines():
            if (line == '\n'): continue
            lineSplit = line.split()
            u, v = [int(val) for val in lineSplit[:2]]
            edgeInfo = [int(val) for val in lineSplit[2:]]
            LSG.add_edge(u, v)
            for j in range(0, KE):
                LSG[u][v]['e' + str(j)] = edgeInfo[j]
    print 'finish read seeds'


def queryLocalNodes(LSG, LG, qn, wi):
    print 'choose node:', qn, wi
    for nodeID in LG.neighbors_iter(qn):
        if (not LSG.has_node(nodeID)):
            LSG.add_node(nodeID)
            for key, value in LG.node[nodeID].iteritems():
                LSG.node[nodeID][key] = value
            LSG.node[nodeID]['wi'] = wi * LSG.node[qn]['wi']
    
        if (not LSG.has_edge(qn, nodeID)):
            LSG.add_edge(qn, nodeID)
            for key, value in LG[qn][nodeID]:
                LSG[qn][nodeID][key] = value

