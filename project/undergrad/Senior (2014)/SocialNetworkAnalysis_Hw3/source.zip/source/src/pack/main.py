#!/usr/bin/python

import subprocess
import networkx as nx
import random
import bisect
import local
import math
from scipy import stats


PASSWD = '7SKPj0c9kQ'

NUM_QUERY = 100
KV = 4
KE = 0
bound = [1, 2, 3, 6, 10, 15, 21, 28, 36, 45, 55, 70, 100, 200, 100000000]
degW = [1.0 for i in range(len(bound))]
#degW = [5.462067367613678, 3.598396329249131, 2.785596358592972, 2.014543639725167, 1.5344741875080903, 1.188469753750067, 0.9894991663772071, 0.8442171704032176, 0.7067722637717714, 0.5997808297659708, 0.513734444510293, 0.40685506265144855, 0.3120829551899339, 0.17363803149741275, 0.06887158526051822]

def getSeedGraph(LSG):
    global KV, KE
    with subprocess.Popen(('./query.py ' + PASSWD), shell=True, stdout=subprocess.PIPE).stdout as sf:
        teamID = sf.readline()
        queryID = sf.readline()
        
        KV, KE = [int(val) for val in sf.readline().split()]
        num_nodes = [int(val) for val in sf.readline().split()][0]

        for i in range(0, num_nodes):
            lineSplit = sf.readline().split()
            nodeID, nodeDeg = [int(val) for val in lineSplit[:2]]
            nodeInfo = [int(val) for val in lineSplit[2:]]
            LSG.add_node(nodeID)
            LSG.node[nodeID]['deg'] = nodeDeg
            LSG.node[nodeID]['wi'] = 1.0
            for j in range(0, KV):
                LSG.node[nodeID]['v' + str(j)] = nodeInfo[j]
        
        for line in sf.readlines():
            if (line == '\n'): continue
            lineSplit = line.split()
            u, v = [int(val) for val in lineSplit[:2]]
            edgeInfo = [int(val) for val in lineSplit[2:]]
            LSG.add_edge(u, v)
            for j in range(0, KE):
                LSG[u][v]['e' + str(j)] = edgeInfo[j]


def queryNodes(LSG, qn, wi, ID):
    with open('../data/query' + str(ID), 'r') as f:
        data = f.readlines()

    teamID = int(data[0])
    queryID = int(data[1])
    print queryID

    line_split = data[2].split()
    nodeID, nodeDeg = [int(val) for val in line_split[:2]]
    nodeInfo = [int(val) for val in line_split[2:]]

    for i in range(nodeDeg):
        line_split = data[i + 3].split()
        nodeID, nodeDeg = [int(val) for val in line_split[:2]]
        nodeInfo = [int(val) for val in line_split[2:]]

        if (not LSG.has_node(nodeID)):
            LSG.add_node(nodeID)
            LSG.node[nodeID]['deg'] = nodeDeg
            LSG.node[nodeID]['wi'] = wi * LSG.node[qn]['wi']
            for j in range(KV):
                LSG.node[nodeID]['v' + str(j)] = nodeInfo[j]
            
        if (not LSG.has_edge(qn, nodeID)):
            LSG.add_edge(qn, nodeID)


def checkNodes(G):
    sum_fDeg = 0
    nodeList = []
    degList = [0]

    for n in G.nodes_iter():
        G.node[n]['fDeg'] = G.node[n]['deg'] - G.degree(n)
        nodeList.append(n)
        #print n, 'deg', G.node[n]['deg'], 'wi', G.node[n]['wi']
        sum_fDeg = sum_fDeg + math.floor(G.node[n]['fDeg'] * G.node[n]['wi'])
        degList.append(sum_fDeg)

    return sum_fDeg, nodeList, degList


def calDeg(G, tag):
    degSum = [0] * len(bound)
    pt = 1.0 / nx.number_of_nodes(G)
    degMap = {}
    for n in G.nodes_iter():
        for i in range(0, len(bound)):
            ptt = pt if tag is False else pt * degW[i]
            if (G.node[n]['deg'] <= bound[i]):
                degSum[i] += ptt
                degMap[n] = i
                break
    if tag is True: return degSum, degMap
    else: return degSum


def calNodeAttr(G, degMap = None):
    nodeAttr = [{} for i in range(KV)]
    pt = 1.0 / nx.number_of_nodes(G)
    for n in G.nodes_iter():
        for key, value in G.node[n].iteritems():
            if (key[0] == 'v'):
                ptt = pt if degMap is None else pt * degW[degMap[n]]
                index = int(key[1])
                if value in nodeAttr[index].keys():
                    nodeAttr[index][value] += ptt 
                else:
                    nodeAttr[index][value] = ptt
    return nodeAttr


def calCloseness(G):
    ccList = nx.closeness_centrality(G)
    return sorted(ccList.items(), key = lambda pair: pair[1], reverse = True)


def countClosenessRank(topk):
    with open('../public_closeness.txt') as pc:
        clist = [int(line.split()[0]) for line in pc]
    return sum([clist.index(v[0])+1 for v in topk])


def entropy(xs):
    a, b = zip(*xs)
    return stats.entropy(a, b)


def main():
    # Load Local Graph
    LSG = nx.Graph() 
    #LG = nx.Graph()
    #local.loadLocalGraph(LG)

    # Calculate Local Graph Result
    #l_degSum = calDeg(LG, False)
    #l_nodeAttrSum = calNodeAttr(LG)
    #l_topCloseness = calCloseness(LG)[0:100]

    # Retrieve Local Seed Graph
    local.getLocalSeedGraph(LSG)
    print 'seed nodes:', nx.number_of_nodes(LSG)

    # Retrieve Seed Graph
    #getSeedGraph()

    # Initial Info
    sum_fDeg, nodeList, degList = checkNodes(LSG)

    # Main process
    for t in range(202, 301):
        val = random.randint(0, sum_fDeg - 1)
        pos = bisect.bisect_right(degList, val) - 1
        qn = nodeList[pos]
        ave_fDeg = 1.0 * sum_fDeg / nx.number_of_nodes(LSG)
        queryNodes(LSG, qn, ave_fDeg / math.floor(LSG.node[qn]['fDeg'] * LSG.node[qn]['wi']), t)
        #local.queryLocalNodes(LSG, LG, qn, ave_fDeg / math.floor(LSG.node[qn]['fDeg'] * LSG.node[qn]['wi']))
        sum_fDeg, nodeList, degList = checkNodes(LSG)
    print 'finish main process'
    print 'subgraph nodes:', nx.number_of_nodes(LSG)

    # Calculate Sample Graph Result
    degSum, degMap = calDeg(LSG, True)
    nodeAttrSum = calNodeAttr(LSG, degMap)
    #topCloseness = calCloseness(LSG)[0:100]


    # Calculate KL Divergence
    #degKL = stats.entropy(l_degSum, degSum)
    #nodeAttrKL = [entropy([(a[k], b.get(k, 0.0000000001)) for k in a.iterkeys()]) for a, b in zip(l_nodeAttrSum, nodeAttrSum)]
    #print degKL, nodeAttrKL

    # print degree
    #print l_degSum
    print degSum

    # print node attribute
    for i in range(KV):
        print nodeAttrSum[i]


    # print closeness centrality
    rankSum = countClosenessRank(topCloseness)
    #print topCloseness
    print rankSum



if __name__ == '__main__':
    main()
