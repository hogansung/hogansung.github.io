#!/usr/bin/python

with open('../data/seed', 'r') as f:
    teamID = int(f.readline().strip())
    queryID = int(f.readline().strip())

    KV, KE = [int(val) for val in f.readline().strip().split()]
    num_nodes = int(f.readline().strip().split()[0])

    print teamID, queryID, KV, KE, num_nodes

    for i in range(0, num_nodes):
        lineSplit = f.readline().strip().split()
        nodeID, nodeDeg = [int(val) for val in lineSplit[:2]]
        nodeInfo = [int(val) for val in lineSplit[2:]]

        print nodeID, nodeDeg
        print nodeInfo
