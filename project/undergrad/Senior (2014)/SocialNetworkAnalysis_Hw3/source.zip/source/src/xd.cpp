#include <cstdio>
#include <cstring>

int main() {
    char words[101];
    scanf("%s", words);

    for (int i = 0; words[i]; i++) {
        printf("%d\n", words[i]);
    }

    char buf[801];
    int flag = 0;
    for (int i = 0; words[i]; i++) {
        int t = 128;
        int tt = 7;
        while (t) {
            buf[flag++] = (words[i] & t) >> tt
            t >>= 1;
            tt--;
        }
    }
}
