addNoise = function(element) {
    item = sample(1:100, 1)
    if (item <= 3) return(NA)
    else return(element)
}

subtest = apply(subtest, c(1, 2), addNoise)

write.csv(subtrain, '../data/subtrain.csv', row.names = FALSE, col.names = TRUE, quote = FALSE)
write.csv(subtest, '../data/subtest.csv', row.names = FALSE, col.names = TRUE, quote = FALSE)
