tar = 'ahyy punenpgre'
tar = 'zna 3 cevags, bowqhzc -q szg2, ernqrys -n szg2 | terc zntvp'
tar = 'uggcf://nfpvvarzn.bet/n/5idj9x78vspxoj1lvvzimc46l'

d = {'a': 'b', 'c': 'd', 'b': 'c', 'e': 'f', 'd': 'e', 'g': 'h', 'f': 'g', 'i': 'j', 'h': 'i', 'k': 'l', 'j': 'k', 'm': 'n', 'l': 'm', 'o': 'p', 'n': 'o', 'q': 'r', 'p': 'q', 's': 't', 'r': 's', 'u': 'v', 't': 'u', 'w': 'x', 'v': 'w', 'y': 'z', 'x': 'y', 'z': 'a'}

for i in xrange(26):
    print tar
    tar = ''.join([d[w] if w in d else w for w in tar])

