import socket
import binascii
import z3

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7005))


# z3
s = z3.Solver()
a, b, c, d, e, f, g = z3.BitVecs('a b c d e f g', 64)
mod = 1 << 64

s.add(a * b * c % mod == 11432338203557685825)
s.add(a * b * f % mod == 7009074961153156160)
s.add(a * b * g % mod == 3224226047463458439)
s.add(a * c * e % mod == 1340861934553908998)
s.add(a * c * f % mod == 8699261672194141120)
s.add(a * d * f % mod == 5232552718082304512)
s.add(b * c * f % mod == 8941928873267534656)
s.add(b * d * g % mod == 13842750632996104008)
s.add(b * e * g % mod == 7300311676521932606)
s.add(c * d * e % mod == 8773692266198055632)
s.add(c * d * f % mod == 5795003210910433792)
s.add(c * f * g % mod == 1688782921040576832)
s.add(d * f * g % mod == 5805833754537692672)
s.add(e * f * g % mod == 13761016490562631808)

# solve the problem
assert(s.check())
res = s.model()


# create msg
resList = [res[a].as_long(), res[b].as_long(), res[c].as_long(), res[d].as_long(), res[e].as_long(), res[f].as_long(), res[g].as_long()]
msg = '-'.join([format(r, 'x') for r in resList])


# save serial number
with open('sn3-1.txt', 'w') as outf:
    outf.write(msg + '\n')


# Send something
data = client_socket.recv(1024)
client_socket.send(msg + '\n')


# Catch the flag
data = client_socket.recv(1024)
with open('ans3-1.txt', 'w') as outf:
    outf.write(data)
