import re

outf = open('code3-3.py', 'w')

outf.write(
'''import socket
import binascii
import z3

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7007))


# z3
s = z3.Solver()

x = [z3.BitVec('x_%s' % i, 32) for i in range(80)]
mod = 1 << 32


# add CNS constraints
''')


outf.write('s.add(z3.Or(')
for i in range(80 - 2):
    if i != 0:
        outf.write(', ')
    outf.write('z3.And(x[' + str(i) + '] == ord(\'C\'), x[' + str(i + 1) + '] == ord(\'N\'), x[' + str(i + 2) + '] == ord(\'S\'))')
outf.write('))' + '\n')


outf.write('\n\n# add printable constraints\n')
for i in range(80):
    outf.write('s.add(z3.And(32 <= x[' + str(i) + '], x[' + str(i) + '] <= 126))' + '\n')


outf.write('\n\n# add known constraints\n')
with open('../rev3.cpp') as inf:
    for line in inf.readlines():
        if '    check_eq' in line:
            match = re.match(r'    check_eq\((.*), (.*)\);', line)
            eql = match.group(1)
            eqr = match.group(2)
            outf.write('s.add(' + eql + ' % mod == ' + eqr + ')' + '\n')


outf.write(
'''\n\n# solve the problem
assert(s.check())
res = s.model()
''')


outf.write('\n\n# create msg\n')
outf.write('msg = \'\'.join(map(chr, [' + ', '.join(['res[x[' + str(i) + ']].as_long()' for i in range(80)]) + ']))' + '\n')


outf.write(
'''\n\n# save serial number
with open('sn3-3.txt', 'w') as outf:
    outf.write(msg + '\\n')
''')


outf.write(
'''\n\n# send something
data = client_socket.recv(1024)
client_socket.send(msg + '\\n')


# Catch the flag
data = client_socket.recv(1024)
with open('ans3-3.txt', 'w') as outf:
    outf.write(data)
''')


outf.close()
