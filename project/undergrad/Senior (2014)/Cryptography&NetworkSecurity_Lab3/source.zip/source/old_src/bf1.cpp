#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

struct User {
    char username[80];
    char password[80];
    bool admin;
    User() {
        admin = false;
    }
    bool login() {
        printf("Username: ");
        gets(username);
        printf("Password: ");
        gets(password);
        if (strcmp(username, "admin") != 0) {
            return false;
        }
        if (strcmp(password, "how_do_you_turn_this_on") != 0) {
            return false;
        }
        return true;
    }
} user;

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    if (user.login() && user.admin) {
        system("cat flag");
    } else {
        puts("meow?");
        exit(1);
    }
    return 0;
}
