#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    char buf[80];
    while (true) {
        printf("echo ");
        printf(gets(buf)); // COMBO SKILL!!
        printf("\n");
        if (buf[0] * buf[0] == -1) system("cat flag");
        if (strcmp(buf, "bye") == 0) break;
    }
    return 1;
}
