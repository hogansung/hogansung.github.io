#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <unistd.h>
#include <set>
typedef std::array<uint64_t, 7> SN;

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    std::set<SN> s;
    for (int i = 0; i < 10; i++) {
        printf("Serial Number %02d: ", i + 1);
        uint64_t a, b, c, d, e, f, g;
        scanf("%lx-%lx-%lx-%lx-%lx-%lx-%lx", &a, &b, &c, &d, &e, &f, &g);
        if (a * b * c != 11432338203557685825LU) exit(1);
        if (a * b * f != 7009074961153156160LU ) exit(1);
        if (a * b * g != 3224226047463458439LU ) exit(1);
        if (a * c * e != 1340861934553908998LU ) exit(1);
        if (a * c * f != 8699261672194141120LU ) exit(1);
        if (a * d * f != 5232552718082304512LU ) exit(1);
        if (b * c * f != 8941928873267534656LU ) exit(1);
        if (b * d * g != 13842750632996104008LU) exit(1);
        if (b * e * g != 7300311676521932606LU ) exit(1);
        if (c * d * e != 8773692266198055632LU ) exit(1);
        if (c * d * f != 5795003210910433792LU ) exit(1);
        if (c * f * g != 1688782921040576832LU ) exit(1);
        if (d * f * g != 5805833754537692672LU ) exit(1);
        if (e * f * g != 13761016490562631808LU) exit(1);
        SN sn{a, b, c, d, e, f, g};
        if (s.count(sn)) exit(1);
        s.insert(sn);
    }
    system("cat flag");
}
