#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

uint32_t magic;

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    char buf[80];
    printf("echo ");
    fgets(buf, sizeof(buf), stdin);
    printf(buf);
    if (strlen(buf) > sizeof(buf)) magic = 0xFACEB00C;
    if (magic == 0xFACEB00C) system("cat flag");
    else exit(1);
    return 0;
}
