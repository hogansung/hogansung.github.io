#include <cassert>
#include <cstdio>
#include <unistd.h>

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    char flag[80], buf[80];
    FILE *fp = fopen("flag", "r");
    assert(fp != NULL);
    fgets(flag, sizeof(flag), fp);
    printf("echo ");
    fgets(buf, sizeof(buf), stdin);
    printf(buf);
    return 0;
}
