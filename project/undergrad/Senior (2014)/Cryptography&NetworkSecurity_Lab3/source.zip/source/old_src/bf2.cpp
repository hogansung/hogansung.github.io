#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <openssl/md5.h>

void readline(char *buf, int len) {
    int pos = 0;
    while (pos < len) {
        int c = getchar();
        if (c == EOF || c == '\n') break;
        buf[pos++] = c;
    }
    buf[pos] = '\0';
}

struct User {
    char username[80];
    char password[80];
    char credential[200];
    uint32_t admin;
    User() {
        admin = 0;
    }
    bool login() {
        printf("Username: ");
        readline(username, sizeof(username));
        printf("%d\n", sizeof(username));
        printf("Password: ");
        readline(password, sizeof(password));
        strcpy(credential, "sa1t");
        strcat(credential, ":");
        strcat(credential, username);
        strcat(credential, ":");
        strcat(credential, password);
        auto md5 = MD5((unsigned char*)credential, strlen(credential), NULL);
        if (memcmp(md5, "It is incredible", MD5_DIGEST_LENGTH) == 0) {
            admin = 0xDEADBEEF;
        }
        fprintf(stderr, "user %d %s\n", strlen(username), username);
        fprintf(stderr, "pass %d %s\n", strlen(password), password);
        fprintf(stderr, "cred %s\n", credential);
        fprintf(stderr, "admin %08x\n", admin);
        return true;
    }
} user;

int main() {
    alarm(60);
    setbuf(stdout, NULL);
    if (user.login() && user.admin == 0xDEADBEEF) {
        system("cat flag");
    } else {
        puts("meow?");
        exit(1);
    }
    return 0;
}
