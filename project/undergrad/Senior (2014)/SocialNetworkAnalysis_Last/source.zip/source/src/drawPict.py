#!/usr/bin/python

import sys
import math
import matplotlib.pyplot as plt

DATA = ['O_Loc_F+Graph_F', 'Graph_F', 'O_Loc_F', 'ON_Loc_F+Graph_F', 'ONLoc_F']

#G_RF_TRAIN   = [1.0, 0.9927546286364001, 1.0, 1.0, 1.0]
#G_GBM_TRAIN  = [0.909474662089, 0.889070926792, 0.789329222373, 0.910540211045, 0.796654642373 ]
#G_RF_TEST    = [0.9033215177039999, 0.8795050229614001, 0.7812904891106, 0.90429634231, 0.787046938667]
#G_GBM_TEST   = [0.899927434544, 0.881946502907, 0.777462368098, 0.900638988906, 0.782720691223]

#B_RF_TRAIN   = [1.0, 0.988452882221, 0.999089091257, 1.0, 0.999138207569]
#B_GBM_TRAIN  = [0.86042544638, 0.837264233579, 0.789329222373, 0.863256408324, 0.73483603361]
#B_RF_TEST    = [0.843091346116, 0.816264300887, 0.69802460451, 0.846020552254, 0.712224064687]
#B_GBM_TEST   = [0.833875055803, 0.818228900742, 0.777462368098, 0.835196736337, 0.689111949414]

SG_RF_TEST  = [0.903322, 0.870595, 0.781290, 0.904296, 0.787047]
SG_GBM_TEST = [0.898379, 0.878609, 0.773823, 0.898359, 0.779512]
SB_RF_TEST  = [0.860581, 0.835733, 0.762521, 0.864703, 0.767030]
SB_GBM_TEST = [0.859176, 0.839079, 0.762909, 0.860194, 0.763152]


def draw_TEST(RF_TEST, GBM_TEST, STAT):
    plt.plot(range(len(RF_TEST)), RF_TEST , 's-', lw = 6, markersize = 15, label = 'RF')
    plt.plot(range(len(GBM_TEST)), GBM_TEST , 'D-', lw = 6, markersize = 15, label = 'GBM')
    plt.xticks(range(len(RF_TEST)), DATA)
    plt.legend(loc = 3)
    plt.xlabel(STAT)
    plt.ylabel('Accuracy')
    plt.show()


def draw(TRAIN, TEST, STAT):
    plt.plot(range(len(TRAIN)), TRAIN, 's-', lw = 6, markersize = 15, label = 'Train predict Train')
    plt.plot(range(len(TEST)), TEST , 'D-', lw = 6, markersize = 15, label = 'Test  predict Test ')
    plt.xticks(range(len(TRAIN)), DATA)
    plt.legend(loc = 3)
    plt.xlabel(STAT)
    plt.ylabel('Accuracy')
    plt.show()


def main():
    #draw(G_RF_TRAIN, G_RF_TEST, 'RF on Gowalla data')
    #draw(G_GBM_TRAIN, G_GBM_TEST, 'GBM on Gowalla data')
    draw_TEST(SG_RF_TEST, SG_GBM_TEST, 'Compare RF and GBM on Stitched Gowalla data')

    #draw(B_RF_TRAIN, B_RF_TEST, 'RF on Brightkite data')
    #draw(B_GBM_TRAIN, B_GBM_TEST, 'GBM on Brightkite data')
    draw_TEST(SB_RF_TEST, SB_GBM_TEST, 'Compare RF and GBM on Stitched Brightkie data')


if __name__ == '__main__':
    main()
