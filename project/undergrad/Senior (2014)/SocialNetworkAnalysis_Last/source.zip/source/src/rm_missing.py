if __name__ == '__main__':
    with open('../sdata/test.dat') as tfile:
        with open('../cdata/test.dat', 'w') as ofile:
            line_cnt = 0
            missing_cnt = 0
            for line in tfile:
                line_cnt += 1
                for f in line.split()[1:]:
                    if int(f.split(':')[0]) > 11:
                        ofile.write(line)
                        missing_cnt -= 1
                        break
            print 1.0 * (missing_cnt + line_cnt) / line_cnt
