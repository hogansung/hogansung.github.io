if __name__ == '__main__':
    with open('../cdata/subtest.dat') as tfile:
        with open('../npdata/subtest.dat', 'w') as ofile:
            line_cnt = 0
            np_cnt = 0
            for line in tfile:
                line = line.strip()
                line_cnt += 1
                if (int((line.split(' ')[1]).split(':')[0]) > 11):
                    np_cnt += 1

                ofile.write(line.split(' ')[0])

                for f in line.split()[1:]:
                    idx = int(f.split(':')[0])
                    val = float(f.split(':')[1])
                    if idx > 11:
                        ofile.write(' ' + str(idx - 11) + ':' + str(val))
                ofile.write('\n')

            print 1.0 * np_cnt / line_cnt
