if __name__ == '__main__':
    with open('../cdata/subtrain.dat') as tfile:
        with open('../ccdata/subtrain.dat', 'w') as ofile:
            line_cnt = 0
            np_cnt = 0
            for line in tfile:
                line_cnt += 1
                if (int((line.split(' ')[1]).split(':')[0]) > 11):
                    np_cnt += 1
                    continue
                else:
                    ofile.write(line)

            print 1.0 * np_cnt / line_cnt
