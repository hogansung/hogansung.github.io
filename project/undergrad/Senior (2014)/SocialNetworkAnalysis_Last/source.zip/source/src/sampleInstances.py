#!/ur/bin/python

import sys
import random
import Queue
import collections
import networkx as nx
import numpy as np


CHECKIN_FILE = '../data/st_loc-gowalla_totalCheckins.txt'
EDGE_FILE = '../data/loc-gowalla_edges.txt'

INSTANCE_FILE = '../data/st_gowalla_instances'
SHARE_EDGE_FILE = '../data/st_gowalla_share_edges'

SAMPLE_NEG_RATE = 0.003
SAMPLE_POS_RATE = 0.2
MAXNODE = 196590

USER_LOC = collections.defaultdict(set)         # 107092, max 196590
LOC_USER = collections.defaultdict(set)         # 1280969, max 5977757
EDGES = []
SAMPLE_INSTANCE = []
SHARE_EDGES = []
GRAPH = nx.Graph()


def readData():
    global USER_LOC, LOC_USER
    with open(CHECKIN_FILE, 'r') as f:
        for line in f.readlines():
            inst = line.strip().split('\t')
            USER_LOC[int(inst[0])].add(inst[4])
            LOC_USER[inst[4]].add(int(inst[0]))

    global EDGES
    with open(EDGE_FILE, 'r') as f:
        for line in f.readlines():
            inst = line.strip().split('\t')
            EDGES.append(map(int, inst))


def samplePosInstances():
    cnt = 0
    for inst in EDGES:
        GRAPH.add_edge(inst[0], inst[1])
        if (len(USER_LOC[inst[0]] & USER_LOC[inst[1]]) > 0):
            cnt = cnt + 1
            if random.random() < SAMPLE_POS_RATE:
                SAMPLE_INSTANCE.append([inst[0], inst[1], 1])
            else:
                SHARE_EDGES.append(inst)
        else: 
            SHARE_EDGES.append(inst)
    print 'qualified edges: ', cnt


def sampleNegInstances():
    neighbors_set = [set(GRAPH.neighbors(i)) for i in range(MAXNODE + 1)]
    print 'finish create neigbors'

    cnt = 0
    for loc, user_set in LOC_USER.iteritems():
        for i in user_set:
            for j in user_set:
                if i != j and i not in neighbors_set[j] and len(neighbors_set[i] & neighbors_set[j]) > 0:
                    cnt = cnt + 1
                    if random.random() < 0.003:
                        SAMPLE_INSTANCE.append([i, j, 0])
    print 'neg instances: ', cnt 


def writeData():
    with open(SHARE_EDGE_FILE, 'w') as f:
        f.write('\n'.join(str(u) + ' ' + str(v) for u, v in SHARE_EDGES))

    with open(INSTANCE_FILE, 'w') as f:
        f.write('\n'.join(str(u) + ' ' + str(v) + ' ' + str(y) for u, v, y in SAMPLE_INSTANCE))


def main():
    readData()
    print 'finish read data'

    samplePosInstances()
    print 'finish samplePosInstances'

    sampleNegInstances()
    print 'finish sampleNegInstances'

    writeData()
    print 'finish write data'


if __name__ == '__main__':
    main()
