#!/usr/bin/python

import sys
import time
import math
import random
import collections
import matplotlib.pyplot as plt
import networkx as nx
import scipy.sparse as sps


INF = 1e10

TRAIN_EDGE_FILE = '../Gowalla_new/link_prediction/gowalla.train.txt'
TEST_EDGE_FILE = '../Gowalla_new/link_prediction/gowalla.test.txt'
USER_FILE = '../Gowalla_new/link_prediction/users_info_new.dat'
CHECKIN_FILE = '../loc-gowalla_totalCheckins.txt'

SUBTRAIN_OUTPATH = '../data/subtrain.dat'
SUBTEST_OUTPATH = '../data/subtest.dat'
TRAIN_OUTPATH = '../data/train.dat'
TEST_OUTPATH = '../data/test.dat'


SUBTRAIN_GRAPH = nx.Graph()
SUBTRAIN_DATA = []
SUBTEST_DATA = []
TRAIN_GRAPH = nx.Graph()
TRAIN_DATA = []
TEST_DATA = []


# user: list(time, location)
CHECKIN_INFO = collections.defaultdict(list)

# location: lat, lng
LOCATION_INFO = {}

# user: location
MOST_FREQ_LOCATION = {}

# user: location: times
TABLE = collections.defaultdict(lambda: collections.defaultdict(int))

# location: user: times
REVERSE_TABLE = collections.defaultdict(lambda: collections.defaultdict(int))

# user: location_times ^ 2
INST_SQUARE = collections.defaultdict(float)

# location: entropy
ENTROPY = collections.defaultdict(float)


def readData():
    global CHECKIN_INFO, LOCATION_INFO
    with open(CHECKIN_FILE, 'r') as f:
        for line in f.readlines():
            inst = line.strip().split('\t')
            CHECKIN_INFO[int(inst[0])].append([time.mktime(time.strptime(inst[1], '%Y-%m-%dT%H:%M:%SZ')), int(inst[4])])
            LOCATION_INFO[int(inst[4])] = [float(inst[2]), float(inst[3])] 

    global SUBTRAIN_GRAPH, SUBTEST_GRAPH, TRAIN_GRAPH, TEST_GRAPH
    with open(TRAIN_EDGE_FILE, 'r') as f:
        for line in f.readlines():
            inst = [int(t) for t in line.strip().split('\t')]
            TRAIN_DATA.append(inst)
            if (inst[2] == 1):
                TRAIN_GRAPH.add_edge(int(inst[0]), int(inst[1]))

            if (random.random() < 0.632):
                SUBTRAIN_DATA.append(inst)
                if (inst[2] == 1):
                    SUBTRAIN_GRAPH.add_edge(inst[0], inst[1])
            else:
                SUBTEST_DATA.append(inst)

    with open(TEST_EDGE_FILE, 'r') as f:
        for line in f.readlines():
            inst = [int(t) for t in line.strip().split('\t')]
            TEST_DATA.append(inst)


def createTable():
    global TABLE, INST_SQUARE
    for user, TPList in CHECKIN_INFO.iteritems():
        for TP in TPList:
            TABLE[user][TP[1]] += 1
            REVERSE_TABLE[TP[1]][user] += 1
        for v in TABLE[user].itervalues():
            INST_SQUARE[user] += v * v;
        
    for pos, user_times in REVERSE_TABLE.iteritems():
        totalTime = sum(user_times.values())
        for times in user_times.itervalues():
            q = 1.0 * times / totalTime
            ENTROPY[pos] -= q * math.log(q)

    for user, location_times in TABLE.iteritems():
        MOST_FREQ_LOCATION[user] = max(location_times.iterkeys(), key = (lambda key: location_times[key]))


def calLocationDist(loc0, loc1):
    return math.sqrt( (LOCATION_INFO[loc0][0] - LOCATION_INFO[loc1][0]) * (LOCATION_INFO[loc0][0] - LOCATION_INFO[loc1][0])
                    + (LOCATION_INFO[loc0][1] - LOCATION_INFO[loc1][1]) * (LOCATION_INFO[loc0][1] - LOCATION_INFO[loc1][1]) )


def createFeatures(data, graph, path):
    with open(path, 'w') as f:
        for inst in data:
            ID = []
            X = []
            if (inst[0] in TABLE.keys() and inst[1] in TABLE.keys()):
                intersect_p = set(TABLE[inst[0]].keys()) & set(TABLE[inst[1]].keys())
                union_p = set(TABLE[inst[0]].keys()) | set(TABLE[inst[1]].keys())

                # place features
                common_p = len(intersect_p)
                overlap_p = 1.0 * common_p / len(union_p)
                w_common_p = 0
                for t in intersect_p:
                    w_common_p += TABLE[inst[0]][t] * TABLE[inst[1]][t]
                w_overlap_p = 1.0 * w_common_p / math.sqrt(INST_SQUARE[inst[0]] * INST_SQUARE[inst[1]])
                aa_ent = 0
                for t in intersect_p:
                    aa_ent += 1.0 / ENTROPY[t]
                min_ent = min([ENTROPY[t] for t in intersect_p] + [INF])
                aa_p = 0
                for t in intersect_p:
                    aa_p += 1.0 / math.log(sum(REVERSE_TABLE[t].values()))
                min_p = min([sum(REVERSE_TABLE[t].values()) for t in intersect_p] + [INF])

                # global features
                geodist = calLocationDist(MOST_FREQ_LOCATION[inst[0]], MOST_FREQ_LOCATION[inst[1]])
                w_geodist = 1.0 * geodist / (TABLE[inst[0]][MOST_FREQ_LOCATION[inst[0]]] * TABLE[inst[1]][MOST_FREQ_LOCATION[inst[1]]])
                pp = len(TABLE[inst[0]].keys()) * len(TABLE[inst[0]].keys())

                # merge features
                ID += range(1, 12)
                X += [common_p, overlap_p, w_common_p, w_overlap_p, aa_ent, min_ent, aa_p, min_p, geodist, w_geodist, pp]


            if (graph.has_node(inst[0]) and graph.has_node(inst[1])):
                # social features
                common_n = len(list(nx.common_neighbors(graph, inst[0], inst[1])))
                overlap_n = 1.0 * common_n / (nx.degree(graph, inst[0]) + nx.degree(graph, inst[1]) - common_n)
                aa_n = 0
                for cn in nx.common_neighbors(graph, inst[0], inst[1]): 
                    aa_n += 1.0 / math.log(nx.degree(graph, cn))

                # global features
                pa = nx.degree(graph, inst[0]) * nx.degree(graph, inst[1])

                # additional features
                jac_coef = 1.0 * common_n / overlap_n
                inv_deg_sum = 1.0 / nx.degree(graph, inst[0]) + 1.0 / nx.degree(graph, inst[1])
                
                # merge features
                ID += range(12, 16)
                X += [common_n, overlap_n, aa_n, pa, jac_coef, inv_deg_sum]


            y = inst[2]

            # write features
            output = ' '.join([str(y)] + [':'.join(str(i) for i in p) for p in zip(ID, X)] +  ['\n'])
            f.write(output)
        
def main():
    readData()
    print 'finish read data'

    createTable()
    print 'finish create table'

    createFeatures(SUBTRAIN_DATA, SUBTRAIN_GRAPH, SUBTRAIN_OUTPATH)
    print 'finish create subtrain'

    createFeatures(SUBTEST_DATA, SUBTRAIN_GRAPH, SUBTEST_OUTPATH)
    print 'finish create subtest'

    createFeatures(TRAIN_DATA, TRAIN_GRAPH, TRAIN_OUTPATH)
    print 'finish create train'

    createFeatures(TEST_DATA, TRAIN_GRAPH, TEST_OUTPATH)
    print 'finish create test'


if __name__ == '__main__':
    main()

