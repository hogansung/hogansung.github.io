#!/usr/bin/python

import sys
import time
import math
import random
import collections
import matplotlib.pyplot as plt
import networkx as nx
import scipy.sparse as sps


SHARE_EDGE_FILE = '../data/st_gowalla_share_edges'
INSTANCE_FILE = '../data/st_gowalla_instances'
CHECKIN_FILE = '../data/st_loc-gowalla_totalCheckins.txt'
FEATURE_FILE = '../data/st_gowalla_features'


GRAPH = nx.Graph()
INSTANCE_DATA = []


# user: list(time, location)
CHECKIN_INFO = collections.defaultdict(list)

# location: lat, lng
LOC_INFO = {}

# user: location
MOST_FREQ_LOC = {}

# user: location: times
USER_LOC_TIMES = collections.defaultdict(lambda: collections.defaultdict(int))

# location: user: times
LOC_USER_TIMES = collections.defaultdict(lambda: collections.defaultdict(int))

# user: location_times ^ 2
USER_LOC_SQT = collections.defaultdict(float)

# location: entropy
ENTROPY = collections.defaultdict(float)


def readData():
    global CHECKIN_INFO, LOC_INFO
    with open(CHECKIN_FILE, 'r') as f:
        for line in f.readlines():
            inst = line.strip().split('\t')
            CHECKIN_INFO[int(inst[0])].append([time.mktime(time.strptime(inst[1], '%Y-%m-%dT%H:%M:%SZ')), inst[4]])
            LOC_INFO[inst[4]] = [float(inst[2]), float(inst[3])] 

    global GRAPH
    with open(SHARE_EDGE_FILE, 'r') as f:
        for line in f.readlines():
            inst = [int(t) for t in line.strip().split()]
            GRAPH.add_edge(inst[0], inst[1])

    global INSTANCE_DATA
    with open(INSTANCE_FILE, 'r') as f:
        for line in f.readlines():
            inst = [int(t) for t in line.strip().split()]
            INSTANCE_DATA.append(inst)
    

def createTable():
    global USER_LOC, USER_LOC_SQT
    for user, TPList in CHECKIN_INFO.iteritems():
        for TP in TPList:
            USER_LOC_TIMES[user][TP[1]] += 1
            LOC_USER_TIMES[TP[1]][user] += 1
        for v in USER_LOC_TIMES[user].itervalues():
            USER_LOC_SQT[user] += v * v;
        
    for pos, user_times in LOC_USER_TIMES.iteritems():
        totalTime = sum(user_times.values())
        for times in user_times.itervalues():
            q = 1.0 * times / totalTime
            ENTROPY[pos] -= q * math.log(q)

    for user, location_times in USER_LOC_TIMES.iteritems():
        MOST_FREQ_LOC[user] = max(location_times.iterkeys(), key = (lambda key: location_times[key]))


def calLocationDist(loc0, loc1):
    return math.sqrt( (LOC_INFO[loc0][0] - LOC_INFO[loc1][0]) * (LOC_INFO[loc0][0] - LOC_INFO[loc1][0])
                    + (LOC_INFO[loc0][1] - LOC_INFO[loc1][1]) * (LOC_INFO[loc0][1] - LOC_INFO[loc1][1]) )


def createFeatures():
    with open(FEATURE_FILE, 'w') as f:
        for inst in INSTANCE_DATA:
            assert(inst[0] in USER_LOC_TIMES.keys() and inst[1] in USER_LOC_TIMES.keys())

            XID = []
            X = []
            
            intersect_p = set(USER_LOC_TIMES[inst[0]].keys()) & set(USER_LOC_TIMES[inst[1]].keys())
            union_p = set(USER_LOC_TIMES[inst[0]].keys()) | set(USER_LOC_TIMES[inst[1]].keys())
            assert(len(intersect_p) > 0)

            # place features
            common_p = len(intersect_p)
            overlap_p = 1.0 * common_p / len(union_p)
            w_common_p = 0
            for t in intersect_p:
                w_common_p += USER_LOC_TIMES[inst[0]][t] * USER_LOC_TIMES[inst[1]][t]
            w_overlap_p = 1.0 * w_common_p / math.sqrt(USER_LOC_SQT[inst[0]] * USER_LOC_SQT[inst[1]])
            aa_ent = 0
            for t in intersect_p:
                aa_ent += 1.0 / ENTROPY[t]
            min_ent = min([ENTROPY[t] for t in intersect_p])
            aa_p = 0
            for t in intersect_p:
                aa_p += 1.0 / math.log(sum(LOC_USER_TIMES[t].values()))
            min_p = min([sum(LOC_USER_TIMES[t].values()) for t in intersect_p])

            # global features
            geodist = calLocationDist(MOST_FREQ_LOC[inst[0]], MOST_FREQ_LOC[inst[1]])
            w_geodist = 1.0 * geodist / (USER_LOC_TIMES[inst[0]][MOST_FREQ_LOC[inst[0]]] * USER_LOC_TIMES[inst[1]][MOST_FREQ_LOC[inst[1]]])
            pp = len(USER_LOC_TIMES[inst[0]].keys()) * len(USER_LOC_TIMES[inst[0]].keys())

            # merge features
            XID += range(1, 12)
            X += [common_p, overlap_p, w_common_p, w_overlap_p, aa_ent, min_ent, aa_p, min_p, geodist, w_geodist, pp]


            if (GRAPH.has_node(inst[0]) and GRAPH.has_node(inst[1])):
                # social features
                common_n = len(list(nx.common_neighbors(GRAPH, inst[0], inst[1])))
                overlap_n = 1.0 * common_n / (nx.degree(GRAPH, inst[0]) + nx.degree(GRAPH, inst[1]) - common_n)
                aa_n = 0
                for cn in nx.common_neighbors(GRAPH, inst[0], inst[1]): 
                    aa_n += 1.0 / math.log(nx.degree(GRAPH, cn))

                # global features
                pa = nx.degree(GRAPH, inst[0]) * nx.degree(GRAPH, inst[1])

                # additional features
                jac_coef = 1.0 * common_n / (nx.degree(GRAPH, inst[0]) + nx.degree(GRAPH, inst[1]) - common_n)
                inv_deg_sum = 1.0 / nx.degree(GRAPH, inst[0]) + 1.0 / nx.degree(GRAPH, inst[1])
                
                # merge features
                XID += range(12, 18)
                X += [common_n, overlap_n, aa_n, pa, jac_coef, inv_deg_sum]


            # write features
            output = ' '.join([str(inst[2])] + [':'.join(str(i) for i in p) for p in zip(XID, X)] +  ['\n'])
            f.write(output)
        

def main():
    readData()
    print 'finish read data'

    createTable()
    print 'finish create table'

    createFeatures()
    print 'finish create instances'


if __name__ == '__main__':
    main()

