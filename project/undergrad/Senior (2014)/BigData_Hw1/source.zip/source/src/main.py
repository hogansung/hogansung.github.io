#!/bin/bash

# cost:     11564
# visit:    8257
# rev:      6998


from datetime import datetime
from collections import defaultdict
from bisect import bisect_left

startDay = datetime.strptime('2013-12-01', '%Y-%m-%d')

loc_costSum = defaultdict(int)
loc_costCnt = defaultdict(int)
loc_visitCnt = defaultdict(int) # non-personal

mediaSet = set()
locSet = set()

def parseData():
    # load data
    data = []
    with open('../dat/analysis.txt') as f:
        for line in f.readlines():
            kind, media, loc, time, money = line.strip().split()
            time = (datetime.strptime(time, '%Y-%m-%d') - startDay).days
            data.append([kind, media, loc, time, int(money)])
            mediaSet.add(media)
            locSet.add(loc)
    data = sorted(data, key=lambda x: x[3])
    mediaList = list(sorted(mediaSet))
    locList = list(sorted(locSet))
    print len(mediaList)
    print len(locList)

    # generate data
    trainFlag = 0
    tnX = []
    tnY = []
    ttX = []
    ttY = []
    for inst in data:
        kind, media, loc, time, money = inst
        if kind == 'cost':
            loc_costSum[loc] += money
            loc_costCnt[loc] += 1
        elif kind == 'visit':
            loc_visitCnt[loc] += 1
        else:
            mediaBin = [0 for i in xrange(len(mediaList))]
            mediaBin[bisect_left(mediaList, media)] = 1
            locBin = [0 for i in xrange(len(locList))]
            locBin[bisect_left(locList, loc)] = 1

            if trainFlag < 5000:
                tnX.append(mediaBin + locBin + [time, loc_costSum[loc], loc_costCnt[loc], loc_visitCnt[loc]])
                tnY.append(money)
            else:
                ttX.append(mediaBin + locBin + [time, loc_costSum[loc], loc_costCnt[loc], loc_visitCnt[loc]])
                ttY.append(money)
            trainFlag += 1


    # create data
    with open('../dat/tn.svm', 'w') as f:
        for x, y in zip(tnX, tnY):
            f.write(' '.join([str(y)] + [str(i+1) + ':' + str(x[i]) for i in range(len(x))]) + '\n')


parseData()
