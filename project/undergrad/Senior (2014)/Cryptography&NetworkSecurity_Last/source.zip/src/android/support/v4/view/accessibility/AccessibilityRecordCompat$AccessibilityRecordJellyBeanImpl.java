// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.view.View;

// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityRecordCompat, AccessibilityRecordCompatJellyBean

static class  extends 
{

    public void setSource(Object obj, View view, int i)
    {
        AccessibilityRecordCompatJellyBean.setSource(obj, view, i);
    }

    ()
    {
    }
}
