// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.graphics.drawable.Drawable;

// Referenced classes of package android.support.v4.app:
//            ActionBarDrawerToggle

public static interface 
{

    public abstract Drawable getThemeUpIndicator();

    public abstract void setActionBarDescription(int i);

    public abstract void setActionBarUpIndicator(Drawable drawable, int i);
}
