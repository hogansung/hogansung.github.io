// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityNodeInfoCompat, AccessibilityNodeInfoCompatKitKat

static class _cls2Impl extends _cls2Impl
{

    public int getLiveRegion(Object obj)
    {
        return AccessibilityNodeInfoCompatKitKat.getLiveRegion(obj);
    }

    public void setLiveRegion(Object obj, int i)
    {
        AccessibilityNodeInfoCompatKitKat.setLiveRegion(obj, i);
    }

    _cls2Impl()
    {
    }
}
