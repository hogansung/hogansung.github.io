// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.app.Notification;
import android.app.NotificationManager;

// Referenced classes of package android.support.v4.app:
//            NotificationManagerCompat, NotificationManagerCompatEclair

static class A extends A
{

    public void cancelNotification(NotificationManager notificationmanager, String s, int i)
    {
        NotificationManagerCompatEclair.cancelNotification(notificationmanager, s, i);
    }

    public void postNotification(NotificationManager notificationmanager, String s, int i, Notification notification)
    {
        NotificationManagerCompatEclair.postNotification(notificationmanager, s, i, notification);
    }

    A()
    {
    }
}
