#!/bin/bash
export PATH=$PATH:"C:\Users\user\Dropbox\Courses\Junior_2\DSP\Hw2\htk341_win32"
