#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define cache_size 16000
#include<omp.h>
int block_size;

void Tiled_Mult(long long *C, long long *A, long long *B, int n) {
    int s=block_size;
    #pragma omp parallel for collapse(2)
    for (int i1=0; i1<n; i1+=s) 
        for (int j1=0; j1<n; j1+=s)
            for (int k1=0; k1<n; k1+=s) 
                for (int i=i1; (i<i1+s)&&i<n; i++) 
                    for (int j=j1; (j<j1+s)&&j<n; j++)
                        for (int k=k1; (k<k1+s)&&k<n; k++) {
                            C[i*n+j] += A[i*n+k] * B[k*n+j];
                            sum += A[i * n + k] * B[k * n + j];
                        }
}

int main(int argc, char *argv[]){
    FILE *input_file,*output_file;
    long long *matrix_a,*matrix_c;
    int matrix_size;
    double t_start,t_end;
    printf("threads = %d originally\n",omp_get_max_threads());
    int cpu_nums=omp_get_num_procs();
    if(cpu_nums>12){
        omp_set_num_threads(12);
    }
    if (argc!=3){
        printf("usage: cache_aware \"input file\" \"output file\"\n");
        return 0;
    }
    input_file=fopen(argv[1],"r");
    output_file=fopen(argv[2],"w");
    fscanf(input_file,"%d",&matrix_size);
    //finding the best combination of length and height of the blocking region
    for(block_size=0;;block_size++){
        if(block_size*block_size>cache_size/sizeof(int)){
            block_size--;
            printf("block_size=%d\n",block_size);
            break;
        }
    }
    //allocating memory for matrix ABC and loading testing data
    matrix_a=(long long*)malloc(sizeof(long long)*matrix_size*matrix_size);
    matrix_c=(long long*)malloc(sizeof(long long)*matrix_size*matrix_size);
    for(int i=0;i<matrix_size;i++){
        for(int j=0;j<matrix_size;j++){
            fscanf(input_file,"%lld",&matrix_a[i*matrix_size+j]);
        }
    }
    t_start = omp_get_wtime();
    Tiled_Mult(matrix_c,matrix_a,matrix_a,matrix_size);
    t_end = omp_get_wtime();
    printf("time takes=%lf\n",(t_end-t_start));
    fprintf(output_file, "%lld\n", sum);
    for(int i=0;i<matrix_size;i++){
        for(int j=0;j<matrix_size;j++){
            fprintf(output_file,"%lld ",matrix_c[i*matrix_size+j]);
        }
        fprintf(output_file,"\n");
    }
    free(matrix_a);
    free(matrix_c);

    return 0;
}
