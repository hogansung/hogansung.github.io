#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

using namespace std;

const string numName = "tmp/num.txt";
const string courseName = "tmp/course";
const string scoreName = "tmp/score";
const int BUFFER_SIZE = 1024;


string parseCourse(char buf[]) {
    int len = strlen(buf);
    int alpha = 0;
    int num = 0;
    string ret = string();

    for (int i = 0; i < len; i++) {
        if (isalpha(buf[i])) {
            ret.push_back(buf[i]);
            alpha++;
            num = 0; // TT9999
        }
        else if (isdigit(buf[i])) {
            ret.push_back(buf[i]);
            num++;
        }
    }

    if (num != 4) return string();
    else return ret;
}

string parseScore(char buf[]) {
    int len = strlen(buf);
    string ret = string();

    if (len > 0 && buf[0] == '#') return string("#");
    else if (len > 0 && buf[0] == 'A' || buf[0] == 'B' || buf[0] == 'C' || buf[0] == 'F') {
        ret.push_back(buf[0]);
        if (len > 1 && (buf[1] == '+')) ret.push_back('+');
        else if (len > 1 && (buf[1] == '-' || buf[1] == '_')) ret.push_back('-');
        return ret;
    }
    else return string();
}

int main(int argc, char *argv[]) {
    char studentID[BUFFER_SIZE];

    if (argc < 2) {
        fprintf(stderr, "Parse argument error.\n");
        exit(EXIT_FAILURE);
    }

    int entries = atoi(argv[1]);
    

    // read numName
    FILE *nFile = fopen(numName.c_str(), "r");
    if (nFile == NULL) {
        fprintf(stderr, "Open %s failed.\n", numName.c_str());
        exit(EXIT_FAILURE);
    }
    fscanf(nFile, "%s", studentID);

    int len = strlen(studentID);
    for (int i = 1; i < len; i++) {
        if (studentID[i] == 'O') studentID[i] = '0';
        else if (studentID[i] == 'I') studentID[i] = '1';
    }

    fclose(nFile);

    
    // open output file
    string outFile = "res/" + string(studentID) + ".txt";
    freopen(outFile.c_str(), "w", stdout);


    // read course, score file
    for (int i = 0; i < entries; i++) {
        char tmpName[BUFFER_SIZE];
        char buf[BUFFER_SIZE];


        // courseINFO 
        sprintf(tmpName, "%s_%d.txt", courseName.c_str(), i);
        FILE *cFile = fopen(tmpName, "r");
        if (cFile == NULL) {
            fprintf(stderr, "Open %s failed.\n", tmpName);
            exit(EXIT_FAILURE);
        }
        fgets(buf, BUFFER_SIZE, cFile);
        string cret = parseCourse(buf);
        fclose(cFile);

    
        // scoreINFO
        sprintf(tmpName, "%s_%d.txt", scoreName.c_str(), i);
        FILE *sFile = fopen(tmpName, "r");
        if (sFile == NULL) {
            fprintf(stderr, "Open %s failed.\n", tmpName);
            exit(EXIT_FAILURE);
        }
        fgets(buf, BUFFER_SIZE, sFile);
        string sret = parseScore(buf);
        fclose(cFile);


        // printINFO
        if (cret.length() != 0 && sret.length() != 0) fprintf(stdout, "%s,%s,%s\n", studentID, cret.c_str(), sret.c_str());
        else if (cret.length() != 0 && sret.length() == 0) fprintf(stdout, "%s,%s,%s\n", studentID, cret.c_str(), "X");
    }
}
