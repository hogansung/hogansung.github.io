#!/bin/bash

# declaration
numLx=182
numLy=90
numRx=500
numRy=150

courseLx=56
courseLy=409
courseRx=206
courseRy=2592

scoreLx=1040
scoreLy=400
scoreRx=1132
scoreRy=2592

dy=40
entries=53

declare -i numDX
numDX=${numRx}-${numLx}

declare -i numDY
numDY=${numRy}-${numLy}

declare -i courseDX
courseDX=${courseRx}-${courseLx}

declare -i courseDY
courseDY=${courseRy}-${courseLy}

declare -i scoreDX
scoreDX=${scoreRx}-${scoreLx}

declare -i scoreDY
scoreDY=${scoreRy}-${scoreLy}

declare -i numScaleDX
numScaleDX=${numDX}*3/2

declare -i numScaleDY
numScaleDY=${numDY}*3/2

declare -i scoreScaleDX
scoreScaleDX=${scoreDX}*3/2

declare -i scoreScaleDY
scoreScaleDY=${scoreDY}*3/2


# initialize
echo "initialization"
target="data/*"
numName="tmp/num"
courseName="tmp/course"
scoreName="tmp/score"


for f in ${target}
do
    base=$(basename "${f}")
    echo "Now is processing ${base}..."


    # trim
    echo "trim first page of pdf"
    convert -density 300 -quality 100 ${f} -virtual-pixel edge -blur 0x5 -fuzz 15% -trim info: |\
        awk '{ print $4 }' | head -n 1 | xargs -i convert -density 300 -quality 100 ${f} -crop {} +repage tmp/${base}


    # transform
    echo "transform pdf into png"
    convert -density 300 -quality 100 tmp/${base} tmp/${base%.*}.png 


    # split
    echo "begin split image"
    convert tmp/${base%.*}-0.png -crop ${numDX}.x${numDY}+${numLx}+${numLy} -resize ${numScaleDX}x${numScaleDY} ${numName}.png
    convert tmp/${base%.*}-0.png -crop ${courseDX}x${courseDY}+${courseLx}+${courseLy} ${courseName}.png
    convert tmp/${base%.*}-0.png -crop ${scoreDX}x${scoreDY}+${scoreLx}+${scoreLy} ${scoreName}.png


    # parse studentID
    echo "parse stduentID"
    tesseract ${numName}.png ${numName} 1>/dev/null 2>/dev/null


    # split course images
    echo "spliting course images"
    nowCLy=${courseLy}
    for ((i = 0; i < ${entries}; i++))
    do  
        convert ${courseName}.png -crop ${courseDX}x${dy}+${courseLx}+${nowCLy} ${courseName}_${i}.png
        tesseract ${courseName}_${i}.png ${courseName}_${i} 1>/dev/null 2>/dev/null
        
        nowCLy=$(echo ${nowCLy} + ${dy} | bc)

        if [ $(echo ${i} % 2 | bc) -eq "0" ] 
        then
            nowCLy=$(echo ${nowCLy} + 1 | bc)
        fi
    done


    # split score images
    echo "spliting score images"
    nowSLy=${scoreLy}
    for ((i = 0; i < ${entries}; i++))
    do  
        convert ${scoreName}.png -crop ${scoreDX}x${dy}+${scoreLx}+${nowSLy} -resize ${scoreScaleDX}x${scoreScaleDY} ${scoreName}_${i}.png
        tesseract ${scoreName}_${i}.png ${scoreName}_${i} -psm 6 1>/dev/null 2>/dev/null #-l chi_tra
        
        nowSLy=$(echo ${nowSLy} + ${dy} | bc)

        if [ $(echo ${i} % 2 | bc) -eq "0" ] 
        then
            nowSLy=$(echo ${nowSLy} + 1 | bc)
        fi
    done


    # generate file in res
    echo "generate result"
    ./bin/mapping ${entries}
done

# clean all
echo "clean useless data"
#rm tmp/*
