#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <utility>
#include <map>
#include <algorithm>

using namespace std;

const int TIMES = 1e7;
const int LIMIT = 1e6;

map<int, double> m[LIMIT];

int main() {
    srand(time(NULL));

    for (int i = 0; i < TIMES; i++) {
        while (true) {
            int x = rand() % LIMIT;
            int y = rand() % LIMIT;
            double v = (double)(rand() % 2000000000) / 1e6 - 1000;

            if (m[y].count(x) == 0) {
                m[y][x] = v;
                break;
            }
        }

    }

    for (int i = 0; i < LIMIT; i++) {
        for (map<int, double>::iterator it = m[i].begin(); it != m[i].end(); it++) {
            fprintf(stdout, "%d %d %f\n", it->first, i, it->second);
        }
    }
}
