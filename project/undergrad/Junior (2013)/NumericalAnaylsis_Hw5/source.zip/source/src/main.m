function main()

[fid message] = fopen(('ma.txt'), 'r');
if (fid == -1)
    disp(message);
end
ain = textscan(fid, '%f %f %f');

[fid message] = fopen(('mb.txt'), 'r');
if (fid == -1)
    disp(message);
end
bin = textscan(fid, '%f %f %f');

t = cputime; tic;

for i = 1 : size(ain{1}):
    ain{1}(1) = ain{1}(1) + 1;
    ain{2}(1) = ain{2}(1) + 1;

for i = 1 : size(bin{1}):
    bin{1}(1) = bin{1}(1) + 1;
    bin{2}(1) = bin{2}(1) + 1;

sa = sparse(ain{1}, ain{2}, ain{3}, 1000000, 1000000);
sb = sparse(bin{1}, bin{2}, bin{3}, 1000000, 1000000);

ans = sa * sb;

fprintf('CPU time used %f\n', cputime - t);
fprintf('Elapsed time used: %f\n', toc);
