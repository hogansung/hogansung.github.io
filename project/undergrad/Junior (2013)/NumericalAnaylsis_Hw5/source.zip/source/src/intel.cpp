#include <cstdio>
#include <mkl.h>

const int TIMES = 1e7;
const int LIMIT = 1e6;

double av[TIMES];
int at[LIMIT];
int ac[LIMIT + 1];
int ar[TIMES];

double bv[TIMES];
int bc[TIMES];
int bt[LIMIT];
int br[LIMIT + 1];

int main() {
    FILE *fa = fopen("ma.txt", "r");
    FILE *fb = fopen("mb.txt", "r");

    if (fa == NULL || fb == NULL) {
        fprintf(stderr, "File ma.txt or mb.txt cannot open.\n");
        exit(EXIT_FAILURE);
    }

    int x;
    int y;
    double v;

    for (int i = 0; i < TIMES; i++) {
        fscanf(fa, "%d%d%lf", &x, &y, &v);
        ar[i] = x;
        at[y]++;
        av[i] = v;

        fscanf(fb, "%d%d%lf", &x, &y, &v);
        br[i] = x;
        bt[y]++;
        bv[i] = v;
    }

    fclose(fa);
    fclose(fb);

    for (int i = 0; i < LIMIT; i++) {
        ac[i + 1] += ac[i] + at[i];
        bc[i + 1] += bc[i] + bt[i];
    }

    MKL_INT m = LIMIT;
    MKL_INT n = LIMIT;
    MKL_INT k = LIMIT;
    mkl_dcscmm(, )
}
