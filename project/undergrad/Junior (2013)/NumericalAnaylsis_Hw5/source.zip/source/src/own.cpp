#include <cstdio>
#include <cstdlib>
#include <vector>
#include <utility>
#include <map>
#include <algorithm>

using namespace std;

const int TIMES = 1e7;
const int LIMIT = 1e6;

double av[TIMES];
int at[LIMIT];
int ac[LIMIT + 1];
int ar[TIMES];

double bv[TIMES];
int bt[LIMIT];
int bc[TIMES];
int br[LIMIT + 1];

map<int, double> m[LIMIT];
vector<pair<pair<int, int>, double> > vct; 

int main() {
    FILE *fa = fopen("ma.txt", "r");
    FILE *fb = fopen("mb.txt", "r");

    if (fa == NULL || fb == NULL) {
        fprintf(stderr, "File ma.txt or mb.txt cannot open.\n");
        exit(EXIT_FAILURE);
    }

    int x;
    int y;
    double v;

    for (int i = 0; i < TIMES; i++) {
        fscanf(fa, "%d%d%lf", &x, &y, &v);
        ar[i] = x;
        at[y]++;
        av[i] = v;

        fscanf(fb, "%d%d%lf", &x, &y, &v);
        vct.push_back(pair<pair<int, int>, double>(pair<int,int>(x, y), v));
    }

    fclose(fa);
    fclose(fb);

    sort(vct.begin(), vct.end());
    for (int i = 0; i < TIMES; i++) {
        bt[vct[i].first.first]++;
        bc[i] = vct[i].first.second;
        bv[i] = vct[i].second;
    } 


    for (int i = 0; i < LIMIT; i++) {
        ac[i + 1] = ac[i] + at[i];
        br[i + 1] = br[i] + bt[i];
    }

    for (int i = 0; i < LIMIT; i++) {
        for (int j = ac[i]; j < ac[i + 1]; j++) {
            int r = ar[j];
            double va = av[j];

            for (int k = br[i]; k < br[i + 1]; k++) {
                int c = bc[k];
                double vb = bv[k];

                if (m[c].count(r) == 0) {
                    m[c][r] = va * vb;
                }
                else {
                    m[c][r] += va * vb;
                }
            }
        }
    }

    FILE *of = fopen("own.txt", "w");
    if (of == NULL) {
        fprintf(stderr, "Output file cannot open.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < LIMIT; i++) {
        for (map<int, double>::iterator it = m[i].begin(); it != m[i].end(); it++) {
            fprintf(of, "%d %d %.10f\n", it->first, i, it->second);
        }
    }
    fclose(of);
} 
