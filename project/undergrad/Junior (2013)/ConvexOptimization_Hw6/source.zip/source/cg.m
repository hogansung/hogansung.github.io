function s = cg(C, w1, eywx, X, XT, y, ITERMAX, eps)
b = -w1;
l = length(y);

tempd = eywx ./ (ones(l, 1) + eywx).^2;
D = spdiags(tempd, 0, l, l);

r = b;
d = b;
s = 0;
b2 = dot(b, b);
r2 = b2;
for i = 1 : length(b)
	if r2 <= eps^2 * b2
		break;
	end
	t = d + C * (XT * (D * (X * d)));
	alpha = r2 / (d' * t);
	s = s + d * alpha;
	r = r - alpha * t;
	r2_new = dot(r, r);
	beta = r2_new / r2;
	d = r + beta * d;
	r2 = r2_new;
end
