function test()

a = [1, 2, 3];
b = [1, 2, 3];

tic;
a = 2;
b = 3;
disp(2 ^ 2 / b ^ 2);
fprintf('xd %f\n', toc);