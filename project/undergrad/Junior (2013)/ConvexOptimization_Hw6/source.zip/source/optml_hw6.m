addpath('liblinear-1.94/matlab/');

%filepath = 'kddb.t';
filepath = 'kddb';

[y, X] = libsvmread(filepath);

time = cputime;
ITERMAX = 100000;
C = 0.1;
eps = 0.01;
eta = 0.01;
l = length(y);
[n , m] = size(X);
w = zeros([m, 1]);
w10 = 0;

xw = zeros([n, 1]);
fw = C * log(2) * l;

[r, c, v] = find(X);
instsnum = length(v)
w1 = zeros(m, 1);

for k = 1 : ITERMAX
	k
	norm(w1)
	eywx = exp(-y .* xw);
tic;
	%for i = 1 : instsnum
	%	w1(c(i)) = w1(c(i)) + (1 / (1 + eywx(r(i))) - 1) * y(r(i)) * v(i);
	%end
	w1 = w + C * X' * (y .* (ones(n, 1) ./ (ones(n, 1) + eywx) - ones(n, 1)));
toc;
	if k == 1
		w10 = dot(w1, w1);
	end
	disp(dot(w1, w1)/w10);
	if dot(w1, w1) <= eps^2 * w10;
		break;
	end
tic;
	s = cg(C, w1, eywx, X, X', y, instsnum, eps);
toc;
	alpha = 1;
	xs = X * s;
	for i = 1 : ITERMAX
		fnw = sum(log(ones(n, 1) + exp(-y .* (xw + alpha * xs))));
		fnw = C * fnw + 0.5 * (w + alpha * s)' * (w + alpha * s);
		if fnw <= fw + eta * alpha * dot(w1, s)
			fw = fnw;
			break;
		end
		alpha = alpha / 2;
	end
	alpha
	w = w + alpha * s;
	xw = xw + alpha * xs;
end
disp(dot(w1, w1) / w10);
time = cputime - time
