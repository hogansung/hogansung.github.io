function newton()
addpath('liblinear-1.94/matlab/');

tnFile = 'kddb';
ttFile = 'kdda.t';

eps = 0.01;
C = 0.1;
eta = 0.01;
xi = 0.1;

[label, inst] = libsvmread(tnFile);
[n, m] = size(inst);
label = 2 * label - ones(n, 1);

w = zeros([m, 1]); % weight
e = zeros([n, 1]); % e ^ (-y_i * x_i * w')
f = zeros([n, 1]); % e ^ (-y_i * x_i * w') / (1 + e ^ (-y_i * x_i * w')) ^ 2

wx = zeros([n, 1]); % x * w
sx = zeros([n, 1]); % x * s
rf = 0 + C * n * log(2);

gf = zeros([m, 1]); % first gradient order
r = zeros([m, 1]); % CG var
d = zeros([m, 1]); % CG var

CPUTIME = cputime;
TIME = tic;

curIter = 0;
galpha = -1;
while true
	curIter = curIter + 1;
	
	e = exp(-label .* wx);
	f = e ./ (ones(n, 1) + e) .^ 2;
	
	gf = w + C * (inst' * (label .* (ones(n, 1) ./ (ones(n, 1) + e) - ones(n, 1))));
	r = -gf;
	d = -gf;
	if (curIter == 1) 
		gzero = gf;
	end

	
	% stop condition
	fprintf('Iter %d: %f\n', curIter, norm(gf));
	if (norm(gf) <= eps * norm(gzero))
		break
	end
	
	
	% Find s
	s = zeros([m, 1]);
	while norm(r) > xi * norm(gf)
		gs = (d + C * inst' * (f .* (inst * d)));
		
		alpha = norm(r) ^ 2 / (d' * gs);
		s = s + alpha * d;
		nr = r - alpha * gs;
		
		beta = norm(nr) ^ 2 / norm(r) ^ 2;
		d = nr + beta * d;
		r = nr;
	end
	
	
	% Find alpha and update
	alpha = 1.0;
	sx = inst * s; 
	rs = eta * gf' * s;
	
	while true
		left = 0.5 * dot(w + alpha * s, w + alpha * s) + C * (ones(1, n) * log(ones(n, 1) + exp(-label .* (wx + alpha * sx))));
		
		if left <= rf + alpha * rs
			rf = left;
			break;
		else
			alpha = alpha / 2;
		end
	end

	
	% update w, wx
	w = w + alpha * s;
	wx = wx + alpha * sx;
	galpha = alpha;
end


% print statistic
fprintf('CPU time: %f (excluding IO)\n', cputime - CPUTIME);
fprintf('Elapsed time: %f (excluding IO)\n', toc(TIME));
fprintf('Final f(w) value = %f\n', rf);
fprintf('Final step size = %f\n', galpha);
