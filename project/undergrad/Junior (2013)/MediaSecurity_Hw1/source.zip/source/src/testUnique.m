function testUnique(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%

%% test %%
testSimilarity(origfile, markedfile, outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);