function testCropping(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imageCrop = imageOrig(129:384, 129:384, :);
imageWhole = imread(origfile);
imageWhole(129:384, 129:384, :) = imageCrop;
imwrite(imageWhole, '../tmp/image.bmp');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);