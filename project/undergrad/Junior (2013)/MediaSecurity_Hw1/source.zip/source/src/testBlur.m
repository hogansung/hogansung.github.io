function testBlur(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imageFilter = fspecial('disk', 5);
imageBlurred = imfilter(imageOrig, imageFilter, 'replicate');
imwrite(imageBlurred, '../tmp/image.bmp');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);