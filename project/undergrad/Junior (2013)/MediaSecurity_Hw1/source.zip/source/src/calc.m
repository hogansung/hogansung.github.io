function calc()

filename = {'airplane', 'baboon', 'fruits', 'peppers'};
folder = {'0.1', '1', '10', '100'};

for i = 1 : 4
	for j = 1 : 4
		orig = imread(strcat('../data/', filename{i}, '.bmp'));
		mark = imread(strcat('../res/informed_watermark_system/', filename{i}, '/', folder{j}, '/', filename{i}, '_marked.bmp'));
		disp(PSNR(orig, mark));
	end
end