function testRotate(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imageRotate = imrotate(imageOrig, 90);
imageRecover = imrotate(imageRotate, -90);
imwrite(imageRecover, '../tmp/image.bmp');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);
