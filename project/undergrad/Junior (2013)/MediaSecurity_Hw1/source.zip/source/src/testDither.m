function testDither(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageRGB = imread(markedfile);
imageYCBCR = rgb2ycbcr(imageRGB);
imageLumaLayer = imageYCBCR(:, :, 1);
imageDither = dither(imageLumaLayer);
imageYCBCR(:, :, 1) = imageDither * 255;
imageRGB = ycbcr2rgb(imageYCBCR);
imwrite(imageRGB, '../tmp/image.bmp');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);