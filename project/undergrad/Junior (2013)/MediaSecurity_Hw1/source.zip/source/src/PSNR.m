function psnr = PSNR(A, B)

myMax = double(max(A(:)));

square = (double(A) - double(B)) .^2;
[r, c] = size(A);

mse = sum(square(:)) / (r * c);
psnr = 10 * log10(myMax * myMax / mse);
