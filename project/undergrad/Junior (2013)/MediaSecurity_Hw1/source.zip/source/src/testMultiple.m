function testMultiple(origfile, outputfile, imagefile, n, alpha, informed)

%% attack %%
multiplefile = '../tmp/image.bmp';
SpreadSpectrumEmbed(origfile, multiplefile, '../wm/Gaussian100.seq', n, alpha);
SpreadSpectrumEmbed(multiplefile, multiplefile, '../wm/Gaussian200.seq', n, alpha);
SpreadSpectrumEmbed(multiplefile, multiplefile, '../wm/Gaussian400.seq', n, alpha);
SpreadSpectrumEmbed(multiplefile, multiplefile, '../wm/Gaussian700.seq', n, alpha);
SpreadSpectrumEmbed(multiplefile, multiplefile, '../wm/Gaussian800.seq', n, alpha);

%% test %%
testSimilarity(origfile, multiplefile, outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);