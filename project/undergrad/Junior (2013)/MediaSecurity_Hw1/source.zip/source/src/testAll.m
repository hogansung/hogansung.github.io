function testAll(origfile, filename, n, alpha, informed)

%% watermark_num involves textSimilarity.m, drawGraph.m, testCollusion.m, testMultiple.m
%% alpha involves this, testMultiple.m, testCollusion.m

fprintf(2, '%s %s %d %f\n', origfile, filename, n, alpha);

%% first target on airplan.bmp %%
markedfile = strcat(filename, '_marked.bmp');

%% random gaussian %%
%GenerateGaussianSequence(1000, n)
fprintf(2, 'create watermark seq\n');

%% Embed watermark %%
SpreadSpectrumEmbed(origfile, markedfile, '../wm/Gaussian514.seq', n, alpha);
fprintf(2, 'embed watermark\n');

%% test unique %%
%testUnique(origfile, markedfile, strcat(filename, '_simUnique'), strcat(filename, '_uni.bmp'), n, informed);
fprintf(2, 'unique test\n');

%% test scale %%
%testScale(origfile, markedfile, strcat(filename, '_simScale'), strcat(filename, '_scale.bmp'), n, informed);
fprintf(2, 'scale test\n');

%% test rotate %%
%testRotate(origfile, markedfile, strcat(filename, '_simRotate'), strcat(filename, '_rotate.bmp'), n, informed);
fprintf(2, 'rotate test\n');

%% test blur %%
%testBlur(origfile, markedfile, strcat(filename, '_simBlur'), strcat(filename, '_blur.bmp'), n, informed);
fprintf(2, 'blur test\n');

%% test jpeg %%
%testJPEG(origfile, markedfile, strcat(filename, '_simJPEG'), strcat(filename, '_jpeg.bmp'), n, informed);
fprintf(2, 'JPEG test\n');

%% test dither %%
%testDither(origfile, markedfile, strcat(filename, '_simDither'), strcat(filename, '_dither.bmp'), n, informed);
fprintf(2, 'dither test\n');

%% test cropping %%
%testCropping(origfile, markedfile, strcat(filename, '_simCropping'), strcat(filename, '_crop.bmp'), n, informed);
fprintf(2, 'cropping test\n');

testNoise(origfile, markedfile, strcat(filename, '_simNoise'), strcat(filename, '_noise.bmp'), n, informed);
fprintf(2, 'noise test\n');

%% test multiple %%
%testMultiple(origfile, strcat(filename, '_simMultiple'), strcat(filename, '_multi.bmp'), n, alpha, informed);
fprintf(2, 'multiple test\n');

%% test collusion %%
%testCollusion(origfile, strcat(filename, '_simCollusion'), strcat(filename, '_collusion.bmp'), n, alpha, informed);
fprintf(2, 'Collusion test\n');
