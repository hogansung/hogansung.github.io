function testNoise(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imageNoise = imnoise(imageOrig, 'gaussian');
imwrite(imageNoise, '../tmp/image.bmp');

%imshow(imageNoise);

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);