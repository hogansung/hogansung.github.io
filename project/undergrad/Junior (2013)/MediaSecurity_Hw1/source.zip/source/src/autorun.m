function autorun()

system = {'../res/informed_watermark_system', '../res/blind_watermark_system'};
filename_str = {'airplane', 'baboon', 'fruits', 'peppers'};
alpha_str = {'0.1', '1', '10', '100'};
alpha = [0.1, 1, 10, 100];


%fprintf(2, '%s', filename_str{1});

for i = 1 : 2
	for j = 1 : 4
		for k = 1 : 4
			origfile = strcat('../data/', filename_str{j}, '.bmp');
			filename = strcat(system{i}, '/', filename_str{j}, '/', alpha_str{k}, '/', filename_str{j});
			testAll(origfile, filename, 512, alpha(k), i == 1);	
		end
	end
end