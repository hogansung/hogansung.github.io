function testCollusion(origfile, outputfile, imagefile, n, alpha, informed)

collusion = zeros(n, 1);
watermark_seq = [100, 200, 400, 700, 900];

%% attack %%
for i = 1 : length(watermark_seq)
	[fid message] = fopen(strcat('../wm/Gaussian', int2str(watermark_seq(i)), '.seq'), 'r');
	if (fid == -1)
		disp(message);
	end
	
	wmSeq = fscanf(fid, '%f');
	fclose(fid);
	
	collusion = collusion + wmSeq / length(watermark_seq);
end

[fid message] = fopen('../tmp/collusion_watermark', 'w');
if (fid == -1)
	disp(message);
end

for i = 1 : n
	fprintf(fid, '%f', collusion(i));
end

SpreadSpectrumEmbed(origfile, '../tmp/image.bmp', '../tmp/collusion_watermark', n, alpha);

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);