function sim = SpreadSpectrumExtract(origfile, suspfile, wmfile, n)
% Extract watermark from an image according to spread spectrum watermarking algorithm

% Parameters:
% (1) suspfile: filename of suspect image
% (2) wmfile: random sequence file
% (3) n: # of bits representing the watermark



% preprocessing - read susp image
% hint: imread(), rgb2ycbcr(), dct2()

imageSuspRGB = imread(suspfile);
imageSuspYCBCR = rgb2ycbcr(imageSuspRGB);

imageSuspLumaLayer = imageSuspYCBCR(:, :, 1);
[r, c] = size(imageSuspLumaLayer);

imageSuspDCT = dct2(imageSuspLumaLayer);



% preprocessing - prepar watermark sequence
% hint: fopen(), fscanf(), sign()

[fid message] = fopen(wmfile, 'r');
if (fid == -1)
    disp(message);
end

wmSeq = sign(fscanf(fid, '%f'));
fclose(fid);


% extracting and calculating similarity
% hint: ZigzagOrder.m, reshape()

imageOrigRGB = imread(origfile);
imageOrigYCBCR = rgb2ycbcr(imageOrigRGB);

imageOrigLumaLayer = imageOrigYCBCR(:, :, 1);
[r, c] = size(imageOrigLumaLayer);

imageOrigDCT = dct2(imageOrigLumaLayer);


order = ZigzagOrder(n);

%% in case alpha is too small to differentiate the max value
myMax = 0.01;

for i = 1 : r
   for j = 1 : c
      tag = order(i, j);

      if (tag > r * c - n && tag <= r * c)
         diff = imageSuspDCT(i, j) - imageOrigDCT(i, j);
         extractMark(tag - r * c + n, 1) = diff;

         if (abs(diff) > myMax) 
            myMax = abs(diff);
         end
      end
   end
end

for i = 1 : n
   extractMark(i, 1) = extractMark(i, 1) / myMax;
end

sim = dot(extractMark, wmSeq) / length(extractMark);
