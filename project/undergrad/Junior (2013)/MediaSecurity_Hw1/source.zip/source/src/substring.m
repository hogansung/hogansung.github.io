function substr = substring(string, st, en)

substr = '';
for i = st : en
	substr = strcat(substr, string(i));
end