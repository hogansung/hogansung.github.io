function testScale(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imageSmall = imresize(imageOrig, 0.5);
imageRecover = imresize(imageSmall, 2);
imwrite(imageOrig, '../tmp/image.bmp');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);
