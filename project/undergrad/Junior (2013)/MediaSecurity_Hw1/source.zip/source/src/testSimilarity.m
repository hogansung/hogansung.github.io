function testSimilarity(origfile, markedfile, recordfile, n, informed)

[fid message] = fopen(recordfile, 'w');
if (fid == -1)
	disp(message);
end


res = SpreadSpectrumExtractMulti(origfile, markedfile, n);
myMax = 0;
for i = 1 : length(res)
	if (abs(res(i)) > myMax)
		myMax = abs(res(i));
	end
end

for i = 1 : 1000
	if (informed)
		%% informed system %%
		fprintf(fid, '%f\n', res(i));
	else
		%% blind system %%
		fprintf(fid, '%f\n', res(i) / myMax);
	end
end

fclose(fid);
