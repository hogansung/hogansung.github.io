function testJPEG(origfile, markedfile, outputfile, imagefile, n, informed)

%% attack %%
imageOrig = imread(markedfile);
imwrite(imageOrig, '../tmp/image.bmp', 'jpg');

%% test %%
testSimilarity(origfile, '../tmp/image.bmp', outputfile, n, informed);

%% draw graph %%
drawGraph(outputfile, imagefile);