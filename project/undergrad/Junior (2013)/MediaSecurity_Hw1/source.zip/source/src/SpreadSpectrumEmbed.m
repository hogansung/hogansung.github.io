function SpreadSpectrumEmbed(origfile, markedfile, wmfile, n, alpha)
% Embed watermark into an image according to spread spectrum watermarking algorithm

% Parameters:
% (1) origfile: filename of cover image
% (2) markedfile: filename of output image
% (3) wmfile: random sequence file
% (4) n: # of bits representing the watermark
% (5) alpha: the strength of the watermark



% Preprocessing - read original image
% hint: imread(), rgb2ycbcr(), dct2(), reshape()

imageRGB = imread(origfile);
% figure; imshow(imageRGB);
imageYCBCR = rgb2ycbcr(imageRGB);

imageLumaLayer = imageYCBCR(:, :, 1);
% figure; imshow(imageLumaLayer);
% figure; imshow(imageLumaLayer);
[r, c] = size(imageLumaLayer);

imageDCT = dct2(imageLumaLayer);

% imshow(log(abs(imageDCT)),[]), colormap(jet(256)), colorbar;



% Preprocessing - preparing zigzag scan index
% hint: ZigzagOrder.m

order = ZigzagOrder(n);



% Preprocessing - read watermark sequence
% hint: GenerateGaussianSequence.m, fopen(), fscanf(), sign()

% assume only one watermark
% GenerateGaussianSequence(100, n);

[fid message] = fopen(wmfile, 'r');
if (fid == -1)
    disp(message);
end

wmSeq = sign(fscanf(fid, '%f'));
fclose(fid);


%embedding and write marked image
% hint: reshape(), idct2(), ycbcr2rgb(), imwrite()

for i = 1 : r
   for j = 1 : c
      tag = order(i, j);

      if (tag > r * c - n && tag <= r * c) 
         imageDCT(i, j) = imageDCT(i, j) + wmSeq(tag - r * c + n) * alpha;
      end
   end
end

imageLumaLayer = uint8(idct2(imageDCT));
% figure; imshow(imageLumaLayer);
imageYCBCR(:, :, 1) = imageLumaLayer;
imageRGB = ycbcr2rgb(imageYCBCR);

imwrite(imageRGB, markedfile);
% figure; imshow(imageRGB);


