function drawGraph(outputfile, imagefile)

[fid message] = fopen(outputfile, 'r');
if (fid == -1)
    disp(message);
end

x = 1:1000;
y = 100 * fscanf(fid, '%f %f');
fclose(fid);

z = figure(1);
plot(x, y);
set(gca, 'YTick', -20:10:100);
set(gca, 'YTickLabel', -20:10:100);
xlabel('Random Watermarks');
ylabel('Extract similarities');
title(imagefile);

saveas(z, imagefile, 'bmp');


