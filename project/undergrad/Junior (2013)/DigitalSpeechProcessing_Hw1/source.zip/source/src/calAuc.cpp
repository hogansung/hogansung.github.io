#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <assert.h>

using namespace std;

const int BUFFER_SIZE = 1025;
const string ACC_NAME = "acc.txt";

string fileA;
string fileB;

vector<string> strA;
vector<string> strB;

char buf[BUFFER_SIZE], mn[BUFFER_SIZE];

void ParseArg(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: ./calAuc [fileA.txt] [fileB.txt]\n");
        exit(EXIT_FAILURE);
    }
    
    fileA = string(argv[1]);
    fileB = string(argv[2]);
}

void ReadFile(const string &name, vector<string> &vct) {
    FILE *pfile = fopen(name.c_str(), "r");
    if (pfile == NULL) {
        fprintf(stderr, "Read file failed.\n");
        exit(EXIT_FAILURE);
    }

    while (fgets(buf, sizeof(buf), pfile) != NULL) {
        sscanf(buf, "%s", mn);
        vct.push_back(mn);
    }

    fclose(pfile);
}

void WriteAcc(double ans) {
    FILE *pfile = fopen(ACC_NAME.c_str(), "w");
    if (pfile == NULL) {
        fprintf(stderr, "Write in acc failed.\n");
        exit(EXIT_FAILURE);
    }

    fprintf(pfile, "%f\n", ans);

    fclose(pfile);
}

int main(int argc, char *argv[]) {
    /* Parse argument */
    ParseArg(argc, argv);

    /* Read files */
    ReadFile(fileA, strA);
    ReadFile(fileB, strB);
    assert(strA.size() == strB.size());

    /* Judge files */
    int size = strA.size();
    int correct = 0;
    for (int i = 0; i < size; i++) {
        if (strA[i] == strB[i]) correct++;
    }
    
    /* Write in acc.txt, and print acc */
    double ans = (double)correct / size;
    WriteAcc(ans);
    printf("%f\n", ans);
}
