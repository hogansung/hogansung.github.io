#include "modelType.h"
#include <assert.h>
#include <ctime>
#include <vector>

const int TEST_LINES = 2500;
const int TEST_LEN = 50;

string MODEL_LIST_NAME;
string TEST_NAME;
string RES_NAME;
vector<HMM> hmm;

char con[TEST_LEN + 1];
double d[2][MAX_ST];

void ParseArg(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: ./test modellist.txt [testing_data#.txt] [result#.txt]\n");
        exit(EXIT_FAILURE);
    }
    
    MODEL_LIST_NAME = string(argv[1]);
    TEST_NAME = string(argv[2]);
    RES_NAME = string(argv[3]);
}

void LoadModels() {
    FILE *pfile = fopen(MODEL_LIST_NAME.c_str(), "r");
    if (pfile == NULL) {
        fprintf(stderr, "Read modellist file failed.\n");
        exit(EXIT_FAILURE);
    }

    while (fscanf(pfile, "%s", buffer) != EOF) {
        HMM nhmm;
        loadHMM(nhmm, buffer);
        hmm.push_back(nhmm);
    }

    fclose(pfile);
}

void ReadTestFile() {
    FILE *pfile = freopen(TEST_NAME.c_str(), "r", stdin);
    if (pfile == NULL) {
        fprintf(stderr, "Read test file failed.\n");
        exit(EXIT_FAILURE);
    }
}

void WriteResFile() {
    FILE *pfile = freopen(RES_NAME.c_str(), "w", stdout);
    if (pfile == NULL) {
        fprintf(stderr, "Write res file failed.\n");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char *argv[]) {
    /* Parse argument */
    ParseArg(argc, argv);

    /* Load models from modellist */
    LoadModels();

    /* Redirect test file to stdin */
    ReadTestFile();

    /* Redirect res file to stdout */
    WriteResFile();

    srand(time(NULL));

    for (int i = 0; i < TEST_LINES; i++) {
        scanf("%s", con);
        assert(strlen(con) == (unsigned)TEST_LEN);

        double pmax = 0;
        int t = -1;
        for (vector<HMM>::iterator it = hmm.begin(); it != hmm.end(); it++) {
            int nst = it->nt;

            for (int k = 0; k < nst; k++) {
                d[0][k] = it->init[k] * it->ob[con[0] - 'A'][k];
            }


            for (int j = 1; j < TEST_LEN; j++) {
                for (int l = 0; l < nst; l++) { // dst
                    double nmax = 0;
                    for (int k = 0; k < nst; k++) { // src
                        nmax = max(nmax, d[(j + 1) % 2][k] * it->trans[k][l]);
                    }
                    d[j % 2][l] = nmax * it->ob[con[j] - 'A'][l];
                }
            }

            double nmax = 0;
            for (int k = 0; k < nst; k++) {
                nmax = max(nmax, d[(TEST_LEN - 1) % 2][k]);
            }

            if (nmax > pmax) {
                pmax = nmax;
                t = it - hmm.begin();
            }
        }

        if (t == -1) {
            fprintf(stderr, "No model can generate this sequence, just random choose one.\n");
            t = rand() % hmm.size();
        }
        printf("%s %e\n", hmm[t].modelName.c_str(), pmax);
    }
}
