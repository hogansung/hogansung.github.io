#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <float.h>
extern "C" {
    #include "cblas.h"
}

const int size = 5000;
int iters = 5;

inline double fRand() {
    return DBL_MIN + (double)rand() / RAND_MAX * (DBL_MAX - DBL_MIN);
}

int main() {
    srand(time(NULL));

    double *A, *B, *C;
    double s_init, s_elap;
    
    A = (double *)malloc(size * size * sizeof(double));
    B = (double *)malloc(size * size * sizeof(double));
    C = (double *)malloc(size * size * sizeof(double));

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            A[i * size + j] = fRand();
            B[i * size + j] = fRand();
            C[i * size + j] = fRand();
        }
    }

    // first round
    //cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, size, size, size, 1, A, size, B, size, 0, C, size);

    // cal iters
    s_init = clock();
    for (int i = 0; i < iters; i++) {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, size, size, size, 1, A, size, B, size, 0, C, size);
    }
    
    // average
    s_elap = (clock() - s_init) / iters;

    printf("Total time spent: %f\n", s_elap);
}
