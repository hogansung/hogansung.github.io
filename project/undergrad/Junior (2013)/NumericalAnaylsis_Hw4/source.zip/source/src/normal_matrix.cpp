#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <float.h>

const int size = 5000;

inline double fRand() {
    return DBL_MIN + (double)rand() / RAND_MAX * (DBL_MAX - DBL_MIN);
}

int main() {
    srand(time(NULL));

    double *A, *B, *C;
    double s_init, s_elap;
    
    A = (double *)malloc(size * size * sizeof(double));
    B = (double *)malloc(size * size * sizeof(double));
    C = (double *)malloc(size * size * sizeof(double));
    memset(C, 0, sizeof(C));

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            A[i * size + j] = fRand();
            B[i * size + j] = fRand();
            C[i * size + j] = fRand();
        }
    }

    s_init = clock();

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            for (int k = 0; k < size; k++) {
                C[i * size + j] += A[i * size + k] * B[k * size + j];
            }
        }
    }
    
    s_elap = clock() - s_init;

    printf("Total time spent: %f\n", s_elap);
}
