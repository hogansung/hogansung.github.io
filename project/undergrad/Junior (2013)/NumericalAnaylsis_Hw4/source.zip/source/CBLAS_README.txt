gcc -c -I /home/hogan/Tools/CBLAS/src/ blas_matrix.cpp
gfortran -o blas_matrix blas_matrix.o /home/hogan/Tools/CBLAS/lib/cblas_LINUX.a /usr/lib/libblas.a
