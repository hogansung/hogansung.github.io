1.  source /opt/intel/composer_xe_2013_sp1.0.080/mkl/bin/mklvars.sh intel64
2.  compiler flags: -Wl,--start-group ${MKLROOT}/lib/intel64/libmkl_intel_lp64.a ${MKLROOT}/lib/intel64/libmkl_core.a ${MKLROOT}/lib/intel64/libmkl_sequential.a -Wl,--end-group -lpthread -lm 
