
# FileParser:
    1.  It is used to catch information about "import", "variable", "function".
    2.  There maybe many bugs in this file, for example, it can not differentiate "function" and "variable declaration with override".
    
    Usage: parser [Param] [FileName] [Folder]

    Param: (Default: -ivf)
        -i: show import info
        -v: show variables info
        -f: show functions info



# FolderParser:
    1.  It is used to parse written document.
    2.  It can give out an outline of files in the same folder.
    3.  It only catches the comment at the head of each file document.

    Usage: integrator [target folder] [output file]



# If there is any bug found or any suggestion, please inform me, thanks.

# To know more detailed usage, please refer my work.

