BaseActivity extends FragmentActivity implements ServiceConnection
	PlayPauseButton mPlayPauseButton
		initialized
			in initBottomActionBar(), called in onCreate()
		update
			.updateState() called in updatePlaybackControls(), called in onServiceConnected() and onResume()

PlayPauseButton	extends ImageButton implements OnClickListener, OnLongClickListener
	updateState()
		do
			update drawable corresponding to playing/paused
		called in
			onClick()
	onClick()
		do
			MusicUtils.playOrPause();
       		updateState();

MusicUtils
	IApolloService mService
	playOrPause()
		do
			if (mService.isPlaying()) {
					mService.pause();
                } else {
                    mService.play();
                }