#include <cstdio>
#include <cstdlib>
#include <cfloat>
#include <vector>

using namespace std;
const double eps = 1e-10;

vector<double> vct;
vector<double> dvct;

void parseArg(int argc, char *argv[]) {
    /* function parameter in reverse order */
    if (argc <= 1) {
        fprintf(stderr, "Please insert function parameters in reverse order.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 1; i < argc; i++) {
        double d = strtod(argv[i], NULL);
        vct.push_back(d);
        if (i > 1) dvct.push_back((double)d * (i - 1));
    }
}

double cal(double x, vector<double> &v) {
    double ret = 0;
    double mul = 1;
    for (vector<double>::iterator it = v.begin(); it != v.end(); it++) {
        ret += *it * mul;
        mul *= x;
    }
    return ret;
}

double bisection(double a = -DBL_MAX, double b = DBL_MAX) {
    while (true) {
        double p = (a + b) / 2;
        if (cal(p, vct) <= eps && cal(p, vct) >= -eps) return p;
        else if (cal(a, vct) * cal(p, vct) < 0) b = p;
        else a = p;
    }
}

double newton(double x = 0) {
    while (true) {
        if (cal(x, vct) <= eps && cal(x, vct) >= -eps) return x;
        x += -cal(x, vct) / cal(x, dvct);
    }
}

int main(int argc, char *argv[]) {
    /* read in f(x) parameter */
    parseArg(argc, argv);

    /* bisection */
    printf("Root of bisection %f\n", bisection());

    /* newton */
    printf("Root of newton %f\n", newton());
}
