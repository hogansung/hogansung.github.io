#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdlib.h>

#define SIZE 2000

int main() {

    srand(time(NULL));

    if (freopen("input", "w", stdout) < 0) {
        fprintf(stderr, "File cannot open.\n");
        exit(EXIT_FAILURE);
    }

    printf("%d\n", SIZE);
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d%c", rand() % 10000, j == SIZE - 1 ?'\n' :' ');
        }
    }

    return 0;
}
