#include <stdio.h>
#include <string.h>
#include <assert.h>

#define MAX_SIZE 2000

int n;
long long matA[MAX_SIZE][MAX_SIZE], matB[MAX_SIZE][MAX_SIZE];
long long ans[MAX_SIZE][MAX_SIZE];

int i, j, k;

int main() {
    scanf("%d", &n);
    assert(n >= 0 && n <= MAX_SIZE);
    
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%lld", &matA[i][j]);
            matB[j][i] = matA[i][j];
        }
    }

    long long sum = 0;
    memset(ans, 0, sizeof(ans));

    #pragma omp parallel 
    {
        #pragma omp for collapse(2) reduction(+:sum) private(k)
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                for (k = 0; k < n; k++) {
                     ans[i][j] += matA[i][k] * matB[j][k];
                }
                sum += ans[i][j];
            }
        }
    }
    
    printf("%lld\n", sum);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%lld ", ans[i][j]);
        }
        puts("");
    }
    return 0;
}
