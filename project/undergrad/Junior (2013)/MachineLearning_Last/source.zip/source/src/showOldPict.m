function showOldPict()

%% Path
originTrainPath = '../data/ml2013final_train.dat';
%originTrainPath = '../data/test.dat';
picturePath = '../oldPict';


%% Find the libsvm tools
addpath('../libsvm-3.17/matlab/');


%% Read data from train
[label, inst] = libsvmread(originTrainPath);


%% Reshape and write file
for i = 1 : length(inst(:, 1))
	if length(inst(i, :)) < 12810
		inst(i, 12810) = 0;
	end
	mat = permute(full(reshape(inst(i, :), 105, 122)), [2 1]);	
	mat = ones(122, 105) - mat;
	
	imwrite(mat, strcat(picturePath, '/overall/image_', int2str(i), '.bmp'), 'bmp');
	imwrite(mat, strcat(picturePath, '/', int2str(label(i)), '/image_', int2str(i), '.bmp'), 'bmp');
end