function [model] = ovrtrain(varargin)

error(nargchk(2, 3, nargin));

y = varargin{1};
x = varargin{2};

if nargin == 3
	cmd = varargin{3};
else 
	cmd = '';
end

labelSet = unique(y);
labelSetSize = length(labelSet);
models = cell(labelSetSize,1);

for i=1:labelSetSize
    models{i} = svmtrain(double(y == labelSet(i)), x, cmd);
end

model = struct('models', {models}, 'labelSet', labelSet);
