function trainArg()

% Data path
originTrainPath = '../data/ml2013final_train.dat';
%originTrainPath = '../libsvm-3.17/heart_scale';
%originTestPath = '../data/ml2013final_test1.nolabel.dat';

%% Find the libsvm tools
addpath('../libsvm-3.17/matlab/');

%% Read data from train
% 6144 entries in total
[label, inst] = libsvmread(originTrainPath);
%[N D] = size(inst);


%% Divide train data and valid data
boundary = round(0.8 * size(label));

trainLabel = label(1 : boundary, :);
trainInst = inst(1:boundary, :);

testLabel = label(boundary + 1:end);
testInst = inst(boundary + 1:end, :);


%% train parameters
bestcv = 0;
for log2c = -1:2:3,
  for log2g = -12:2:2,
    cmd = ['-q -c ', num2str(2^log2c), ' -g ', num2str(2^log2g)];
    cv = get_cv_ac(trainLabel, trainInst, cmd, 5);
    if (cv >= bestcv),
      bestcv = cv; bestc = 2^log2c; bestg = 2^log2g;
    end
    fprintf('%g %g %g (best c=%g, g=%g, rate=%g)\n', log2c, log2g, cv, bestc, bestg, bestcv);
  end
end


%% Train svm
model = ovrtrain(trainLabel, trainInst, '-h 0');
%disp(size(model));


%% Predict svm
[predictLabel, accuracy, prob_value] = ovrpredict(testLabel, testInst, model, '-b 1');
fprintf('Overall accuracy = %g%%\n', accuracy * 100);