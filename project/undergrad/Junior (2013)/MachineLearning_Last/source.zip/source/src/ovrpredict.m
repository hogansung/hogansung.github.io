function [pred, ac, decv] = ovrpredict(varargin)

error(nargchk(3, 4, nargin));

y = varargin{1};
x = varargin{2};
model = varargin{3};

if nargin == 4
	cmd = varargin{4};
else 
	cmd = '';
end

labelSet = model.labelSet;
labelSetSize = length(labelSet);
models = model.models;
decv= zeros(size(y, 1), labelSetSize);

for i=1:labelSetSize
  [l,a,d] = svmpredict(double(y == labelSet(i)), x, models{i}, '-b 0');
  decv(:, i) = d * (2 * models{i}.Label(1) - 1);
end
[tmp,pred] = max(decv, [], 2);
pred = labelSet(pred);
ac = sum(y==pred) / size(x, 1);
