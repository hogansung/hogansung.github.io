#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <csignal>
#include <fenv.h>

/* Manually alter mask value on stack
 * This will work only on 32-bit system */

void handler(int signum, siginfo_t *siginfo, void *context) {
    unsigned int base;
    unsigned short *control;

    base = (unsigned int)&base; // get data structure on stack
    control = (unsigned short*)*(unsigned int*)(base + 260); // get value ptr on stack

    if(siginfo->si_code == 6) { // turn on mask for UNDERFLOW and INEXACT
        *control |= (FE_UNDERFLOW | FE_INEXACT);
    }
    else if(siginfo->si_code == 4) { // turn on mask for OVERFLOW
        *control |= FE_OVERFLOW;
    }

    fprintf(stderr, "fp exception %x at address %x\n", siginfo->si_code, siginfo->si_addr);
    return;
}

int main() {
    // turn off mask for all float exception
    #pragma STDC FENV_ACCESS ON
    feenableexcept(FE_DIVBYZERO | FE_INEXACT | FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);

    // register sigaction
    struct sigaction act;
    memset(&act, 0, sizeof(act));

    act.sa_sigaction = &handler;
    act.sa_flags = SA_SIGINFO;

    if (sigaction(SIGFPE, &act, NULL) < 0) {
        fprintf(stderr, "Set sigaction failed.\n");
        exit(EXIT_FAILURE);
    }

    // start calculation
    double x;
    x = DBL_MIN;
    printf("min_normal = %g\n", x);

    __asm("mov $0x12345678,%esi");
    x = x / 13.0;
    printf("min_normal / 13.0 = %g\n", x);

    x = DBL_MAX;
    printf("max_normal = %g\n", x);

    x = x * x;
    printf("max_normal * max_normal = %g\n", x);

    return 0;
}
