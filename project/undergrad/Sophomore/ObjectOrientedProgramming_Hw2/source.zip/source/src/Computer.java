public class Computer{
  
   /**
    * Create a shuffler for this player to get cards randomly.
    */
   private Shuffler shuffler = new Shuffler();

   /**
    * Create a shuffler for this player to get cards randomly.
    */
   private Checker checker = new Checker();


   /**
    * Create a player, who is going to play the game with computer.
    */
   private Player player = new Player(shuffler, checker);


   /**
    * Computer will keep holding the game until the player want to quit.
    */
   public void gameStart(){
      while (!player.getBet()){
         shuffler.clearSet();
         player.getCard();
         player.repick();
         player.judge();
      }
   }
}
