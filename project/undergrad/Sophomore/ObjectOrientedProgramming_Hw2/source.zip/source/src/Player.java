import java.util.*;
import ntu.csie.oop13spring.Card;

public class Player{

   /**
    * Create a scanner to read in inputs.
    */
   private Scanner scanner = new Scanner(System.in);

   /**
    * This shuffler will be referenced from Class Computer.
    */
   private Shuffler shuffler;

   /**
    * This checker will be referenced from Class Computer.
    */
   private Checker checker;


   /**
    * Create a card set to store the certain five cards.
    */
   private Card[] cardSet = new Card[5];

   /**
    * Create string name to store the player name, and string choice to store the player's decision.
    */
   private String name, choice;

   /**
    * Create int bet to store the bet number, cnt to store the times that player had played, and sum to store the total sum of money.:
    */
   private int bet, cnt, sum;


   /**
    * Used to read in the player's name, initialize values, and reference the shuffler and checker from Class Computer.
    */
   public Player(Shuffler shufflerFromComputer, Checker checkerFromComputer){
      System.out.print("Please enter your name: ");
      name = scanner.next();
      System.out.format("Welcome, %s.\nYou have 1000 P-credits now.\n", name);

      shuffler = shufflerFromComputer;
      checker = checkerFromComputer;
      cnt = 0;
      sum = 1000;
   }


   /**
    * Used to read in the player's bet for the certain round.
    * @return True, if the player want to quit the game.
    * @return False, if the player insert a legal number of bet.
    */
   public boolean getBet(){
      while (true){
         System.out.println("Please enter your P-credit bet for round 1 (1-5 or 0 for quitting the game): ");
         bet = scanner.nextInt();

         if (bet == 0){
            if (sum > 1000)   System.out.format("Good bye, %s. You played for %d round and won %d P-credits.\n", name, cnt, sum-1000);
            else if (sum < 1000) System.out.format("Good bye, %s. You played for %d round and lost %d P-credits.\n", name, cnt, 1000-sum);
            else  System.out.format("Good bye, %s. You played for %d round and won nothing.\n", name, cnt);
            return true;
         }
         else if (0 < bet && bet <= 5 && bet <= sum){
            cnt++;
            sum -= bet;
            return false;
         }
         else  System.out.println("You insert an illegal number of bet! Check again!");
      }
   }


   /**
    * Used to print out the certain card.
    * @param Suit  the suit of the certain card.
    * @param Value   the value of the certain card.
    */
   public void showCard(int Suit, int Value){
      if (Suit == 1)  System.out.print(" S");
      else if (Suit == 2)  System.out.print(" H");
      else if (Suit == 3)  System.out.print(" D");
      else if (Suit == 4)  System.out.print(" C");

      if (Value == 1)   System.out.print("A");
      else if (1 < Value && Value <= 10) System.out.print(Value);
      else if (Value == 11)   System.out.print("J");
      else if (Value == 12)   System.out.print("Q");
      else if (Value == 13)   System.out.print("K");
   }


   /**
    * Used to get five cards randomly and put them into card set.
    */
   public void getCard(){
      System.out.print("Your cards are");
      for (int i=0; i<5; i++){
         cardSet[i] = shuffler.pickCard();
         System.out.format(" (%c)", i + 'a');

         showCard(cardSet[i].getSuit(), cardSet[i].getValue());
      }
      System.out.println(" or (n)");
   }


   /**
    * Used to let the player repick cards and put them into card set.
    */
   public void repick(){

      boolean[] vis;

      while (true){
         System.out.print("Which cards do you want to keep? "); 
         choice = scanner.next();
         
         vis = new boolean[5];
         boolean suc = true, none = false, choose = false;

         for (int i=0; i<choice.length(); i++){
            if (choice.charAt(i) >= 'a' && choice.charAt(i) <= 'e'){
               vis[choice.charAt(i) - 'a'] = true;
               choose = true;
            }
            else if (choice.charAt(i) == 'n')   none = true;   
            else  suc = false;
         }

         if (suc && ((none && !choose) || (!none && choose)))  break;
         else  System.out.println("Your decision is illegal, please choose again!");
      }

      System.out.print("Okay. I will discard");

      for (int i=0; i<5; i++){
         if (!vis[i]){
            System.out.format(" (%c)", i + 'a');
            cardSet[i] = shuffler.pickCard();
         }
      }
      System.out.println(".");

      System.out.print("Your new cards are");
      for (int i=0; i<5; i++){
         showCard(cardSet[i].getSuit(), cardSet[i].getValue());
      }
      System.out.println(".");
   }


   /**
    * Used to find out the winning prize for the certain round.
    */
   public void judge(){
      int inc = 0, type = checker.check(cardSet);

      if (type == 0) inc = 300;
      else if (type == 1)  inc = 200; 
      else if (type == 2)  inc = 25; 
      else if (type == 3)  inc = 15; 
      else if (type == 4)  inc = 9; 
      else if (type == 5)  inc = 5; 
      else if (type == 6)  inc = 3; 
      else if (type == 7)  inc = 2; 
      else if (type == 8)  inc = 2; 
      else if (type == 9)  inc = 1;

      inc *= bet;
      if (type == 0 && bet == 5) inc = 4000;

      if (type == 0) System.out.format("You get a natural royal flush. The payoff is %d.\n", inc);
      else if (type == 1) System.out.format("You get a four deuces. The payoff is %d.\n", inc);
      else if (type == 2) System.out.format("You get a wild royal flush. The payoff is %d.\n", inc);
      else if (type == 3) System.out.format("You get a five of a kind. The payoff is %d.\n", inc);
      else if (type == 4) System.out.format("You get a straight flush. The payoff is %d.\n", inc);
      else if (type == 5) System.out.format("You get a four of a kind. The payoff is %d.\n", inc);
      else if (type == 6) System.out.format("You get a full house. The payoff is %d.\n", inc);
      else if (type == 7) System.out.format("You get a flush. The payoff is %d.\n", inc);
      else if (type == 8) System.out.format("You get a straight. The payoff is %d.\n", inc);
      else if (type == 9) System.out.format("You get a three of a kind. The payoff is %d.\n", inc);
      else if (type == 10) System.out.format("You get an others. The payoff is %d.\n", inc);

      sum += inc;
      System.out.format("You have %d P-credits now\n", sum);
   }
}
