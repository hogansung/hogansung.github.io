import java.util.*;

public class POOCasino{

   /**
    * Class POOCasino will create a computer to handle the whole game.
    */
   public static void main(String[] args){
      System.out.println("POOCasino Deuces Wild, written by b00902064 Hao-en Sung");

      Computer computer = new Computer();
      computer.gameStart();      
   }
}
