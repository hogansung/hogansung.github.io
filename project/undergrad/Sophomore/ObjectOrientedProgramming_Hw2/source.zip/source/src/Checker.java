import  ntu.csie.oop13spring.Card;

public class Checker{
   
   /**
    * Used to store the information of the current card set.
    */
   private boolean[][] myset;

   /**
    * Used to find out the biggest card type that one can have.
    * @return  The number of the card type.
    */
   public int check(Card[] cardSet){
      /**
       * Used to store the number of special cards.
       */
      int deuces = 0;

      myset = new boolean[4][13];
      for (int i=0; i<5; i++){
         if (cardSet[i].getValue() != 2) myset[cardSet[i].getSuit() - 1][cardSet[i].getValue() - 1] = true;
         else deuces++;
      }
      
      if (NaturalRoyalFlush(deuces))  return 0;
      if (FourDeuces(deuces))   return 1;
      if (WildRoyalFlush(deuces))  return 2;
      if (FiveOfAKind(deuces))  return 3;
      if (StraightFlush(deuces))   return 4;
      if (FourOfAKind(deuces))  return 5;
      if (FullHouse(deuces)) return 6;
      if (Flush(deuces))  return 7;
      if (Straight(deuces))  return 8;
      if (ThreeOfAKind(deuces))  return 9;
      return 10;
   }

   boolean NaturalRoyalFlush(int deuces){
      for (int i=0; i<4; i++){
         int suc = 0;
         if (myset[i][0])  suc++;
         for (int j=9; j<13; j++) if (myset[i][j]) suc++;

         if (suc == 5)  return true;
      }
      return false;
   }

   boolean FourDeuces(int deuces){
      if (deuces == 4)  return true;
      return false;
   }

   boolean WildRoyalFlush(int deuces){
      for (int i=0; i<4; i++){
         int suc = 0;
         if (myset[i][0])  suc++;
         for (int j=9; j<13; j++) if (myset[i][j]) suc++;

         if (suc + deuces == 5)  return true;
      }
      return false;
   }

   boolean FiveOfAKind(int deuces){
      for (int i=0; i<13; i++){
         int suc = 0;
         for (int j=0; j<4; j++){
            if (myset[j][i])  suc++;
         }
         if (suc + deuces == 5)  return true;
      }
      return false;
   }

   boolean StraightFlush(int deuces){
      for (int i=0; i<4; i++){
         for (int j=0; j<9; j++){
            int suc = 0;
            for (int k=0; k<5; k++){
               if (myset[i][j+k])   suc++;
            }
            if (suc + deuces == 5)  return true;
         }
         int suc = myset[i][0] == true?1:0;
         for (int j=9; j<13; j++){
            if (myset[i][j])  suc++;
         }
         if (suc + deuces == 5)  return true;
      }
      return false;
   }

   boolean FourOfAKind(int deuces){
      for (int i=0; i<13; i++){
         int suc = 0;
         for (int j=0; j<4; j++){
            if (myset[j][i])  suc++;
         }
         if (suc + deuces == 4)  return true;
      }
      return false;
   }

   boolean FullHouse(int deuces){
      for (int i=0; i<13; i++){
         for (int j=0; j<13; j++){
            if (i == j) continue;

            int suc = 0;
            for (int k=0; k<4; k++){
               if (myset[k][i])  suc++;
            }
            for (int k=0; k<4; k++){
               if (myset[k][j])  suc++;
            }
            if (suc + deuces == 5)  return true;
         }
      }
      return false;
   }

   boolean Flush(int deuces){
      for (int i=0; i<4; i++){
         int suc = 0;
         for (int j=0; j<13; j++){
            if (myset[i][j])  suc++;
         }
         if (suc + deuces == 5)  return true;
      }
      return false;
   }

   boolean Straight(int deuces){
      for (int i=0; i<9; i++){
         int suc = 0;
         for (int j=0; j<5; j++){
            if (myset[0][i+j] || myset[1][i+j] || myset[2][i+j] || myset[3][i+j])   suc++;
         }
         if (suc + deuces == 5)  return true;
      }

      int suc = myset[0][0] || myset[1][0] || myset[2][0] || myset[3][0] == true?1:0;
      for (int i=9; i<13; i++){
         if (myset[0][i] || myset[1][i] || myset[2][i] || myset[3][i])   suc++;
      }
      if (suc + deuces == 5)  return true;
      return false;
   }

   boolean ThreeOfAKind(int deuces){
      for (int i=0; i<13; i++){
         int suc = 0;
         for (int j=0; j<4; j++){
            if (myset[j][i])  suc++;
         }
         if (suc + deuces == 3)  return true;
      }
      return false;
   }
}
