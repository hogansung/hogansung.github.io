import ntu.csie.oop13spring.Card;

public class Shuffler{

   /**
    * Used to record the card status for 52 cards.
    */
   boolean[] vis = new boolean[52];

   /**
    * Used to choosing a card that had not been used.
    * @return  An instance that represents a card.
    */
   public Card pickCard(){
      int tmp;

      while (true){
         tmp = (int)(Math.random()*52);

         if (vis[tmp] == false){
            vis[tmp] = true;
            break;
         }
      }
   
      Card newCard = new Card((byte)(tmp/13 + 1), (byte)(tmp%13 + 1));
      return newCard;
   }

   public void clearSet(){
      for (int i=0; i<52; i++)   vis[i] = false;
   }
}
