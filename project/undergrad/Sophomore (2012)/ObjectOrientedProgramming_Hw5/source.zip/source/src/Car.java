public class Car implements Comparable<Car>, Runnable{
   private int pos, speed, nspeed, nnspeed, start, id;
   public boolean alc, keep;

   /**
    * This is the constructor of Class Car.
    */
   Car(int v, int p, int s, int d){
      speed = v;
      pos = p;
      alc = false;
      keep = false;
      start = s;
      id = d;
   }

   /**
    * This is the comparator for Class Car.
    */
   public int compareTo(Car arg){
      return arg.pos - this.pos;
   }

   public int getPos(){
      return pos;
   }

   public int getSpeed(){
      return speed;
   }

   public int getNSpeed(){
      return nspeed;
   }

   public int getNNSpeed(){
      return nnspeed;
   }

   public boolean getAlc(){
      return alc;
   }

   public boolean getKeep(){
      return keep;
   }

   public int getStart(){
      return start;
   }

   public int getId(){
      return id;
   }

   public void setSpeed(int v){
      speed = v;
   }

   public void setNSpeed(int v){
      nspeed = v;
   }

   public void setNNSpeed(int v){
      nnspeed = v;
   }

   public void setAlc(boolean st){
      alc = st;
   }

   public void setKeep(boolean st){
      keep = st;
   }

   public void run(){
      pos += speed;
      speed = nspeed;
      if (alc) nspeed = nnspeed;
   }
}
