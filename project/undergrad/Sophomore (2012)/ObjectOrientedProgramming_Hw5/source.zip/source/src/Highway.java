import java.util.*;

public class Highway{
   private int task, len, num, inter, left, right, v_limit = 4;
   private Car[] car_list = new Car[1000];

   private Car[][] rcd = new Car[200][1000];
   private int[][] bound = new int[200][2];
   private Thread[] carThread = new Thread[1000];

   /**
    * This is the constructor of class Highway
    */
   public Highway(int a, int b, int c, int d){
      task = a;
      len = b;
      num = c;
      inter = d;
      left = right = 0;
   }

   /**
    * This is the function who return the minimum among the two inputs
    */
   private int Min(int a, int b){return a<b ?a:b;}

   /**
    * Return the reference of object rcd.
    */
   public Car[][] getRcd(){
      return rcd;
   }

   public int[][] getBound(){
      return bound;
   }


   /**
    * This function adjust all the cars that are just on the highway at each time t.
    */
   public int run(int t){
      boolean fail = false;
      
      /**
       * If now is at time 200, or my feature option is on, just call the function print.
       */
      for (int i=left; i<right; i++) rcd[t-1][i] = new Car(car_list[i].getSpeed(), car_list[i].getPos(), car_list[i].getStart(), 
            car_list[i].getId());
      bound[t-1][0] = left;
      bound[t-1][1] = right;

      /**
       * Deal with all the cars that is starting from print 1.
       */
      if (left == right && num > 0){
         car_list[right] = new Car(v_limit, 1, 0, right);
         right++;
         num--;
      }
      else if (left < right && num > 0 && car_list[right - 1].getPos() >= 3){
         car_list[right] = new Car(Min(v_limit, (car_list[right - 1].getPos() - 1) / 2), 1, 0, right);
         right++;
         num--;
      }

      /**
       * Deal with all the cars that is starting from the interchange, which is at point 50.
       */
      int tag = -1;
      if (inter > 0){
         for (int i=right - 1; i>=left && tag == -1; i--){
            if (car_list[i].getPos() == 50) tag = -2;
            else if (car_list[i].getPos() > 50 && tag == -1)  tag = i;
         }

         if (tag == -1){
            car_list[right] = new Car(v_limit, 50, 1, right);
            right++;
            inter--;
         }
         else if (tag != -2 && car_list[tag].getPos() >= 52){
            car_list[right] = new Car(Min(v_limit, (car_list[tag].getPos() - 50) / 2), 50, 1, right);
            right++;
            inter--;
         }
      }

      /**
       * Sort the array starting form left to right in the decreasing order of position.
       */
      Arrays.sort(car_list, left, right);

      /**
       * Adjust the speed for the farest car on the highway.
       */
      if (left < right && task == 2 && t == 5){
         car_list[left].setSpeed(car_list[left].getSpeed() / 2);
         car_list[left].setNSpeed(car_list[left].getSpeed());
      }
      else if (left < right){
         if (car_list[left].alc){
            car_list[left].setAlc(false);
            car_list[left].setKeep(true);
         }
         else if (car_list[left].getSpeed() == v_limit)  car_list[left].setNSpeed(v_limit);
         else if (car_list[left].getKeep()){
            car_list[left].setKeep(false);
            car_list[left].setNSpeed(car_list[left].getSpeed());
         }
         else if (car_list[left].getSpeed() < v_limit){
            car_list[left].setNSpeed(car_list[left].getSpeed());
            car_list[left].setNNSpeed(v_limit);
            car_list[left].setAlc(true);
         }
         else  System.err.println("Something wrong.");
      }

      /**
       * Adjust the speed for all the other cars on the highway.
       */
      for (int i=left+1; i<right; i++){
         int my_min = Min(v_limit, (car_list[i - 1].getPos() - car_list[i].getPos()) / 2);

         if (car_list[i].alc){
            car_list[i].setAlc(false);
            car_list[i].setKeep(true);
         }
         else if (car_list[i].getSpeed() >= my_min)  car_list[i].setNSpeed(my_min);
         else if (car_list[i].getKeep()){
            car_list[i].setKeep(false);
            car_list[i].setNSpeed(car_list[i].getSpeed());
         }
         else if (car_list[i].getSpeed() < my_min){
            car_list[i].setNSpeed(car_list[i].getSpeed());
            car_list[i].setNNSpeed(my_min);
            car_list[i].setAlc(true);
         }
         else  System.err.println("Something wrong.");
      }

      /**
       * Adjust all the cars position with the current speed.
       */
      for (int i=left; i<right; i++){
         carThread[i] = new Thread(car_list[i]);
         carThread[i].start();
         try {
            carThread[i].join();
         }
         catch (InterruptedException e){
            System.err.println("Something wrong.");
            return 1;
         }
      }
      
      /**
       * Check whether there is any illegal surpassing cars.
       */
      for (int i=left; i<right; i++)   if (car_list[i].getPos() > len) left++;

      /**
       * Check whether there is any illegal surpassing event occurred.
       * And if my feature option is on, I will print out the illegal surpassing events' ids.
       */
       
      for (int i=left+1; i<right; i++) if (car_list[i-1].getPos() <= car_list[i].getPos()) fail = true;
      
      /**
       * If any collision happened, just print the error message and then quit.
       */
      if (fail || t >= 200)   return 1;
      
      return 0;
   }
}
