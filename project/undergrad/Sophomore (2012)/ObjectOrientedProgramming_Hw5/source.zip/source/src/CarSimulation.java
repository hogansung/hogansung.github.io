import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class CarSimulation{
   public static void main(String[] args){

      /**
       * This part parses all the input arguments.
       */
      int task = Integer.parseInt(args[0]);
      int len = Integer.parseInt(args[1]);
      int num = Integer.parseInt(args[2]);
      int inter = 0;

      if (task == 3) inter = Integer.parseInt(args[3]);

      /**
       * Create a object called my_highway to contain all the cars.
       */
      Highway myHighway = new Highway(task, len, num, inter);

      /**
       * Do certain move at every single point.
       */
      int times = 0;
      while (true){
         int feedback = myHighway.run(++times);

         /**
          * If any error message was returned, just quit the program.
          */
         if (feedback == 1)   break;
      }

      JFrame frame = new myFrame(myHighway.getRcd(), myHighway.getBound(), len, times);
   }
}

class myFrame extends JFrame{

   private void setRoundDocStyle(StyledDocument roundDoc){
      Style base = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
      
      Style regular = roundDoc.addStyle("regular", base);
      StyleConstants.setFontFamily(regular, "Senserif");
      StyleConstants.setBold(regular, true);
      StyleConstants.setFontSize(regular, 26);
      
      Style cyan = roundDoc.addStyle("cyan", regular);
      StyleConstants.setForeground(cyan, new Color(91, 149, 239));
   }
   
   private void setCarGraphDocStyle(StyledDocument carGraphDoc){
      Style base = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
      
      Style regular = carGraphDoc.addStyle("regular", base);
      StyleConstants.setForeground(regular, new Color(74, 58, 69));
      StyleConstants.setFontFamily(regular, "Senserif");
      StyleConstants.setBold(regular, true);
      StyleConstants.setFontSize(regular, 14);
      
      Style green = carGraphDoc.addStyle("green", regular);
      StyleConstants.setForeground(green, new Color(59, 151, 45));

      Style blue = carGraphDoc.addStyle("blue", regular);
      StyleConstants.setForeground(blue, new Color(17, 121, 195));

      Style purple = carGraphDoc.addStyle("purple", regular);
      StyleConstants.setForeground(purple, new Color(148, 32, 239));

      Style red = carGraphDoc.addStyle("red", regular);
      StyleConstants.setForeground(red, new Color(255, 55, 53));
   }

   private void setCarStatDocStyle(StyledDocument carStatDoc){
      Style base = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
      
      Style regular = carStatDoc.addStyle("regular", base);
      StyleConstants.setForeground(regular, new Color(74, 58, 69));
      StyleConstants.setFontFamily(regular, "Monospaced");
      StyleConstants.setBold(regular, true);
      StyleConstants.setFontSize(regular, 14);
      
      Style green = carStatDoc.addStyle("green", regular);
      StyleConstants.setForeground(green, new Color(59, 151, 45));

      Style blue = carStatDoc.addStyle("blue", regular);
      StyleConstants.setForeground(blue, new Color(17, 121, 195));
   }

   private void setAuthorInfoDocStyle(StyledDocument authorDoc){
      Style base = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
      
      Style regular = authorDoc.addStyle("regular", base);
      StyleConstants.setFontFamily(regular, "Senserif");
      StyleConstants.setBold(regular, true);
      StyleConstants.setItalic(regular, true);
      StyleConstants.setFontSize(regular, 12);
      StyleConstants.setForeground(regular, new Color(229, 218, 158));
   }


   public myFrame(Car[][] rcd, int[][] bound, int len, int times){
      /**
       * Set the size of this frame.
       */
      setSize(640, 480);

      /**
       * Let this frame be visible.
       */
      setLayout(null);


      /**
       * Set style for word in carGraphDoc.
       */
      StyledDocument carGraphDoc = new DefaultStyledDocument();
      setCarGraphDocStyle(carGraphDoc);
      
      /**
       * Used to present car position.
       */
      JTextPane carPosGraph = new JTextPane(carGraphDoc);
      carPosGraph.setEditable(false);
      carPosGraph.setBackground(new Color(178, 177, 157));
      carPosGraph.setMargin(new Insets(7, 9, 7, 2));

      /**
       * Used to package CarPosGraph.
       */
      JScrollPane carPosGraphScroll = new JScrollPane(carPosGraph);
      carPosGraphScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
      carPosGraphScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
      carPosGraphScroll.setBounds(36, 36, 360, 312);
      carPosGraphScroll.setBorder(BorderFactory.createEmptyBorder());
      add(carPosGraphScroll);
      

      /**
       * Set style for output for carStatDoc.
       */
      StyledDocument carStatDoc = new DefaultStyledDocument();
      setCarStatDocStyle(carStatDoc);

      /**
       * Used to present car state.
       */
      NonScrollingPane carPosStat = new NonScrollingPane(carStatDoc);
      carPosStat.setEditable(false);
      carPosStat.setBackground(new Color(178, 177, 157));
      carPosStat.setMargin(new Insets(5, 5, 5, 5));

      /**
       * Used to package CarPosStat.
       */
      JScrollPane carPosStatScroll = new JScrollPane(carPosStat);
      carPosStatScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
      carPosStatScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
      carPosStatScroll.setBounds(36, 370, 568, 48);   // down 418
      carPosStatScroll.setBorder(BorderFactory.createEmptyBorder());
      add(carPosStatScroll);


      /**
       * Set style for word in roundDoc.
       */
      StyledDocument roundDoc = new DefaultStyledDocument();
      setRoundDocStyle(roundDoc);

      /**
       * Used to show the round number.
       */
      JTextPane roundNum = new JTextPane(roundDoc);
      roundNum.setBounds(428, 48, 186, 32);
      roundNum.setBackground(new Color(115, 114, 101));
      add(roundNum);


      /**
       * Used to goto certain round.
       */
      JTextField gotoField = new GotoField();
      gotoField.setBounds(440, 109, 84, 30);
      gotoField.setForeground(new Color(138, 138, 138));
      gotoField.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.white), 
               BorderFactory.createEmptyBorder(0, 2, 0, 2)));
      add(gotoField);

      
      /**
       * Play button for auto play or stop.
       */
      PlayStopBtn playStopBtn = new PlayStopBtn();
      playStopBtn.setBounds(456, 264, 124, 32);
      add((JButton)playStopBtn);


      /**
       * Used to deal with how to show current round.
       */
      Dealer dealer = new Dealer(carGraphDoc, carStatDoc, roundDoc, (GotoField)gotoField, playStopBtn, rcd, bound, len, times);
      playStopBtn.setDealer(dealer);


      /**
       * Used to create goto event.
       */
      JButton gotoBtn = new GotoBtn(dealer);
      gotoBtn.setBounds(524, 108, 76, 32);
      gotoBtn.setBackground(new Color(92, 168, 131));
      add(gotoBtn);


      /**
       * Prev button for former stage.
       */
      JButton prevBtn = new PrevBtn(dealer);
      prevBtn.setBounds(456, 160, 124, 32);
      add(prevBtn);

      /**
       * Next button for former stage.
       */
      JButton nextBtn = new NextBtn(dealer);
      nextBtn.setBounds(456, 212, 124, 32);
      add(nextBtn);


       /**
       * Set style for Author.
       */
      StyledDocument authorDoc = new DefaultStyledDocument();
      setAuthorInfoDocStyle(authorDoc);
      try {
         authorDoc.insertString(0, "All rights reserved by Hogan.", authorDoc.getStyle("regular"));
      }
      catch (BadLocationException err){
         System.err.println("Something wrong.");
      }

      /**
       * Used to show the round number.
       */
      JTextPane authorInfo = new JTextPane(authorDoc);
      authorInfo.setBounds(420, 316, 212, 24);
      authorInfo.setBackground(new Color(115, 114, 101));
      add(authorInfo);


      Container c = getContentPane();
      c.setBackground(new Color(115, 114, 101));
      setVisible(true);
   }
}

class Dealer implements ActionListener{
   private StyledDocument carGraphDoc, carStatDoc, roundDoc;
   private GotoField gotoField;
   private PlayStopBtn playStopBtn;
   private Car[][] rcd;
   private int[][] bound;
   private int stage, len, times;
   private Thread thread;
   private boolean playing;

   Dealer(StyledDocument a, StyledDocument b, StyledDocument c, GotoField d, PlayStopBtn e, Car[][] f, int[][] g, int h, int i){
      carGraphDoc = a;
      carStatDoc = b;
      roundDoc = c;

      gotoField = d;
      playStopBtn = e;

      rcd = f;
      stage = 0;
      bound = g;
      len = h;
      times = i;

      Show();
   }

   private void Show(){
      int left = bound[stage][0], right = bound[stage][1];
      Car[] car_list = rcd[stage];


      /* Used to clear all the data in doc. */
      try {
         carGraphDoc.remove(0, carGraphDoc.getLength());
         carStatDoc.remove(0, carStatDoc.getLength());
         roundDoc.remove(0, roundDoc.getLength());
      }
      catch (BadLocationException err){
         System.err.println("Something wrong.");
      }


      /* Deal with the output of round number. */
      try {
         roundDoc.insertString(0, "Round #" + (stage + 1)/100 + (stage + 1)%100/10 + (stage + 1)%10, roundDoc.getStyle("cyan"));
      }
      catch (BadLocationException err){
         System.err.println("Something wrong.");
      }


      /* Deal with all the output for graph.*/
      for (int i=left; i<right; i++){
         ArrayList<String> initString = new ArrayList<String>();   
         ArrayList<String> initStyles = new ArrayList<String>();

         int id = car_list[i].getId(), pos = car_list[i].getPos(), speed = car_list[i].getSpeed();

         initString.add("Car #" + id/100 + id%100/10 + id%10);
         initString.add("  at");
         initString.add("  position " + pos/100 + pos%100/10 + pos%10);
         initString.add("  with");
         initString.add("  speed " + speed + "\n");

         if (car_list[i].getStart() == 0)  initStyles.add("green");
         else  initStyles.add("blue");
         initStyles.add("regular");
         initStyles.add("purple");
         initStyles.add("regular");
         initStyles.add("red");

         try {
            for (int j=0; j<initString.size(); j++){
               carGraphDoc.insertString(carGraphDoc.getLength(), initString.get(j), carGraphDoc.getStyle(initStyles.get(j)));
            }
         }
         catch (BadLocationException err){
            System.err.println("Something wrong.");
         }
      }

      /* Deal with all the output for stat. */
      int flag = 1;
      ArrayList<String> initString = new ArrayList<String>();
      ArrayList<String> initStyles = new ArrayList<String>();

      for (int i=right - 1; i>=left; i--){
         while(flag < car_list[i].getPos()){
            flag++;
            initString.add(".");
            initStyles.add("regular");
         }
         if (car_list[i].getStart() == 0){
            initString.add("x");
            initStyles.add("green");
         }
         else {
            initString.add("x");
            initStyles.add("blue");
         }
         flag++;
      }
      while (flag <= len){
         initString.add(".");
         initStyles.add("regular");
         flag++;
      }

      try {
         for (int i=0; i<initString.size(); i++){
            carStatDoc.insertString(carStatDoc.getLength(), initString.get(i), carStatDoc.getStyle(initStyles.get(i)));
         }
      }
      catch (BadLocationException err){
         System.err.println("Something wrong.");
      }
   }

   public void actionPerformed(ActionEvent e){
      int nextStage = stage;

      if (e.getActionCommand().equals("Prev")){
         if (playing){
            JOptionPane.showMessageDialog(null, "Now is still playing.", "Please wait", JOptionPane.WARNING_MESSAGE);
            return;
         }
         nextStage--;
      }
      else if (e.getActionCommand().equals("Next")){
         if (playing){
            JOptionPane.showMessageDialog(null, "Now is still playing.", "Please wait", JOptionPane.WARNING_MESSAGE);
            return;
         }
         nextStage++;
      }
      else if (e.getActionCommand().equals("Goto")){
         if (playing){
            JOptionPane.showMessageDialog(null, "Now is still playing.", "Please wait", JOptionPane.WARNING_MESSAGE);
            return;
         }
         try{
            nextStage = Integer.parseInt(gotoField.getText()) - 1;
         }
         catch(NumberFormatException err){
             JOptionPane.showMessageDialog(null, "Your insertion format is not legal.", "Number Format Error", JOptionPane.ERROR_MESSAGE);
         }
      }
      else if (e.getActionCommand().equals("Play")){
         gotoField.reset();   // will then return

         thread = new Thread(new Runnable(){
            public void run(){
               while(stage < times - 1){
                  stage++;
                  Show();

                  try {
                     Thread.sleep(500);
                  }
                  catch (InterruptedException err){
                     System.err.println("Pause is pressed.");
                     return;
                  }
               }
               if (times < rcd.length) JOptionPane.showMessageDialog(null, "Car accident happened in Round#" 
                  + (times + 1), "Car Accident", JOptionPane.ERROR_MESSAGE);
               playStopBtn.setText("Play");
               playing = false;
            } 
         });

         playStopBtn.setText("Stop");
         playing = true;
         thread.start();
         return;
      }
      else if (e.getActionCommand().equals("Stop")){
         thread.interrupt(); 
         playing = false;
         playStopBtn.setText("Play");
      }
      
      if (nextStage < 0)   JOptionPane.showMessageDialog(null, "There isn't any former stage.", "Prev Stage", JOptionPane.WARNING_MESSAGE);
      else if (times < rcd.length && nextStage >= times) JOptionPane.showMessageDialog(null, "Car accident happened in Round#" 
            + (times + 1), "Car Accident", JOptionPane.ERROR_MESSAGE);
      else if (nextStage >= rcd.length) JOptionPane.showMessageDialog(null, "There isn't any latter stage.", 
            "Next Stage", JOptionPane.WARNING_MESSAGE);
      else {
         stage = nextStage;
         Show();
      }

      gotoField.reset();
   }
}

class GotoField extends JTextField implements FocusListener{
   private final String defString;

   public GotoField(){
      super("Key-in Stage");
      defString = "Key-in Stage";
      super.addFocusListener(this);
   }

   public void focusGained(FocusEvent e){
      if (this.getText().isEmpty()){
         super.setText("");
      }
   }

   public void focusLost(FocusEvent e){
      if (this.getText().isEmpty()){
         super.setText(defString);
      }
   }

   public void reset(){
      super.setText(defString);
      setText(defString);
   }

   public String getText(){
      String insertion = super.getText();
      return insertion.equals(defString) ?"" :insertion;
   }
}

class NonScrollingPane extends JTextPane{
   public NonScrollingPane(StyledDocument doc){
      super(doc);
   }

   public boolean getScrollableTracksViewportWidth(){
      //return getSize().width < getParent().getSize().width;
      return getUI().getPreferredSize(this).width <= getParent().getSize().width;
   }
/*
   public void setSize(Dimension d){
      if (d.width < getParent().getSize().width){
         d.width = getParent().getSize().width;
      }
      super.setSize(d);
   }
   */
}

class GradientBtn extends JButton{
   public GradientBtn(){}
   public GradientBtn(String input){
      super(input);
      setContentAreaFilled(false);
      setFocusPainted(false);
   }
   protected void paintComponent(Graphics g){
      Graphics2D g2d = (Graphics2D)g.create();
      
      g2d.setPaint(new GradientPaint(new Point(0, 0), new Color(167, 195, 165), new Point(0, getHeight()), new Color(92, 168, 131)));
      g2d.fillRect(0, 0, getWidth(), getHeight());
      g2d.dispose();

      super.paintComponent(g);
   }
}

class GotoBtn extends GradientBtn{
   private Dealer dealer;

   public GotoBtn(Dealer a){
      super("Goto");
      dealer = a;
      addActionListener(dealer);
   }
}

class PrevBtn extends GradientBtn{
   private Dealer dealer;

   public PrevBtn(Dealer a){
      super("Prev");
      dealer = a;
      addActionListener(dealer);
   }
}

class NextBtn extends GradientBtn{
   private Dealer dealer;

   public NextBtn(Dealer a){
      super("Next");
      dealer = a;
      addActionListener(dealer);
   }
}

class PlayStopBtn extends GradientBtn{
   private Dealer dealer;

   public PlayStopBtn(){
      super("Play");
   }

   public void setDealer(Dealer a){
      dealer = a;
      addActionListener(dealer);
   }
}
