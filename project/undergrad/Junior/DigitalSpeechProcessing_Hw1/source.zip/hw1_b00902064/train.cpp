#include "modelType.h"

int ITER_NUM;
string INIT_NAME;
string SEQ_NAME;
string MODEL_NAME;

const int SEQ_LINE = 10000;
const int SEQ_LEN = 50;

char con[SEQ_LINE][SEQ_LEN + 1];
double pa[SEQ_LEN][MAX_ST];
double pb[SEQ_LEN][MAX_ST];
double pr[SEQ_LEN][MAX_ST];
double pe[SEQ_LEN][MAX_ST][MAX_ST];
double pr_zero[MAX_ST];
double pr_st[MAX_ST];
double pe_st[MAX_ST][MAX_ST];
double pr_ob[MAX_OB][MAX_ST];

void ParseArg(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Usage: ./train [#iter] model_init.txt [seq_model_##.txt] [model_##.txt]\n");
        exit(EXIT_FAILURE);
    }
    
    ITER_NUM = strtol(argv[1], 0, 10);
    INIT_NAME = string(argv[2]);
    SEQ_NAME = string(argv[3]);
    MODEL_NAME = string(argv[4]);
}

void ReadSeqFile() {
    FILE *pfile = fopen(SEQ_NAME.c_str(), "r");

    for (int i = 0; i < SEQ_LINE; i++) {
        fscanf(pfile, "%s", con[i]);
        assert(strlen(con[i]) == (unsigned)SEQ_LEN);
    }
}

int main(int argc, char *argv[]) {
    /* Parse argument */
    ParseArg(argc, argv);

    HMM hmm;         
    loadHMM(hmm, INIT_NAME);

    ReadSeqFile();

    int nst = hmm.nt;
    int nob = hmm.no;
    for (int t = 0; t < ITER_NUM; t++) {
        if (t % 50 == 0) fprintf(stderr, "%s is now at iter #%d\n", MODEL_NAME.c_str(), t);
        memset(pr_zero, 0, sizeof(pr_zero));
        memset(pr_st, 0, sizeof(pr_st));
        memset(pe_st, 0, sizeof(pe_st));
        memset(pr_ob, 0, sizeof(pr_ob));

        for (int i = 0; i < SEQ_LINE; i++) {
            /* Initialization */
            memset(pb, 0, sizeof(pb));
            for (int k = 0; k < nst; k++) {
                pa[0][k] = hmm.init[k] * hmm.ob[con[i][0] - 'A'][k];
                pb[SEQ_LEN - 1][k] = 1;
            }

            /* Forward procedure */
            for (int j = 0; j < SEQ_LEN - 1; j++) {
                for (int l = 0; l < nst; l++) { // det
                    double sum = 0;
                    for (int k = 0; k < nst; k++) { // src
                        sum += pa[j][k] * hmm.trans[k][l];
                    }
                    pa[j + 1][l] = sum * hmm.ob[con[i][j + 1] - 'A'][l];
                }
            }

            /* Backward procedure */
            for (int j = SEQ_LEN - 2; j >= 0; j--) {
                for (int k = 0; k < nst; k++) { // src
                    for (int l = 0; l < nst; l++) { // det
                        pb[j][k] += hmm.trans[k][l] * hmm.ob[con[i][j + 1] - 'A'][l] * pb[j + 1][l];
                    }
                }
            }

            /* Calculate pr */
            for (int j = 0; j < SEQ_LEN; j++) {
                double sum = 0;
                for (int k = 0; k < nst; k++) {
                    sum += pa[j][k] * pb[j][k];
                }
                for (int k = 0; k < nst; k++) {
                    pr[j][k] = pa[j][k] * pb[j][k] / sum;
                }
            }

            /* Calculate pe */
            for (int j = 0; j < SEQ_LEN - 1; j++) {
                double sum = 0;
                for (int k = 0; k < nst; k++) {
                    for (int l = 0; l < nst; l++) {
                        sum += pa[j][k] * hmm.trans[k][l] * hmm.ob[con[i][j + 1]- 'A'][l] * pb[j + 1][l];
                    }
                }
                for (int k = 0; k < nst; k++) {
                    for (int l = 0; l < nst; l++) {
                        pe[j][k][l] = pa[j][k] * hmm.trans[k][l] * hmm.ob[con[i][j + 1] - 'A'][l] * pb[j + 1][l] / sum;
                    }
                }
            }
            
            /* pr for time zero */
            for (int k = 0; k < nst; k++) {
                pr_zero[k] += pr[0][k];
            }

            /* Sum of pr for each state */
            for (int j = 0; j < SEQ_LEN - 1; j++) {
                for (int k = 0; k < nst; k++) {
                    pr_st[k] += pr[j][k];
                }
            }

            /* Sum of pe for pair of states */
            for (int j = 0; j < SEQ_LEN - 1; j++) {
                for (int k = 0; k < nst; k++) {
                    for (int l = 0; l < nst; l++) {
                        pe_st[k][l] += pe[j][k][l];
                    }
                }
            }

            /* Sum of pr with ob for each state */
            for (int j = 0; j < SEQ_LEN - 1; j++) {
                for (int k = 0; k < nst; k++) {
                    pr_ob[con[i][j] - 'A'][k] += pr[j][k];
                }
            }
        }
        
        /* Update init */
        for (int k = 0; k < nst; k++) {
            hmm.init[k] = pr_zero[k] / SEQ_LINE; 
        }

        /* Update trans */
        for (int k = 0; k < nst; k++) {
            for (int l = 0; l < nst; l++) {
                hmm.trans[k][l] = pe_st[k][l] / pr_st[k];
            }
        }

        /* Update ob */
        for (int k = 0; k < nob; k++) {
            for (int l = 0; l < nst; l++) {
                hmm.ob[k][l] = pr_ob[k][l] / pr_st[l];
            }
        }
    }

    dumpHMM(hmm, MODEL_NAME);
}
