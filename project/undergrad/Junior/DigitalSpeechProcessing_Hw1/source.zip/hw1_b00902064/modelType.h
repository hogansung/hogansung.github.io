#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <assert.h>

#define MAX_ST 10
#define MAX_OB 26
#define BUF_SIZE 1025

using namespace std;

const string INIT_STR = "initial:";
const string TRANS_STR = "transition:";
const string OB_STR = "observation:";

struct HMM {
    string modelName;
    int nt;
    int no;
    double init[MAX_ST];
    double trans[MAX_ST][MAX_ST];
    double ob[MAX_OB][MAX_ST];
};

char buffer[BUF_SIZE];

void loadHMM(HMM &hmm, const string name) {
    FILE *pfile = fopen(name.c_str(), "r");
    if (pfile == NULL) {
        fprintf(stderr, "Load HMM file failed.\n");
        exit(EXIT_FAILURE);
    }

    hmm.modelName = name;
    while (fscanf(pfile, "%s", buffer) != EOF) {
        if (strcmp(buffer, INIT_STR.c_str()) == 0) {
            fscanf(pfile, "%d", &hmm.nt);
            for (int i = 0; i < hmm.nt; i++) {
                fscanf(pfile, "%lf", &hmm.init[i]);
            }
        }
        else if (strcmp(buffer, TRANS_STR.c_str()) == 0) {
            fscanf(pfile, "%d", &hmm.nt);
            for (int i = 0; i < hmm.nt; i++) {
                for (int j = 0; j < hmm.nt; j++) {
                    fscanf(pfile, "%lf", &hmm.trans[i][j]);
                }
            }
        }
        else {
            fscanf(pfile, "%d", &hmm.no);
            for (int i = 0; i < hmm.no; i++) {
                for (int j = 0; j < hmm.nt; j++) {
                    fscanf(pfile, "%lf", &hmm.ob[i][j]);
                }
            }
        }
    }

    fclose(pfile);
}

void dumpHMM(HMM &hmm, const string name) {
    FILE *pfile = fopen(name.c_str(), "w");
    if (pfile == NULL) {
        fprintf(stderr, "Dump HMM file failed.\n");
        exit(EXIT_FAILURE);
    }

    fprintf(pfile, "%s %d\n", INIT_STR.c_str(), hmm.nt);
    for (int i = 0; i < hmm.nt; i++) {
        fprintf(pfile, "%f ", hmm.init[i]);
    }
    fprintf(pfile, "\n\n");

    fprintf(pfile, "%s %d\n", TRANS_STR.c_str(), hmm.nt);
    for (int i = 0; i < hmm.nt; i++) {
        for (int j = 0; j < hmm.nt; j++) {
            fprintf(pfile, "%f ", hmm.trans[i][j]);
        }
        fprintf(pfile, "\n");
    }
    fprintf(pfile, "\n");

    fprintf(pfile, "%s %d\n", OB_STR.c_str(), hmm.no);
    for (int i = 0; i < hmm.no; i++) {
        for (int j = 0; j < hmm.nt; j++) {
            fprintf(pfile, "%f ", hmm.ob[i][j]);
        }
        fprintf(pfile, "\n");
    }
    fprintf(pfile, "\n");

    fclose(pfile);
}
