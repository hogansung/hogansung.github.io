import os
from nltk.tokenize import sent_tokenize, RegexpTokenizer
from collections import defaultdict

dirPath = '../ndat/'

vsize = 200
kgram = 6
tokenizer = RegexpTokenizer(r'\w+')

wordMap = defaultdict(list)


# read vectors
with open('../dat/vectors.txt') as inf:
    for line in inf.readlines()[1:]:
        inst = line.strip().split()
        wordMap[inst[0]] = map(float, inst[1:])

'''
# train
with open('../dat/train.txt', 'w') as outf:
    for fn in os.listdir(dirPath):
        filePath = dirPath + fn
        print(filePath)

        with open(filePath, 'r') as inf:
            text = ' '.join(filter(lambda x: len(x) > 0, inf.read().split('\n')))

        sents = sent_tokenize(text)

        for sent in sents:
            wordList = [w.lower() for w in tokenizer.tokenize(sent)]
            for i in range(len(wordList) - kgram + 1):
                printList = [' '.join(map(str, wordMap[w])) for w in wordList[i: i + kgram]]
                outf.write(' '.join(printList) + '\n')
'''

# test
with open('../dat/test.txt', 'w') as outf:
    filePath = '../dat/testing_data_jiang.txt'
    print(filePath)

    with open(filePath, 'r') as inf:
        for line in inf.readlines():
            sent = ' '.join(line.strip().split()[1:])
            wordList = [w.lower() for w in tokenizer.tokenize(sent)]
            outf.write(str(len(wordList)) + '\n')
            outf.write(' '.join([' '.join(map(str, wordMap[w])) for w in wordList]) + '\n')



