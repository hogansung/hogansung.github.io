import os
dirPath = '../dat/Holmes_Training_Data/'
ndirPath = '../ndat/'

for fn in os.listdir(dirPath):
    filePath = dirPath + fn
    print filePath

    with open(filePath, 'r') as inf, open(ndirPath + fn, 'w') as outf:
        flag = False
        for line in inf.readlines():
            if line[:5] == '*END*': flag = True
            elif flag == True:
                outf.write(line)
