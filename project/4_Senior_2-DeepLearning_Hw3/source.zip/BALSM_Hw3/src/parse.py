import os
from nltk.tokenize import sent_tokenize, RegexpTokenizer

dirPath = '../ndat/'

kgram = 10
tokenizer = RegexpTokenizer(r"[\w\-']+")

with open('../dat/oriText.txt', 'w') as outf:
    # train
    for fn in os.listdir(dirPath):
        filePath = dirPath + fn
        print filePath

        with open(filePath, 'r') as inf:
            text = ' '.join(filter(lambda x: len(x) > 0, inf.read().split('\n')))

        sents = sent_tokenize(text)

        for sent in sents:
            wordList = [w.lower() for w in tokenizer.tokenize(sent)]
            outf.write(' '.join(wordList) + '\n')


    # test
    filePath = '../dat/testing_data.txt'
    print filePath

    with open(filePath, 'r') as inf:
        for line in inf.readlines():
            sent = ' '.join(line.strip().split()[1:])
            wordList = [w.lower() for w in tokenizer.tokenize(sent)]
            outf.write(' '.join(wordList) + '\n')



