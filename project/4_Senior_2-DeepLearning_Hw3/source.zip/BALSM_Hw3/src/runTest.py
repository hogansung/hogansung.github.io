import os
import math
from nltk.tokenize import sent_tokenize, RegexpTokenizer
from collections import defaultdict

dirPath = '../ndat/'

vsize = 200
kgram = 6

wordMap = defaultdict(list)


def cosSim(listA, listB):
    up = 0
    qA = 0
    qB = 0
    for i in xrange(len(listA)):
        up += listA[i] * listB[i]
        qA += listA[i] * listA[i]
        qB += listB[i] * listB[i]

    return up / math.sqrt(qA * qB)



# read vectors
with open('../dat/large2.txt') as inf:
    for line in inf.readlines()[1:]:
        inst = line.strip().split()
        wordMap[inst[0]] = map(float, inst[1:])


# test
c_tokenizer = RegexpTokenizer(r"[\w\-'\[\]]+")
tokenizer = RegexpTokenizer(r"[\w\-']+")

with open('/tmp2/b00902064/DeepLearning/dat/testing_data.txt', 'r') as inf, open('../dat/cos_new_dist.out', 'w') as outf:
    lines = inf.readlines()
    outf.write('id,answer\n')

    for i in xrange(0, len(lines), 5):
        sent = ' '.join(lines[i].strip().split()[1:])
        wordList = [w.lower() for w in c_tokenizer.tokenize(sent)]

        loc = -1
        for j in xrange(len(wordList)):
            if wordList[j][0] == '[':
                loc = j
        assert(loc >= 0)

        maxv = -1000000000
        maxc = -1
        for j in xrange(5):
            sent = ' '.join(lines[i + j].strip().split()[1:])
            tarA = c_tokenizer.tokenize(sent)[loc].lower()[1:-1]

            total = 0
            for k in xrange(len(wordList)):
                if k == loc:
                    continue

                tarB = wordList[k]
                #assert(tarA in wordMap.keys() and tarB in wordMap.keys())
                if tarA not in wordMap.keys() or tarB not in wordMap.keys():
                    print tarA, tarB
                if (tarA[0].isdigit()):
                    continue
                
                val = cosSim(wordMap[tarA], wordMap[tarB]) / abs(k - loc)

                if (val > maxv):
                    maxv = val
                    maxc = j
        
        outf.write(str(i / 5 + 1) + ',' + chr(ord('a') + maxc) + '\n')



