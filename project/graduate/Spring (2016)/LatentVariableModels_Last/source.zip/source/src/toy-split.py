import numpy as np

VECTOR_SIZE = 100
LATENT_SIZE = 10
SAMPLE_RATE = 5.99

a = np.random.random((VECTOR_SIZE, LATENT_SIZE))
b = np.random.random((VECTOR_SIZE, LATENT_SIZE))
c = np.matmul(a, b.T)

dat = []
for index, x in np.ndenumerate(c):
    dat.append([index[0], index[1], x])

# split
idx = np.random.choice(range(VECTOR_SIZE*VECTOR_SIZE), 
                       int(VECTOR_SIZE*VECTOR_SIZE * SAMPLE_RATE), 
                       replace=False)
rev_idx = list(np.setdiff1d(np.array(range(VECTOR_SIZE*VECTOR_SIZE)), idx))

with open('tnList', 'w') as wf:
    wf.write(str(len(idx)) + '\n')
    for i in idx:
        wf.write(','.join(map(str, dat[i])) + '\n')

with open('ttList', 'w') as wf:
    wf.write(str(len(rev_idx)) + '\n')
    for i in rev_idx:
        wf.write(','.join(map(str, dat[i])) + '\n')
