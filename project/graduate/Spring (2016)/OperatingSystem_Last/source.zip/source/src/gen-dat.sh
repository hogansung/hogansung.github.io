for name in 1 2 4 8 16 32 64 128
do
    eval "dd if=/dev/urandom of=../dat/rand-dat/d${name}m bs=1048576 count=${name}"
done
