#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#define NUM_ITER 10000
#define L3_CACHE_SIZE 3145728 		        /* 3 MB in L3 cache */
#define ARRAY_SIZE L3_CACHE_SIZE*4 	        /* 12MB array*/
#define CACHE_LINE_SIZE 64 	    	        /* 64 byte-line in L3 cache */
#define INTEGER_SIZE sizeof(int) 	        /* size of integer */
#define STRIDE 32*CACHE_LINE_SIZE/INTEGER_SIZE	/* size of stride */

int main(){
    unsigned int cycleNumHigh, cycleNumLow;
    unsigned long long int startCycle, endCycle;
    int *ptr, *endOfArray;
    int sum = 0;
    int* array = (int*) malloc(sizeof(int) * ARRAY_SIZE);

    printf("# Cycles\n");

    for (int i = 0; i < ARRAY_SIZE; i++)
    	array[i] = 0;

    for (int i = 0; i < NUM_ITER; i++) {
    	sum = 0;
    	ptr = array;
    	endOfArray = ptr + ARRAY_SIZE;

        /* Start: Get the number of cycles */
        asm volatile ("cpuid\n\t"
                      "rdtsc\n\t"
                      "mov %%edx, %0\n\t"
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */

        for (; ptr != endOfArray; ptr += STRIDE)
        	sum += ptr[0] + ptr[16] + ptr[32] + ptr[48] + ptr[64] + ptr[80] +
        			ptr[96] + ptr[112] + ptr[128] + ptr[144] + ptr[160] + ptr[176] +
        			ptr[192] + ptr[208] + ptr[224] + ptr[240] + ptr[256] + ptr[272] +
        			ptr[288] + ptr[304] + ptr[320] + ptr[336] + ptr[352] + ptr[368] +
        			ptr[384] + ptr[400] + ptr[416] + ptr[432] + ptr[448] + ptr[464] +
        			ptr[480] + ptr[496];

        /* Start: Get the number of cycles */
        asm volatile ("rdtscp\n\t"
                      "mov %%edx, %0\n\t"
                      "mov %%eax, %1\n\t"
                      "cpuid\n\t"
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */

        /* print the result */
        printf("%llu\n", endCycle - startCycle);
    }
}
