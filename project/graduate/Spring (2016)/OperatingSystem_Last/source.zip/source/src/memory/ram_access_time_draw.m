data1 = csvread(string('stride_16.csv'));
data2 = csvread(string('stride_256.csv'));
data3 = csvread(string('stride_1024.csv'));
data4 = csvread(string('stride_4096.csv'));
data5 = csvread(string('stride_16384.csv'));
data6 = csvread(string('stride_65536.csv'));

figure();
semilogx(data1(:,1), data1(:,2), 'y-'), hold on
semilogx(data2(:,1), data2(:,2), 'm-'), hold on
semilogx(data3(:,1), data3(:,2), 'c-'), hold on
semilogx(data4(:,1), data4(:,2), 'r-'), hold on
semilogx(data5(:,1), data5(:,2), 'g-'), hold on
semilogx(data6(:,1), data6(:,2), 'b-'), grid on
title('RAM Access Latency'), xlabel('Size (bytes)'), ylabel('Cycles'),set(gca,'fontsize',26)
legend('16 bytes','256 bytes', '1024 bytes', '4096 bytes', '16384 bytes', '65536 bytes');