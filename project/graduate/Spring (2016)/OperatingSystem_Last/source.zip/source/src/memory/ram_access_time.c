#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define ITERATION   1000000
const double MEASUREMENT_OVERHEAD = 55.63;
const double LOOP_OVERHEAD = 8.38;

//Cache Size: L1-D: 32 KB L2: 256 KB; L3: 3 MB;
int strideSize[6] = { 16, 256, 1024, 4096, 16384, 65536 }; //Bytes
int memSize[5] = { 1024, 1024 * 10, 1024 * 100, 1024 * 1000, 1024 * 10000}; // 1KB, 10KB, 100KB, 1MB, 10MB   

/* Variables used for counter */ 
unsigned long long int startCycleNum, endCycleNum;  /* Store # of cycles */  
unsigned int cycleNumHigh, cycleNumLow;   /* Store high, low byte of # of cycle */
double calCacheTime(long, long);

int main(int argc, char* argv[]) {

    double cycles = 0;

    for(int i = 0; i < 6; i++){
        FILE *file;
        char fileName[32];
        snprintf(fileName, sizeof(char)*32, "stride_%i.csv", strideSize[i]);
        file = fopen(fileName, "w");
        if(file == NULL){
            fprintf(stderr, "Error open file.\n");
            exit(1);
        }
        for(int j = 0; j < 5; j++){
            for (int k = 1; k < 20; k++){
                cycles = calCacheTime( strideSize[i], memSize[j] * k * 0.5);            
                fprintf(file, "%d, %f\n", memSize[j] * k, cycles);
            }
        }
        fclose(file);
    }
}

double calCacheTime(long strideSize, long memSize){

    /* Initialize the memory */ 
    int* arr = (int*) malloc( memSize / sizeof(int) * sizeof(int));
    int numOfElement = memSize / sizeof(int);
    int stepOfIndex = strideSize / sizeof(int);

    /* forward */
    // for (int i = 0; i < numOfElement; i++){    
    //     // int index = (i + stepOfIndex) % numOfElement;
    //     // arr[i] = index; // store the position of the next element.
    // }

    /* backward */ 
    for (int i = 0; i < numOfElement; i++){

        int index = ( i + stepOfIndex ) % numOfElement;
        arr[index] = i;
    }

    /* Warm up the memory */
    int p = 0;
    do {       
        p = arr[p];
    } while (p != 0);
    p = 0;


    /* Start: Get # of cycles in the beginning */ 
    asm volatile ("cpuid\n\t"   /* Flush the cpu pipeline */ 
            "rdtsc\n\t"   /* Read Time-Stamp Counter */ 
            "mov %%edx, %0\n\t"   /* Move data from rdx into cycleNumHigh */  
            "mov %%eax, %1\n\t"   /* Move data from rax into cycleNumLow */ 
    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
    :: "%eax","%ebx", "%ecx", "%edx");

    startCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);    //Calculate the cycle number  
    /* End: Get # of cycles in the beginning */ 


    /* Fetch the element for ITERATION times. */ 
    for (int i = 0; i < ITERATION; i++){
        p = arr[p];
    }    

    /* Start: Get # of cycles in the end */ 
    asm volatile ("rdtscp\n\t"  /* Read Time-Stamp Counter and Processor ID */ 
            "mov %%edx, %0\n\t"   /* Move data */ 
            "mov %%eax, %1\n\t"   /* Move data */ 
            /*"cpuid\n\t"*/       /* Flush CPU pipeline, not necssary*/ 
    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
    :: "%eax","%ebx", "%ecx", "%edx");

    endCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);      //Calculate the cycle number  
    /* End: Get # of cycles in the end*/ 

    /* print the result */ 
    //printf("%f\n", (endCycleNum - startCycleNum)/(double)ITERATION);
    free(arr); 
    return (endCycleNum - startCycleNum - MEASUREMENT_OVERHEAD)/(double) ITERATION - LOOP_OVERHEAD;
}
