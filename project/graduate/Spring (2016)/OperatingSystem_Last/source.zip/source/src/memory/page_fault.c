#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>

const int NUM_ITER = 32;
const long long OFFSET_SIZE = 16777216; // 16 MB
const long long FILE_SIZE = 4294967296; // 4096 MB

/*
 * Prerequisite: 
 * 1. echo 3 | sudo tee /proc/sys/vm/drop_caches [for Linux]
 * 2. dd if=/dev/urandom of=../../dat/d512m bs=1048576 count=512 (generate random file)
 */

int main(){    
    unsigned int cycleNumHigh, cycleNumLow;
    char c;

    printf("# Cycles\n");

    int fd = open("../../dat/rand-dat/d512m", O_RDWR | O_DIRECT | O_SYNC | O_LARGEFILE);
    if (fd < 0) {
        fprintf(stderr, "Error in reading file!\n");
        perror("");
        exit(EXIT_FAILURE);
    }

    char* my_mmap = (char*) mmap(NULL, FILE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    
    unsigned long long int startCycle, endCycle;
    for (int i = 0; i < NUM_ITER; i++) {
        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        c = my_mmap[i * OFFSET_SIZE % FILE_SIZE]; 
        
        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* print the result */ 
        printf("%llu\n", endCycle - startCycle);
    }

    munmap(my_mmap, FILE_SIZE);
    close(fd);
}
