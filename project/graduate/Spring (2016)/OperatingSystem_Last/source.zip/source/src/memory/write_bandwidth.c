#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#define NUM_ITER 10000
#define L3_CACHE_SIZE 3145728 			/* 3 MB in L3 cache */
#define ARRAY_SIZE L3_CACHE_SIZE*4 		/* 12MB array*/
#define CACHE_LINE_SIZE 64 		    	/* 64 byte-line in L3 cache */
#define INTEGER_SIZE sizeof(int) 		/* size of integer */
#define STRIDE 32*CACHE_LINE_SIZE/INTEGER_SIZE	/* size of stride */

int main(){
    unsigned int cycleNumHigh, cycleNumLow;
    unsigned long long int startCycle, endCycle;
    int *ptr, *endOfArray;
    int* array = (int*) malloc(sizeof(int) * ARRAY_SIZE);

    printf("# Cycles\n");

    for (int i = 0; i < ARRAY_SIZE; i++)
    	array[i] = 0;

    for (int i = 0; i < NUM_ITER; i++) {
    	ptr = array;
    	endOfArray = ptr + ARRAY_SIZE;

        /* Start: Get the number of cycles */
        asm volatile ("cpuid\n\t"
                      "rdtsc\n\t"
                      "mov %%edx, %0\n\t"
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */

        for (; ptr != endOfArray; ptr += STRIDE) {
            ptr[0] = 1;
            ptr[16] = 1;
            ptr[32] = 1;
            ptr[48] = 1;
            ptr[64] = 1;
            ptr[80] = 1;
            ptr[96] = 1;
            ptr[112] = 1;
            ptr[128] = 1;
            ptr[144] = 1;
            ptr[160] = 1;
            ptr[176] = 1;
            ptr[192] = 1;
            ptr[208] = 1;
            ptr[224] = 1;
            ptr[240] = 1;
            ptr[256] = 1;
            ptr[272] = 1;
            ptr[288] = 1;
            ptr[304] = 1;
            ptr[320] = 1;
            ptr[336] = 1;
            ptr[352] = 1;
            ptr[368] = 1;
            ptr[384] = 1;
            ptr[400] = 1;
            ptr[416] = 1;
            ptr[432] = 1;
            ptr[448] = 1;
            ptr[464] = 1;
            ptr[480] = 1;
            ptr[496] = 1;
        }

        /* Start: Get the number of cycles */
        asm volatile ("rdtscp\n\t"
                      "mov %%edx, %0\n\t"
                      "mov %%eax, %1\n\t"
                      "cpuid\n\t"
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */

        /* print the result */
        printf("%llu\n", endCycle - startCycle);
    }
}
