#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define ITERATIONS 100000
#define MEASUREMENT_OVERHEAD 32

void func () {}
void funcA (int a) {}
void funcB (int a, int b) {}
void funcC (int a, int b, int c) {}
void funcD (int a, int b, int c, int d) {}
void funcE (int a, int b, int c, int d, int e) {}
void funcF (int a, int b, int c, int d, int e, int f) {}
void funcG (int a, int b, int c, int d, int e, int f, int g) {}

void test() {
    unsigned long long int startTime, endTime;
    unsigned int cycleNumHigh, cycleNumLow;

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    func();
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcA(0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcB(0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcC(0, 0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcD(0, 0, 0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcE(0, 0, 0, 0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcF(0, 0, 0, 0, 0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu, ", endTime - startTime);

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    funcG(0, 0, 0, 0, 0, 0, 0);
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");
    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    printf("%llu\n", endTime - startTime);
}

int main () {

	int i;
    printf("0, 1, 2, 3, 4, 5, 6, 7\n");
    for (i = 0; i < ITERATIONS; i++) {
        test();
    }
}
