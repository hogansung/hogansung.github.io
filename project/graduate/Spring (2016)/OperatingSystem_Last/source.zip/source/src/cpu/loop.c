#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(){

    unsigned long long int startCycle, endCycle; 
    unsigned int cycleNumHigh, cycleNumLow;

    int idx = 0;
    printf("header\n");
    idx = 0;
    /* Start: Get the number of cycles */ 
    asm volatile ("cpuid\n\t"   
            "rdtsc\n\t" 
            "mov %%edx, %0\n\t" 
            "mov %%eax, %1\n\t"
            : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
            :: "%eax","%ebx", "%ecx", "%edx");
    startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    /* End: Get the number of cycles */ 

    for(; idx < 100000; idx++);

    /* Start: Get the number of cycles */ 
    asm volatile ("rdtscp\n\t" 
            "mov %%edx, %0\n\t"   
            "mov %%eax, %1\n\t"
            /*"cpuid\n\t"*/   
            : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
            :: "%eax","%ebx", "%ecx", "%edx");
    endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    /* End: Get the number of cycles */ 
    /* print the result */ 
    printf("%llu\n", endCycle - startCycle);
}
