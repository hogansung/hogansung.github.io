#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
/* For System Call */
#include <unistd.h>


int main(){

    unsigned long long int startCycleNum, endCycleNum;  /* Store the # of cycle */  
    unsigned int cycleNumHigh, cycleNumLow;   /* Store the high, low byte of cycle */ 
    int iteration = 100000;
    int pid;    /* Process ID */ 
    int idx = 0;
    printf("# of Cycles\n");    
    for(;idx < iteration; idx++){
        if((pid = vfork())>0){  /* vfork returns 0 to children, returns pid of children process to parent) */ 
        
            /* Suspend the execution of calling process 
             * until children process (specidied by pid) changes its state */ 
            waitpid(pid, NULL, 0);
        
        }else if (pid == 0){    /* pid = 0 means that the process is children. */ 

            /* Start: Get the number of cycles */ 
            asm volatile ("cpuid\n\t"   
                    "rdtsc\n\t" 
                    "mov %%edx, %0\n\t" 
                    "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
            startCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

            getpid();   /* the simplest system call. */ 

            /* Start: Get the number of cycles */ 
            asm volatile ("rdtscp\n\t" 
                    "mov %%edx, %0\n\t"   
                    "mov %%eax, %1\n\t"
                    /*"cpuid\n\t"*/   
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
            endCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

            /* print out the result */ 
            printf("%llu\n", endCycleNum - startCycleNum);
            
            /* End the children process */ 
            _exit(0);
        }
    }
}
