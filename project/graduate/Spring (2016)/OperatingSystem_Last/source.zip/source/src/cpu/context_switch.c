#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <pthread.h>

const int NUM_ITER = 100000;
double aveWR;

double calWR() {
    unsigned int cycleNumHigh, cycleNumLow;
    double numCycle = 0;
    char buf[2];
    int pipe_t[2];
    if (pipe(pipe_t)) {
        fprintf (stderr, "Error in creating pipes!\n");
        exit (1);
    }

    unsigned long long int startCycle, endCycle; 
    for (int i = 0; i < NUM_ITER; i++) {
        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        c = map[(((i+1) * offset) % (FILESIZE - 1))]; 

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        numCycle += endCycle - startCycle;
    }
    
    return numCycle / NUM_ITER;
}

void calProcessSwitch() {
    unsigned int cycleNumHigh, cycleNumLow;
    char buf[2];

    int pipe_p[2];
    int pipe_c[2];
    if (pipe(pipe_p) || pipe(pipe_c)) {
        fprintf (stderr, "Error in creating pipes!\n");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) { // fork failed
        fprintf(stderr, "Error in fork!\n");
        exit(EXIT_FAILURE);
    } else if (pid == 0) { // child process
        close(pipe_p[1]);
        close(pipe_c[0]);

        unsigned long long int startCycle, endCycle; 
        for (int i = 0; i < NUM_ITER; i++) {
            /* Start: Get the number of cycles */ 
            asm volatile ("cpuid\n\t"   
                          "rdtsc\n\t" 
                          "mov %%edx, %0\n\t" 
                          "mov %%eax, %1\n\t"
                        : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                        :: "%eax","%ebx", "%ecx", "%edx");
            startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
            /* End: Get the number of cycles */ 

            write(pipe_c[1], "#", 1);
            read(pipe_p[0], buf, 1);

            /* Start: Get the number of cycles */ 
            asm volatile ("rdtscp\n\t" 
                          "mov %%edx, %0\n\t"   
                          "mov %%eax, %1\n\t"
                          /*"cpuid\n\t"*/   
                          : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                          :: "%eax","%ebx", "%ecx", "%edx");
            endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
            /* End: Get the number of cycles */ 
        }
    } else { // parent process
        close(pipe_p[0]);
        close(pipe_c[1]);

        unsigned long long int startCycle, endCycle; 
        for (int i = 0; i < NUM_ITER; i++) {
            /* Start: Get the number of cycles */ 
            asm volatile ("cpuid\n\t"   
                          "rdtsc\n\t" 
                          "mov %%edx, %0\n\t" 
                          "mov %%eax, %1\n\t"
                        : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                        :: "%eax","%ebx", "%ecx", "%edx");
            startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
            /* End: Get the number of cycles */ 

            read(pipe_c[0], buf, 1);
            write(pipe_p[1], "#", 1);

            /* Start: Get the number of cycles */ 
            asm volatile ("rdtscp\n\t" 
                          "mov %%edx, %0\n\t"   
                          "mov %%eax, %1\n\t"
                          /*"cpuid\n\t"*/   
                          : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                          :: "%eax","%ebx", "%ecx", "%edx");
            endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
            /* End: Get the number of cycles */ 

            printf("%.10f\n", (endCycle - startCycle) / 2 - aveWR);
        }
    } 
}

int pipe_f[2];
int pipe_s[2];

void* fThread() {
    unsigned int cycleNumHigh, cycleNumLow;
    char buf[2];

    unsigned long long int startCycle, endCycle; 
    for (int i = 0; i < NUM_ITER; i++) {
        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        write(pipe_f[1], "#", 1);
        read(pipe_s[0], buf, 1);

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 
    }

    return NULL;
}

void sThread() {
    unsigned int cycleNumHigh, cycleNumLow;
    char buf[2];

    unsigned long long int startCycle, endCycle; 
    for (int i = 0; i < NUM_ITER; i++) {
        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        read(pipe_f[0], buf, 1);
        write(pipe_s[1], "#", 1);

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        printf("%.10f\n", (endCycle - startCycle) / 2 - aveWR);
    }
}

void calThreadSwitch() {
    unsigned int cycleNumHigh, cycleNumLow;
    double aveWR = calWR();
    char buf[2];

    if (pipe(pipe_f) || pipe(pipe_s)) {
        fprintf (stderr, "Error in creating pipes!\n");
        exit(EXIT_FAILURE);
    }

    pthread_t td;

    if (pthread_create(&td, NULL, fThread, NULL)) {
        fprintf(stderr, "Error in creating pthread!\n");
        exit(EXIT_FAILURE);
    }
    sThread();

    pthread_join(td, NULL);
}

void printErrorMsg() {
    fprintf(stderr, "Usage: ./context_switch [command]\n");
    fprintf(stderr, "Available command: p (process)\n");
    fprintf(stderr, "                 : t (thread)\n");
}

int main(int argc, char* argv[]){
    aveWR = calWR();
    //fprintf(stderr, "average W+R: %.10f\n", aveWR);

    if (argc != 2) {
        printErrorMsg();
        exit(EXIT_FAILURE);
    } else {
        if (argv[1][0] == 'p') {
            printf("# Cycles\n");
            calProcessSwitch(); 
        } else if (argv[1][0] == 't') {
            printf("# Cycles\n");
            calThreadSwitch();
        } else {
            printErrorMsg();
            exit(EXIT_FAILURE);
        } 
    }
}
