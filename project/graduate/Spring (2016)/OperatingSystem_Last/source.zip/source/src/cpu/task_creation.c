#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <sys/wait.h>
#include <stdint.h>

#define ITERATIONS 100000

/* the emty start routine to put into newly created thread */
void * start_routine (void * arg) {
    return NULL;
}

/* test with forking child process */
void testProcess() {
    unsigned long long int startTime, endTime;
    unsigned int cycleNumHigh, cycleNumLow;
    pid_t pid;

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

    pid = fork();

    if (pid == 0) {
        /* child process, do nothing, since we want to measure
           the cycle of calling fork() */
        exit(0);
    } else {
        /* record the cycle right after the child process is created,
           since the parent will always run before its child process,
           so put stop here */
        asm volatile ("rdtscp\n\t"
                      "mov %%edx, %0\n\t"
                      "mov %%eax, %1\n\t"
                      "cpuid\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                   :: "%eax","%ebx", "%ecx", "%edx");

        endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

        /* parent process, make parent process wait for it's
           corresponding child process to exit, or zombie process
           may exist */
        waitpid(pid, NULL, 0);
    }

    printf("%llu\n", endTime - startTime);

    /* flush all the buffer, avoid the buffet got copy to child process
       and print more than one time */
    fflush(NULL);
}

void testThread() {
    unsigned long long int startTime, endTime;
    unsigned int cycleNumHigh, cycleNumLow;
    pthread_t thread;

    asm volatile ("cpuid\n\t"
                  "rdtsc\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                :: "%eax","%ebx", "%ecx", "%edx");

    startTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

    pthread_create(&thread, NULL, *start_routine, NULL);

    /* stop roght after a thread is created */
    asm volatile ("rdtscp\n\t"
                  "mov %%edx, %0\n\t"
                  "mov %%eax, %1\n\t"
                  "cpuid\n\t"
                  : "=r" (cycleNumHigh), "=r" (cycleNumLow)
                  :: "%eax","%ebx", "%ecx", "%edx");

    endTime = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);

    /* wait for the new thread to exit */
    pthread_join(thread, NULL);

    printf("%llu\n", endTime - startTime);
}

int main (int argc, char *argv[]) {
    int i  = 0;
    printf("# Cycles\n");
    fflush(NULL);
    /* run loop depends on argument */
    if (!strcmp(argv[1], "process")) {
        for (; i < ITERATIONS; i++)
            testProcess();
    } else if (!strcmp(argv[1], "thread")) {
        for (; i < ITERATIONS; i++)
            testThread();
    }
    return 0;
}
