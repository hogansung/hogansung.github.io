#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
int main(){    

    unsigned long long int startCycleNum, endCycleNum;  /* Store # of cycles */  
    unsigned int cycleNumHigh, cycleNumLow;   /* Store high, low byte of # of cycle */
    int idx = 0;

    printf("# Cycles\n");   /* Used for collecting data */ 
    
    for(;idx<100000;idx++){
        /* Start: Get # of cycles in the beginning */ 
        asm volatile ("cpuid\n\t"   /* Flush the cpu pipeline */ 
                "rdtsc\n\t"   /* Read Time-Stamp Counter */ 
                "mov %%edx, %0\n\t"   /* Move data from rdx into cycleNumHigh */  
                "mov %%eax, %1\n\t"   /* Move data from rax into cycleNumLow */ 
                : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                :: "%eax","%ebx", "%ecx", "%edx");

        startCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);   /* Calculate the cycle number */ 
        /* End: Get # of cycles in the beginning */ 


        /* Start: Get # of cycles in the end */ 
        asm volatile ("rdtscp\n\t"  /* Read Time-Stamp Counter and Processor ID */ 
                "mov %%edx, %0\n\t"   /* Move data */ 
                "mov %%eax, %1\n\t"   /* Move data */ 
                /*"cpuid\n\t"*/       /* Flush CPU pipeline, not necssary*/ 
                : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                :: "%eax","%ebx", "%ecx", "%edx");

        endCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get # of cycles in the end*/ 

        /* print the result */ 
        printf("%llu\n", endCycleNum - startCycleNum);
    }
}
