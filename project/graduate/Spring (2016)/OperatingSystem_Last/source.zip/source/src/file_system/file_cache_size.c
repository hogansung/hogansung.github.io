#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

const static double LOOP_OVERHEAD = 6.0;
const static double MEASUREMENT_OVERHEAD = 55.63; 
// const static char* fileName = "./testfile_1GB";
const static int BLOCK_SIZE = 4096; //4 KB 

long long getFileSize(int);

int main (int argc, char* argv[]){
	
	if(argc < 2){
		fprintf(stderr, "Please specify the file to load\n");
		exit(1);
	}

	char* fileName = argv[1];

	int fd = open(fileName, O_RDONLY);	// open file read only
	if (fd < 0){
		fprintf(stderr, "Error opening file: %s\n", fileName);
		exit(1);
	}

	long long fileSize = getFileSize(fd); //Bytes
	long long numOfElement = fileSize / BLOCK_SIZE;
	char* block = (char*) malloc(BLOCK_SIZE);
	int readBytes = 0;

	printf("fileSize: %lld, Number of Block: %lld. \n", fileSize, numOfElement);

	if (fileSize <= 0)
	{
		fprintf(stderr, "Error: fileSize is 0.\n");
		exit(1);
	}

	if (numOfElement <= 0)
	{
		fprintf(stderr, "Error: Number of Element is 0.\n");
		exit(1);
	}

	/* read the file block by block to put it into file cache. */
	for (long long i = 0; i < numOfElement; i++){
		readBytes = read(fd, block, BLOCK_SIZE);
	}

	/* Set the file offset to the beginning */ 
	lseek(fd, 0, SEEK_SET);
	
	unsigned long long int startCycleNum, endCycleNum;  /* Store # of cycles */  
    unsigned int cycleNumHigh, cycleNumLow;   /* Store high, low byte of # of cycle */

	/* Start: Get # of cycles in the beginning */ 
    asm volatile ("cpuid\n\t"   /* Flush the cpu pipeline */ 
		            "rdtsc\n\t"   /* Read Time-Stamp Counter */ 
		            "mov %%edx, %0\n\t"   /* Move data from rdx into cycleNumHigh */  
		            "mov %%eax, %1\n\t"   /* Move data from rax into cycleNumLow */ 
					: "=r" (cycleNumHigh), "=r" (cycleNumLow) 
					:: "%eax","%ebx", "%ecx", "%edx");
    startCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);   /* Calculate the cycle number */ 
    /* End: Get # of cycles in the beginning */ 


    for (long long i = 0; i < numOfElement; i++){
	    /* Read a block of the file */ 
    	readBytes = read(fd, block, BLOCK_SIZE);
    }

	/* Start: Get # of cycles in the end */ 
    asm volatile ("rdtscp\n\t"  /* Read Time-Stamp Counter and Processor ID */ 
                	"mov %%edx, %0\n\t"   /* Move data */ 
                	"mov %%eax, %1\n\t"   /* Move data */ 
                	"cpuid\n\t"       /* Flush CPU pipeline, not necssary*/ 
    				: "=r" (cycleNumHigh), "=r" (cycleNumLow) 
    				:: "%eax","%ebx", "%ecx", "%edx");

    endCycleNum = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
    /* End: Get # of cycles in the end*/ 

    /* close file */ 
    close(fd);

    printf("AVG: %f cycles per block\n", ((double)(endCycleNum - startCycleNum)/numOfElement - LOOP_OVERHEAD));
    return 0;
}

    long long getFileSize(int fd) {
    	struct stat s;
    	if (fstat(fd, &s) == -1) {
    		int saveErrno = errno;
    		fprintf(stderr, "fstat(%d) returned errno=%d.", fd, saveErrno);
    		return(-1);
    	}
    	return(s.st_size);
    }