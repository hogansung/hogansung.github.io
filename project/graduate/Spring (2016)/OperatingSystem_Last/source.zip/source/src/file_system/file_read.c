#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <assert.h>

const int NUM_ITER = 100;
const int BLOCK_SIZE = 4096; // 4 KB
const int FILE_SIZE = 536870912; // 512 MB

char path[] = "../../dat/rand-dat/d512m";

/*
 * Prerequisite: 
 * 1. (a) open (O_SYNC) + fcntl (F_NOCACHE) [for MAC OS]
 *    (b) open (O_DIRECT | O_SYNC) [for Linux]
 */

void seqRead() {
    unsigned int cycleNumHigh, cycleNumLow;
    char buf[BLOCK_SIZE];

    int fd = open(path, O_DIRECT | O_SYNC);
    if (fd < 0) {
        fprintf(stderr, "Error in creating file!\n");
        exit(EXIT_FAILURE);
    }
    /*
    if(fcntl(fd, F_NOCACHE, 1) == -1) {
        fprintf(stderr, "Error in disabling file cache!\n");
        exit(EXIT_FAILURE);
    }
    */

    unsigned long long int startCycle, endCycle;
    assert(NUM_ITER <= FILE_SIZE / BLOCK_SIZE);
    for (int i = 0; i < NUM_ITER; i++) {
        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        read(fd, buf, BLOCK_SIZE);

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* print the result */ 
        printf("%llu\n", endCycle - startCycle);
    }

    close(fd);
}

void rndRead() {
    unsigned int cycleNumHigh, cycleNumLow;
    char buf[BLOCK_SIZE];

    int fd = open(path, O_SYNC);
    if (fd < 0) {
        fprintf(stderr, "Error in creating file!\n");
        exit(EXIT_FAILURE);
    }
    /*
    if(fcntl(fd, F_NOCACHE, 1) == -1) {
        fprintf(stderr, "Error in disabling file cache!\n");
        exit(EXIT_FAILURE);
    }
    */

    unsigned long long int startCycle, endCycle;
    assert(NUM_ITER <= FILE_SIZE / BLOCK_SIZE);
    for (int i = 0; i < NUM_ITER; i++) {
        int idx = rand() % (FILE_SIZE / BLOCK_SIZE);
        lseek(fd, idx * BLOCK_SIZE, SEEK_SET);

        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        read(fd, buf, BLOCK_SIZE);

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* print the result */ 
        printf("%llu\n", endCycle - startCycle);
    }

    close(fd);
}

void printErrorMsg() {
    fprintf(stderr, "Usage: ./file_read [command]\n");
    fprintf(stderr, "Available command: s (sequential read)\n");
    fprintf(stderr, "                 : r (random read)\n");
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printErrorMsg();
        exit(EXIT_FAILURE);
    } else {
        if (argv[1][0] == 's') {
            printf("# Cycles\n");
            seqRead();
        } else if (argv[1][0] == 'r') {
            printf("# Cycles\n");
            rndRead();
        } else {
            printErrorMsg();
            exit(EXIT_FAILURE);
        } 
    }
}
