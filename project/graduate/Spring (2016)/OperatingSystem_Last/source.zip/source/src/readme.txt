# set cpupower
sudo cpupower --cpu all frequency-set -f 1600MHz

# delete file cache
echo 3 | sudo tee /proc/sys/vm/drop_caches

# set priority and single core
sudo nice --20 taskset 0x1 [Program]
