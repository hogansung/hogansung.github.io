#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <assert.h>

const int NUM_ITER = 100;
const int PORT_NO = 10000;
const char IP_ADDRESS[] = "127.0.0.1";

void testHandShake() {
    unsigned int cycleNumHigh, cycleNumLow;
    unsigned long long int startCycle, endCycle;

    for (int i = 0; i < NUM_ITER; i++) {
        /* create socket */
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) {
            fprintf(stderr, "Error in opening socket!\n");
            exit(EXIT_FAILURE);
        }

        struct hostent* hostp = gethostbyname(IP_ADDRESS);
        if (hostp == NULL) {
            fprintf(stderr,"Error in finding such host!\n");
            exit(EXIT_FAILURE);
        }
        
        struct in_addr* ip = (struct in_addr*)hostp->h_addr_list[0];

        /* create server socket address */
        struct sockaddr_in s_addr;
        memset((char*) &s_addr, 0, sizeof(s_addr));
        s_addr.sin_family = AF_INET;
        s_addr.sin_addr.s_addr = ip->s_addr;;
        s_addr.sin_port = htons(PORT_NO);

        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* try connecting */
        ssize_t res = connect(sockfd, (struct sockaddr*) &s_addr, sizeof(s_addr));
        
        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 
       
        /* delayed examination */
        if (res < 0) {
            fprintf(stderr,"Error in connecting!\n");
            exit(EXIT_FAILURE);
        }

        /* print the result */ 
        printf("%llu\n", endCycle - startCycle);

        /* close sockets */
        close(sockfd);
    }
}

void testTerminate() {
    unsigned int cycleNumHigh, cycleNumLow;
    unsigned long long int startCycle, endCycle;

    for (int i = 0; i < NUM_ITER; i++) {
        /* create socket */
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) {
            fprintf(stderr, "Error in opening socket!\n");
            exit(EXIT_FAILURE);
        }

        struct hostent* hostp = gethostbyname(IP_ADDRESS);
        if (hostp == NULL) {
            fprintf(stderr,"Error in finding such host!\n");
            exit(EXIT_FAILURE);
        }
        
        struct in_addr* ip = (struct in_addr*)hostp->h_addr_list[0];

        /* create server socket address */
        struct sockaddr_in s_addr;
        memset((char*) &s_addr, 0, sizeof(s_addr));
        s_addr.sin_family = AF_INET;
        s_addr.sin_addr.s_addr = ip->s_addr;;
        s_addr.sin_port = htons(PORT_NO);

        /* try connecting */
        ssize_t res = connect(sockfd, (struct sockaddr*) &s_addr, sizeof(s_addr));
        if (res < 0) {
            fprintf(stderr,"Error in connecting!\n");
            exit(EXIT_FAILURE);
        }

        /* Start: Get the number of cycles */ 
        asm volatile ("cpuid\n\t"   
                      "rdtsc\n\t" 
                      "mov %%edx, %0\n\t" 
                      "mov %%eax, %1\n\t"
                    : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                    :: "%eax","%ebx", "%ecx", "%edx");
        startCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* close sockets */
        close(sockfd);

        /* Start: Get the number of cycles */ 
        asm volatile ("rdtscp\n\t" 
                      "mov %%edx, %0\n\t"   
                      "mov %%eax, %1\n\t"
                      /*"cpuid\n\t"*/   
                      : "=r" (cycleNumHigh), "=r" (cycleNumLow) 
                      :: "%eax","%ebx", "%ecx", "%edx");
        endCycle = (((uint64_t) cycleNumHigh << 32) | cycleNumLow);
        /* End: Get the number of cycles */ 

        /* print the result */ 
        printf("%llu\n", endCycle - startCycle);
    }
}

void printErrorMsg() {
    fprintf(stderr, "Usage: ./client [command]\n");
    fprintf(stderr, "Available command: h (hand shake)\n");
    fprintf(stderr, "                 : t (terminate)\n");
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printErrorMsg();
        exit(EXIT_FAILURE);
    } else {
        if (argv[1][0] == 'h') {
            printf("# Cycles\n");
            testHandShake();
        } else if (argv[1][0] == 't') {
            printf("# Cycles\n");
            testTerminate();
        } else {
            printErrorMsg();
            exit(EXIT_FAILURE);
        } 
    }
}

/* start communication */
/*
char buf[256] = "zzzz";

res = write(sockfd, buf, strlen(buf));
if (res < 0) {
    fprintf(stderr, "Error in writing!\n");
    exit(EXIT_FAILURE);
}

res = read(sockfd, buf, 255);
if (res < 0) {
    fprintf(stderr, "Error in reading!\n");
    exit(EXIT_FAILURE);
}
printf("Here is the message: %s\n", buf);
*/
