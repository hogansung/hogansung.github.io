#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <assert.h>

const int PORT_NO = 10000;

int main() {
    /* create socket */
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        fprintf(stderr, "Error in opening socket!\n");
        exit(EXIT_FAILURE);
    }

    /* create server socket address */
    struct sockaddr_in s_addr;
    memset((char*) &s_addr, 0, sizeof(s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_addr.s_addr = INADDR_ANY;
    s_addr.sin_port = htons(PORT_NO);

    /* try binding */
    if (bind(sockfd, (struct sockaddr*) &s_addr, sizeof(s_addr)) < 0) {
        fprintf(stderr, "Error in binding!\n");
        exit(EXIT_FAILURE);
    }

    /* start listeing */
    listen(sockfd,5);

    /* create client socket address */
    struct sockaddr_in c_addr;
    socklen_t c_len = sizeof(c_addr);

    while (1) {
        /* create connection socket */
        int connfd = accept(sockfd, (struct sockaddr*) &c_addr, &c_len);
        if (connfd < 0) {
            fprintf(stderr, "Error in accepting!\n");
            exit(EXIT_FAILURE);
        }

        /* start communication */
        /*
        char buffer[256] = {};
        ssize_t res = read(connfd, buffer, 255);
        if (res < 0) {
            fprintf(stderr, "Error in reading!\n");
            exit(EXIT_FAILURE);
        }
        fprintf(stdout, "Here is the message: %s\n", buffer);

        memset(buffer, 0, sizeof(buffer));
        res = write(connfd,"I got your message", 18);
        if (res < 0) {
            fprintf(stderr, "Error in writing!\n");
            exit(EXIT_FAILURE);
        }
        */

        /* close connection socket */
        close(connfd);
    }

    /* close socket */
    close(sockfd);
}
