#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 


int main(int argc, char *argv[])
{

    /* Hostname, Port specified by user */ 
    if (argc < 3){
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    struct hostent *server;
    server = gethostbyname(argv[1]);
    int port_num = atoi(argv[2]);

    /* if there's no such hostname */ 
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }    

    /* create socket */ 
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){ 
        fprintf(stderr, "ERROR opening socket\n");
        exit(1);
    }
    
    /* set up the server side */ 
    struct sockaddr_in serv_addr;
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(port_num);


    /* connect to the socket on the host */ 
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0){
        fprintf(stderr, "ERROR connecting\n");
        exit(1); 
    } 
        
    int work_bytes;
    char buffer[256];

    while(1){
        printf("Please enter the message: ");
        
        bzero(buffer,256);
        fgets(buffer,255,stdin);
        
        work_bytes = write(sockfd,buffer,strlen(buffer));
        if (work_bytes < 0){ 
            fprintf(stderr, "ERROR writing to socket\n");
            exit(1);
        }
  
        work_bytes = read(sockfd,buffer,255);
        
        if (work_bytes < 0){ 
             fprintf(stderr, "ERROR reading from socket\n");
             exit(1);
        }
        printf("%s",buffer);
    }
    close(sockfd);
    return 0;
}