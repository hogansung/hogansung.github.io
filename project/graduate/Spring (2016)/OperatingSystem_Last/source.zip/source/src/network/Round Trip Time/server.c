#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char *argv[])
{
    /* create socket */ 
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0){
        fprintf(stderr, "ERROR opening socket");
        exit(1);
    }

    /* port specified from users */ 
    if (argc < 2) {
        fprintf(stderr,"ERROR, no port provided\n");
        exit(1);
    }
    int port_num = atoi(argv[1]);
    
    /* create server socket */    
    struct sockaddr_in serv_addr;
    memset((char*) &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port_num);

    /* binding */ 
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
        fprintf(stderr, "ERROR on binding!!!\n");
        exit(1);
    }

    /* server listening */ 
    listen(sockfd,5);
    
    /* create connection socket */
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    int new_sockfd = accept(sockfd, (struct sockaddr *) &client_addr, &client_len);
    if (new_sockfd < 0){
        fprintf(stderr, "Error on accept!\n");
        exit(1);
    }

    int work_bytes;
    char buffer[256];
    while (1) {
        // Clear the buffer. 
        bzero(buffer,256);

        // Read the msg from socket, work_bytes means the bytes that we recieved. 
        work_bytes = read(new_sockfd,buffer,255);

        if (work_bytes < 0){
            fprintf(stderr,"ERROR reading from socket\n");
            exit(1);
        }

        printf("Messaeg from socket: %s", buffer);

        work_bytes = write(new_sockfd,"I got your message",18);

        if (work_bytes < 0){
            fprintf(stderr, "Error writing to socket!!\n");
            exit(1);
        }
    }
    /* close the connected socket */ 
    close(new_sockfd);
    /* close the server socket */ 
    close(sockfd);
    return 0;
}