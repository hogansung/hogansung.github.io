A Fused Convolutional and Recurrent Neural Network for Visual-Inertial Odometry
