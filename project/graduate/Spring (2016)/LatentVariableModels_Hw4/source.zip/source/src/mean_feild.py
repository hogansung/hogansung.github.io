import matplotlib.pyplot as plt
from matplotlib import cm
import pandas as pd
import numpy as np
import math


# fix numpy seed
np.random.seed(514)
TARGET = 1
THRESHOLD = 128


# read data
df = pd.read_csv('../dat/train.csv', sep=',')

# pick up one image
lab = df.iloc[TARGET,0]
img = df.iloc[TARGET,1:].as_matrix()
img = img.astype(np.uint8)

# set threshold for images
img[img < THRESHOLD] = 0
img[img >= THRESHOLD] = 255

# build ground truth matrix into {-1, +1}
gmat = img.astype(np.int64)
gmat = gmat / 255 * 2 - 1

# flip 10% at random
idx = np.random.choice(range(784), 78, replace=False)
rev_idx = list(np.setdiff1d(np.array(range(784)), idx))
img[idx] = 255-img[idx]

# reshape array into image
img = img.reshape((28,28))
plt.imshow(img,cmap=cm.gray)

# map matrix into {-1, +1}
mat = img.astype(np.int64)
mat = mat / 255 * 2 - 1


# accuracy calculation
def calACC(pmat, gmat, idx):
    ret = 0.0
    pmax = pmat.flatten() >= 0
    gmat = gmat >= 0
    
    for i in idx:
        if pmax[i] == gmat[i]:
            ret += 1.0
    return ret / len(idx)


# Mean Field Algorithm Implementation
NUM_ITER = 10
CONST = 1

bmat = mat * CONST
mmat = np.random.uniform(-1.0, +1.0, (28,28))

for t in range(NUM_ITER):
    for i in range(28):
        for j in range(28):
            a = bmat[i,j]
            if i > 0:
                a += mmat[i-1,j]
            if i < 27:
                a += mmat[i+1,j]
            if j > 0:
                a += mmat[i,j-1]
            if j < 27:
                a += mmat[i,j+1]
            mmat[i,j] = np.tanh(a)

# calculate accuracy
print 'Perturbed Pixels: %f' % calACC(mmat, gmat, idx)
print 'Unperturbed Pixels: %f' % calACC(mmat, gmat, rev_idx)
print 'Overall: %f' % calACC(mmat, gmat, range(784))            

# map matrix into {0, 255}
mmat = (mmat + 1) / 2 * 255
img = mmat.astype(np.uint8)
plt.imshow(img,cmap=cm.gray)
plt.savefig('../res/mean_field.png')
