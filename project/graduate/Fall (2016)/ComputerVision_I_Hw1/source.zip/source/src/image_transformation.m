res = figure('visible','off');
set(res, 'PaperPosition', [0 0 40 20]);

% Four 3D points
obj = [-1 -0.5 2; 1 -0.5 2; 1 0.5 2; -1 0.5 2];
obj(:, 4) = [1 1 1 1];

% Four scenarios
E = cell(4);
K = cell(4);
S = cell(4);

K{1} = [1 0 0; 0 1 0; 0 0 1];
E{1} = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
S{1} = 'No rigid body transformation';

K{2} = [1 0 0; 0 1 0; 0 0 1];
E{2} = [1 0 0 0; 0 1 0 0; 0 0 1 1; 0 0 0 1];
S{2} = 'Translation';

K{3} = [1 0 0; 0 1 0; 0 0 1];
E{3} = [sqrt(2) / 4 -sqrt(3) / 2 sqrt(2)/4 0; 
        sqrt(6)/4 1/2 sqrt(6)/4 0; 
        -sqrt(2)/2 0 sqrt(2)/2 1; 0 0 0 1];
S{3} = 'Translation and rotation';

K{4} = [15 0 0; 0 15 0; 0 0 1];
E{4} = [0 -sqrt(3)/2 1/2 0; 
        0 1/2 sqrt(3)/2 0; 
        -1 0 0 13; 0 0 0 1];
S{4} = 'Translation and rotation, long distance';

% Draw subplots accordingly
for k = 1:4
    subplot(2,2,k);
    dat = K{k} * [eye(3) zeros(3, 1)] * E{k} * obj';
    plotsquare(dat);
    title(S{k});
end

% Save generated figure
saveas(res, '../res/image_transformation.jpg');