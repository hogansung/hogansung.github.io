load('../dat/facedata.mat');

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 40 20]);

subplot(1,2,1);
surf(heightmap, albedo);
title('Albedo');

subplot(1,2,2);
surf(heightmap, uniform_albedo);
title('Uniform Albedo');

saveas(res, '../res/face_3D.jpg');