load('../dat/facedata.mat');

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 20 20]);

[n, m] = size(heightmap);
img_a_1 = zeros(n, m);
img_a_2 = zeros(n, m);
img_a_12 = zeros(n, m);
img_ua_1 = zeros(n, m);
img_ua_2 = zeros(n, m);
img_ua_12 = zeros(n, m);

for i = 1:n
    for j = 1:m
        if i < n
            b = heightmap(i,j) - heightmap(i+1,j);
        else 
            b = heightmap(i,j);
        end
        if j < m
            a = heightmap(i,j) - heightmap(i,j+1);
        else
            a = heightmap(i,j);
        end
        nz = sqrt(1/(a*a+b*b+1));
        nx = a * nz;
        ny = b * nz;
        
        dist_1 = norm(lightsource(1,:) - [i, j, heightmap(i,j)]);
        img_a_1(i,j) = max(0, albedo(i,j) * [nx ny nz] ...
            * lightsource(1,:)' * 1.0 / (dist_1^2));
        img_ua_1(i,j) = max(0, uniform_albedo(i,j) * [nx ny nz] ...
            * lightsource(1,:)' * 1.0 / (dist_1^2));
        
        dist_2 = norm(lightsource(2,:) - [i, j, heightmap(i,j)]);
        img_a_2(i,j) = max(0, albedo(i,j) * [nx ny nz] ...
            * lightsource(2,:)' * 1.0 / (dist_1^2));
        img_ua_2(i,j) = max(0, uniform_albedo(i,j) * [nx ny nz] ...
            * lightsource(2,:)' * 1.0 / (dist_1^2));
        
        img_a_12(i,j) = img_a_1(i,j) + img_a_2(i,j);
        img_ua_12(i,j) = img_ua_1(i,j) + img_ua_2(i,j);
    end
end

subplot(2,3,1);
imagesc(img_a_1);
title('Albedo with light 1');

subplot(2,3,2);
imagesc(img_a_2);
title('Albedo with light 2');

subplot(2,3,3);
imagesc(img_a_12);
title('Albedo with light 1 and 2');

subplot(2,3,4);
imagesc(img_ua_1);
title('Uniform Albedo with light 1');

subplot(2,3,5);
imagesc(img_ua_2);
title('Uniform Albedo with light 2');

subplot(2,3,6);
imagesc(img_ua_12);
title('Uniform Albedo with light 1 and 2');

saveas(res, '../res/render.jpg');