load('../dat/facedata.mat');

%% Draw Surface Normal

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 20 20]);

[n, m] = size(heightmap);
nx = zeros(n, m);
ny = zeros(n, m);
nz = zeros(n, m);

for i = 1:n
    for j = 1:m
        if i < n
            b = heightmap(i,j) - heightmap(i+1,j);
        else 
            b = heightmap(i,j);
        end
        if j < m
            a = heightmap(i,j) - heightmap(i,j+1);
        else
            a = heightmap(i,j);
        end
        nz(i,j) = sqrt(1/(a*a+b*b+1));
        nx(i,j) = a * nz(i,j);
        ny(i,j) = b * nz(i,j);
    end
end

x = 1:5:130;
y = 1:5:190;
[X,Y] = meshgrid(x, y);

ss_h = imresize(heightmap, 0.2);
ss_nx = imresize(nx, 0.2);
ss_ny = imresize(ny, 0.2);
ss_nz = imresize(nz, 0.2);

quiver3(X, Y, ss_h, ss_nx, ss_ny, ss_nz);
title('Surface');

saveas(res, '../res/surface_normal.jpg');