load('../dat/synthetic_data.mat');

%% Preparation

% Prepare image matrix
img = zeros(4, 10000);
img(1,:) = im1(:);
img(2,:) = im2(:);
img(3,:) = im3(:);
img(4,:) = im4(:);
img = arrayfun(@(x) double(x) / 256, img);
imgc = num2cell(img, 1);

% Prepare small image matrix
s_img = img([1 2:4],:);
s_imgc = num2cell(s_img, 1);

% Prepare light direction sources
lgt = zeros(4, 3);
lgt(1,:) = l1(:) / norm(l1(:));
lgt(2,:) = l2(:) / norm(l2(:));
lgt(3,:) = l3(:) / norm(l3(:));
lgt(4,:) = l4(:) / norm(l4(:));

% Calculate pesudo inverse of light matrix
plgt = pinv(lgt);

% Calculate G = Kd * N = L \ I
G = arrayfun(@(x) plgt * x{:}, imgc, 'UniformOutput', false);
s_G = arrayfun(@(x) plgt * x{:}, s_imgc, 'UniformOutput', false);

G = reshape(G, [100, 100]);
s_G = reshape(s_G, [100, 100]);



%% (1) Draw Albedo

% Calculate Kd = |G|
Kd = arrayfun(@(x) norm(x{:}), G, 'UniformOutput', false);
s_Kd = arrayfun(@(x) norm(x{:}), s_G, 'UniformOutput', false);

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 40 20]);

subplot(1,2,1);
imagesc(cell2mat(s_Kd));
title('Albedo with 3 images');

subplot(1,2,2);
imagesc(cell2mat(Kd));
title('Albedo with 4 images');

saveas(res, '../res/stereo_albedo.jpg');



%% (2) Draw Surface Normal

% Calculate N
N = cellfun(@(x,y) x/y, G, Kd, 'UniformOutput', false);
N = reshape(cell2mat(N), [3, 100, 100]);
Nx = squeeze(N(1,:,:));
Ny = squeeze(N(2,:,:));
Nz = squeeze(N(3,:,:));

s_N = cellfun(@(x,y) x/y, s_G, s_Kd, 'UniformOutput', false);
s_N = reshape(cell2mat(s_N), [3, 100, 100]);
s_Nx = squeeze(s_N(1,:,:));
s_Ny = squeeze(s_N(2,:,:));
s_Nz = squeeze(s_N(3,:,:));

% Calculate D
D = zeros(100, 100);
s_D = zeros(100, 100);
for i = 2:100
    D(i,1) = D(i-1,1) - Nx(i,1)/Nz(i,1);
    s_D(i,1) = s_D(i-1,1) - s_Nx(i,1)/s_Nz(i,1);
end
for i = 1:100
    for j = 2:100
        D(i,j) = D(i,j-1) - Ny(i,j)/Nz(i,j);
        s_D(i,j) = s_D(i,j-1) - s_Ny(i,j)/s_Nz(i,j);
    end
end

% Subsample graph
x = 1:5:100;
y = 1:5:100;
[X,Y] = meshgrid(x, y);
ss_Nx = imresize(Nx, 0.2);
ss_Ny = imresize(Ny, 0.2);
ss_Nz = imresize(Nz, 0.2);
ss_D = imresize(D, 0.2);

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 40 20]);

subplot(1,2,1);
quiver3(X, Y, ss_D, ss_Nx, ss_Ny, ss_Nz);
title('Surface normal with 3 images');

subplot(1,2,2);
quiver3(X, Y, ss_D, ss_Nx, ss_Ny, ss_Nz);
title('Surface normal with 4 images');

saveas(res, '../res/stereo_surface_normal.jpg');



%% (3) Draw depth map

res = figure('visible','off');
set(res, 'PaperPosition', [0 0 40 20]);

subplot(1,2,1);
x = 1:1:100;
y = 1:1:100;
[X,Y] = meshgrid(x, y);
surf(X, Y, D);
title('Depth map with 3 images');

subplot(1,2,2);
surf(s_D);
title('Depth map with 4 images');

saveas(res, '../res/stereo_depth_map.jpg');