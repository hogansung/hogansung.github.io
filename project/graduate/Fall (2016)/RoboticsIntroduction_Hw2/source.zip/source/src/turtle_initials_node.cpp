#include "ros/ros.h"
#include <string>

/********************************
 *
 * ADD ADDITIONAL HEADERS HERE.
 *
 ********************************/

#include <cmath>
#include "turtlesim/SetPen.h";
#include "turtlesim/TeleportAbsolute.h";
#include "geometry_msgs/Twist.h";

const double pi = acos(-1);

/***************************
 *
 * ADD ANY CALLBACKS HERE.
 *
 ***************************/

/***************************
 *
 * HELPER FUNCTION.
 *
 ***************************/

void pen_on(ros::ServiceClient& setpenClient) {
	turtlesim::SetPen setpen_srv;
	setpen_srv.request.r = 0xb3;
	setpen_srv.request.g = 0xb8;
	setpen_srv.request.b = 0xff;
	setpen_srv.request.width = 3;
	setpenClient.call(setpen_srv);
} 

void pen_off(ros::ServiceClient& setpenClient) {
	turtlesim::SetPen setpen_srv;
	setpen_srv.request.r = 0x45;
	setpen_srv.request.g = 0x56;
	setpen_srv.request.b = 0xff;
	setpen_srv.request.width = 0;
	setpenClient.call(setpen_srv);
} 

void teleport(float x, float y, double theta, ros::ServiceClient& teleportClient) {
	turtlesim::TeleportAbsolute teleport_srv;
	teleport_srv.request.x = x;
	teleport_srv.request.y = y;
	teleport_srv.request.theta = theta;
	teleportClient.call(teleport_srv);
}

void change(double lx, double az, ros::Publisher& drawPub) {
	geometry_msgs::Twist twist;
	twist.linear.x = lx;
	twist.angular.z = az;
	drawPub.publish(twist);
}

int main(int argc, char **argv)
{
	// Initialize the node.
	ros::init(argc, argv, "turtle_initials_node");
	ros::NodeHandle node;

	// Sleep on startup for 1 second.
	ros::Rate startup(1);
	startup.sleep();

	// Loop at 10Hz, publishing commands.
	ros::Rate rate(10);

	/***************************************
	 *
	 * SETUP TOPIC AND SERVICE CONNECTIONS.
	 *
	 ***************************************/

	ros::Publisher drawPub = node.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
	ros::ServiceClient setpenClient = node.serviceClient<turtlesim::SetPen>("/turtle1/set_pen");
	ros::ServiceClient teleportClient = node.serviceClient<turtlesim::TeleportAbsolute>("/turtle1/teleport_absolute");

	// Print the start of the control.
	ROS_INFO("STARTING TURTLE INITIALS CONTROL.");

	int st = 0;
	// 0: .
	// 1: H: 1
	// 2: H: -
	// 3: H: 1
	// 2: .
	// 3: S (top)
	// 4: S (bot)
	// 5: celebration


	int cnt = 0;

	// Loop while ROS is okay.
	while (ros::ok()) 
	{
		/*************************************************
		 *
		 * SET UP STATE MACHINE FOR CONTROLING TURTLESIM.
		 *
		 *************************************************/
		if (st == 0) {
			if (cnt == 0) {
				pen_off(setpenClient);
				teleport(1.5, 10, 3*pi/2, teleportClient);
				pen_on(setpenClient);
				cnt += 1;
			} else if (cnt == 63) {
				change(0, 0, drawPub);
				st = 1;
				cnt = 0;	
			} else {
				change(1, 0, drawPub);
				cnt += 1;
			}
		} else if (st == 1) {
			if (cnt == 0) {
				teleport(1.5, 7, 0, teleportClient);
				pen_on(setpenClient);
				cnt += 1;
			} else if (cnt == 31) {
				change(0, 0, drawPub);
				pen_off(setpenClient);
				st = 2;
				cnt = 0;
			} else {
				change(1, 0, drawPub);
				cnt += 1;
			}
		} else if (st == 2) {
			if (cnt == 0) {
				pen_off(setpenClient);
				teleport(4.5, 10, 3*pi/2, teleportClient);
				pen_on(setpenClient);
				cnt += 1;
			} else if (cnt == 61) {
				change(0, 0, drawPub);
				st = 3;
				cnt = 0;
			} else {
				change(1, 0, drawPub);
				cnt += 1;
			}
		} else if (st == 3) {
			if (cnt == 0) {
				pen_off(setpenClient);
				teleport(5, 4, 3*pi/2, teleportClient);
				pen_on(setpenClient);
				change(1, 0, drawPub);
				cnt += 1;
			} else {
				change(0, 0, drawPub);
				st = 4;
				cnt = 0;
			}
		} else if (st == 4) {
			if (cnt == 0) {
				pen_off(setpenClient);
				teleport(9.5, 8.5, pi/2, teleportClient);
				pen_on(setpenClient);
				cnt += 1;
			} else if (cnt == 73) {
				change(0, 0, drawPub);
				pen_off(setpenClient);
				st = 5;
				cnt = 0;
			} else {
				change(1, 0.66, drawPub);
				cnt += 1;
			}
		} else if (st == 5) {
			if (cnt == 0) {
				pen_on(setpenClient);
				cnt += 1;
			} else if (cnt == 73) {
				change(0, 0, drawPub);
				pen_off(setpenClient);
				st = 6;
				cnt = 0;
			} else {
				change(1, -0.66, drawPub);
				cnt += 1;
			}
		} else if (st == 6) {
			if (cnt == 0) {
				pen_off(setpenClient);
				teleport(10, 4, 3*pi/2, teleportClient);
				pen_on(setpenClient);
				change(1, 0, drawPub);
				cnt += 1;
			} else {
				change(0, 0, drawPub);
				st = 7;
				cnt = 0;
			}
		} else if (st == 7) {
			pen_off(setpenClient);
			teleport(5.5, 2, pi/2, teleportClient);
			change(2, 1, drawPub);
		}

		// Allow for processing incoming messages.
		ros::spinOnce();

		// Sleep to control the rate of publishing.
		rate.sleep();
	}
}
