#include <cstdio>
#include <cstdlib>
#include <vector>
#include <utility>
#include <string>
#include <algorithm>
#include <unordered_set>

using namespace std;

const int LEN = 5;
const int MAXLEN = 30;

int main() {
    // [Read Data]
    string path = "../dat/hw1_word_counts_" + 
      to_string(LEN/10) + to_string(LEN%10) + ".txt";
    FILE* pfile = fopen(path.c_str(), "r");
    if (pfile == NULL) {
        fprintf(stderr, "Read file failed\n");
        exit(EXIT_FAILURE);
    }

    char word[MAXLEN];
    int cnt;
    vector<pair<int, string>> vct;
    while (fscanf(pfile, "%s%d", word, &cnt) != EOF) {
        vct.emplace_back(cnt, word);
    }

    fclose(pfile);
    


    int size = vct.size();
    {   // [Problem (a)]
        sort(vct.begin(), vct.end());
        fprintf(stdout, "Most frequent fifteen words\n");
        for (int i = 0; i < 15; i++) {
            fprintf(stdout, "%s\n", vct[size-1-i].second.c_str());
        }
        fprintf(stdout, "\n");
        fprintf(stdout, "Less frequent forteen words\n");
        for (int i = 0; i < 14; i++) {
            fprintf(stdout, "%s\n", vct[i].second.c_str());
        }
        fprintf(stdout, "\n");
    }

    

    {   // [Problem (b)]
        // [Input] 
        //   * Guess string
        //     * capital characters only
        //     * empty character with - sign 
        //   * Charater string: {A,...,Z}
        //     * no additional space is allowed
        char str[MAXLEN];
        char chr[MAXLEN];
        while (scanf("%s%s", str, chr) != EOF) {
            unordered_set<int> uset;
            int nchr = strlen(chr);
            for (int i = 0; i < LEN; i++) {
                uset.emplace(str[i]-'A');
            }
            for (int i = 1; i < nchr-1; i+=2) {
                uset.emplace(chr[i]-'A');
            }

            vector<pair<double,int>> res;
            for (int k = 0; k < 26; k++) {
                if (uset.find(k) != uset.end()) {
                    continue; // queried, just skip
                }
                int num = 0;
                int div = 0;
                for (int i = 0; i < size; i++) {
                    bool suc = true;
                    int match = 0;
                    for (int j = 0; j < LEN; j++) {
                        if (str[j] == '-') {
                            if (uset.find(vct[i].second[j]-'A') 
                                != uset.end()) {
                                suc = false;
                            }
                            if (vct[i].second[j]-'A' == k) {
                                match += 1;
                            }
                        } else {
                            if (str[j] != vct[i].second[j]) {
                                suc = false;
                            }
                        }
                    }
                    if (suc == true) {
                        div += vct[i].first;
                        if (match > 0) {
                            num += vct[i].first;
                        }
                    }
                }
                res.emplace_back(1.0 * num / div, k);
            }

            int res_size = res.size();
            sort(res.begin(), res.end());
            fprintf(stdout, "Best: %c\n", res[res_size-1].second + 'A');
            fprintf(stdout, "Prob: %.4f\n\n",res[res_size-1].first);
        }
    }
}
