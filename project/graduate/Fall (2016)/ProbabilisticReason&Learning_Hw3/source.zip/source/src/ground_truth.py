for k in range(5):
    nm = 0
    dn = 0

    for i in range(1024):
        suc = ((i & (1 << (2*k+1))) != 0)

        val = (1-0.2) / (1+0.2) * (0.2 ** abs(128-i))
        if suc == True:
            nm = nm + val
        dn = dn + val

    print nm / dn
