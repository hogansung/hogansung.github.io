% Number of bits
NB = 10;

% Given B_2, B_4, B_6, B_8, B_10
tar = [2, 4, 6, 8, 10];

% Given evidence
z = 128;

% Alpha setting
a = 0.2;

% Number of samples
N = 1000000;

for k = 1:size(tar, 2)
    % Initialize numerator and denominator
    nm = 0;
    dn = 0;
    
    % Record
    rcd = zeros(1, N);
    
    for i = 1:N
        % Random joint distribution of B_1, ..., B_10
        t = randi(2^NB)-1;

        % Check I(q, q')
        suc = bitand(t, 2^(tar(k)-1)) ~= 0;

        % Update
        val = (1-a) / (1+a) * a^abs(z-t);
        nm = nm + suc * val;
        dn = dn + val;
        
        rcd(i) = nm / dn;
    end
    
    % Save image and ouput result
    res = figure('visible', 'off');
    plot(rcd);
    rcd(end)
    saveas(res, strcat('B', int2str(2*k), '.png'));
end