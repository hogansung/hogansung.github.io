%% ----------- Parameters ---------------
t_res = 0.3 ; % theta resolution
d_res =0.25 ; % delta resolution
threshold =0.75; % threshold value for hough peaks

%% ----------- Importing Image and converting to Grayscale -----------
I = imread('lanes.png');
I = rgb2gray(I);
subplot(1,3,1);imshow(I); title('(a) Original Image'); hold on ;

%% ----------- Using Edge Detector -----------
E = edge(I, 'sobel',0.05);
subplot(1,3,2); imshow(E); title('(b) Edges (Sobel, 0.05)'); hold on ;

%% ----------- Hough Transform of Image -----------
%[H, theta, rho] = hough(E); -- inbuilt Matlab function to check result

H = zeros(1,180/t_res) ; 
t = atan2(size(E,1 ) ,size(E,2)) ;
rowSize = ceil(size(E,1)*sin(t)+size(E,2)*cos(t));
T =0 ; % couting variable
img_H = zeros(2*(rowSize/d_res)+1,180/t_res) ;
for row = 1:size(E,1)
    for col =1:size(E,2)
        T = T+1;
        if(E(row,col)== 1) 
            for degree = t_res:t_res:180
                d =(col*cosd(degree)+row*sind(degree));
                H(T,round(degree/t_res)) = d ;
                img_H(round(d/d_res) + rowSize/d_res+1,round(degree/t_res))=img_H(round(d/d_res)+rowSize/d_res+1, round(degree/t_res))+1; 
            end
        end
    end
end
%% -------------- Threshold peak detection and Hough line generation -------------------
clear row col d x y
T = 0 ;
max_img = max(max(img_H));
for row =1:size(img_H,1)
    for col= 1:size(img_H,2)
        if(img_H(row,col) > threshold*max_img)
            T = T +1; 
            d =(row-1-rowSize /d_res)*d_res ;
            t = col*t_res ;
            fy =@(x) (d-x*cosd(t))/sind(t) ;
            fplot(fy,'Color', 'r') ;
        end
    end
end
subplot(1,3,3); imshow(I); title('(d) Hough Lines on Original Image'); hold on ;