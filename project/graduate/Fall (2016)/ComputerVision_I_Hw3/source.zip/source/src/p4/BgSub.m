
tau = 25;

%framesequence = 'data/highway/';
framesequence = 'data/truck/';
Img = backgroundSubtract(framesequence, tau);

% --- Plotting ---
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,400,200]);

subplot (1,2,1);
%It = im2double( imread( strcat(framesequence, '00050.png') ) );
It = im2double( imread( strcat(framesequence, '00395.png') ) );
imshow(It);
title('(a) a image from a frame t');

subplot(1,2,2);
imshow(Img);
title('(b) background image');

%saveas(graph, 'Output/4-1_SubBackground-1.jpg');
saveas(graph, 'Output/4-1_SubBackground-2.jpg');

%% Background Substruction
function Img = backgroundSubtract(framesequence, tau)
    imgSeqFiles = dir( strcat(framesequence,'*.png') );
    nFiles = length(imgSeqFiles);
    I = imread( strcat(framesequence,imgSeqFiles(1).name) );
    
    [nRows, nCols] = size(I);
    backImgSum = double( zeros(nRows, nCols) );
    
    for ii = 2:nFiles
        It_0 = im2double( imread( strcat(framesequence,imgSeqFiles(ii-1).name) ) );
        It_1 = im2double( imread( strcat(framesequence,imgSeqFiles(ii).name) ) );
        Img = imageDifference(It_0, It_1, tau);
        backImgSum = backImgSum + Img;    
    end
    
    Img = backImgSum / (nFiles-1);
    
end

function SubBackImg = imageDifference(It_0, It_1, tau)
    SubBackImg = It_1 - It_0;
    [nRows, nCols] = size(SubBackImg);
    for i = 1:nRows
        for j = 1:nCols
            % If exceed difference threshold, then set the pixel value to
            % zero
            if ( abs(SubBackImg(i,j)) > tau )
                SubBackImg(i,j) = It_0(i,j) - It_1(i,j); 
            else
                SubBackImg(i,j) = It_0(i,j);
            end
        end
    end

end
