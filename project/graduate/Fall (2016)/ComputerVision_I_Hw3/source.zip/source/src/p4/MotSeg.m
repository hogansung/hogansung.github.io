u2 = dlmread('data/u2.txt');
v2 = dlmread('data/v2.txt');

It = im2double( imread( strcat('data/flower/', '00029.png') ) );
It = rgb2gray(It);

[n, m] = size(It);

It_segTree = zeros(n, m);
I_OnlyTree = zeros(n, m);
MotSegFig = zeros(n, m);
threhold = [2.6,3.8];
SegLst = [1, 1.5, 1.9, 2.6, 3.8];


for i = 1:n
    for j = 1:m
        MagOfMotion = sqrt(u2(i,j)^2 + v2(i,j)^2 );
        if (MagOfMotion <= SegLst(1))
            MotSegFig(i,j) = 1; 
        elseif ( SegLst(1) < MagOfMotion && MagOfMotion <= SegLst(2) )
            MotSegFig(i,j) = 2; 
        elseif ( SegLst(2) < MagOfMotion && MagOfMotion <= SegLst(3) )
            MotSegFig(i,j) = 3; 
        elseif ( SegLst(3) < MagOfMotion && MagOfMotion <= SegLst(4) )
            MotSegFig(i,j) = 4;
        elseif ( SegLst(4) < MagOfMotion && MagOfMotion <= SegLst(5) )
            MotSegFig(i,j) = 5;
        else
            MotSegFig(i,j) = 6;
        end
        %MotSegFig(i,j) = MagOfMotion;
        
        if(threhold(1)<MagOfMotion && MagOfMotion<threhold(2))
            It_segTree(i,j) = 255;
            I_OnlyTree(i,j) = It(i,j);
        else
            It_segTree(i,j) = It(i,j);
            I_OnlyTree(i,j) = 255;
        end      
    end
end

graph = figure('visible', 'on');
set(gcf,'units','points','position',[0,0,800,800]);

subplot(2,2,1);
imshow(It);
axis on;
title('flower/00029.png');

subplot(2,2,2);
%colormap('jet');
imagesc(MotSegFig);
%colorbar;
title('Magnitude of Motion');

subplot(2,2,3);
imshow(It_segTree);
axis on;
title('Segment out Tree with white color');

subplot(2,2,4);
imshow(I_OnlyTree);
axis on;
title('Only Tree remains');
saveas(graph, 'Output/4-2.jpg');