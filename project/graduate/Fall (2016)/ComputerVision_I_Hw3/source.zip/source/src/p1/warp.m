%% Warp script which reprojects image to desired rectangle

function warped_img = warp(I1, new_points, H)

I1=im2double(I1);
[h w d] = size(I1);

% find and warp incoming corners to new image space
cp = H*[ 1 1 w w ; 1 h 1 h ; 1 1 1 1 ];
Xpr = min( cp(1,:) ) : max( cp(1,:) ); % x range
Ypr = min( cp(2,:) ) : max( cp(2,:) ); % y range

[Xp,Yp] = ndgrid(Xpr,Ypr);
[wp hp] = size(Xp); 
% inverse transform with Homography Matrix
n = wp*hp;
X = H \ [ Xp(:) Yp(:) ones(n,1) ]';  % warp
% bilinear interpolation
xI = reshape( X(1,:),wp,hp)';
yI = reshape( X(2,:),wp,hp)';
Ip(:,:,1) = interp2(I1(:,:,1), xI, yI, '*bilinear'); % red
Ip(:,:,2) = interp2(I1(:,:,2), xI, yI, '*bilinear'); % green
Ip(:,:,3) = interp2(I1(:,:,3), xI, yI, '*bilinear'); % blue

warped_img=im2uint8(Ip);

end