%% Matlab Script that computes Homography matrix from 4 pairs of points

function H = computeH(points, new_points)

  n = size(points, 1); 
  A = zeros(n*3,9); 
  b = zeros(n*3,1); 
for i=1:n 
    A(3*(i-1)+1,1:3) = [new_points(i,:),1]; 
    A(3*(i-1)+2,4:6) = [new_points(i,:),1]; 
    A(3*(i-1)+3,7:9) = [new_points(i,:),1]; 
    b(3*(i-1)+1:3*(i-1)+3) = [points(i,:),1]; 
end 
x = (A\b)'; 
H = [x(1:3); x(4:6); x(7:9)]; 

end

