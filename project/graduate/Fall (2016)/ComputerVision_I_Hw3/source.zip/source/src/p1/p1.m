%% Reads image file and allows user to select add to reproject
I1=imread('stadium.jpg');
%select points on the image, preferable the corners of an ad.
imshow(I1)
points = ginput(4);
figure(1)
subplot(1,2,1); 
imshow(I1); 
new_points = [0,0; 200,0; 200,50; 0,50]; %creates new image of specified size
H= computeH(points,new_points);
%warp will return just the ad rectified
warped_img = warp(I1,new_points, H);
figure(2); imshow(warped_img);
figure(1); plotsquare([points';1 1 1 1]); imshow(I1)
