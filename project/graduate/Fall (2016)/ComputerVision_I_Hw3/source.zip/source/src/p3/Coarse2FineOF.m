%% Read files
I1 = rgb2gray( imread('data/flower/00029.png') );
I1 = mat2gray(I1);

I2 = rgb2gray( imread('data/flower/00030.png') );
I2 = mat2gray(I2);


%% Coarse-to-Fine Estimation 
windowSize = 15;
tau = 0.02;


[n, m] = size(I1); 
MinDim = min( [n, m] );
nLevels = max(1, floor( log2( MinDim) )+1 );
startLevelofPyramid = 4;

% Pyramid Calculation
for i = startLevelofPyramid:nLevels
    reSize = 2^(nLevels - i);
    h_i = round( n/reSize );
    w_i = round( m/reSize );

    I1_i = imresize(I1,[h_i w_i], 'bilinear');
    I2_i = imresize(I2,[h_i w_i], 'bilinear');
    if (i == startLevelofPyramid)
        [u_pre, v_pre, hitMap] = opticalFlow(I1_i, I2_i, windowSize, tau);
    else
        u_pre = resizem(u_pre,[h_i w_i],'bilinear');
        v_pre = resizem(v_pre,[h_i w_i],'bilinear');
        [u_pri, v_pri, hitMap]=opticalFlow2(I1_i, I2_i, u_pre, v_pre, windowSize, tau);
        u_pre = u_pre + u_pri;
        v_pre = v_pre + v_pri;
    end
end
%% Result of Coarse-to-Fine optical flow
u2 = u_pre;
v2 = v_pre;

dlmwrite('Output/u2.txt', u2);
dlmwrite('Output/v2.txt', v2);


%% Result of dense optical flow
[u, v, hitMap] = opticalFlow(I1, I2, windowSize, tau);


%% Plotting 
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,800,310]);

% Plot Dense Optical flow
sp = subplot(1,2,1);
nu = imresize(u, 0.3);
nv = imresize(v, 0.3);

[n, m] = size(nu);
[X, Y] = meshgrid(1:m, 1:n);
quiver(X, Y, nu, nv);
set(gca,'ydir','reverse');
set(sp, 'XLim', [0, m], 'XTick', 0:5:m);
set(sp, 'YLim', [0, n], 'YTick', 0:5:n);
title(strcat('Dense OF, windowsize: ', int2str(windowSize)));

% Plot Coarse to fine Optical flow
sp2 = subplot(1,2,2);
nu2 = imresize(u2, 0.3);
nv2 = imresize(v2, 0.3);

[n2, m2] = size(nu2);
[X2, Y2] = meshgrid(1:m2, 1:n2);
quiver(X2, Y2, nu2, nv2);
set(gca,'ydir','reverse');
set(sp2, 'XLim', [0, m2], 'XTick', 0:5:m2);
set(sp2, 'YLim', [0, n2], 'YTick', 0:5:n2);
title(strcat('Coarse to Fine OF, windowsize: ', int2str(windowSize)));

saveas(graph, 'Output/3-3.jpg');


%% Plotting original graph 
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,800,400]);

subplot(1,2,1);
imshow(imresize(I1, 0.3))
axis on;
title('flower/00029.png');

subplot(1,2,2);
imshow(imresize(I1, 0.3))
axis on;
title('flower/00030.png');
saveas(graph, 'Output/3-original.jpg');


function [u, v, hitMap] = opticalFlow2(I1, I2, u_pre, v_pre, windowSize, tau)

%% Parameters
[n, m] = size(I1);
hw = fix(windowSize/2);

%% Calculate Gradient
[Gx, Gy] = gradient(I1);

%% Precalculate Squared Gradient
Gxx = Gx .* Gx;
Gxy = Gx .* Gy;
Gyy = Gy .* Gy;

%% Optical Flow
u = zeros(n, m);
v = zeros(n, m);
hitMap = false(n, m);
for r = 1:n
    for c = 1:m
        x_LB = max(r-hw, 1);
        x_HB = min(r+hw,n);
        y_LB = max(c-hw, 1);
        y_HB = min(c+hw,m);
        
        vxx = sum(sum(Gxx(x_LB:x_HB, y_LB:y_HB)));
        vyy = sum(sum(Gyy(x_LB:x_HB, y_LB:y_HB)));
        vxy = sum(sum(Gxy(x_LB:x_HB, y_LB:y_HB)));
        
        Gt = zeros(x_HB-x_LB+1, y_HB-y_LB+1);
        for i = 1:x_HB-x_LB+1
            for j = 1:y_HB-y_LB+1
                x_disp = round( i+u_pre(i,j) );
                y_disp = round( j+v_pre(i,j) );
                if(x_LB <= x_disp && x_disp <= x_HB ...
                   && y_LB <= y_disp && y_disp <= y_HB)
                    Gt(i,j) = I2(x_disp, y_disp) - I1(i,j);
                else
                    Gt(i,j) = 0;
                end
            end
        end

        Gxt = Gx(x_LB:x_HB, y_LB:y_HB) .* Gt;
        Gyt = Gy(x_LB:x_HB, y_LB:y_HB) .* Gt;
        
        vxt = sum(sum(Gxt));
        vyt = sum(sum(Gyt));
        
        ATA = [vxx, vxy; vxy, vyy];
        ATb = [-vxt; -vyt];
        
        if min(eig(ATA)) > tau
            V = ATA \ ATb;
            u(r, c) = V(1);
            v(r, c) = V(2);
            hitMap(r, c) = 1;
        end
    end
end
end