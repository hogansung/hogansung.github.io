function [u, v, hitMap] = opticalFlow(I1, I2, windowSize, tau)

%% Parameters
[n, m] = size(I1);
hw = fix(windowSize/2);

%% Calculate Gradient
[Gx, Gy] = gradient(I1);
Gt = I2 - I1;

%% Precalculate Squared Gradient
Gxx = Gx .* Gx;
Gxy = Gx .* Gy;
Gyy = Gy .* Gy;
Gxt = Gx .* Gt;
Gyt = Gy .* Gt;

%% Optical Flow
u = zeros(n, m);
v = zeros(n, m);
hitMap = false(n, m);
for r = 1:n
    for c = 1:m
        vxx = sum(sum(Gxx(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vyy = sum(sum(Gyy(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vxy = sum(sum(Gxy(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vxt = sum(sum(Gxt(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vyt = sum(sum(Gyt(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        
        ATA = [vxx, vxy; vxy, vyy];
        ATb = [-vxt; -vyt];
        
        if min(eig(ATA)) > tau
            V = ATA \ ATb;
            u(r, c) = V(1);
            v(r, c) = V(2);
            hitMap(r, c) = 1;
        end
    end
end