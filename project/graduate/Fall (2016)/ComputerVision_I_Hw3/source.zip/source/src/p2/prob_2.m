%% Read files
crf = imread('../dat/corridor/bt.000.png');
crf = mat2gray(crf);
crs = imread('../dat/corridor/bt.001.png');
crs = mat2gray(crs);

spf = imread('../dat/sphere/sphere.0.png');
spf = rgb2gray(spf);
spf = mat2gray(spf);
sps = imread('../dat/sphere/sphere.1.png');
sps = rgb2gray(sps);
sps = mat2gray(sps);

syf = imread('../dat/synth/synth_000.png');
syf = mat2gray(syf);
sys = imread('../dat/synth/synth_001.png');
sys = mat2gray(sys);

%% Prepare dataset
windowSizeList = [15, 30, 100];
dataList = {crf, crs; spf, sps; syf, sys};
dataName = {'corridor', 'sphere', 'synth'};

%% Problem 2-1
for i = 1:3 % three dataset
    res = figure('visible', 'off');
    set(res, 'PaperPosition', [0 0 12 8]);
    data = dataList(i, :);
    for j = 1:3 % three windowSize
        windowSize = windowSizeList(j);
        [u, v, hitMap] = opticalFlow(data{1}, data{2}, windowSize, 0.5);
        nu = imresize(u, 0.1);
        nv = imresize(v, 0.1);
        [n, m] = size(nu);
        [X, Y] = meshgrid(1:m, 1:n);
        
        sp = subplot(2,3,j);
        quiver(X, Y, nu, nv);
        set(sp, 'XLim', [0, m], 'XTick', 0:5:m);
        set(sp, 'YLim', [0, n], 'YTick', 0:5:n);
        set(sp, 'ydir', 'reverse');
        title(strcat('Needlemap, windowsize: ', int2str(windowSize)));
        
        subplot(2,3,3+j);
        hold on
        imshow(hitMap);
        [n, m] = size(u);
        rectangle('Position',[0, 0, n, m],'EdgeColor','k');
        hold off
        title(strcat('Valid area, windowsize: ', int2str(windowSize)));
    end
    
    saveas(res, strcat('../res/denseOpticalFlow_', dataName{i}, '.jpg'));
end

for i = 1:3 % three dataset
    res = figure('visible', 'off');
    set(res, 'PaperPosition', [0 0 12 8]);
    data = dataList(i, :);
    
    %% Problem 2-2
    corners = cornerDetect(data{1});
    
    subplot(1,2,1);
    hold on
    imshow(data{1});
    viscircles(corners, meshgrid(5, 1:50));
    hold off
    title(strcat('Corner Detection'));
    
    %% Problem 2-3
    vx = zeros(50, 1);
    vy = zeros(50, 1);
    vu = zeros(50, 1);
    vv = zeros(50, 1);
    [u, v, hitMap] = opticalFlow(data{1}, data{2}, 15, 0.1);
    for j = 1:50
        vx(j) = corners(j,1);
        vy(j) = corners(j,2);
        vu(j) = u(vy(j), vx(j));
        vv(j) = v(vy(j), vx(j));
    end
    
    subplot(1,2,2);
    hold on
    imshow(data{1});
    viscircles(corners, meshgrid(5, 1:50));
    quiver(vx, vy, vu, vv, 'color', [0, 0, 1], 'LineWidth', 3);
    hold off
    title(strcat('Corner Detection with Optical Flow'));
    
    saveas(res, strcat('../res/sparseOpticalFlow_', dataName{i}, '.jpg'));
end