function corners = cornerDetect(I)

%% Parameters
windowSize = 7;
smoothSTD = 1;
num = 50;
[n, m] = size(I);
hw = fix(windowSize/2);

%% Gaussian Smoothing
H = fspecial('gaussian', [5, 5], smoothSTD);
I = imfilter(I, H, 'replicate');

%% Calculate Gradient
[Gx, Gy] = gradient(I);

%% Precalculate Squared Gradient
Gxx = Gx .* Gx;
Gxy = Gx .* Gy;
Gyy = Gy .* Gy;

%% Corner Detection
em = zeros(n, m);
mat = zeros(n*m, 3);
for r = 1:n
    for c = 1:m
        vxx = sum(sum(Gxx(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vyy = sum(sum(Gyy(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        vxy = sum(sum(Gxy(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        ATA = [vxx, vxy; vxy, vyy];
        em(r, c) = min(eig(ATA));
    end
end

%% Non-maximum Supression
for r = 1:n
    for c = 1:m
        vmax = max(max(em(max(r-hw, 1):min(r+hw,n), max(c-hw, 1):min(c+hw,m))));
        if em(r, c) == vmax
            mat(r*n+c, :) = [c, r, em(r, c)];
        end
    end
end

%% Return Top-k Corners
[~, idx] = sort(mat(:,3), 'descend');
mat = mat(idx, :);
corners = mat(1:num, 1:2);