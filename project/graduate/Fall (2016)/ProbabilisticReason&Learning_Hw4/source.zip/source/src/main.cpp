#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cfloat>
#include <vector>
#include <utility>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <assert.h>

using namespace std;

const int MAXL = 10000;
const int NUMV = 500;
const int NUMS = 100;

char in[MAXL + 10];

unordered_map<string,int> umsi;
unordered_map<int,string> umis;

vector<string> vocab(NUMV, "");
vector<int> uni(NUMV, 0);
vector<vector<int>> bi(NUMV, vector<int>(NUMV, 0));

// helper function to calculate prob with different lambda
double calLProb(vector<string>& lst, double lambda, bool warning) {
    int size = lst.size();

    int usum = 0;
    for (int i = 0; i < NUMV; i++) {
        usum += uni[i];
    }

    double lprob = 0; 
    for (int i = 0; i < size; i++) {
        int tar = i == 0 ?umsi.at("<s>") :umsi.at(lst[i-1]);
        int bsum = 0;
        for (int j = 0; j < NUMV; j++) {
            bsum += bi[tar][j];
        }
        
        if (bi[tar][umsi.at(lst[i])] == 0 and lambda != 0 and warning) {
            fprintf(stderr, "Warning: (%s, %s) does not appear in documents\n", 
              umis.at(tar).c_str(), lst[i].c_str());
        }

        lprob += log((1-lambda) * uni[umsi.at(lst[i])] / usum + 
          lambda * bi[tar][umsi.at(lst[i])] / bsum);
    }

    return lprob;
}

int main() {
    { // read vocabulary
        string FN = "../dat/vocab.txt";
        FILE *pf = fopen(FN.c_str(), "r");
        if (pf == NULL) {
            fprintf(stderr, "Vocab file cannot read\n");
            exit(EXIT_FAILURE);
        }

        int cnt = 0;
        while (fscanf(pf, "%s", in) != EOF) {
            umsi[in] = cnt;
            umis[cnt] = in;
            vocab[cnt++] = in;
        }

        fclose(pf);
        assert(vocab.size() == NUMV);
    }

    { // read unigram
        string FN = "../dat/unigram.txt";
        FILE *pf = fopen(FN.c_str(), "r");
        if (pf == NULL) {
            fprintf(stderr, "Unigram file cannot read\n");
            exit(EXIT_FAILURE);
        }
        
        int d;
        int cnt = 0;
        while (fscanf(pf, "%d", &d) != EOF) {
            uni[cnt++] = d;
        }

        fclose(pf);
        assert(cnt == NUMV);
    }

    { // read bigram
        string FN = "../dat/bigram.txt";
        FILE *pf = fopen(FN.c_str(), "r");
        if (pf == NULL) {
            fprintf(stderr, "Bigram file cannot read\n");
            exit(EXIT_FAILURE);
        }
        
        int u, v, d;
        while (fscanf(pf, "%d\t%d\t%d", &u, &v, &d) != EOF) {
            u -= 1;
            v -= 1;
            assert(u >= 0 and u < NUMV and v >= 0 and v < NUMV);
            bi[u][v] = d;
        }

        fclose(pf);
    }

    { // 4.3 (a)
        int usum = 0;
        for (int i = 0; i < NUMV; i++) {
            usum += uni[i];
        }
        printf("4.3 (a)\n");
        for (int i = 0; i < NUMV; i++) {
            if (vocab[i][0] == 'A') {
                printf("%s %f\n", vocab[i].c_str(), 1.0 * uni[i]/usum);
            }
        }
        printf("\n\n");
    }

    { // 4.3 (b)
        int tar = umsi.at("THE");
        int sum = 0;
        vector<pair<int,int>> vct;
        for (int j = 0; j < NUMV; j++) {
            sum += bi[tar][j];
            vct.emplace_back(bi[tar][j],j);
        }
        sort(vct.rbegin(), vct.rend());
        printf("4.3 (b)\n");
        for (int i = 0; i < 5; i++) {
            printf("%s %f\n", vocab[vct[i].second].c_str(), 1.0 * vct[i].first/sum);
        }
        printf("\n\n");
    }

    { // 4.3 (c)
        vector<string> lst{"LAST", "WEEK", "THE", "STOCK", "MARKET", "FELL", "BY", "ONE", "HUNDRED", "POINTS"};
        printf("4.3 (c)\n");
        { // I. unigram
            double lprob = calLProb(lst, 0, true); 
            printf("unigram: %f\n", lprob);
        }
        { // II. bigram
            double lprob = calLProb(lst, 1, true);
            printf("bigram: %f\n", lprob);
        }
        printf("\n\n");
    }

    { // 4.3 (d)
        vector<string> lst{"THE", "NINETEEN", "OFFICIALS", "SOLD", "FIRE", "INSURANCE"};
        printf("4.3 (d)\n");
        { // I. unigram
            double lprob = calLProb(lst, 0, true); 
            printf("unigram: %f\n", lprob);
        }
        { // II. bigram
            double lprob = calLProb(lst, 1, true);
            printf("bigram: %f\n", lprob);
        }
        printf("\n\n");
    }

    { // 4.3 (e)
        string FN = "../res/lambda_data.csv";
        FILE* pf = fopen(FN.c_str(), "w");
        if (pf == NULL) {
            fprintf(stderr, "Lambda file cannot write\n");
            exit(EXIT_FAILURE);
        }

        vector<string> lst{"THE", "NINETEEN", "OFFICIALS", "SOLD", "FIRE", "INSURANCE"};
        double mmax = -DBL_MAX;
        double pmax = -1;
        for (int i = 0; i < NUMS; i++) {
            double pos = 1.0 * i / NUMS;
            double lprob = calLProb(lst, pos, false);
            if (lprob > mmax) {
                mmax = lprob;
                pmax = pos;
            }
            fprintf(pf, "%f, %f\n", pos, lprob);
        }

        printf("4.3 (d)\n");
        printf("max prob: %f (at %.2f)", mmax, pmax);
        fclose(pf);
    }
}
