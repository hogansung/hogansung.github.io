% read in data
M = csvread('../res/lambda_data.csv');

% plot figure
res = figure('visible', 'on');
plot(M(:,1), M(:,2));
xlabel('Lambda');
ylabel('Probability')
print -r96 % set resolution
saveas(res, '../res/lambda.jpg');