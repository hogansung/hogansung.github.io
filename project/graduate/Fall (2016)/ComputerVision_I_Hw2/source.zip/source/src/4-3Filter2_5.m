% ***** 4.3-3 Realistic Image *****

% --- Input image file ---
filter_img = im2double( imread('data/cartemplate.jpg') );
car_img = im2double( imread('data/car5.jpg') );

fileID = fopen('data/car5.txt','r');
Coord = fscanf(fileID,'%d %d',[2 Inf]);
Coord = Coord';
fclose(fileID);


filter_img = filter_img - mean(filter_img(:));
car_img_mean = car_img - mean(car_img(:));

%  --- Rescale --- 
filter_img = imresize(filter_img, 0.2);
%filter_img = imresize(filter_img, [186,407]);

% --- Blur with std ---
filter_img = imgaussfilt(filter_img, 2);
car_img_mean = imgaussfilt(car_img_mean, 2);

% --- Rotation ---
filter_img = imrotate(filter_img, 180,'bilinear','crop');

% --- Flip ---
%filter_img = flip(filter_img,2);

% --- Convolution ---
ans_img = conv2(car_img_mean, filter_img, 'same');

%  --- Prediction --- 
car_img_box(:,:) = car_img(:,:);
[img_x, img_y] = size(car_img);
[box_x, box_y] = size(filter_img);
[x1,y1] = box_Pre(ans_img, box_x, box_y);
car_img_box = boxDrawing(car_img_box,x1,y1, box_x, box_y, 0);

%  --- Overlapping Area --- 
car_img_box_err(:,:) = car_img(:,:);
overlappingArea = errDetecion(Coord(1,2),Coord(1,1), Coord(2,2),Coord(2,1), x1, y1, x1+box_x, y1+box_y);
car_img_box_err = boxDrawing(car_img_box_err, Coord(1,2), Coord(1,1), Coord(2,2)-Coord(1,2), Coord(2,1)-Coord(1,1), 1);
car_img_box_err = boxDrawing(car_img_box_err,x1,y1, box_x, box_y, 0);

disp(overlappingArea);

% --- Plotting --- 
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,2000,1000]);

subplot(2,3,1);
imshow(filter_img);
axis on;
title('(a) Filter');

subplot(2,3,2);
imshow(car_img_mean);
axis on;
title('(b) Car with Blur');

subplot(2,3,3);
imagesc(ans_img);
title('(c) Heat map');

subplot(2,3,4);
imshow(car_img_box);
axis on;
title('(d) Bounding box');

subplot(2,3,5);
imshow(car_img_box_err);
axis on;
title(strcat('(e) Overlapping box: OLA%= ', string(overlappingArea)));

saveas(graph, 'Output/4.3_Car5.jpg');






function [Xstart,Ystart] = box_Pre(inten_img, dx, dy)
[M,I] = max(inten_img(:));
[I_row, I_col] = ind2sub(size(inten_img),I);
Xstart = I_row - round(dx/2);
Ystart = I_col - round(dy/2);
end

function res_img = boxDrawing(toy_img_box, x, y, dx, dy, color)
toy_img_box(x:x+dx,y) = color;
toy_img_box(x:x+dx,y+dy) = color;
toy_img_box(x,y:y+dy) = color;
toy_img_box(x+dx,y:y+dy) = color;
res_img = toy_img_box;
end

function len = overlapLength(x1,x2,y1,y2)
if (x1<y1) && (y2<x2)
    len = abs(y2-y1);
elseif (x1>y1) && (y2>x2)
    len = abs(x2-x1);
elseif max(y2-x1) > max(x2-y1)
    len = abs(x2-y1);
elseif max(y2-x1) < max(x2-y1)
    len = abs(y2-x1);
end
end

function overlappingArea=errDetecion(x0,y0,x1,y1, p0,q0,p1,q1)
X_intersect = overlapLength(x0,x1, p0,p1);
Y_intersect = overlapLength(y0,y1, q0,q1);

numerator = X_intersect * Y_intersect;
demoniator = abs(x0-x1)*abs(y0-y1) + abs(p0-p1)*abs(q0-q1) - numerator;

overlappingArea = numerator / demoniator *100;
end