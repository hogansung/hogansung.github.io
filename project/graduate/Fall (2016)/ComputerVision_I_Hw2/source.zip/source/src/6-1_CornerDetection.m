% ***** 6.1-2 Corner Detection *****

% --- Input image file ---
load('data/dino2.mat')
load('data/matrix2.mat')
load('data/warrior2.mat')

% --- Parameters ---
nCorners = 20;
smoothSTD = 5;
windowSize = 10;
%image1 = dino01;
%image2 = dino02;

PlottingCorners(dino01, dino02, 'dino01','dino02', '6-1CornerDetection', nCorners, smoothSTD, windowSize);

%PlottingCorners(matrix01, matrix02, 'matrix01','matrix02', '6-1CornerDetection_matrix', nCorners, smoothSTD, windowSize);
%PlottingCorners(warrior01, warrior02, 'warrior01','warrior02', '6-1CornerDetection_warrior', nCorners, smoothSTD, windowSize);


function finish = PlottingCorners(image1, image2, name1, name2, fileName, nCorners, smoothSTD, windowSize);
corners1 = CornerDetect(image1, nCorners, smoothSTD, windowSize);
corners2 = CornerDetect(image2, nCorners, smoothSTD, windowSize);

[NCorners1, dim1] = size(corners1);
[NCorners2, dim2] = size(corners2);

% --- Save Corners result to .txt file ---
tempName = strcat( strcat( strcat(strcat('Output/Corners', fileName), '_'), name1), '.txt' );
save( tempName, 'corners1', '-ascii');

tempName = strcat( strcat( strcat(strcat('Output/Corners', fileName), '_'), name2), '.txt' );
save( tempName, 'corners2', '-ascii');


% --- Plotting Original Image ---
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,1000,1000]);

subplot(2,2,1)
imshow(image1);
axis on;
title( strcat('(a) Original - ', name1 ) );

subplot(2,2,2)
imshow(image2);
axis on;
title( strcat('(b) Original - ', name2 ) );

subplot(2,2,3)
imshow( smoothts(rgb2gray(image1), 'g', windowSize, smoothSTD) );
axis on;
title( strcat('(c) with smoothing and gray - ', name1 ) );

subplot(2,2,4)
imshow( smoothts(rgb2gray(image2), 'g', windowSize, smoothSTD) );
axis on;
title( strcat('(d) with smoothing and gray - ', name2 ) );

contcatString = strcat( strcat('Output/', fileName), '_Original.jpg');
saveas(graph, contcatString);


% --- Plotting Result Image ---
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,1000,500]);

subplot (1,2,1);
imshow(rgb2gray(image1));
axis on;
for i = 1:NCorners1
viscircles([corners1(i,2), corners1(i,1)],40);
end
title( strcat('(a) - ', name1) );

subplot (1,2,2);
imshow(rgb2gray(image2));
axis on;
for i = 1:NCorners2
viscircles([corners2(i,2), corners2(i,1)],40);
end
title( strcat('(b) - ', name2) );

contcatString = strcat( strcat('Output/', fileName), '_Result.jpg');
saveas(graph, contcatString);

finish = 1;
end

function corners = CornerDetect(Image, nCorners, smoothSTD, windowSize)

img = rgb2gray(Image);
[img_x, img_y] = size(img);
img = smoothts(img, 'g', windowSize, smoothSTD);

% ---Gradient ---
[Ix, Iy] = imgradientxy(img);
Ix2 = Ix.*Ix;
Iy2 = Iy.*Iy;
IxIy = Ix.*Iy;

EigMat = zeros(img_x, img_y);

start_x = 1 + round(windowSize/2);
start_y = 1 + round(windowSize/2);
end_x = img_x - round(windowSize/2)-1;
end_y = img_y - round(windowSize/2)-1;

for i = start_x : end_x
    for j = start_y : end_y
        start_i = i - round(windowSize/2);
        start_j = j - round(windowSize/2);
        end_i = i + round(windowSize/2);
        end_j = j + round(windowSize/2);
        
        C11 = sum(sum( Ix2(start_i:end_i, start_j:end_j) ));
        C12 = sum(sum( IxIy(start_i:end_i, start_j:end_j) ));
        C22 = sum(sum( Iy2(start_i:end_i, start_j:end_j) ));
        
        C = [C11, C12; C12, C22];
        e = eig(C);
        EigMat(i,j) = min(e(1), e(2));
        
    end
end

corners = zeros(nCorners,2);

i=1;
while (i <= nCorners)
    [M,I] = max(EigMat(:));
    [I_row, I_col] = ind2sub(size(EigMat),I);
    tooCloseFlag = 0;
    for j = 1:i
%        I_row, I_col
        if ( distance(I_row, I_col, corners(j,1), corners(j,2)) < windowSize)
            tooCloseFlag = 1;
            break;
        else
            tooCloseFlag = 0;
            continue
        end
    end
    
    if (tooCloseFlag == 1)
        EigMat(I_row,I_col) = 0;
        i = i-1;
    else 
        corners(i,1) = I_row;
        corners(i,2) = I_col;
        EigMat(I_row,I_col) = 0;
    end
    
    i=i+1;
end

end

function dist = distance(x1,y1,x2,y2)
    dist = sqrt( (x1-x2)^2 + (y1-y2)^2 );
end
