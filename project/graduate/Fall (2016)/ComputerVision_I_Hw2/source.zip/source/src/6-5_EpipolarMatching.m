% ***** 6.5 Epipolar Geometry Based Matching *****

% --- Input image file ---
load('data/dino2.mat');
%load('data/matrix2.mat')
%load('data/warrior2.mat')

% --- Parameters ---
ncorners = 10;
smoothSTD = 5;
windowSize = 5;
R = 10;
SSDth = 1.2;


% --- Gray ---
image1 = rgb2gray(dino01);
image2 = rgb2gray(dino02);

%image1 = rgb2gray(matrix01);
%image2 = rgb2gray(matrix02);

%image1 = rgb2gray(warrior01);
%image2 = rgb2gray(warrior02);


corners1 = CornerDetect(image1, ncorners, smoothSTD, windowSize);

fileName = '6-5_dino';
%fileName = '6-5_matrix';
%fileName = '6-5_warrior';

% --- Fundamental matrix ---
F = fund(cor1, cor2);

%corners1 = corners1(1:10,:);
[I, corsSSD] = correspondanceMatchingLine(image1, image2, corners1, F, R, SSDth);


I1 = image1;
I2 = image2;
[I1_x, I1_y] = size(I1);
[I2_x, I2_y] = size(I2);
I_combine = zeros(I1_x, I1_y *2);
I_combine(1:I1_x, 1:I1_y)= I1(1:I1_x, 1:I1_y);
I_combine(1:I2_x, I1_y + 1 : I1_y + I2_y)= I2(1:I2_x, 1 : I2_y);
[Nrows, I_width] = size(I);


% --- Plotting ---
graph = figure('visible', 'off');
imshow(I_combine);
axis on;
for i = 1:Nrows
viscircles([I(i,2), I(i,1)],40);
viscircles([I(i,4) + I1_y , I(i,3)],40);
line( [I(i,2), I(i,4) + I1_y], [I(i,1), I(i,3)] );
end

contcatString = strcat( strcat('Output/', fileName), '_Result.jpg');
saveas(graph, contcatString);




function [I, corsSSD] = correspondanceMatchingLine(I1, I2, corners1, F, R, SSDth)
[N1, width1] = size(corners1);
[H1,L1] = size(I1);
[H2,L2] = size(I2);

I = [];
corsSSD = [];

for i = 1:N1
    
    line = F*[corners1(i,2), corners1(i,1),1]';
    xrange = [1, L2];
    yrange = [1, H2];

    PtMat = linePts(line, xrange, yrange);

    % --- mirroring ---
    tempPtMat = [PtMat(1,2),PtMat(1,1) ; PtMat(2,2), PtMat(2,1)];
    PtMat = tempPtMat;

    a = (PtMat(1,2) - PtMat(2,2)) / (PtMat(1,1) - PtMat(2,1));
    b = PtMat(1,2) - a*PtMat(1,1);
    
    corners2 = [];
    for j = R:H2-R
        if (round(a*j+b) < round(R/2) || round(a*j+b)>L2-round(R/2))
            continue;
        else
            corners2 = [corners2;[j,round(a*j+b)]];
        end
    end
    
    [N2, width2] = size(corners2);
    
    temp = zeros(1,N2);
    
    halfR = round(R/2);
    w1 = I1( corners1(i,1)-halfR :corners1(i,1)+halfR , corners1(i,2)-halfR:corners1(i,2)+halfR );
    
    for j = 1:N2
        %[corners2(j,1)-halfR, corners2(j,1)+halfR ; corners2(j,2)-halfR, corners2(j,2)+halfR]
        w2 = I2( corners2(j,1)-halfR:corners2(j,1)+halfR , corners2(j,2)-halfR:corners2(j,2)+halfR );
        temp(j) = SSDmatch(w1,w2);
    end
    
    [minSSD,index_min] = min(temp(:));
    if (minSSD<SSDth) 
        continue;
    else
        tempI = [corners1(i,1), corners1(i,2), corners2(index_min,1), corners2(index_min,2)];
        I = [I;tempI];
        corsSSD = [corsSSD;minSSD];
    end    
end



end


function F = fund(x1, x2)
% Computes the fundamental matrix from a set of image correspondences
%
% INPUTS
%   x1    - Image coordinates for reference camera 1 (one per row)
%   x2    - Image coordinates for moved camera 2 (one per row)
%
% OUTPUTS
%   F     - Fundamental matrix (relates pts in cam 1 to lines in cam 2)
%
% DATESTAMP
%   21-May-07 4:16pm
%
% See also SVD

%% 0. Error-checking for input
n = size(x1,1);
if (size(x2,1) ~= n)
    error('Invalid correspondence: number of points don''t match!');
end

%% 1. Perform Hartley normalization (p. 212 of MaSKS)
avg1 = sum(x1,1) / n;
avg2 = sum(x2,1) / n;
diff1 = x1 - repmat(avg1,n,1);
diff2 = x2 - repmat(avg2,n,1);
std1 = sqrt(sum(diff1.^2,1) / n);
std2 = sqrt(sum(diff2.^2,1) / n);
H1 = [1/std1(1), 0, -avg1(1)/std1(1);
      0, 1/std1(2), -avg1(2)/std1(2);
      0, 0, 1];
H2 = [1/std2(1), 0, -avg2(1)/std2(1);
      0, 1/std2(2), -avg2(2)/std2(2);
      0, 0, 1];

norm1 = ([x1 ones(n,1)])*H1';
norm2 = ([x2 ones(n,1)])*H2';

%% 2. Compute a first approximation of the fundamental matrix
design = zeros(n,9);

for i=1:n
    design(i,:) = kron(norm1(i,:), norm2(i,:));
end

[U,S,V] = svd(design);
Fs = V(:,9);
F = reshape(Fs, 3, 3);

%% 3. Impose the rank constraint
[U,S,V] = svd(F);
S(3,3) = 0;
F = U*S*V';

%% 4. Undo the normalization
F = H2'*F*H1;

end

function pts = linePts(line, xrange, yrange)
% Returns the endpoints of a line clipped by the given bounding box.
%
% INPUTS
%   line    - Homogeneous coordinates of the line
%   xrange  - X-coordinate range of the bounding box [xmin, xmax]
%   yrange  - Y-coordinate range of the bounding box [ymin, ymax]
% 
% OUTPUTS
%   pts     - The endpoints of the line in the bounding box.
% 
% DATESTAMP
%   18-May-07 12:10am
% 

xmin = xrange(1); xmax = xrange(2);
ymin = yrange(1); ymax = yrange(2);

% Find the four intersections with the bounding box limits
allPts = [xmin, -(line(1)*xmin + line(3))/line(2);
          xmax, -(line(1)*xmax + line(3))/line(2);
          -(line(2)*ymin + line(3))/line(1), ymin;
          -(line(2)*ymax + line(3))/line(1), ymax];

% Clip testing: find the two intersections inside the bounding box
count = 0;
pts = zeros(2,2);
for i=1:4
    if ((allPts(i,1) >= xmin) && (allPts(i,1) <= xmax) && ...
        (allPts(i,2) >= ymin) && (allPts(i,2) <= ymax))
        % add it to the list of endpoints
        count = count + 1;

        if (count == 1)
            pts(count,:) = allPts(i,:);
        elseif (count > 1)
            addPoint = logical(1);
            for j=1:count-1
                % Check to see that we're not adding a duplicate point
                diff = sum(abs(pts(j,:) - allPts(i,:)));
                if (diff < 1e-5)
                    % Don't add the point
                    addPoint = 0;
                end
            end
            
            if (~addPoint)
                count = count - 1;
            elseif (count > 2)
                % This is an error
                error('Bug: more than two points on the line intersect the bounding box!');
            else
                % Add the point to the list
                pts(count,:) = allPts(i,:);
            end
        end
    end
end
end

function ssd = SSDmatch(w1,w2)
[rows1, cols1] = size(w1);
[rows2, cols2] = size(w2);

if (rows1 ~= rows2 || cols1 ~= cols2)
    ssd = 0;
else
    Diff = w1 - w2;
    ssd = sum(sum(Diff.*Diff));
end

end

function corners = CornerDetect(Image, nCorners, smoothSTD, windowSize)
img = rgb2gray(Image);
[img_x, img_y] = size(img);
img = smoothts(img, 'g', windowSize, smoothSTD);

% ---Gradient ---
[Ix, Iy] = imgradientxy(img);
Ix2 = Ix.*Ix;
Iy2 = Iy.*Iy;
IxIy = Ix.*Iy;

EigMat = zeros(img_x, img_y);

start_x = 1 + round(windowSize/2);
start_y = 1 + round(windowSize/2);
end_x = img_x - round(windowSize/2)-1;
end_y = img_y - round(windowSize/2)-1;

for i = start_x : end_x
    for j = start_y : end_y
        start_i = i - round(windowSize/2);
        start_j = j - round(windowSize/2);
        end_i = i + round(windowSize/2);
        end_j = j + round(windowSize/2);
        
        C11 = sum(sum( Ix2(start_i:end_i, start_j:end_j) ));
        C12 = sum(sum( IxIy(start_i:end_i, start_j:end_j) ));
        C22 = sum(sum( Iy2(start_i:end_i, start_j:end_j) ));
        
        C = [C11, C12; C12, C22];
        e = eig(C);
        EigMat(i,j) = min(e(1), e(2));
        
    end
end

corners = zeros(nCorners,2);

i=1;
while (i <= nCorners)
    [M,I] = max(EigMat(:));
    [I_row, I_col] = ind2sub(size(EigMat),I);
    tooCloseFlag = 0;
    for j = 1:i
%        I_row, I_col
        if ( distance(I_row, I_col, corners(j,1), corners(j,2)) < windowSize)
            tooCloseFlag = 1;
            break;
        else
            tooCloseFlag = 0;
            continue
        end
    end
    
    if (tooCloseFlag == 1)
        EigMat(I_row,I_col) = 0;
        i = i-1;
    else 
        corners(i,1) = I_row;
        corners(i,2) = I_col;
        EigMat(I_row,I_col) = 0;
    end
    
    i=i+1;
end

end

function dist = distance(x1,y1,x2,y2)
    dist = sqrt( (x1-x2)^2 + (y1-y2)^2 );
end