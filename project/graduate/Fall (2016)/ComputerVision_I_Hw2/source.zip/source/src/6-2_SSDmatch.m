% ***** 6.2 SSD Matching *****

function ssd = SSDmatch(w1,w2)
[rows1, cols1] = size(w1);
[rows2, cols2] = size(w2);

if (rows1 ~= rows2 || cols1 ~= cols2)
    ssd = 0;
else
    Diff = w1 - w2;
    ssd = sum(sum(Diff.*Diff));
end

end