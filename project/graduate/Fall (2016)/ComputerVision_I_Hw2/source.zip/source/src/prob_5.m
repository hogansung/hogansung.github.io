%% Data preparation
addpath('../dat/');

image = imread('geisel.jpeg');
image = im2double(image);
[nrow, ncol] = size(image);

res = figure('visible', 'off');


%% Smoothing [1pt]
K = 1/159 * [2 4 5 4 2; 4 9 12 9 4; 5 12 15 12 5; 4 9 12 9 4; 2 4 5 4 2];
smoothImg = conv2(image, K, 'same');
subplot(2,2,1);
imshow(smoothImg);
title('Gaussian Filter with {\sigma} = 1.4');


%% Gradient Computation [2pt]
sx = [-1 0 1; -2 0 2; -1 0 1];
sy = [-1 -2 -1; 0 0 0; 1 2 1];
Gx = conv2(smoothImg, sx, 'same');
Gy = conv2(smoothImg, sy, 'same');
G = zeros(nrow, ncol);
Gt = zeros(nrow, ncol);
for i = 1:nrow
    for j = 1:ncol
        G(i,j) = sqrt(Gx(i,j)^2 + Gy(i,j)^2);
        Gt(i,j) = atan2(Gy(i,j), Gx(i,j));
    end
end
subplot(2,2,2);
imshow(G);
title('Gradient Magnitude');


%% Non Maximum suppression [3pt]
dir = [[0, 1]; [-1, 1]; [-1, 0]; [-1, -1]; [0, -1]; [1, -1]; [1, 0]; [1, 1]];
ts = pi/4;

nm = zeros(nrow, ncol);

for i = 2:(nrow-1)
    for j = 2:(ncol-1)
        k = round(Gt(i,j) / ts) + 4; 
        
        idx1 = int32(mod(k, 8)+1);
        idx2 = int32(mod(k+4, 8)+1);
        d1 = dir(idx1, :);
        d2 = dir(idx2, :);
            
        if G(i,j) > G(i+d1(1), j+d1(2)) ...
                && G(i,j) > G(i+d2(1), j+d2(2))
            nm(i,j) = G(i,j);
        end
    end
end
subplot(2,2,3);
imshow(nm);
title('Suppressed Image');


%% Hysteresis Thresholding [3pt]
import java.util.LinkedList
q = LinkedList();

th = 80/256;
tl = 50/256;
ht = zeros(nrow, ncol);
for i = 1:nrow
    for j = 1:ncol
        if nm(i,j) >= th
            q.add([i, j]);
            ht(i,j) = nm(i,j);
        end
    end
end

while (q.size() ~= 0)
    p = q.getFirst(); q.remove();
    r = p(1); c = p(2);
    for k = 1:8
        nr = r + dir(k, 1);
        nc = c + dir(k, 2);
        if nr == 0 || nc == 0 || nr > nrow || nc > ncol
            % do nothing
        elseif nm(nr, nc) >= tl && ht(nr, nc) == 0
            ht(nr, nc) = nm(nr, nc);
        end
    end
end
subplot(2,2,4);
imshow(ht);
title('Hystersis Thresholding');


%% Save Image
saveas(res, '../res/prob_5.jpg');