% ***** 6.4 Epipolar Geometry *****

% --- Input image file ---
load('data/dino2.mat')
%load('data/matrix2.mat')
%load('data/warrior2.mat')

% --- Gray ---
image1 = rgb2gray(dino01);
image2 = rgb2gray(dino02);


% --- Fundamental matrix ---
F = fund(cor1, cor2);

plotting(F, image1, image2, 'dino01', 'dino02', '6-4EpipolarGeometry_dino', cor1, cor2);
%plotting(F, rgb2gray(matrix01), rgb2gray(matrix02), 'matrix01', 'matrix02', '6-4EpipolarGeometry_matrix', cor1, cor2);
%plotting(F, rgb2gray(warrior01), rgb2gray(warrior02), 'warrior01', 'warrior02', '6-4EpipolarGeometry_warrior', cor1, cor2);



function finish = plotting(F, image1, image2, name1, name2, fileName, cor1, cor2)
[nRow1, wid1] = size(cor1);
[nRow2, wid2] = size(cor2);

[H1,L1] = size(image1);
[H2,L2] = size(image2);

% --- Plotting ---
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,4000,2000]);

imshow(image1);
axis on;
hold on;
for i = 1:nRow1
viscircles([cor1(i,1), cor1(i,2)],40);

line = F*[cor1(i,1), cor1(i,2),1]';
xrange = [1, L1];
yrange = [1, H1];
PtMat = round( linePts(line, xrange, yrange) );

for i = 1:2
    for j = 1:2
        if (PtMat(i,j) == 0)
            PtMat(i,j) = 1;
        elseif (PtMat(i,j) >= H1 && j == 2)
            PtMat(i,j) = H1;
        elseif (PtMat(i,j) > L1 && j == 1)
            PtMat(i,j) = L1;
        end
    end
end

% --- usage of plot line: plot([x1;x2],[y1;y2])
plot( [PtMat(1,1);PtMat(2,1)], [PtMat(1,2);PtMat(2,2)],'b-' );
end

title( strcat('(a) - ', name1) );
contcatString = strcat( strcat('Output/', fileName), '_Result1.jpg');
saveas(graph, contcatString);



graph = figure('visible', 'off');
%set(gcf,'units','points','position',[0,0,1000,500]);

imshow(image2);
axis on;
hold on;
for i = 1:nRow2
viscircles([cor2(i,1), cor2(i,2)],40);

line = F*[cor1(i,1), cor1(i,2),1]';
xrange = [1, L2];
yrange = [1, H2];
PtMat = round( linePts(line, xrange, yrange) );

for i = 1:2
    for j = 1:2
        if (PtMat(i,j) == 0)
            PtMat(i,j) = 1;
        elseif (PtMat(i,j) >= H2 && j == 2)
            PtMat(i,j) = H2;
        elseif (PtMat(i,j) > L2 && j == 1)
            PtMat(i,j) = L2;
        end
    end
end

% --- usage of plot line: plot([x1;x2],[y1;y2])
plot( [PtMat(1,1);PtMat(2,1)], [PtMat(1,2);PtMat(2,2)],'b-');

end
title( strcat('(b) - ', name2) );

contcatString = strcat( strcat('Output/', fileName), '_Result2.jpg');
saveas(graph, contcatString);

end

function F = fund(x1, x2)
% Computes the fundamental matrix from a set of image correspondences
%
% INPUTS
%   x1    - Image coordinates for reference camera 1 (one per row)
%   x2    - Image coordinates for moved camera 2 (one per row)
%
% OUTPUTS
%   F     - Fundamental matrix (relates pts in cam 1 to lines in cam 2)
%
% DATESTAMP
%   21-May-07 4:16pm
%
% See also SVD

%% 0. Error-checking for input
n = size(x1,1);
if (size(x2,1) ~= n)
    error('Invalid correspondence: number of points don''t match!');
end

%% 1. Perform Hartley normalization (p. 212 of MaSKS)
avg1 = sum(x1,1) / n;
avg2 = sum(x2,1) / n;
diff1 = x1 - repmat(avg1,n,1);
diff2 = x2 - repmat(avg2,n,1);
std1 = sqrt(sum(diff1.^2,1) / n);
std2 = sqrt(sum(diff2.^2,1) / n);
H1 = [1/std1(1), 0, -avg1(1)/std1(1);
      0, 1/std1(2), -avg1(2)/std1(2);
      0, 0, 1];
H2 = [1/std2(1), 0, -avg2(1)/std2(1);
      0, 1/std2(2), -avg2(2)/std2(2);
      0, 0, 1];

norm1 = ([x1 ones(n,1)])*H1';
norm2 = ([x2 ones(n,1)])*H2';

%% 2. Compute a first approximation of the fundamental matrix
design = zeros(n,9);

for i=1:n
    design(i,:) = kron(norm1(i,:), norm2(i,:));
end

[U,S,V] = svd(design);
Fs = V(:,9);
F = reshape(Fs, 3, 3);

%% 3. Impose the rank constraint
[U,S,V] = svd(F);
S(3,3) = 0;
F = U*S*V';

%% 4. Undo the normalization
F = H2'*F*H1;

end

function pts = linePts(line, xrange, yrange)
% Returns the endpoints of a line clipped by the given bounding box.
%
% INPUTS
%   line    - Homogeneous coordinates of the line
%   xrange  - X-coordinate range of the bounding box [xmin, xmax]
%   yrange  - Y-coordinate range of the bounding box [ymin, ymax]
% 
% OUTPUTS
%   pts     - The endpoints of the line in the bounding box.
% 
% DATESTAMP
%   18-May-07 12:10am
% 

xmin = xrange(1); xmax = xrange(2);
ymin = yrange(1); ymax = yrange(2);

% Find the four intersections with the bounding box limits
allPts = [xmin, -(line(1)*xmin + line(3))/line(2);
          xmax, -(line(1)*xmax + line(3))/line(2);
          -(line(2)*ymin + line(3))/line(1), ymin;
          -(line(2)*ymax + line(3))/line(1), ymax];

% Clip testing: find the two intersections inside the bounding box
count = 0;
pts = zeros(2,2);
for i=1:4
    if ((allPts(i,1) >= xmin) && (allPts(i,1) <= xmax) && ...
        (allPts(i,2) >= ymin) && (allPts(i,2) <= ymax))
        % add it to the list of endpoints
        count = count + 1;

        if (count == 1)
            pts(count,:) = allPts(i,:);
        elseif (count > 1)
            addPoint = logical(1);
            for j=1:count-1
                % Check to see that we're not adding a duplicate point
                diff = sum(abs(pts(j,:) - allPts(i,:)));
                if (diff < 1e-5)
                    % Don't add the point
                    addPoint = 0;
                end
            end
            
            if (~addPoint)
                count = count - 1;
            elseif (count > 2)
                % This is an error
                error('Bug: more than two points on the line intersect the bounding box!');
            else
                % Add the point to the list
                pts(count,:) = allPts(i,:);
            end
        end
    end
end
end
