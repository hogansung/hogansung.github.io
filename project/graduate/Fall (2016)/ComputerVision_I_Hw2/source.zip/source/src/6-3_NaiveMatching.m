% ***** 6.3 Naive Matching *****

% --- Input image file ---
load('data/dino2.mat')
load('data/matrix2.mat')
load('data/warrior2.mat')

% --- Image ---
%I1 = dino01;
%I2 = dino02;

% --- FileName ---
%fileName = '6-3NaiveMatching_Dino';

% --- Parameters ---
ncorners = 10;
smoothSTD = 5;
windowSize = 5;
R = 10;
SSDth = 1.2;


PlottingNaiveMatching(dino01, dino02, '6-3NaiveMatching_Dino', ncorners, smoothSTD, windowSize, R, SSDth);
%PlottingNaiveMatching(matrix01, matrix02, '6-3NaiveMatching_matrix', ncorners, smoothSTD, windowSize, R, SSDth);
%PlottingNaiveMatching(warrior01, warrior02, '6-3NaiveMatching_waerrior', ncorners, 5, 10, 10, 2);


function finish = PlottingNaiveMatching(I1,I2, fileName, ncorners, smoothSTD, windowSize, R, SSDth)
corners1 = CornerDetect(I1, ncorners, smoothSTD, windowSize);
corners2 = CornerDetect(I2, ncorners, smoothSTD, windowSize);

[I, corsSSD] = naiveCorrespondanceMatching(I1, I2, corners1, corners2, R, SSDth);


% --- Combine the two image ---
I1 = rgb2gray(I1);
I2 = rgb2gray(I2);
[I1_x, I1_y] = size(I1);
[I2_x, I2_y] = size(I2);
I_combine = zeros(I1_x, I1_y *2);
I_combine(1:I1_x, 1:I1_y)= I1(1:I1_x, 1:I1_y);
I_combine(1:I2_x, I1_y + 1 : I1_y + I2_y)= I2(1:I2_x, 1 : I2_y);
[Nrows, I_width] = size(I);

graph = figure('visible', 'off');
%set(gcf,'units','points','position',[0,0,1000,500]);

imshow(I_combine);
axis on;
for i = 1:Nrows
viscircles([I(i,2), I(i,1)],40);
viscircles([I(i,4) + I1_y , I(i,3)],40);

% --- usage of line: line([col1,col2],[row1,row2])
line( [I(i,2), I(i,4) + I1_y], [I(i,1), I(i,3)] );
end

%contcatString = 'Output/6-3Naive Matching.jpg';
contcatString = strcat( strcat('Output/', fileName), '.jpg');
saveas(graph, contcatString);

finish = 1;
end

function [I,corsSSD] = naiveCorrespondanceMatching(I1, I2, corners1, corners2, R, SSDth);

[N1, width1] = size(corners1);
[N2, width2] = size(corners2);

I = [];
corsSSD = [];
for i = 1:N1
    temp = zeros(1,N2);
    halfR = round(R/2);
    w1 = I1( corners1(i,1)-halfR :corners1(i,1)+halfR , corners1(i,2)-halfR:corners1(i,2)+halfR );
    
    for j = 1:N2
        w2 = I2( corners2(j,1)-halfR:corners2(j,1)+halfR , corners2(j,2)-halfR:corners2(j,2)+halfR );
        temp(j) = SSDmatch(w1,w2);
    end
    
    [minSSD,index_min] = min(temp(:));
    if (minSSD<SSDth) 
        continue;
    else
        tempI = [corners1(i,1), corners1(i,2), corners2(index_min,1), corners2(index_min,2)];
        I = [I;tempI];
        corsSSD = [corsSSD;minSSD];
    end
    
    
end

end

function ssd = SSDmatch(w1,w2)
[rows1, cols1] = size(w1);
[rows2, cols2] = size(w2);

if (rows1 ~= rows2 || cols1 ~= cols2)
    ssd = 0;
else
    Diff = w1 - w2;
    ssd = sum(sum(Diff.*Diff));
end

end

function corners = CornerDetect(Image, nCorners, smoothSTD, windowSize)
img = rgb2gray(Image);
[img_x, img_y] = size(img);
img = smoothts(img, 'g', windowSize, smoothSTD);

% ---Gradient ---
[Ix, Iy] = imgradientxy(img);
Ix2 = Ix.*Ix;
Iy2 = Iy.*Iy;
IxIy = Ix.*Iy;

EigMat = zeros(img_x, img_y);

start_x = 1 + round(windowSize/2);
start_y = 1 + round(windowSize/2);
end_x = img_x - round(windowSize/2)-1;
end_y = img_y - round(windowSize/2)-1;

for i = start_x : end_x
    for j = start_y : end_y
        start_i = i - round(windowSize/2);
        start_j = j - round(windowSize/2);
        end_i = i + round(windowSize/2);
        end_j = j + round(windowSize/2);
        
        C11 = sum(sum( Ix2(start_i:end_i, start_j:end_j) ));
        C12 = sum(sum( IxIy(start_i:end_i, start_j:end_j) ));
        C22 = sum(sum( Iy2(start_i:end_i, start_j:end_j) ));
        
        C = [C11, C12; C12, C22];
        e = eig(C);
        EigMat(i,j) = min(e(1), e(2));
        
    end
end

corners = zeros(nCorners,2);

i=1;
while (i <= nCorners)
    [M,I] = max(EigMat(:));
    [I_row, I_col] = ind2sub(size(EigMat),I);
    tooCloseFlag = 0;
    for j = 1:i
%        I_row, I_col
        if ( distance(I_row, I_col, corners(j,1), corners(j,2)) < windowSize)
            tooCloseFlag = 1;
            break;
        else
            tooCloseFlag = 0;
            continue
        end
    end
    
    if (tooCloseFlag == 1)
        EigMat(I_row,I_col) = 0;
        i = i-1;
    else 
        corners(i,1) = I_row;
        corners(i,2) = I_col;
        EigMat(I_row,I_col) = 0;
    end
    
    i=i+1;
end

end

function dist = distance(x1,y1,x2,y2)
    dist = sqrt( (x1-x2)^2 + (y1-y2)^2 );
end
