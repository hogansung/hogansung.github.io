% ***** 4.1 Filter *****

% --- Input image file ---
filter_img = im2double( imread('data/filter.jpg') );
toy_img = im2double( imread('data/toy.png') );

% --- Modification ---
filter_img = filter_img - mean(filter_img(:));
toy_img_mean = toy_img - mean(toy_img(:));

% --- Convolution ---
ans_img(:,:,:) = conv2(toy_img_mean(:,:,:), filter_img(:,:,:), 'same');

% --- Bounding Box Detection and Plotting ---
toy_img_box(:,:,:) = toy_img(:,:,:);
box_length = 127;
box_height = 127;
[x1,y1] = box_Pre(ans_img,100,300,60,200, box_length, box_height);
toy_img_box = boxDrawing(toy_img_box,x1,y1, box_length, box_height, 0);
[x2,y2] = box_Pre(ans_img,20,150,300,400, box_length, box_height);
toy_img_box = boxDrawing(toy_img_box,x2,y2, box_length, box_height, 0);
[x3,y3] = box_Pre(ans_img,200,330,320,430, box_length, box_height);
toy_img_box = boxDrawing(toy_img_box,x3,y3, box_length, box_height, 0);

% --- Plotting ---
graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,4000,2000]);

subplot (1,2,1);
imagesc(ans_img);
title('(a) Heat map');

subplot(1,2,2);
imshow(toy_img_box);
axis on;
title('(b) Bounding box');

saveas(graph, 'Output/4.1Warmup.jpg');



% ***** 4.2 Detection Error *****
toy_img_box_err1(:,:,:) = toy_img(:,:,:);
toy_img_box_err2(:,:,:) = toy_img(:,:,:);
toy_img_box_err3(:,:,:) = toy_img(:,:,:);

box_length = 127;
box_height = 127;

x_grou1 = 100;
y_grou1 = 100;
overlappingArea1=errDetecion(x_grou1,y_grou1,x1,y1, box_length, box_height);
toy_img_box_err1 = boxDrawing(toy_img_box_err1,x_grou1,y_grou1, box_length, box_height, 0.5);
toy_img_box_err1 = boxDrawing(toy_img_box_err1,x1,y1, box_length, box_height, 0);

x_grou2 = 80;
y_grou2 = 60;
overlappingArea2=errDetecion(x_grou2,y_grou2,x1,y1, box_length, box_height);
toy_img_box_err2 = boxDrawing(toy_img_box_err2,x_grou2,y_grou2, box_length, box_height, 0.5);
toy_img_box_err2 = boxDrawing(toy_img_box_err2,x1,y1, box_length, box_height, 0);

x_grou3 = 150;
y_grou3 = 200;
overlappingArea3=errDetecion(x_grou3,y_grou3,x1,y1, box_length, box_height);
toy_img_box_err3 = boxDrawing(toy_img_box_err3,x_grou3,y_grou3, box_length, box_height, 0.5);
toy_img_box_err3 = boxDrawing(toy_img_box_err3,x1,y1, box_length, box_height, 0);

graph = figure('visible', 'off');
set(gcf,'units','points','position',[0,0,2000,1000]);
subplot (2,2,1);
imshow(toy_img_box_err1);
axis on;
title(strcat('OLA% with GT1=', string(overlappingArea1)));

subplot(2,2,2);
imshow(toy_img_box_err2);
axis on;
title(strcat('OLA% with GT2=', string(overlappingArea2)));

subplot(2,2,3);
imshow(toy_img_box_err3);
axis on;
title(strcat('OLA% with GT3=', string(overlappingArea3)));

saveas(graph, 'Output/4.2Error.jpg');


function [Xstart,Ystart] = box_Pre(inten_img,x1,x2,y1,y2, dx, dy)
temp = inten_img(x1:x2,y1:y2);
[M,I] = max(temp(:));
[I_row, I_col] = ind2sub(size(temp),I);
Xstart = I_row - round(dx/2) + x1;
Ystart = I_col - round(dy/2) + y1;
end

function res_img = boxDrawing(toy_img_box, x, y, dx, dy,color)
toy_img_box(x:x+dx,y) = color;
toy_img_box(x:x+dx,y+dy) = color;
toy_img_box(x,y:y+dy) = color;
toy_img_box(x+dx,y:y+dy) = color;
res_img = toy_img_box;
end

function overlappingArea=errDetecion(x_grou,y_grou,x_pre,y_pre, dx, dy)

X_union = dx + max(x_grou, x_pre) - min(x_grou, x_pre);
Y_union = dy + max(y_grou, y_pre) - min(y_grou, y_pre);

X_substract = abs(x_grou - x_pre);
Y_substract = abs(y_grou - y_pre);

X_intersec = dx - X_substract;
Y_intersec = dy - Y_substract;

numerator = X_intersec * Y_intersec;
demoniator = X_union * Y_union - 2 * (X_substract * Y_substract);

overlappingArea = numerator / demoniator *100;
end
