function tt_p = fisherTest(tn_x, tn_y, tt_x, W, mu, k)

% select subset of W
sW = W(1:k, :);

% remap function to subspace
tn_x = bsxfun(@minus, tn_x, mu) * sW';
tt_x = bsxfun(@minus, tt_x, mu) * sW';

% apply 1NN
tt_p = kNN(tn_x, tn_y, tt_x, 1, 2);