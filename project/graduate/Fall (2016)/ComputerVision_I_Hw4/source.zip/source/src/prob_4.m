%% load dataset
[tn_x, tn_y] = loadSubset(0, '../dat/yaleBfaces');
[tt_1_x, tt_1_y] = loadSubset(1, '../dat/yaleBfaces');
[tt_2_x, tt_2_y] = loadSubset(2, '../dat/yaleBfaces');
[tt_3_x, tt_3_y] = loadSubset(3, '../dat/yaleBfaces');
[tt_4_x, tt_4_y] = loadSubset(4, '../dat/yaleBfaces');

%% 4-1 and 4-3
kLst = [1, 3, 5];
pLst = [2, 1, 3];
for i = 1:length(kLst)
    for j = 1:length(pLst)
        tt_1_p = kNN(tn_x, tn_y, tt_1_x, kLst(i), pLst(j));
        fprintf('Test 1 with (k=%d, p=%d): %f\n', ...
            kLst(i), pLst(j), calAcc(tt_1_y, tt_1_p));
        tt_2_p = kNN(tn_x, tn_y, tt_2_x, kLst(i), pLst(j));
        fprintf('Test 2 with (k=%d, p=%d): %f\n', ...
            kLst(i), pLst(j), calAcc(tt_2_y, tt_2_p));
        tt_3_p = kNN(tn_x, tn_y, tt_3_x, kLst(i), pLst(j));
        fprintf('Test 3 with (k=%d, p=%d): %f\n', ...
            kLst(i), pLst(j), calAcc(tt_3_y, tt_3_p));
        tt_4_p = kNN(tn_x, tn_y, tt_4_x, kLst(i), pLst(j));
        fprintf('Test 4 with (k=%d, p=%d): %f\n', ...
            kLst(i), pLst(j), calAcc(tt_4_y, tt_4_p));
    end
end