%% load dataset
[tn_x, tn_y] = loadSubset(0, '../dat/yaleBfaces');
[tt_1_x, tt_1_y] = loadSubset(1, '../dat/yaleBfaces');
[tt_2_x, tt_2_y] = loadSubset(2, '../dat/yaleBfaces');
[tt_3_x, tt_3_y] = loadSubset(3, '../dat/yaleBfaces');
[tt_4_x, tt_4_y] = loadSubset(4, '../dat/yaleBfaces');

%% 6-1
[W, mu] = fisherTrain(tn_x, tn_y, 10);

%% 6-2
st_W = zeros(450, 50);
for i = 1:9
    lt = 50 * (i-1) + 1;
    rt = 50 * i;
    st_W(lt:rt, :) = mat2gray(reshape(W(i, :), [50, 50]));
end
res = figure('visible', 'off');
imshow(st_W);
saveas(res, strcat('../res/fisherBases', '.jpg'));

% %% 6-3
tt_1_err = zeros(1, 9);
tt_2_err = zeros(1, 9);
tt_3_err = zeros(1, 9);
tt_4_err = zeros(1, 9);
for k = 1:9
    tt_1_p = fisherTest(tn_x, tn_y, tt_1_x, W, mu, k);
    tt_1_err(k) = 1 - calAcc(tt_1_y, tt_1_p);
    tt_2_p = fisherTest(tn_x, tn_y, tt_2_x, W, mu, k);
    tt_2_err(k) = 1 - calAcc(tt_2_y, tt_2_p);
    tt_3_p = fisherTest(tn_x, tn_y, tt_3_x, W, mu, k);
    tt_3_err(k) = 1 - calAcc(tt_3_y, tt_3_p);
    tt_4_p = fisherTest(tn_x, tn_y, tt_4_x, W, mu, k);
    tt_4_err(k) = 1 - calAcc(tt_4_y, tt_4_p);
end
res = figure('visible', 'off');
plot(1:9, tt_1_err, 1:9, tt_2_err, 1:9, tt_3_err, 1:9, tt_4_err);
legend('Test Data 1', 'Test Data 2', 'Test Data 3', 'Test Data 4');
xlabel('Number of Principle Conponents');
saveas(res, strcat('../res/fisherTest', '.jpg'));