function tt_p = kNN(tn_x, tn_y, tt_x, k, p)

n_tn = size(tn_x, 1);
n_tt = size(tt_x, 1);
tt_p = zeros(n_tt, 1);

for i = 1:n_tt
    dis = zeros(n_tn, 2);
    for j = 1:n_tn
        dis(j, 1) = norm(tn_x(j, :) - tt_x(i, :), p);
        dis(j, 2) = tn_y(j);
    end
    
    [~, idx] = sort(dis(:, 1));
    dis = dis(idx, :);
    
    tt_p(i) = mode(dis(1:k, 2));
end