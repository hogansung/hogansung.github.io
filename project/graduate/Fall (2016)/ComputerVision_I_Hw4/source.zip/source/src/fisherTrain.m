function [W, mu] = fisherTrain(tn_x, tn_y, c)

%% parameters
[n, ~] = size(tn_x);

%% PCA
[w_pca, mu] = eigenTrain(tn_x, n-c);
tn_x = (tn_x-mu) * w_pca;

%% LDA
muLst = zeros(c, n-c);
c_size = zeros(c, 1);
for i = 1:c
    muLst(i, :) = mean(tn_x(tn_y == i, :), 1);
    c_size(i) = sum(tn_y == i);
end
muAll = mean(tn_x, 1);

sb = zeros(n-c, n-c);
for i = 1:c
    bd = muLst(i, :) - muAll;
    sb = sb + c_size(i) * (bd' * bd);
end

sw = zeros(n-c, n-c);
for i = 1:n
    wd = tn_x(i, :) - muLst(tn_y(i), :);
    sw = sw + wd' * wd;
end

[V, ~] = eigs(sb, sw, c-1);
%V = fliplr(V);
w_lda = V(:, 1:(c-1));

W = w_lda' * w_pca';
