function [acc] = calAcc(y, p)

acc = sum(y == p) / length(y);