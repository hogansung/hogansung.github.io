#include <cstdio>
#include <cstdlib>
#include <cfloat>
#include <cmath>
#include <vector>
#include <string>

using namespace std;

const int NUM_STAT = 26;
const int NUM_OBSV = 2;
const int NUM_DATA = 180000;

int main() {
    vector<double> init(NUM_STAT, 0);
    { // initialStateDistribution.txt
        FILE* pf = fopen("../dat/initialStateDistribution.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open initialStateDistribution.txt");
            exit(EXIT_FAILURE);
        }

        double d;
        for (int i = 0; i < NUM_STAT; i++) {
            fscanf(pf, "%lf", &d);
            init[i] = d;
        }

        fclose(pf);
    }

    vector<vector<double>> trans(NUM_STAT, vector<double>(NUM_STAT, 0));
    { // transitionMatrix.txt
        FILE* pf = fopen("../dat/transitionMatrix.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open transitionMatrix.txt");
            exit(EXIT_FAILURE);
        }

        double d;
        for (int i = 0; i < NUM_STAT; i++) {
            for (int j = 0; j < NUM_STAT; j++) {
                fscanf(pf, "%lf", &d);
                trans[i][j] = d;
            }
        }

        fclose(pf);
    }

    vector<vector<double>> obsv(NUM_STAT, vector<double>(NUM_OBSV, 0));
    { // emissionMatrix.txt
        FILE* pf = fopen("../dat/emissionMatrix.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open emissionMatrix.txt");
            exit(EXIT_FAILURE);
        }

        double d;
        for (int i = 0; i < NUM_STAT; i++) {
            for (int j = 0; j < NUM_OBSV; j++) {
                fscanf(pf, "%lf", &d);
                obsv[i][j] = d;
            }
        }

        fclose(pf);
    }

    vector<int> data(NUM_DATA, 0);
    { // observations.txt
        FILE* pf = fopen("../dat/observations.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open observations.txt");
            exit(EXIT_FAILURE);
        }

        int d;
        for (int i = 0; i < NUM_DATA; i++) {
            fscanf(pf, "%d", &d);
            data[i] = d;
        }

        fclose(pf);
    }
    
    vector<vector<double>> val(NUM_DATA, vector<double>(NUM_STAT, 0));
    vector<vector<int>> rcd(NUM_DATA, vector<int>(NUM_STAT, 0));
    for (int j = 0; j < NUM_STAT; j++) {
        val[0][j] = log(init[j]) + log(obsv[j][data[0]]);
    }
    for (int i = 1; i < NUM_DATA; i++) {
        for (int j = 0; j < NUM_STAT; j++) { // next
            double mmax = -DBL_MAX;
            int idx = -1;
            for (int k = 0; k < NUM_STAT; k++) { // prev
                double tmp = val[i-1][k] + log(trans[k][j]);
                if (tmp > mmax) {
                    mmax = tmp;
                    idx = k;
                }
            }
            rcd[i][j] = idx;
            val[i][j] = mmax + log(obsv[j][data[i]]);
        }
    }

    vector<int> s(NUM_DATA, 0);
    double mmax = -DBL_MAX;
    int idx = -1;
    for (int j = 0; j < NUM_STAT; j++) {
        if (val[NUM_DATA-1][j] > mmax) {
            mmax = val[NUM_DATA-1][j];
            idx = j;
        }
    }
    s[NUM_DATA-1] = idx;
    for (int i = NUM_DATA-1; i > 0; i--) {
        s[i-1] = idx = rcd[i][idx];
    }

    { // output.txt
        FILE* pf = fopen("../res/output.csv", "w");
        if (pf == NULL) {
            fprintf(stderr, "cannot write output.csv");
            exit(EXIT_FAILURE);
        }

        for (int i = 0; i < NUM_DATA; i++) {
            fprintf(pf, "%d%c", s[i], i == NUM_DATA-1 ?'\n' :',');
        }

        fclose(pf);
    }

    { // for checking
        string str;
        int lst = s[0];
        str.push_back('a' + lst);
        for (int i = 1; i < NUM_DATA; i++) {
            if (lst == s[i]) {
                // do nothing
            } else {
                lst = s[i];
                str.push_back('a' + lst);
            }
        }
        printf("%s\n", str.c_str());
    }
}
