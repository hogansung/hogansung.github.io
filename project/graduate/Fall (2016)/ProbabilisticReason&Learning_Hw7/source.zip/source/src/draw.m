% read in data
M = csvread('../res/output.csv');

% plot figure
res = figure('visible', 'off');
plot(M);
xlabel('Time');
ylabel('State')
print -r96 % set resolution
saveas(res, '../res/state.jpg');