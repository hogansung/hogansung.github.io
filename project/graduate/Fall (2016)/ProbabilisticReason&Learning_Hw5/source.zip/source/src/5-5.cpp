#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <algorithm>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

double square(double x) {
    return x * x;
}

double calErr(vector<double>& dat, VectorXd& x) {
    int size = dat.size();
    double ret = 0;
    for (int l = 4; l < size; l++) {
        double pred = 0;
        for (int i = 0; i < 4; i++) {
            pred += x(i) * dat[l-1-i];
        }
        ret += square(dat[l] - pred);
    }
    return ret / (size - 4);
}

int main() {
    vector<double> tn;
    { // read training data: nasdaq00.txt
        FILE *pf = fopen("../dat/nasdaq00.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open nasdaq00.txt\n");
            exit(EXIT_FAILURE);
        }

        double v;
        while (fscanf(pf, "%lf", &v) != EOF) {
            tn.emplace_back(v);
        }

        fclose(pf);
    }
    
    vector<double> tt;
    { // read testing data: nasdaq01.txt
        FILE *pf = fopen("../dat/nasdaq01.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open nasdaq01.txt\n");
            exit(EXIT_FAILURE);
        }

        double v;
        while (fscanf(pf, "%lf", &v) != EOF) {
            tt.emplace_back(v);
        }

        fclose(pf);
    }

    // 5.5 (a) Prepare needed info from training set
    // to calculate \sum_{l=4}^{n-1} x_{l-i} x_{l-j}
    vector<vector<double>> vct(5, vector<double>(5, 0));
    int size = tn.size();
    for (int l = 4; l < size; l++) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                vct[i][j] += tn[l-i] * tn[l-j]; 
            }
        }
    }

    // 5.5 (a) Prepare matrix a and vector b
    // to solve a x = b => x = a^{-1} b
    MatrixXd a(4, 4);
    for (int i = 1; i < 5; i++) {
        for (int j = 1; j < 5; j++) {
            a(i-1, j-1) = vct[i][j];
        }
    }
    VectorXd b(4);
    for (int j = 1; j < 5; j++) {
        b(j-1) = vct[0][j];
    }
    VectorXd x(4);
    x = a.inverse() * b;
    printf("5.5 (a)\n");
    for (int i = 0; i < 4; i++) {
        printf("a_%d: %+f\n", i+1, x(i));
    }
    printf("\n\n");

    // 5.5 (b) Calculate MSE for training and testing 
    printf("5.5 (b)\n");
    double tnErr = calErr(tn, x);
    printf("Training RMSE: %f\n", tnErr);
    double ttErr = calErr(tt, x);
    printf("Testing RMSE:  %f\n", ttErr);
    printf("\n\n");
}
