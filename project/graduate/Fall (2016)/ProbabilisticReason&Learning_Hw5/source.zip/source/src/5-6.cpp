#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

const int NUM_TN = 700;
const int NUM_TT = 400;
const int NUM_FT = 64;

const double eps = 1e-9;
const double rel_eps = 1e-5;
const double LN_RATE = 0.02 / (2 * NUM_TN); //0.0002;

void readData(MatrixXf& x, const int nrow, const int ncol, const string str) {
    string fn = "../dat/" + str;
    FILE *pf = fopen(fn.c_str(), "r");
    if (pf == NULL) {
        fprintf(stderr, "cannot open %s\n", str.c_str());
        exit(EXIT_FAILURE);
    }

    int v;
    for (int i = 0; i < nrow; i++) {
        for (int j = 0; j < ncol; j++) { 
            fscanf(pf, "%d", &v);
            x(i, j) = v;
        }
        x(i,ncol) = 1;
    }

    fclose(pf);
}

double smd(double x) {
    return 1.0 / (1 + exp(-x));
}

double calLLH(const VectorXf& y, const VectorXf& p, const int size) {
    double res = 0;
    for (int l = 0; l < size; l++) {
        res += y(l) * log(eps+p(l)) + (1-y(l)) * log(eps+1-p(l));
    }
    return res;
}

double calACC(const VectorXf& y, const VectorXf& p, const int size) {
    double res = 0;
    for (int l = 0; l < size; l++) {
        res += y(l) == (p(l) > 0.5);
    }
    return res / size;
}

int main() {
    // 5.6 (a): Training 
    printf("\n\n\n[[ TRAINING PHASE ]]\n");

    // Read training data
    printf("\nRead training data\n");
    MatrixXf tn3_x(NUM_TN, NUM_FT+1);
    readData(tn3_x, NUM_TN, NUM_FT, "train3.txt");
    VectorXf tn3_y = VectorXf::Zero(NUM_TN);
    MatrixXf tn5_x(NUM_TN, NUM_FT+1);
    readData(tn5_x, NUM_TN, NUM_FT, "train5.txt");
    VectorXf tn5_y = VectorXf::Ones(NUM_TN);
    MatrixXf tn_x(2*NUM_TN, NUM_FT+1);
    tn_x << tn3_x,
            tn5_x;
    VectorXf tn_y(2*NUM_TN);
    tn_y << tn3_y,
            tn5_y;

    // Prepare weighting matrix
    VectorXf w = VectorXf::Zero(NUM_FT+1);

    // Calculate initial error
    VectorXf tn_p = (tn_x * w).unaryExpr(&smd);
    double tn_acc = calACC(tn_y, tn_p, 2*NUM_TN);
    double tn_llh = calLLH(tn_y, tn_p, 2*NUM_TN);
    double lt_llh = tn_llh;
    printf("#%4d TN Error (LLH): %f (%f)\n", 0, 1 - tn_acc, tn_llh);

    // Start training process
    for (int iter = 1; ; iter++) {
        // g'(x)
        VectorXf nw = VectorXf::Zero(64);
        nw = tn_x.transpose() * (tn_y - tn_p);

        /*{ // update w by Newton Method
            // g''(x)
            VectorXf tn_q = (-tn_x * w).unaryExpr(&smd);
            MatrixXf pq = tn_p.cwiseProduct(tn_q).asDiagonal();
            MatrixXf hs = -tn_x.transpose() * pq * tn_x;
            w = w - hs.inverse() * nw;
        }*/
        
        { // update w by Gradient Descent
            w = w + LN_RATE * nw;
        }

        tn_p = (tn_x * w).unaryExpr(&smd);
        tn_acc = calACC(tn_y, tn_p, 2*NUM_TN);
        tn_llh = calLLH(tn_y, tn_p, 2*NUM_TN);

        if (abs(tn_llh - lt_llh) < rel_eps * abs(lt_llh)) {
            printf("\nConverge!\n");
            printf("#%4d TN Error (LLH): %f (%f)\n", iter, 1 - tn_acc, tn_llh);
            break;
        } else if (iter % 1000 == 0) {
            printf("#%4d TN Error (LLH): %f (%f)\n", iter, 1 - tn_acc, tn_llh);
        }

        lt_llh = tn_llh;
    }

    // Print out learned weighting matrix
    printf("\nLearned Weighting Matrix\n");
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            printf("%+f ", w(i*8+j));
        }
        puts("");
    }
    

    // 5.6 (a): Testing 
    printf("\n\n\n[[ TESTING PHASE ]]\n");

    // Read testing data
    printf("\nRead testing data\n");
    MatrixXf tt3_x(NUM_TT, NUM_FT+1);
    readData(tt3_x, NUM_TT, NUM_FT, "test3.txt");
    VectorXf tt3_y = VectorXf::Zero(NUM_TT);
    MatrixXf tt5_x(NUM_TT, NUM_FT+1);
    readData(tt5_x, NUM_TT, NUM_FT, "test5.txt");
    VectorXf tt5_y = VectorXf::Ones(NUM_TT);
    MatrixXf tt_x(2*NUM_TT, NUM_FT+1);
    tt_x << tt3_x,
            tt5_x;
    VectorXf tt_y(2*NUM_TT);
    tt_y << tt3_y,
            tt5_y;
    
    // Start prediction process
    VectorXf tt_p = (tt_x * w).unaryExpr(&smd);
    double tt_acc = calACC(tt_y, tt_p, 2*NUM_TT);
    printf("TT Error: %f\n", 1 - tt_acc);
}
