#include <cstdio>
#include <cstdlib>
#include <cfloat>
#include <vector>
#include <random>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

const int NUM_STAT = 81;
const int NUM_ACTN = 4;

const double g = 0.9925;
const double ceps = 1e-9; // eps for convergence
const double seps = 1e-6; // eps for showing up

default_random_engine generator;
uniform_int_distribution<int> distribution(0,3);

void printPath(const VectorXd& policy);
void printPlan(const VectorXi& pi, const VectorXd& policy);
int valueIterate(const vector<MatrixXd>& prob, 
  const VectorXd& reward, VectorXi& pi, VectorXd& policy);
int policyIterate(const vector<MatrixXd>& prob, 
  const VectorXd& reward, VectorXi& pi, VectorXd& policy);

int main() {
    // read prob
    vector<MatrixXd> prob(4, MatrixXd::Zero(NUM_STAT, NUM_STAT));
    {
        for (int i = 0; i < 4; i++) {
            string fn = "../dat/prob_a" + to_string(i+1) + ".txt";
            FILE *pf = fopen(fn.c_str(), "r");
            if (pf == NULL) {
                fprintf(stderr, "Cannot open %s\n", fn.c_str());
                exit(EXIT_FAILURE);
            }

            int a, b;
            double v;
            while (fscanf(pf, "%d%d%lf", &a, &b, &v) != EOF) {
                a -= 1;
                b -= 1;
                prob[i](a, b) = v;
            }

            fclose(pf);
        }
    }

    // read reward
    VectorXd reward = VectorXd::Zero(NUM_STAT);
    {
        string fn = "../dat/rewards.txt";
        FILE *pf = fopen(fn.c_str(), "r");
        if (pf == NULL) {
            fprintf(stderr, "Cannot open %s\n", fn.c_str());
            exit(EXIT_FAILURE);
        }

        int d;
        for (int i = 0; i < NUM_STAT; i++) {
            fscanf(pf, "%d", &d);
            reward[i] = d;
        }

        fclose(pf);
    }


    { // 8-2 (a) and (b)
        // random policy
        VectorXd policy = VectorXd::Random(NUM_STAT);
        VectorXi pi = VectorXi::Zero(NUM_STAT);

        printf("\n\nProblem 8-2 (a) and (b)\n");
        int cnt = valueIterate(prob, reward, pi, policy);
        printf("Converge after %d iterations\n", cnt);

        for (int i = 0; i < NUM_STAT; i++) {
            if (policy(i) > ceps or policy(i) < -ceps) {
                printf("#%d: %f\n", i+1, policy(i));
            }
        }

        // 8-2 (a)
        printPath(policy);

        // 8-2 (b)
        printPlan(pi, policy);
    }


    { // 8-2 (c)
        VectorXd policy = VectorXd::Zero(NUM_STAT);

        { // random pi
            VectorXi pi = VectorXi::Zero(NUM_STAT);
            for (int i = 0; i < NUM_STAT; i++) {
                pi(i) = distribution(generator);
            }
            
            printf("\n\nProblem 8-2 (c)\n");
            int cnt = policyIterate(prob, reward, pi, policy);
            printf("Converge after %d iterations\n", cnt);

            for (int i = 0; i < NUM_STAT; i++) {
                if (policy(i) > ceps or policy(i) < -ceps) {
                    printf("#%d: %f\n", i+1, policy(i));
                }
            }

            printPath(policy);
            printPlan(pi, policy);
        }

        { // 8-2 (c) i.
            VectorXi pi = VectorXi::Zero(NUM_STAT);
            for (int i = 0; i < NUM_STAT; i++) {
                pi(i) = 2;
            }
            
            printf("\n\nProblem 8-2 (c) i.\n");
            int cnt = policyIterate(prob, reward, pi, policy);
            printf("Converge after %d iterations\n", cnt);
            printPath(policy);
            printPlan(pi, policy);
        }

        { // 8-2 (c) ii.
            VectorXi pi = VectorXi::Zero(NUM_STAT);
            for (int i = 0; i < NUM_STAT; i++) {
                pi(i) = 3;
            }
            
            printf("\n\nProblem 8-2 (c) ii.\n");
            int cnt = policyIterate(prob, reward, pi, policy);
            printf("Converge after %d iterations\n", cnt);
            printPath(policy);
            printPlan(pi, policy);
        }
    }
}

void printPath(const VectorXd& policy) {
    printf("\n");
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            int idx = i + j*9;
            if (policy(idx) > seps) {
                printf("_");
            } else if (policy(idx) < -seps) {
                printf("d");
            } else {
                printf("#");
            }
        }
        printf("\n");
    }
}

void printPlan(const VectorXi& pi, const VectorXd& policy) {
    printf("\n");
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            int idx = i + j*9;
            if (policy(idx) > seps) {
                if (pi(idx) == 0) {
                    printf("←");
                } else if (pi(idx) == 1) {
                    printf("↑"); 
                } else if (pi(idx) == 2) {
                    printf("→");
                } else {
                    printf("↓");
                }
            } else if (policy(idx) < -seps) {
                printf("d");
            } else {
                printf("#");
            }
        }
        printf("\n");
    }
}

int valueIterate(const vector<MatrixXd>& prob, 
  const VectorXd& reward, VectorXi& pi, VectorXd& policy) {
    bool cont;
    int times = 0;
    do {
        cont = false;
        times += 1;

        vector<VectorXd> pv(4, VectorXd::Zero(NUM_STAT));
        for (int j = 0; j < NUM_ACTN; j++) {
            pv[j] = prob[j] * policy;
        }

        VectorXd npolicy = VectorXd::Zero(NUM_STAT);
        double sum = 0;
        for (int i = 0; i < NUM_STAT; i++) {
            double mmax = -DBL_MAX;
            for (int j = 0; j < NUM_ACTN; j++) {
                if (pv[j](i) > mmax) {
                    mmax = pv[j](i);
                    pi(i) = j;
                }
            }
            npolicy(i) = reward[i] + g * pv[pi(i)](i);

            double diff = fabs(policy(i) - npolicy(i));
            sum += diff;
            if (diff >= ceps or diff <= -ceps) {
                cont = true;
            }
        }
        policy = npolicy;
    } while (cont);

    return times;
}

int policyIterate(const vector<MatrixXd>& prob, 
  const VectorXd& reward, VectorXi& pi, VectorXd& policy) {
    bool cont;
    int times = 0;
    do {
        cont = false;
        times += 1;

        MatrixXd id = MatrixXd::Identity(NUM_STAT, NUM_STAT);
        MatrixXd nprob = MatrixXd::Zero(NUM_STAT, NUM_STAT);
        for (int i = 0; i < NUM_STAT; i++) {
            nprob.row(i) = prob[pi(i)].row(i);
        }

        policy = (id - g * nprob).inverse() * reward;

        vector<VectorXd> pv(4, VectorXd::Zero(NUM_STAT));
        for (int j = 0; j < NUM_ACTN; j++) {
            pv[j] = prob[j] * policy;
        }

        int sum = 0;
        for (int i = 0; i < NUM_STAT; i++) {
            double mmax = -DBL_MAX;
            int ppi = pi(i);
            for (int j = 0; j < NUM_ACTN; j++) {
                if (pv[j](i) > mmax) {
                    mmax = pv[j](i);
                    pi(i) = j;
                }
            }

            sum += (ppi != pi(i));
        }
        cont = (sum != 0);
    } while (cont);

    return times-1; // last iteration is the same as previous one
}
