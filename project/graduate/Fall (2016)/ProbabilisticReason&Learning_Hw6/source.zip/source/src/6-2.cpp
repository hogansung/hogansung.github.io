#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_set>

using namespace std;

const int MAX_ITER = 256;
const int NUM_I = 267;
const int NUM_F = 23;

double calLL(vector<vector<int>>& dat_x, vector<int>& dat_y, vector<double>& prob) {
    double ret = 0;
    for (int i = 0; i < NUM_I; i++) {
        double val = 1.0;
        for (int j = 0; j < NUM_F; j++) {
            val *= pow(1-prob[j], dat_x[i][j]);
        }
        
        if (dat_y[i] == 0) {
            ret += log(val);
        } else {
            ret += log(1-val);
        }
    }
    return ret / NUM_I;
}

int calERR(vector<vector<int>>& dat_x, vector<int>& dat_y, vector<double>& prob) {
    int cnt = 0;
    for (int i = 0; i < NUM_I; i++) {
        double val = 1.0;
        for (int j = 0; j < NUM_F; j++) {
            val *= pow(1-prob[j], dat_x[i][j]);
        }
       
        if (dat_y[i] == (val >= 0.5)) {
            cnt += 1;
        }
    }
    return cnt;
}

int main() {
    vector<vector<int>> dat_x(NUM_I, vector<int>(NUM_F, 0));
    { // read x
        FILE* pf = fopen("../dat/spectX.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open x file\n");
            exit(EXIT_FAILURE);
        }

        int d;
        for (int i = 0; i < NUM_I; i++) {
            for (int j = 0; j < NUM_F; j++) {
                fscanf(pf, "%d", &d);
                dat_x[i][j] = d;
            }
        }
        
        fclose(pf);
    }

    vector<int> dat_y(NUM_I, 0);
    { // read y
        FILE* pf = fopen("../dat/spectY.txt", "r");
        if (pf == NULL) {
            fprintf(stderr, "cannot open y file\n");
            exit(EXIT_FAILURE);
        }
        
        int d;
        for (int i = 0; i < NUM_I; i++) {
            fscanf(pf, "%d", &d);
            dat_y[i] = d;
        }
        
        fclose(pf);
    }
    
    vector<double> prob(NUM_F, 1.0 / NUM_F);
    printf("Iter %d: %d %f\n", 0, 
      calERR(dat_x, dat_y, prob), calLL(dat_x, dat_y, prob));

    unordered_set<int> um;
    for (int i = 0; i <= 8; i++) {
        um.insert((1 << i));
    }

    for (int times = 1; times <= MAX_ITER; times++) {
        vector<double> nprob(NUM_F, 0);
        vector<int> cnt(NUM_F, 0); // T_i
        for (int i = 0; i < NUM_I; i++) {
            double val = 1.0;
            for (int j = 0; j < NUM_F; j++) {
                cnt[j] += dat_x[i][j];
                val *= pow(1-prob[j], dat_x[i][j]);
            }
            for (int j = 0; j < NUM_F; j++) {
                nprob[j] += dat_y[i] * dat_x[i][j] * prob[j] / (1-val);
            }
        }
        for (int j = 0; j < NUM_F; j++) {
            nprob[j] /= cnt[j];
        }
        prob = nprob;

        if (um.find(times) != um.end()) {
            printf("Iter %d: %d %f\n", times, 
              calERR(dat_x, dat_y, prob), calLL(dat_x, dat_y, prob));
        }
    }
}
