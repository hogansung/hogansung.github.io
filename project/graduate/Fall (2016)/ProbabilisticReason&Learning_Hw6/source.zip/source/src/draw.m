%% Parameters
max_iter = 10;


%% 6-3 (f)
res = figure('visible', 'off');

x1 = -2;
x2 = 1;
lst1 = [x1; zeros(max_iter, 1)];
lst2 = [x2; zeros(max_iter, 1)];
for i = 1:max_iter
    x1 = x1 - tanh(x1);
    lst1(i+1) = x1;
    x2 = x2 - tanh(x2);
    lst2(i+1) = x2;
end

plot(0:max_iter, lst1, '--ro', 0:max_iter, lst2, '--bx');
legend('x_0 = -2', 'x_0 = 1');
saveas(res, '../res/6-3-f.jpg');


%% 6-3 (g)
res = figure('visible', 'off');

x1 = -2;
x2 = 1;
lst1 = [x1; zeros(max_iter, 1)];
lst2 = [x2; zeros(max_iter, 1)];
for i = 1:max_iter
    x1 = x1 - tanh(x1) / sech(x1)^2 ;
    lst1(i+1) = x1;
    x2 = x2 - tanh(x2) / sech(x2)^2;
    lst2(i+1) = x2;
end

plot(0:max_iter, lst1, '--ro', 0:max_iter, lst2, '--bx');
legend('x_0 = -2', 'x_0 = 1');
saveas(res, '../res/6-3-g.jpg');


%% 6-3 (k)
res = figure('visible', 'off');

x1 = -2;
x2 = 1;
lst1 = [x1; zeros(max_iter, 1)];
lst2 = [x2; zeros(max_iter, 1)];
for i = 1:max_iter
    t1 = 0;
    t2 = 0;
    for j = 1:10
        t1 = t1 + tanh(x1 + 1/j);
        t2 = t2 + tanh(x2 + 1/j);
    end
    x1 = x1 - 1/10 * t1;
    lst1(i+1) = x1;
    x2 = x2 - 1/10 * t2;
    lst2(i+1) = x2;
end

fprintf('when x = %f, g(x) has minimum value %f\n', x2, log(cosh(x2)));

plot(0:max_iter, lst1, '--ro', 0:max_iter, lst2, '--bx');
legend('x_0 = -2', 'x_0 = 1');
saveas(res, '../res/6-3-k.jpg');