function [] = manipulate(bname, cname, oname)

bfile = imread(bname);
cfile = imread(cname);

[bh, bw, ~] = size(bfile);
[ch, cw, ~] = size(cfile);

ph = idivide(int32(bh-ch+1), int32(2), 'floor');
pw = idivide(int32(bw-cw+1), int32(2), 'floor');

bfile(ph:ph+ch-1, pw:pw+cw-1, :) = cfile;
imwrite(bfile, oname);

end