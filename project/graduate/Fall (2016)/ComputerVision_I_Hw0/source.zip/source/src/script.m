%% Path setting
DAT = '../dat/';
RES = '../res/';


%% Problem 1: Image Manipulation [5pts]

bnameLst = cellstr(['border1.png';'border2.png';'border3.jpg';'border4.jpg']);
cnameLst = cellstr(['center1.png';'center2.png';'center3.jpg';'center4.jpg']);

for i = 1:length(bnameLst)
    bname = strcat(DAT, bnameLst{i});
    cname = strcat(DAT, cnameLst{i});
    oname = strcat(RES, 'output', bname(end-4:end));
    manipulate(bname, cname, oname);
end



%% Problem 2:  Image Rotation [5pts]

% parameters
angleLst = [pi/2, pi, pi*3/2];
fname = strcat(DAT, 'starbucks-ring.jpg');
oname = strcat(RES, 'rotation.jpg');

res = figure('visible','off');
ffile = imread(fname);
subplot(3,3,[1:6]);
imshow(ffile);

for i = 1:length(angleLst)
    img = rotate(fname, angleLst(i));
    subplot(3,3,6+i);
    imshow(img);
end

saveas(res, oname);