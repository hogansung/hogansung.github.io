function [ret] = rotate(fname, theta)
    
ffile = imread(fname);
[h, w, d] = size(ffile);

ret = zeros(w, h, d, 'uint8');

hh = (1+h) / 2;
hw = (1+w) / 2;
rotMat = [cos(theta), sin(theta); -sin(theta), cos(theta)];

for i = 1:h
    for j = 1:w
        resMax = [i-hh, j-hw] * rotMat + [hh, hw];
        nh = int32(resMax(1,1));
        nw = int32(resMax(1,2));
        ret(nh,nw,:) = ffile(i,j,:);
    end
end

end

