# Goal
- Design a SAT solver from scratch


# Varied Solvers
## Random Solver
### Implementation
- Generate a random assignment to all variables
- Verify whether generated assignment can fulfill the given CNF or not
- If accetped, return `sat`; or resample
- If declined, generate another random assignment which is different from previous trials; if all assignments have been explored, return `unsat`
- If time is up, return `unknown`

### Command Line
- `./random input.cnf`

### Possible Output
#### `sat`
- One satisfaction is found
#### `unsat`
- No solution can be found (after fully-exploration)
#### `unknown` (with number and ratio of trials)
- Program is terminated before fully exploration (default: after 10 seconds)

### Version
#### V0.0 (October 10, 2017) [ce231824bafff30ad99e734097cbb2309721f46a]
1. Finish parsing input files in DIMACS CNF format

#### V1.0 (October 11, 2017) [1566751110de30d10e71f0d31b8ccca257f27eea]
1. Refactor `Clause` and `Solver` structure
2. Support random assignments (without duplicates)
3. Finish Solver.solve() function, so that it can return `sat`, `unsat`, or `unknown`


## DPLL Solver
### Possible Output
#### `sat`
- One satisfaction is found
#### `unsat`
- No solution can be found (after fully-exploration)
#### `unknown`
- Program is terminated before fully exploration (default: after 30 seconds)

### Command Line
- `./dpll input.cnf`

### Version
#### V0.0 (October 20, 2017) [0c20f91549ecac12a23c5788fcfe4cf3c11acb90]
1. Copy the final structure of Random Solver
2. Temporarily remove timeout feature
3. Implement DPLL algorithm with moving literals (refer to appendix for more details)

#### V1.0 (October 20, 2017) [5322fd5753e25173fa2d90a12f553c8ec7c1b8c8]
1. Finish run.py to solve SAT problems with DPLL algorithm in series
2. Add timout feature for `unknown`

#### V1.1 (October 20, 2017) [5319416e8e16a3354937240658bda1e8c114a4a1]
1. Update run.py to generate logs

#### V2.0 (October 20, 2017) [0ecfbfd2dd5af3d7f47c0d64c81f73d26cb49eb0]
1. Add backtracking feature: need not to to start over all literals when making decisions

#### V3.0 (October 20, 2017) [9530c96ae75efb2e8c66fb44a16ca3daa129d90a]
1. Skip moving variables in a clause when that clause is already satisfied


## CDCL Solver
### Possible Output
#### `sat`
- One satisfaction is found
#### `unsat`
- No solution can be found (after fully-exploration)
#### `unknown`
- Program is terminated before fully exploration (default: after 30 seconds)

### Command Line
- `./cdcl input.cnf`

### Version
#### V0.0 (November 17, 2017) [40e22503d6b217a73539d6e12cda7e2976773b8e]
1. Copy the final structure of DPLL Solver
2. Implement partial CDCL algorithm: build graphs, learn clause

#### V1.0 (November 17, 2017) [66297913cc5df5ff97eff8564b6d2bbe3ee58f3e]
1. Add specific test case for CDCL: 
    - Example input `../dat/cdcl.cnf` based on [link](https://www.slideshare.net/sakai/how-a-cdcl-sat-solver-works)
2. Temporarily disable some preprocessing features in order to verify my output
    - [Important] By doing so, some problems cannot be solved properly
3. Use a stack instead of vector to preserve dependency
    - It might solve some potential backtracking issues
4. Fix a bug in `addEdges`


# Appendix
## DPLL Implementation
### Introduction
Different from the two watch-literals method mentioned in class, I decided to use two sets to preserve the current assignment status for each clause. It will bring me one advantage and one drawback.
- Advantage
  - I no longer need to assign watch-literals randomly, which can save me a huge amount of time. It is known that re-sampling one of the valid elements in an array will take O(len(array)) time. In other words, consumption of the whole array takes O(len(array)^2) time.
- Drawback
  - Moving elements between two hash sets is costly, which suffers from a huge constant overhead.

In general, using hash sets preserve all operations being executed in O(1) time complextiy; however, the practical performance highly depends on the problem itself. For example, my implementation will be very benefitial when dealing with few clauses but each clause with many literals.

### DPLL Solver (\* means CDCL)
#### Members
- `l2v`: mapping from `literal` to `value` ([1, n] -> [-1, -n] + [1, n])
- `v2c`: mapping from `value` to `clause id` ([-1, -n] + [1, n] -> [1, m])
- `visited_by`: `clause id` is satisfied because of `literal` ([0, m-1] -> [1, n])
- `visited_v`: whether a variable has been assigned or not ([1, n] -> [0, 1])
- `variable_st`: a stack for all used variables, from old (bot) to new (top)
- `decision_st`: a stack for all decided variables, from old (bot) to new (top)
- `tbl`: a list of `Clause`
- `order`: decision order, which is pre-defined determinedly
- `index`: trace back to the position of the last decision literal in `order` when making decision
- `order_flag`: a global index for `order` array
- `* edges`: dependency of the decision level
- `* level`: decision levels for each literal
- `* cur_level`: current decision level

#### Methods
- `preprocess()`: update `v2c`, `tbl`, `order`, and `index`
-  checkSingleton(): remove literals with only one kind of value
-  checkPureLiteral(): remove last literal in each clause
- `unitAdd(value)`: call Clause.del() for +value and -value
- `unitDel(value)`: call Clause.add() for +value and -value
- `makeDecision()`: make decision based on `order`
- `recursivePropogate()`: keep propagating as many variables as possible
- `backTracking()`: roll back literal assignments till last decision; or return `UNSAT`
- `checkTimeout()`: check whether time is consumed
- `checkExhausted()`: check whether all the literals are assigned
- `* addEdges`: build dependency between two assignments
- `* learnClause`: add new clause during the learning process

### Clause
#### Members
- `id`: the identity number for the clause (0-based)
- `c_set`: current `value` set for the clause
- `r_set`: removed `value` set for the clause

#### Methods
- preprocess(value): put value into `c_set` (only executed once)
- add(value): move value from `r_set` to `c_set` (backtracking)
- del(value): move value from `r_set` to `c_set`
