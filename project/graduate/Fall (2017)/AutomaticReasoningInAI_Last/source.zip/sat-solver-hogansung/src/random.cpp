#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <unordered_set>
#include <algorithm>
#include <assert.h>

using namespace std;

const int BUF_SIZE = 100000;
const double eps = 1e-10;

int fcmp(double x, double y) {
    if (x < y - eps) {
        return -1;
    } else if (x > y + eps) {
        return +1;
    } else {
        return 0;
    }
}

struct Clause {
    Clause() {}
    Clause(vector<int>& v): vct(v) {};
    vector<int> vct; 
};

struct Solver {
    Solver() {}

    vector<int> parseLine(const char buf[], const int len, const int nv);
    void parseFile(FILE* pfile);
    void print();

    void randomAssign();
    bool checkAssign();
    bool checkSatisfaction();
    void solve();

    map<int,bool> vmap;
    vector<Clause> tbl;
    unordered_set<string> assignment_set;
    int nv;
    int nc;
};

vector<int> Solver::parseLine(const char buf[], const int len, const int nv) {
    vector<int> vct;

    char d_buf[BUF_SIZE + 10];
    int d_len = 0;
    for (int i = 0; i < len; i++) {
        if (buf[i] == '-' or
          (buf[i] >= '0' and buf[i] <= '9')) {
            d_buf[d_len++] = buf[i];
        } else {
            d_buf[d_len] = 0;

            int val = strtol(d_buf, 0, 10);
            if (val == 0) {
                return vct;
            } else {
                assert(abs(val) <= nv);

                vct.emplace_back(val);
                d_len = 0;
            }
        }
    }

    assert(false);
}

void Solver::parseFile(FILE* pfile) {
    int cnt = 0;

    char buf[BUF_SIZE + 10];
    while (fgets(buf, BUF_SIZE, pfile) != NULL) {
        int len = strlen(buf);
        if (buf[0] == '\n') {
            continue;
        } else if (buf[0] == 'c') {
            continue;    
        } else if (buf[0] == 'p') {
            sscanf(buf, "p cnf %d %d", &nv, &nc);            
        } else {
            printf("%s", buf);
            vector<int> vct = parseLine(buf, len, nv); 
            tbl.emplace_back(vct);
            cnt += 1;
        }
    }

    assert(cnt == nc);
}

void Solver::randomAssign() {
    do {
        for (int i = 0; i < nv; i++) {
            vmap[i] = rand() % 2;
        }
    } while (!checkAssign());
}

bool Solver::checkAssign() {
    string hashed_assignments;
    for (auto p : vmap) {
        hashed_assignments.push_back('0' + p.second);
    }
    
    if (assignment_set.find(hashed_assignments) == assignment_set.end()) {
        assignment_set.emplace(hashed_assignments);
        return true;
    } else {
        return false;
    }
}

bool Solver::checkSatisfaction() {
    bool suc = true;
    for (auto clause : tbl) {
        bool ssuc = false;
        for (auto val: clause.vct) {
            int literal = abs(val);
            if (val < 0) {
                ssuc |= !vmap[literal];
            } else {
                ssuc |= vmap[literal];
            }
        }
        suc &= ssuc;
    }
    return suc;
}

void Solver::solve() {
    clock_t clock_start = clock();
    while (true) {
        randomAssign();

        if (checkSatisfaction()) { // sat
            fprintf(stderr, "sat\n");
            for (int literal = 1; literal <= nv; literal++) {
                fprintf(stderr, "%d -> %d\n", literal, vmap.at(literal));
            }
            return; 
        } else { // unsat or unknown or continue
            int size = assignment_set.size();
            double ratio = size;
            for (int i = 0; i < nv; i++) {
                ratio /= 2;
            }

            if (fcmp(ratio, 1.0) == 0) { // unsat
                fprintf(stderr, "unsat\n"); 
                return;
            } else if ((clock() - clock_start) / (double) CLOCKS_PER_SEC >= 10) { // unknown
                fprintf(stderr, "unknown\n");
                fprintf(stderr, "number of trials = %d\n", size);
                fprintf(stderr, "ratio of trials = %f\n", ratio);
                return;
            }
        }
    }
}

void Solver::print() {
    for (auto clause : tbl) {
        for (auto val : clause.vct) {
            printf("%d ", val);
        }
        puts("");
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./solver input.txt\n");
        exit(EXIT_FAILURE);
    }

    FILE* pfile = fopen(argv[1], "r");
    if (pfile == NULL) {
        fprintf(stderr, "Cannot open input file.\n");
        exit(EXIT_FAILURE);
    }

    Solver solver;
    solver.parseFile(pfile);
    // solver.print();
    solver.solve();

    fclose(pfile);
}
