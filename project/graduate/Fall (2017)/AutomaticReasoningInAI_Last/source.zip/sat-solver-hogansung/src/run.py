import os
import sys
import subprocess

TARGET = 'solver'
VERSION = '0'

FD = '../dat/sat-benchmarks/petite/'
TG = '../log/%s_petite_v%s.log' % (TARGET, VERSION)

sat = []
unsat = []
timeout = []
err = []

for fname in os.listdir(FD):
    path = os.path.join(FD, fname)
    if os.path.isfile(path):
        print 'INFO: now is working on %s' % fname
        try:
            output = subprocess.check_output(['./%s' % TARGET, path, '--time', '30'], stderr=subprocess.STDOUT)
            if output == 'sat\n':
                sat.append(fname)
            elif output == 'unsat\n':
                unsat.append(fname)
            elif output == 'unknown\n':
                timeout.append(fname)
            else:
                assert False
        except Exception, e:
            err.append(fname)

with open(TG, 'w') as f:
    f.write('###############\n')
    f.write('# Satisfiable #\n')
    f.write('###############\n')
    for fname in sat:
        f.write(fname + '\n')
    f.write('\n\n')

    f.write('#################\n')
    f.write('# Unsatisfiable #\n')
    f.write('#################\n')
    for fname in unsat:
        f.write(fname + '\n')
    f.write('\n\n')
        
    f.write('###########\n')
    f.write('# Timeout #\n')
    f.write('###########\n')
    for fname in timeout:
        f.write(fname + '\n')
    f.write('\n\n')

    f.write('#########\n')
    f.write('# Error #\n')
    f.write('#########\n')
    for fname in err:
        f.write(fname + '\n')
    f.write('\n\n')
