#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <assert.h>

using namespace std;

const int DEBUG = 0;
const unsigned BUF_SIZE = 100000;

bool verbose = false;
unsigned time_limit = 0;

struct MySet {
    MySet() {}
    MySet(unsigned _n) {
        n = _n;
        idx = vector<int>(n+1, -1);
        val = vector<int>(n, 0);
        flag = 0;
    }
    void add(int value) {
        unsigned literal = abs(value);
        while (literal > n) {
            idx.push_back(-1);
            val.push_back(0);
            n += 1;
        }
        if (idx[literal] == -1) {
            idx[literal] = flag;
            val[flag++] = value; 
        }
    }
    void del(int value) {
        unsigned literal = abs(value);
        int t = idx[literal];
        assert(0 <= t and t < flag);

        idx[abs(val[flag-1])] = t;
        val[t] = val[flag-1];

        idx[literal] = -1;
        flag -= 1;
    }
    bool find(int value) {
        unsigned literal = abs(value);
        return 0 <= idx[literal] and idx[literal] < n and val[idx[literal]] == value;
    }
    int first() {
        assert(flag > 0);
        return val[0];
    }
    unsigned size() {
        return flag;
    }
    vector<int>::iterator begin() {
        return val.begin();
    }
    vector<int>::iterator end() {
        return val.begin() + flag;
    }
    vector<int> idx;
    vector<int> val;
    unsigned flag;
    unsigned n;
};

struct Clause {
    Clause() {}
    Clause(int _n) {
        c_set = MySet(_n);
        r_set = MySet(_n);
    }

    void preprocess(int value);
    void add(int value);
    void del(int value);

    int id;
    MySet c_set;
    MySet r_set;
};

struct Solver {
    Solver() { order_flag = 0; }

    vector<int> parseLine(const char buf[], const int len, const int nv);
    void parseFile(FILE* pfile);
    void debug();

    void solve();
    void preprocess();
    void checkSingleton();
    bool checkPureLiteral();

    void makeDecision();
    bool recursivePropogate();
    bool backTracking(unsigned level);
    bool checkExhausted();
    void unitAdd(int value);
    bool unitDel(int value);

    clock_t clock_start;
    bool checkTimeout();

    void printSAT();
    void printUNSAT();
    void printUNKNOWN();

    void addEdges(unsigned target, MySet& us);
    void learnClause(unsigned& bt_level, Clause& learnedClause);
    void addLearnedClause(Clause& learnedClause);

    vector<int> l2v; // literal to value (-1, +1)
    vector<MySet> v2c;
    vector<unsigned> visited_by;

    vector<unsigned> order;
    vector<unsigned> index;

    vector<int> visited_v;
    vector<unsigned> variable_vct;
    vector<unsigned> decision_vct;

    vector<vector<int>> edges;
    vector<unsigned> level;

    vector<Clause> tbl;

    /* original vector (debug only) */
    vector<vector<int>> dat;
    void verify();

    unsigned nv;
    unsigned nc;
    unsigned cc;
    unsigned order_flag;
    unsigned cur_level;
};

void Clause::preprocess(int value) {
    c_set.add(value);
}

/* move `value` from `removed` array to `current` array */
void Clause::add(int value) {
    assert(r_set.find(value));
    r_set.del(value);
    c_set.add(value);
}

/* move `value` from `current` array to `removed` array */
void Clause::del(int value) {
    assert(c_set.find(value));
    c_set.del(value);
    r_set.add(value);
}

vector<int> Solver::parseLine(const char buf[], const int len, const int nv) {
    vector<int> vct;

    char d_buf[BUF_SIZE + 10];
    int d_len = 0;
    for (int i = 0; i < len; i++) {
        if (buf[i] == '-' or
          (buf[i] >= '0' and buf[i] <= '9')) {
            d_buf[d_len++] = buf[i];
        } else if (d_len > 0) {
            d_buf[d_len] = 0;

            int value = strtol(d_buf, 0, 10);
            if (value == 0) {
                return vct;
            } else {
                assert(abs(value) <= nv);

                vct.emplace_back(value);
                d_len = 0;
            }
        }
    }

    assert(false);
}

void Solver::parseFile(FILE* pfile) {
    int cnt = 0;

    char buf[BUF_SIZE + 10];
    while (fgets(buf, BUF_SIZE, pfile) != NULL) {
        int len = strlen(buf);
        if (buf[0] == '\n') {
            continue;
        } else if (buf[0] == 'c' or 
                   buf[0] == '%' or
                   buf[0] == '0') {
            continue;    
        } else if (buf[0] == 'p') {
            sscanf(buf, "p cnf %d %d", &nv, &nc);            
            tbl = vector<Clause>(nc, Clause(nv));
            cc = nc;
        } else {
            tbl[cnt].id = cnt;
            vector<int> vct = parseLine(buf, len, nv);

            /* original array (debug only) */
            dat.emplace_back(vct);

            for (auto value : vct) {
                tbl[cnt].preprocess(value); 
            }
            cnt += 1;
        }
    }

    assert(cnt == nc);
}

void Solver::debug() {
    fprintf(stderr, "Assignments:\n");
    for (unsigned literal = 1; literal <= nv; literal++) {
        if (l2v[literal] != 0) {
            fprintf(stderr, "%d -> %d\n", literal, l2v[literal]);
        }
    }
    fprintf(stderr, "------------\n");
    for (auto& clause : tbl) {
        fprintf(stderr, "#%d\n", clause.id);
        if (visited_by[clause.id] == 0) {
            for (auto value : clause.c_set) {
                fprintf(stderr, "val = %d\n", value);
            }
            for (auto value : clause.r_set) {
                fprintf(stderr, "// val = %d\n", value);
            }
        } else {
            fprintf(stderr, "(skip)\n");
        }
        fprintf(stderr, "============\n");
    }

    for (int i = 0; i < order_flag; i++) {
        fprintf(stderr, "decision visited %d: %d\n", order[i], visited_v[order[i]]);
    }
    for (auto variable : variable_vct) {
        fprintf(stderr, "varaible visited %d: %d\n", variable, visited_v[variable]);
    }
    fprintf(stderr, "zzzz %d\n", order_flag);
}

void Solver::makeDecision() {
    unsigned literal;
    do {
        assert(order_flag < nv);
        literal = order[order_flag];
        order_flag += 1;
    } while (visited_v[literal] >= 0);

    l2v[literal] = -1;
    level[literal] = cur_level = decision_vct.size() + 1;
    visited_v[literal] = variable_vct.size();
    decision_vct.push_back(literal);
    variable_vct.push_back(literal);

    bool conflict = unitDel(-literal);
    assert(conflict == false);

    if (DEBUG >= 2) fprintf(stderr, "decision value: %d\n", -literal);
    if (DEBUG >= 3) debug();
}

// Case 1: conflict: true
// Case 2: make next decision
bool Solver::recursivePropogate() {
    bool keep;
    do {
        keep = false;
        for (int id = 0; id < cc; id++) {
            if (visited_by[id] == 0) {
                auto& clause = tbl[id];
                if (clause.c_set.size() == 1) {
                    int value = clause.c_set.first();
                    unsigned literal = abs(value);
                    
                    level[literal] = cur_level;
                    addEdges(literal, clause.r_set);

                    if (value > 0) {
                        l2v[literal] = +1;
                        visited_v[literal] = variable_vct.size();
                        variable_vct.push_back(literal);
                        if (DEBUG >= 2) fprintf(stderr, "propagate: %d (line: %d)\n", value, id);
                        if (DEBUG >= 2) {
                            for (auto v : clause.r_set) {
                                fprintf(stderr, "%d ", v);
                            }
                            fprintf(stderr, "\n");
                        }

                        bool conflict = unitDel(value);
                        if (conflict == true) {
                            return true;
                        }
                    } else {
                        l2v[literal] = -1;
                        visited_v[literal] = variable_vct.size();
                        variable_vct.push_back(literal);
                        if (DEBUG >= 2) fprintf(stderr, "propagate: %d (line: %d)\n", value, id);
                        if (DEBUG >= 2) {
                            for (auto v : clause.r_set) {
                                fprintf(stderr, "%d ", v);
                            }
                            fprintf(stderr, "\n");
                        }

                        bool conflict = unitDel(value);
                        if (conflict == true) {
                            return true;
                        }
                    }
                    keep = true;
                }
            } else {
                continue;
            }
        }
    } while (keep == true and checkTimeout() == false);
    if (DEBUG >= 2) fprintf(stderr, "leave propagation\n");
    return false;
}

bool Solver::backTracking(unsigned bt_level) {
    /* find out to-be-corrected decision */
    unsigned decision;
    do {
        if (decision_vct.size() == 0) {
            return false;
        }
        assert(decision_vct.size());
        decision = decision_vct.back(); decision_vct.pop_back();
    } while (decision_vct.size() > bt_level);

    /* roll back everything till to-be-corrected decision */
    edges[0] = vector<int>();
    unsigned literal;
    do {
        literal = variable_vct.back(); variable_vct.pop_back();
        edges[literal] = vector<int>();
        visited_v[literal] = -1;
        int value = literal * l2v[literal];
        unitAdd(value);
        l2v[literal] = 0;
        if (DEBUG >= 2) fprintf(stderr, "remove assignments: %d\n", value);
    } while (literal != decision);
    order_flag = index[decision];

    return true;
}

void Solver::unitAdd(int value) {
    unsigned literal = abs(value);

     // remove variable `+value`
    for (auto id : v2c[+value + nv]) {
        assert(visited_by[id] != 0);
        if (visited_by[id] == literal) {
            auto& clause = tbl[id]; 
            clause.add(+value);
            visited_by[id] = 0;
        }
    }
    
    // remove variable `-value`
    for (auto id : v2c[-value + nv]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            clause.add(-value);
        }
    }
}

bool Solver::unitDel(int value) {
    unsigned literal = abs(value);

    // remove variable `+value`
    for (auto id : v2c[+value + nv]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            clause.del(+value);
            visited_by[id] = literal;
        }
    }
    
    // remove variable `-value`
    bool conflict = false;
    for (auto id : v2c[-value + nv]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            assert(clause.c_set.size() > 0);
            clause.del(-value);
            if (clause.c_set.size() == 0) {
                conflict = true;
                addEdges(0, clause.r_set);

                if (DEBUG == 2) {
                    fprintf(stderr, "conflict at #%d\n", id);
                    for (auto v : clause.c_set) {
                        fprintf(stderr, "%d ", v);
                    }
                    fprintf(stderr, "\n");
                    for (auto v : clause.r_set) {
                        fprintf(stderr, "%d ", v);
                    }
                    fprintf(stderr, "\n");
                }
            }
        }
    }
    
    return conflict;
}

void Solver::checkSingleton() {
    for (unsigned literal = 1; literal <= nv; literal++) {
        if (v2c[-literal + nv].size() == 0) { // only +literal or no appearance
            l2v[literal] = +1;
            
            bool conflict = unitDel(+literal);
            assert(conflict == false);
            
            visited_v[literal] = variable_vct.size();
            variable_vct.push_back(literal);
        } else if (v2c[+literal + nv].size() == 0) { // only -literal
            l2v[literal] = -1;

            bool conflict = unitDel(-literal);
            assert(conflict == false);

            visited_v[literal] = variable_vct.size();
            variable_vct.push_back(literal);
        }
    }
}

bool Solver::checkPureLiteral() {
    return recursivePropogate();
}

bool Solver::checkExhausted() {
    /* checking varaible is more efficient */
    for (unsigned literal = 1; literal <= nv; literal++) {
        if (visited_v[literal] == -1) {
            return false; 
        }
    }
    return true;
}

bool Solver::checkTimeout() {
    return time_limit != 0 and (clock() - clock_start) / (double) CLOCKS_PER_SEC >= time_limit;
}

void Solver::solve() {
    clock_start = clock();

    preprocess();
    if (DEBUG >= 3) debug();

    // checkSingleton will never result in a conflict
    checkSingleton();
    if (DEBUG >= 3) debug();

    // checkPureLiteral might result in a conflict
    bool conflict = checkPureLiteral();
    if (conflict == true) {
        printUNSAT(); 
        return;
    }
    if (DEBUG >= 3) debug();

    // make decision
    bool exhausted = checkExhausted();
    if (exhausted == true) {
        printSAT();
        return;
    } else {
        makeDecision();
    }

    while (true) {
        if (checkTimeout() == true) {
            printUNKNOWN();
            return;
        } else {
            bool conflict = recursivePropogate();
            if (conflict == true) {
                unsigned bt_level;
                Clause learnedClause(nv);
                learnClause(bt_level, learnedClause);

                if (DEBUG >= 2) fprintf(stderr, "Conflict!\n");
                bool ret = backTracking(bt_level);
                if (ret == false) {
                    printUNSAT();
                    return;
                }
                if (DEBUG >= 3) debug();
                if (DEBUG >= 2) fprintf(stderr, "Finish backtracking\n");

                addLearnedClause(learnedClause);
                cur_level = bt_level;
                if (DEBUG >= 3) debug();

                //makeDecision();
            } else {
                bool exhausted = checkExhausted();
                if (exhausted == true) {
                    printSAT();
                    return;
                } else {
                    makeDecision();
                }
            }
        }
    }
}

void Solver::addLearnedClause(Clause& learnedClause) {
    // update v2c & clauses
    for (auto value : learnedClause.c_set) {
        v2c[value + nv].add(learnedClause.id);
    }

    for (auto variable : variable_vct) {
        int value = -variable * l2v[variable];
        if (learnedClause.c_set.find(value)) {
            learnedClause.c_set.del(value);
            learnedClause.r_set.add(value);
        }
    }

    tbl.emplace_back(learnedClause);
    visited_by.push_back(0);
    cc += 1;
}

void Solver::preprocess() {
    l2v = vector<int>(nv+1, 0);

    // hack: the size of MySet might get larger
    v2c = vector<MySet>(2 * nv + 1, MySet(nc));
    for (auto& clause : tbl) {
        for (auto value : clause.c_set) {
            v2c[value + nv].add(clause.id);
        }
    }

    // decide orders for decision
    for (unsigned literal = 1; literal <= nv; literal++) {
        order.push_back(literal);
    }
    random_shuffle(order.begin(), order.end());

    // trace back index
    index = vector<unsigned>(nv+1, 0); 
    for (int i = 0; i < nv; i++) {
        index[order[i]] = i;  
    }

    // initialize for cdcl: notice: edges[0] is designed for the confliction
    edges = vector<vector<int>>(nv+1, vector<int>());
    level = vector<unsigned>(nv+1, 0);

    // initialize visited array
    visited_by = vector<unsigned>(nc, 0);   // index: 0-based; value: 1-based; default: 0
    visited_v = vector<int>(nv+1, -1);  // 1-based
}

void Solver::verify() {
    bool suc = true;
    for (auto vct : dat) {
        bool ssuc = false;
        for (auto value : vct) {
            unsigned literal = abs(value);
            ssuc |= (value * l2v[literal] > 0);
        }

        if (ssuc == false) {
            for (auto value : vct) {
                fprintf(stderr, "%d ", value);
            }
            fprintf(stderr, "\n");
        }

        suc &= ssuc;
    }
    assert(suc == true);
}

void Solver::printSAT() {
    fprintf(stdout, "sat\n");
    if (DEBUG >= 2) {
        fprintf(stderr, "final assignments:\n");
        for (unsigned literal = 1; literal <= nv; literal++) {
            fprintf(stderr, "%d -> %d\n", literal, l2v[literal]);
        }
    }
    if (verbose == true) {
        for (unsigned literal = 1; literal <= nv; literal++) {
            int value = literal * l2v[literal];
            fprintf(stdout, "%d ", value);
        }
        fprintf(stdout, "\n");
    }

    if (DEBUG >= 1) verify();
    if (DEBUG >= 2) fprintf(stderr, "final verification\n");
}

void Solver::printUNSAT() {
    fprintf(stdout, "unsat\n");
    if (verbose == true) {
        if (cc > nc) {
            for (auto v : tbl[cc-1].r_set) {
                fprintf(stdout, "%d ", v); 
            }
            fprintf(stdout, "\n");
        } else {
            fprintf(stdout, "No learned clause\n");
        }
    }
}

void Solver::printUNKNOWN() {
    fprintf(stdout, "unknown\n");
    if (verbose == true) {
        for (unsigned literal = 1; literal <= nv; literal++) {
            int value = literal * l2v[literal];
            if (value != 0) {
                fprintf(stdout, "%d ", value);
            }
        }
        fprintf(stdout, "\n");
    }
}

void Solver::addEdges(unsigned u, MySet& us) {
    for (auto v : us) {
        edges[u].emplace_back(abs(v));
    }
}

void Solver::learnClause(unsigned& bt_level, Clause& learnedClause) {
    vector<bool> vis(nv+1, false);

    learnedClause.id = cc;
    bt_level = 0;
    int num_cur_level = 0;
    
    queue<unsigned> q;
    for (auto v : edges[0]) {
        if (DEBUG >= 2) fprintf(stderr, "%d->%d: %d %d\n", 0, v, level[v], visited_v[v]);
        if (vis[v] == false) {
            vis[v] = true;
            q.emplace(v);
            if (level[v] == cur_level) {
                num_cur_level += 1;
            } else {
                bt_level = max(bt_level, level[v]);
            }
        }
    }
    assert(q.size());

    while (q.size()) {
        unsigned u = q.front(); q.pop();
        if (edges[u].size() == 0) { // decision node
            int value = l2v[u] * u;
            learnedClause.preprocess(-value);
        } else {
            if (level[u] == cur_level) {
                num_cur_level -= 1;
            }
            for (auto v : edges[u]) {
                if (DEBUG >= 2) fprintf(stderr, "%d->%d: %d %d\n", u, v, level[v], visited_v[v]);
                if (vis[v] == false) {
                    vis[v] = true;
                    q.emplace(v);
                    if (level[v] == cur_level) {
                        num_cur_level += 1;
                    } else {
                        bt_level = max(bt_level, level[v]);
                    }
                }
            }
        }

        if (num_cur_level == 1) {
            break;
        }
    }
    assert(num_cur_level == 1);

    if (DEBUG >= 2) fprintf(stderr, "Level of confliction: %u\n", cur_level);
    if (DEBUG >= 2) fprintf(stderr, "Learned clauses:");
    while (q.size()) {
        unsigned u = q.front(); q.pop();
        int value = l2v[u] * u;
        learnedClause.preprocess(-value);
    }

    if (DEBUG == 1) {
        for (auto v : learnedClause.c_set) {
            fprintf(stderr, "%d ", v);
        }
    }
    if (DEBUG >= 1) fprintf(stderr, "\n");

    if (DEBUG >= 2) fprintf(stderr, "Returned to decision level: %u\n", bt_level);
}

void printHelp() {
    fprintf(stderr, "Usage: ./solver filename [--time t] [--verbose]");
}

int main(int argc, char* argv[]) {
    srand(0);

    if (argc < 2) {
        printHelp();
        exit(EXIT_FAILURE);
    } else {
        for (int i = 2; i < argc; i++) {
            if (argv[i] == string("--time")) {
                time_limit = strtol(argv[i+1], 0, 10);
                assert(time_limit > 0);
                i += 1; 
            } else if (argv[i] == string("--verbose")) {
                verbose = true; 
            } else {
                printHelp();
                exit(EXIT_FAILURE);
            }
        }
        
        FILE* pfile = fopen(argv[1], "r");
        if (pfile == NULL) {
            fprintf(stderr, "Cannot open input file.\n");
            exit(EXIT_FAILURE);
        }

        Solver solver;
        solver.parseFile(pfile);
        solver.solve();

        fclose(pfile);
    }
}
