#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <map>
#include <stack>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <assert.h>

using namespace std;

const bool DEBUG = false;
const int BUF_SIZE = 100000;
const int TIME_LIMIT = 30;

struct Clause {
    Clause() {}

    void preprocess(int value);
    void add(int value);
    void del(int value);

    int id;
    unordered_set<int> c_set;
    unordered_set<int> r_set;
};

struct Solver {
    Solver() { order_flag = 0; }

    vector<int> parseLine(const char buf[], const int len, const int nv);
    void parseFile(FILE* pfile);
    void debug();

    void solve();
    void preprocess();
    void checkSingleton();
    bool checkPureLiteral();

    void makeDecision();
    bool recursivePropogate();
    bool backTracking();
    bool checkExhausted();
    void unitAdd(int value);
    bool unitDel(int value);

    clock_t clock_start;
    bool checkTimeout();

    void printSAT();
    void printUNSAT();
    void printUNKNOWN();

    unordered_map<unsigned,int> l2v; // literal to value (-1, +1)
    unordered_map<int,unordered_set<unsigned>> v2c;
    vector<unsigned> visited_by;

    vector<unsigned> order;
    vector<unsigned> index;

    vector<bool> visited_v;
    stack<unsigned> variable_st;
    stack<unsigned> decision_st;

    vector<Clause> tbl;

    /* original vector (debug only) */
    vector<vector<int>> dat;
    void verify();

    int nv;
    int nc;
    int order_flag;
};

void Clause::preprocess(int value) {
    c_set.insert(value);
}

/* move `value` from `removed` array to `current` array */
void Clause::add(int value) {
    assert(r_set.find(value) != r_set.end());
    r_set.erase(value);
    c_set.insert(value);
}

/* move `value` from `current` array to `removed` array */
void Clause::del(int value) {
    assert(c_set.find(value) != c_set.end());
    c_set.erase(value);
    r_set.insert(value);
}

vector<int> Solver::parseLine(const char buf[], const int len, const int nv) {
    vector<int> vct;

    char d_buf[BUF_SIZE + 10];
    int d_len = 0;
    for (int i = 0; i < len; i++) {
        if (buf[i] == '-' or
          (buf[i] >= '0' and buf[i] <= '9')) {
            d_buf[d_len++] = buf[i];
        } else {
            d_buf[d_len] = 0;

            int value = strtol(d_buf, 0, 10);
            if (value == 0) {
                return vct;
            } else {
                assert(abs(value) <= nv);

                vct.emplace_back(value);
                d_len = 0;
            }
        }
    }

    assert(false);
}

void Solver::parseFile(FILE* pfile) {
    int cnt = 0;

    char buf[BUF_SIZE + 10];
    while (fgets(buf, BUF_SIZE, pfile) != NULL) {
        int len = strlen(buf);
        if (buf[0] == '\n') {
            continue;
        } else if (buf[0] == 'c') {
            continue;    
        } else if (buf[0] == 'p') {
            sscanf(buf, "p cnf %d %d", &nv, &nc);            
            tbl = vector<Clause>(nc, Clause());
        } else {
            tbl[cnt].id = cnt;
            vector<int> vct = parseLine(buf, len, nv);

            /* original array (debug only) */
            dat.emplace_back(vct);

            for (auto value : vct) {
                tbl[cnt].preprocess(value); 
            }
            cnt += 1;
        }
    }

    assert(cnt == nc);
}

void Solver::debug() {
    fprintf(stderr, "Assignments:\n");
    for (auto p : l2v) {
        fprintf(stderr, "%d -> %d\n", p.first, p.second);
    }
    fprintf(stderr, "------------\n");
    for (auto& clause : tbl) {
        fprintf(stderr, "#%d\n", clause.id);
        if (visited_by[clause.id] == 0) {
            for (auto value : clause.c_set) {
                fprintf(stderr, "val = %d\n", value);
            }
            for (auto value : clause.r_set) {
                fprintf(stderr, "// val = %d\n", value);
            }
        } else {
            fprintf(stderr, "(skip)\n");
        }
        fprintf(stderr, "============\n");
    }

    for (int i = 0; i < order_flag; i++) {
        fprintf(stderr, "visited %d: %d\n", order[i], (int)visited_v[order[i]]);
    }
    fprintf(stderr, "zzzz %d\n", order_flag);
}

void Solver::makeDecision() {
    unsigned literal;
    do {
        assert(order_flag < nv);
        literal = order[order_flag];
        order_flag += 1;
    } while (visited_v[literal] == true);

    l2v[literal] = -1;
    decision_st.push(literal);
    variable_st.push(literal);
    visited_v[literal] = true;

    bool conflict = unitDel(-literal);
    assert(conflict == false);

    if (DEBUG) fprintf(stderr, "decision value: %d\n", -literal);
    if (DEBUG) debug();
}

// Case 1: conflict: true
// Case 2: make next decision
bool Solver::recursivePropogate() {
    bool keep;
    do {
        keep = false;
        for (int id = 0; id < nc; id++) {
            if (visited_by[id] == 0) {
                auto& clause = tbl[id];
                if (clause.c_set.size() == 1) {
                    int value = (*clause.c_set.begin());
                    unsigned literal = abs(value);
                    if (value > 0) {
                        l2v[literal] = +1;
                        variable_st.push(literal);
                        visited_v[literal] = true;
                        if (DEBUG) fprintf(stderr, "propagate: %d (line: %d)\n", value, id);

                        bool conflict = unitDel(value);
                        if (conflict == true) {
                            return true;
                        }
                    } else {
                        l2v[literal] = -1;
                        variable_st.push(literal);
                        visited_v[literal] = true;
                        if (DEBUG) fprintf(stderr, "propagate: %d (line: %d)\n", value, id);

                        bool conflict = unitDel(value);
                        if (conflict == true) {
                            return true;
                        }
                    }
                    keep = true;
                }
            } else {
                continue;
            }
        }
    } while (keep == true and checkTimeout() == false);
    if (DEBUG) fprintf(stderr, "leave propagation\n");
    return false;
}

bool Solver::backTracking() {
    /* find out to-be-corrected decision */
    unsigned decision;
    do {
        if (decision_st.size() == 0) {
            return false;
        }
        decision = decision_st.top(); decision_st.pop();
    } while (l2v[decision] == +1);

    /* roll back everything till to-be-corrected decision */
    unsigned literal;
    do {
        literal = variable_st.top(); variable_st.pop();
        visited_v[literal] = false;
        int value = literal * l2v[literal];
        unitAdd(value);
        l2v.erase(literal);
        if (DEBUG) fprintf(stderr, "remove assignments: %d\n", value);
    } while (literal != decision);
    if (DEBUG) debug();

    /* switch to-be-corrected decision */
    l2v[decision] = +1;
    order_flag = index[decision] + 1;

    decision_st.push(decision);
    variable_st.push(decision);
    visited_v[decision] = true;

    bool conflict = unitDel(+decision);
    assert(conflict == false);
    if (DEBUG) fprintf(stderr, "altered decision value: %d\n", decision);
    if (DEBUG) debug();

    return true;
}

void Solver::unitAdd(int value) {
    unsigned literal = abs(value);

     // remove variable `+value`
    for (auto id : v2c[+value]) {
        assert(visited_by[id] != 0);
        if (visited_by[id] == literal) {
            auto& clause = tbl[id]; 
            clause.add(+value);
            visited_by[id] = 0;
        }
    }
    
    // remove variable `-value`
    for (auto id : v2c[-value]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            clause.add(-value);
        }
    }
}

bool Solver::unitDel(int value) {
    unsigned literal = abs(value);

    // remove variable `+value`
    for (auto id : v2c[+value]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            clause.del(+value);
            visited_by[id] = literal;
        }
    }
    
    // remove variable `-value`
    bool conflict = false;
    for (auto id : v2c[-value]) {
        if (visited_by[id] == 0) {
            auto& clause = tbl[id];  
            if (clause.c_set.size() == 1) {
                conflict = true;
            }
            clause.del(-value);
        }
    }
    return conflict;
}

void Solver::checkSingleton() {
    for (unsigned literal = 1; literal <= nv; literal++) {
        if (v2c[-literal].size() == 0) { // only +literal or no appearance
            l2v[literal] = +1;
            
            bool conflict = unitDel(+literal);
            assert(conflict == false);
            
            visited_v[literal] = true;
            variable_st.push(literal);
        } else if (v2c[+literal].size() == 0) { // only -literal
            l2v[literal] = -1;

            bool conflict = unitDel(-literal);
            assert(conflict == false);

            visited_v[literal] = true;
            variable_st.push(literal);
        }
    }
}

bool Solver::checkPureLiteral() {
    return recursivePropogate();
}

bool Solver::checkExhausted() {
    /* checking varaible is more efficient */
    for (unsigned literal = 1; literal <= nv; literal++) {
        if (visited_v[literal] == false) {
            return false; 
        }
    }
    return true;
}

bool Solver::checkTimeout() {
    return(clock() - clock_start) / (double) CLOCKS_PER_SEC >= TIME_LIMIT;
}

void Solver::solve() {
    clock_start = clock();

    preprocess();
    if (DEBUG) debug();

    // checkSingleton will never result in a conflict
    checkSingleton();
    if (DEBUG) debug();

    // checkPureLiteral might result in a conflict
    bool conflict = checkPureLiteral();
    if (conflict == true) {
        printUNSAT(); 
        return;
    }
    if (DEBUG) debug();

    // make decision
    bool exhausted = checkExhausted();
    if (exhausted == true) {
        printSAT();
        return;
    } else {
        makeDecision();
    }

    while (true) {
        if (checkTimeout() == true) {
            printUNKNOWN();
            return;
        } else {
            bool conflict = recursivePropogate();
            if (conflict == true) {
                if (DEBUG) fprintf(stderr, "Conflict!\n");
                bool ret = backTracking();
                if (ret == false) {
                    printUNSAT();
                    return;
                }
                if (DEBUG) debug();
                if (DEBUG) fprintf(stderr, "Finish backtracking\n");
            } else {
                bool exhausted = checkExhausted();
                if (exhausted == true) {
                    printSAT();
                    return;
                } else {
                    makeDecision();
                }
            }
        }
    }
}

void Solver::preprocess() {
    // update v2c & clauses
    for (auto& clause : tbl) {
        for (auto value : clause.c_set) {
            v2c[value].emplace(clause.id);
        }
    }

    // decide orders for decision
    for (unsigned literal = 1; literal <= nv; literal++) {
        order.push_back(literal);
    }
    random_shuffle(order.begin(), order.end());
    
    // trace back index
    index = vector<unsigned>(nv+1, 0); 
    for (int i = 0; i < nv; i++) {
        index[order[i]] = i;  
    }

    // initialize visited array
    visited_by = vector<unsigned>(nc, 0);   // index: 0-based; value: 1-based; default: 0
    visited_v = vector<bool>(nv+1, false);  // 1-based
}

void Solver::verify() {
    bool suc = true;
    for (auto vct : dat) {
        bool ssuc = false;
        for (auto value : vct) {
            unsigned literal = abs(value);
            ssuc |= (value * l2v.at(literal) > 0);
        }

        if (ssuc == false) {
            for (auto value : vct) {
                fprintf(stderr, "%d ", value);
            }
            fprintf(stderr, "\n");
        }

        suc &= ssuc;
    }
    assert(suc == true);
}

void Solver::printSAT() {
    fprintf(stdout, "sat\n");
    if (DEBUG) {
        fprintf(stderr, "final assignments:\n");
        for (unsigned literal = 1; literal <= nv; literal++) {
            fprintf(stderr, "%d -> %d\n", literal, l2v.at(literal));
        }
    }

    if (DEBUG) verify();
    if (DEBUG) fprintf(stderr, "final verification\n");
}

void Solver::printUNSAT() {
    fprintf(stdout, "unsat\n");
}

void Solver::printUNKNOWN() {
    fprintf(stdout, "unknown\n");
}

int main(int argc, char* argv[]) {
    srand(0);

    if (argc != 2) {
        fprintf(stderr, "Usage: ./solver input.txt\n");
        exit(EXIT_FAILURE);
    }

    FILE* pfile = fopen(argv[1], "r");
    if (pfile == NULL) {
        fprintf(stderr, "Cannot open input file.\n");
        exit(EXIT_FAILURE);
    }

    Solver solver;
    solver.parseFile(pfile);
    solver.solve();

    /*
    vector<int> vct = {-1, +1, -1, -1, +1, +1, +1, +1, -1, -1,
                       -1, -1, +1, +1, +1, +1, +1, -1, +1, -1};
    for (unsigned literal = 1; literal <= solver.nv; literal++) {
        solver.l2v[literal] = vct[literal-1];
    }
    solver.verify();
    */

    fclose(pfile);
}
