
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from math import sqrt, log

from sklearn.preprocessing import MinMaxScaler


# In[2]:


# read files
tn_data = pd.read_csv('../dat/train.csv', index_col='Id')
tt_data = pd.read_csv('../dat/test.csv', index_col='Id')

# split x & y
tn_y = tn_data['SalePrice']
tn_x = tn_data.drop(['SalePrice'], axis=1)
tt_x = tt_data

# filter out NA columns
tn_null = tn_x.isnull().any()
tt_null = tt_x.isnull().any()
na_filter = ~(tn_null | tt_null)
tn_x = tn_x.loc[:, na_filter]
tt_x = tt_x.loc[:, na_filter]

# split numerical & categorical features
ncol = ['LotArea', 'OverallQual', 'OverallCond', 'YearBuilt', 'YearRemodAdd', '1stFlrSF', '2ndFlrSF', 'LowQualFinSF', 'GrLivArea', 'FullBath', 'HalfBath', 'BedroomAbvGr', 'KitchenAbvGr', 'TotRmsAbvGrd', 'Fireplaces', 'WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch', 'PoolArea', 'MiscVal', 'MoSold', 'YrSold']
tn_nx = tn_x[ncol]
tn_cx = tn_x.drop(ncol, axis=1)
tt_nx = tt_x[ncol]
tt_cx = tt_x.drop(ncol, axis=1)

# join numerical/categorical tn & tt
cx = pd.concat([tn_cx, tt_cx], axis=0)
nx = pd.concat([tn_nx, tt_nx], axis=0)

# scale numerical features
scaler = MinMaxScaler()
nx = pd.DataFrame(scaler.fit_transform(nx), index=nx.index.values, columns=nx.columns.values)

# split numerical tn & tt
tn_nx = nx.iloc[:tn_nx.shape[0],]
tt_nx = nx.iloc[tn_nx.shape[0]:,]

# MSSubClass as a categorical feature
cx['MSSubClass'] = cx['MSSubClass'].astype('object')

# one-hot-encoding categorical features
cx = pd.get_dummies(cx)

# split categorical tn & tt
tn_cx = cx.iloc[:tn_nx.shape[0],]
tt_cx = cx.iloc[tn_nx.shape[0]:,]

# join numerical & categorical features
tn_x = pd.concat([tn_nx, tn_cx], axis=1)
tt_x = pd.concat([tt_nx, tt_cx], axis=1)


# In[3]:


from sklearn.model_selection import ShuffleSplit
# split stn & stt
rs = ShuffleSplit(n_splits=1, test_size=.5, random_state=514)
stn_idx, stt_idx = next(rs.split(tn_x),None)
stn_x = tn_x.iloc[stn_idx,]
stt_x = tn_x.iloc[stt_idx,]
stn_ly = tn_y.iloc[stn_idx,].apply(log)
stt_ly = tn_y.iloc[stt_idx,].apply(log)


# In[4]:


def adjust_pred(p):
    return map(lambda x: log(x) if x > 0 else 0, p)


# In[5]:


from sklearn.linear_model import LinearRegression
from sklearn.svm import LinearSVR, SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error

model_lst = {'LinearRegression': LinearRegression(),              'RandomForestRegressor': RandomForestRegressor(max_depth=10, random_state=514),              'GradientBoostingRegressor': GradientBoostingRegressor(n_estimators=500, max_depth=3, random_state=514),              'MLPRegressor': MLPRegressor(hidden_layer_sizes=(5,), solver='adam', learning_rate='adaptive',                           learning_rate_init=0.03, max_iter=10000, random_state=514)}

for name, model in model_lst.items():
    model.fit(stn_x, stn_ly)

    stn_lp = model.predict(stn_x)
    stt_lp = model.predict(stt_x)
    
    stn_rmse = sqrt(mean_squared_error(stn_ly, stn_lp))
    stt_rmse = sqrt(mean_squared_error(stt_ly, stt_lp))
    print '%s: stn(%f), stt(%f)' % (name, stn_rmse, stt_rmse)

