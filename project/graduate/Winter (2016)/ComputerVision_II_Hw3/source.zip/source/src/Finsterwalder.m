function XcLst = Finsterwalder(nx, Xw)
    assert(size(Xw,1) == 3 && size(nx,1) == 3);
    
    % Normalize nx by nx(:,3)
    nx = nx ./ nx(:,3);
    
    % Calculate distance
    a = norm(Xw(2,:) - Xw(3,:));
    b = norm(Xw(1,:) - Xw(3,:));
    c = norm(Xw(1,:) - Xw(2,:));
    
    % Calculate unit vector
    j1 = 1/sqrt(nx(1,1)^2 + nx(1,2)^2 + 1) * nx(1,:);
    j2 = 1/sqrt(nx(2,1)^2 + nx(2,2)^2 + 1) * nx(2,:);
    j3 = 1/sqrt(nx(3,1)^2 + nx(3,2)^2 + 1) * nx(3,:);
    
    % Calculate angles
    alpha = acos(dot(j2,j3));
    beta =  acos(dot(j1,j3));
    gamma = acos(dot(j1,j2));
    
    % solve lambda (4 solutions)
    G = c^2 * (c^2*sin(beta)^2 - b^2*sin(gamma)^2);
    H = b^2 * (b^2-a^2) * sin(gamma)^2 ...
        + c^2 * (c^2 + 2*a^2) * sin(beta)^2 ...
        + 2*b^2*c^2 * (-1 + cos(alpha)*cos(beta)*cos(gamma));
    I = b^2 * (b^2-c^2) * sin(alpha)^2 ...
        + a^2 * (a^2 + 2*c^2) * sin(beta)^2 ...
        + 2*a^2*b^2 * (-1 + cos(alpha)*cos(beta)*cos(gamma));
    J = a^2 * (a^2*sin(beta)^2 - b^2*sin(alpha)^2);
    r = roots([G, H, I, J]);
    assert(size(r,1) == 3);
    
    % Choose a lambda \in R
    tag = 0;
    for i = 1:3
        if isreal(r(i))
            tag = i;
            break;
        end
    end
    assert(tag ~= 0);
    lambda = r(tag);
    
    % Solve for p, q
    A = 1 + lambda;
    B = -cos(alpha);
    C = (b^2-a^2)/(b^2) - lambda*c^2/b^2;
    D = -lambda * cos(gamma);
    E = ((a^2/b^2) + lambda*c^2/b^2) * cos(beta);
    F = -a^2/b^2 + lambda * ((b^2-c^2)/b^2);
    p = sqrt(B^2 - A*C);
    q = sign(B*E - C*D) * sqrt(E^2 - C*F);
    
    % Solve for u, v
    uvLst = [];
    mLst = [(-B+p)/C, (-B-p)/C];
    nLst = [(-E+q)/C, (-E-q)/C];
    for i = 1:2
        m = mLst(i);
        n = nLst(i);
        AA = b^2 - m^2 * c^2;
        BB = c^2*(cos(beta)-n)*m - b^2*cos(gamma);
        CC = -c^2*n^2 + 2*c^2*n*cos(beta) + b^2 - c^2;
        
        u_large = -sign(BB)/AA * (abs(BB) + sqrt(BB^2-AA*CC));
        v_large = u_large*m + n;
        if isreal(u_large) && isreal(v_large)
            uvLst = [uvLst; [u_large, v_large]];
        end
        
        u_small = CC / (AA*u_large);
        v_small = u_small*m + n;
        if isreal(u_small) && isreal(v_small)
            uvLst = [uvLst; [u_small, v_small]];
        end
    end
    
    % Calculate Xc
    XcLst = {};
    for i = 1:size(uvLst,1)
        u = uvLst(i,1);
        v = uvLst(i,2);
        s1 = sqrt(c^2 / (1 + u^2 - 2*u*cos(gamma)));
        s2 = u * s1;
        s3 = v * s1;
        points = [s1*j1; s2*j2; s3*j3];
        
        varXc = var(points);
        varXw = var(Xw);
        points = points * sqrt(sum(varXw) / sum(varXc));
        points = points ./ sign(points(:,3));

        XcLst{i} = points;
    end
end
