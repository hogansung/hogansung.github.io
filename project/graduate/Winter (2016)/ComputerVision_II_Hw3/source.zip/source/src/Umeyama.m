function [status, R, t] = Umeyama(Xw, Xc)
    assert(size(Xw,1) == size(Xc,1));
    
    meanXw = mean(Xw);
    meanXc = mean(Xc);
    covXwXc = zeros(3,3);
    for i = 1:size(Xw,1)
        covXwXc = covXwXc + (Xc(i,:)-meanXc)' * (Xw(i,:)-meanXw);
    end
    covXwXc = covXwXc / size(Xw,1);
    
    [U, ~, V] = svd(covXwXc);
    
    if rank(covXwXc) == 1
        status = 0;
        R = zeros(3,3);
        t = zeros(3,1);
    else
        status = 1;
        if rank(covXwXc) == 3
            S = eye(3);
            if det(covXwXc) < 0
                S(3,3) = -1;    
            end
        else
            S = eye(3);
            if det(U) * det(V) < 0
                S(3,3) = -1;
            end
        end
        R = U * S * V';
        t = meanXc' - R * meanXw';
    end      
end
