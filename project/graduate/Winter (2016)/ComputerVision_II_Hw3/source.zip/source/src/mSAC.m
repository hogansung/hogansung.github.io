function [best_R, best_t, best_bmap, MAX_TRIALS] = mSAC(hx, hX, K)
    % Parameters
    CONSENSUS_MIN_COST = Inf;
    MAX_TRIALS = Inf;
    THRESHOLD = 1;
    TOLERANCE = chi2inv(0.95,2);
    PROBABILITY = 0.99;
    
    % Initialize return values
    best_R = zeros(3,3);
    best_t = zeros(3,1);
    best_bmap = false(size(hx,1),1);

    % Normalize x
    nx = (K\hx')';
    
    % Dehomogenize
    Xw = hX(:,1:3);
    
    trials = 0;
    s = RandStream('mt19937ar','Seed',514);
    while trials < MAX_TRIALS && CONSENSUS_MIN_COST > THRESHOLD
        trials = trials + 1;
        
        % Random 3 numbers
        idx = randperm(s, size(nx,1));
        
        % Find Camera Coordinate
        XcLst = Finsterwalder(nx(idx(1:3),:), Xw(idx(1:3),:)); % cell

        % Enuerate all pairs
        sbest_cost = Inf;
        for i = 1:length(XcLst)
            % Find R, t
            [status, R, t] = Umeyama(Xw(idx(1:3),:), XcLst{i});
            
            if status == 1
                % Calculate error
                error = calError(hx, hX, K, R, t);

                % Calculate cost
                cost = calCost(error, TOLERANCE);
                
                % Preserve the best model
                if cost < sbest_cost
                    sbest_R = R;
                    sbest_t = t;
                    sbest_bmap = error < TOLERANCE;
                    sbest_n_in = sum(sbest_bmap);
                    sbest_cost = cost;
                end
            end
        end
        
        if sbest_cost < CONSENSUS_MIN_COST
            CONSENSUS_MIN_COST = sbest_cost;
            best_R = sbest_R;
            best_t = sbest_t;
            best_bmap = sbest_bmap;
            
            w = sbest_n_in / size(nx,1);
            MAX_TRIALS = log(1-PROBABILITY) / log(1-w^3);
        end
    end
end

function error = calError(hx, hX, K, R, t)
    px = (K * [R, t] * hX')';
    px = px ./ px(:,3);
    diff = hx(:,1:2) - px(:,1:2);
    error = sum(diff.^2,2);
end

function cost = calCost(error, TOLERANCE)
    cost = sum(min(error, TOLERANCE));
end
