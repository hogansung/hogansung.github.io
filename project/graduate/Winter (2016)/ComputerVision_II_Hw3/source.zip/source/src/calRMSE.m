function RMSE = calRMSE(hx, hX, K, R, t)
    px = (K * [R, t] * hX')';
    px = px ./ px(:,3);
    diff = hx(:,1:2) - px(:,1:2);
    RMSE = sqrt(mean(sum(diff.^2,2)));
end