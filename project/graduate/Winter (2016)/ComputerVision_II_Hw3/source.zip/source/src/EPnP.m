function [R, t] = EPnP(hx, hX, K)
    % Find World Control Points
    [cw1, cw2, cw3, cw4] = calWorldControlPoints(hX);

    % Find Alpha
    alpha = calAlpha(hX, cw1, cw2, cw3, cw4);

    % Find Camera Control Points
    [cc1, cc2, cc3, cc4] = calCameraControlPoints(alpha, hx, K);

    % Find Camera Points
    Xc = calCameraPoints(hX, cc1, cc2, cc3, cc4, alpha);

    % Find out R, t
    [status, R, t] = Umeyama(hX(:,1:3), Xc);
    assert(status == 1);
end

function [cw1, cw2, cw3, cw4] = calWorldControlPoints(hX)
    % Dehomogenize
    Xw = hX(:,1:3);

    meanX = mean(Xw);
    varXw = var(Xw);
    covXw = cov(Xw);
    sX = sqrt(sum(varXw) / 3);

    [~, ~, V] = svd(covXw);

    cw1 = meanX;
    cw2 = sX * V(:,1)' + meanX;
    cw3 = sX * V(:,2)' + meanX;
    cw4 = sX * V(:,3)' + meanX;
end

function alpha = calAlpha(hX, cw1, cw2, cw3, cw4)
    % Dehomogenize
    Xw = hX(:,1:3);

    alpha = zeros(size(Xw,1),4);
    A = [cw2-cw1; cw3-cw1; cw4-cw1];
    b = Xw - cw1;
    alpha(:,2:4) = b/A;
    alpha(:,1) = 1 - sum(alpha, 2);
end

function [cc1, cc2, cc3, cc4] = calCameraControlPoints(alpha, hx, K)
    % Normalize x
    nx = (K\hx')';
    
    % Normalize nx by nx(:,3)
    nx = nx ./ nx(:,3);

    A = zeros(2*size(nx,1), 12);
    for i = 1:size(nx,1)
        A(2*i-1,:) = [alpha(i,1), 0, -alpha(i,1) * nx(i,1), ...
                      alpha(i,2), 0, -alpha(i,2) * nx(i,1), ...
                      alpha(i,3), 0, -alpha(i,3) * nx(i,1), ...
                      alpha(i,4), 0, -alpha(i,4) * nx(i,1)];
        A(2*i,:)   = [0, alpha(i,1), -alpha(i,1) * nx(i,2), ...
                      0, alpha(i,2), -alpha(i,2) * nx(i,2), ...
                      0, alpha(i,3), -alpha(i,3) * nx(i,2), ...
                      0, alpha(i,4), -alpha(i,4) * nx(i,2)];
    end
    
    % Solve for cc1 to cc4
    [~, ~, V] = svd(A, 'econ');
    cc1 = V(1:3,end);
    cc2 = V(4:6,end);
    cc3 = V(7:9,end);
    cc4 = V(10:12,end);
end

function Xc = calCameraPoints(hX, cc1, cc2, cc3, cc4, alpha)
    % Dehomogenize
    Xw = hX(:,1:3);

    Xc = zeros(size(Xw,1), 3);
    for i = 1:size(Xw,1)
        Xc(i,:) = alpha(i,1) * cc1 + alpha(i,2) * cc2 ...
            + alpha(i,3) * cc3 + alpha(i,4) * cc4;
    end
    
    varXw = var(Xw);
    varXc = var(Xc);
    beta = sqrt(sum(varXw)/sum(varXc));
    Xc = Xc * beta;
    Xc = Xc ./ sign(Xc(:,3));
end
