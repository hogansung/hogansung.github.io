function [R, t, W, log] = LM_c(hx, hX, K, R, t)
    % Normalize x
    nx = (K\hx')';

    % Normalize nx by nx(:,3)
    nx = nx ./ nx(:,3);

    % Dehomogenize
    Xw = hX(:,1:3);

    % Covariance Matrix
    Z = zeros(2*size(hx,1));
    invK = inv(K);
    c = invK(1:2,1:2);
    for i = 1:size(hx,1)
        Z(2*i-1:2*i,2*i-1:2*i) = c * c';
    end

    % Initialization
    lambda = 0.001;
    ex = calEpsilon(nx, Xw, R, t);
    perr = 10000000;
    err = ex'*inv(Z)*ex;
    
    % Error Log
    log = err;

    while abs(perr-err) > 0.0001
        W = parameterize(R);

        % Angle Normalization
        if norm(W) > pi
            W = (1 - 2*pi/norm(W)*ceil((norm(W)-pi)/(2*pi))) * W;
        end
        R = deparameterize(W);
        
        % Create \partial(R, t) / \partial(W, t)
        I = eye(3);
        theta = norm(W);
        nW = W/norm(W);
        nWx = skewMatrix(nW);
        
        partial_vv = zeros(12,6);
        partial_vv(10:12,4:6) = eye(3);
        for i = 1:3
            dW = cos(theta)*nW(i,1)*nWx + sin(theta)*nW(i,1)*nWx*nWx ...
                + sin(theta)/theta*skewMatrix(I(i,:)'-nW(i,1)*nW) ...
                + (1-cos(theta))/theta ...
                * (I(i,:)'*nW' + nW*I(i,:) - 2*nW(i,1)*(nW*nW'));
            partial_vv(1:9,i) = vector(dW);
        end   
        
        % Calculate J with \partial(x, y) / \partial(R, t)
        J = zeros(2*size(hx,1),6);
        for i = 1:size(hx,1)
            w = R * Xw(i,:)' + t;
            partial_xp = 1/w(3,1) * ...
                [Xw(i,:), zeros(1,3), -w(1,1)/w(3,1)*Xw(i,:), ...
                 1, 0, -w(1,1)/w(3,1); ...
                 zeros(1,3), Xw(i,:), -w(2,1)/w(3,1)*Xw(i,:), ...
                 0, 1, -w(2,1)/w(3,1)];
            J(2*i-1:2*i,:) = partial_xp * partial_vv;
        end
        
        while true
            % Solve delta
            d = (J'*inv(Z)*J + lambda*eye(6)) \ (J'*inv(Z)*ex);
            nW = W + d(1:3,1);
            nt = t + d(4:6,1);

            % Angle Normalization
            if norm(nW) > pi
                nW = (1 - 2*pi/norm(nW) ...
                    * ceil((norm(nW)-pi)/(2*pi))) * nW;
            end
            nR = deparameterize(nW);

            nex = calEpsilon(nx, Xw, nR, nt);
            if nex'*inv(Z)*nex < ex'*inv(Z)*ex
                R = nR;
                t = nt;
                ex = nex;
                lambda = 0.1 * lambda;
                break;
            else
                lambda = 10 * lambda;
            end
        end

        % Update error
        perr = err;
        err = nex'*inv(Z)*nex;
        log = [log, err];
    end
    W = parameterize(R);
end

function ex = calEpsilon(nx, Xw, R, t)
    px = (R * Xw' + t)';
    px = px ./ px(:,3);
    ex = vector(nx(:,1:2)) - vector(px(:,1:2));
end

function W = parameterize(R) 
    [~, ~, V] = svd(R - eye(3));
    a = V(:,end);
    b = [R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)];
    
    sin_theta = 0.5 * a' * b;
    cos_theta = 0.5 * (trace(R)-1);
    theta = atan2(sin_theta, cos_theta);
    %theta = acos(cos_theta);
    
    W = theta * a / norm(a);
end

function R = deparameterize(W)
    theta = norm(W);
    
    if theta < 1e-7
        assert(false);
    else
        sin_theta = sin(theta);
        cos_theta = cos(theta);
        nW = W / norm(W);
        nWx = skewMatrix(nW);

        R = cos_theta*eye(3) + sin_theta*nWx ...
            + (1-cos_theta)*(nW*nW');
    end
end

function Wx = skewMatrix(W)
    Wx = [0, -W(3,1), W(2,1); ...
          W(3,1), 0, -W(1,1); ...
          -W(2,1), W(1,1), 0];
end

function vx = vector(x)
    vx = x';
    vx = vx(:);
end