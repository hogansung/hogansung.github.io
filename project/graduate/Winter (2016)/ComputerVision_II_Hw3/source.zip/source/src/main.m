%% Preprocessing
% Read data
hx = dlmread('../dat/hw3_points2D.txt');
hX = dlmread('../dat/hw3_points3D.txt');

% Homogenize
hx(:,3) = ones(size(hx,1),1);
hX(:,4) = ones(size(hX,1),1);

% Calibration Matrix
K = [1545.0966799187809, 0, 639.5; ...
     0, 1545.0966799187809, 359.5; ...
     0, 0, 1];


%% Problem 1
% Remove Outliers
[R, t, bmap, MAX_TRIALS] = mSAC(hx, hX, K);
hx = hx(bmap,:);
hX = hX(bmap,:);

RMSE = calRMSE(hx, hX, K, R, t);
fprintf('\n\nProblem 1\n');
fprintf('Number of Inliers: %d\n', sum(bmap));
fprintf('Number of MaxTrials: %.10f\n', MAX_TRIALS);
fprintf('RMSE: %.10f\n', RMSE);


%% Problem 2
[R, t] = EPnP(hx, hX, K);

RMSE = calRMSE(hx, hX, K, R, t);
fprintf('\n\nProblem 2\n');
display(R);
display(t);
fprintf('RMSE: %.10f\n', RMSE);


%% Problem 3
[R, t, W, log] = LM_c(hx, hX, K, R, t);

RMSE = calRMSE(hx, hX, K, R, t);
fprintf('\n\nProblem 3\n');
display(R);
display(t);
display(W);
display(log);
fprintf('RMSE: %.10f\n', RMSE);