# Codes Folder --- code/

## Problem 1
* mSAC.m
- (depend on Finsterwalder.m and Umeyama.m)
- Input: Homogeneous 2D Points, 
         Homogeneous 3D Points, 
         Calibration Matrix
- Output: Rotation Matrix, 
          Translation Matrix, 
          Boolean Map, 
          MAX_TRIALS

* Finsterwalder.m
- (no dependency)
- Input: Normalized Inhomogeneous 2D Points,
         Inhomogeneous 3D Points
- Output: List of Potential Control Points Pairs

* Umeyama.m
- (no dependency)
- Input: Inhomogeneous 3D Points (World Coordinate)
         Inhomogeneous 3D Points (Camera Coordinate)
- Output: Solution Status (False if there is feasible solution),
          Rotation Matrix, 
          Translation Matrix


## Problem 2
* EPnP.m
- (depend on Umeyama.m)
- Input: Homogeneous 2D Points, 
         Homogeneous 3D Points, 
         Calibration Matrix
- Output: Rotation Matrix, 
          Translation Matrix


## Problem 3
* LM_c.m
- (no dependency)
- Input: Homogeneous 2D Points, 
         Homogeneous 3D Points, 
         Calibration Matrix,
         Rotation Matrix, 
         Translation Matrix
- Output: Rotation Matrix, 
          Translation Matrix,
          Parameterized Matrix,
          Error Logs


## Main Script
* main.m
- (depend on mSAC.m, EPnP.m, LM_c.m, calRMSE.m)
- Input: None
- Output: None


## Helper Function
* calRMSE.m
- (no dependency)
- Input: Homogeneous 2D Points, 
         Homogeneous 3D Points, 
         Calibration Matrix,
         Rotation Matrix, 
         Translation Matrix
- Output: RMSE score



# Data Folder --- dat/
* hw3_points2D.txt
* hw3_points3D.txt



# Document Folder --- doc/
* hw3.pdf



# Other files
* CSE_252B_hw3_Sung_A53204772.pdf
* readme.txt



# Author: Hao-en Sung (wrangle1005@gmail.com)
