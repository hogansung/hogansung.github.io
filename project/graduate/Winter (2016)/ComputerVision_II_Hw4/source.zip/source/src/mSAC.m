% lx, rx: 2D homogenerous points
function [best_H, best_bmap, MAX_TRIALS, MIN_COST] = mSAC(lx, rx)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);

    % Parameters
    MIN_COST = Inf;
    MAX_TRIALS = Inf;
    THRESHOLD = 1;
    TOLERANCE = chi2inv(0.95,2);
    PROBABILITY = 0.99;
    
    % Initialize return values
    best_H = zeros(3,3);
    best_bmap = false(n,1);
    
    trials = 0;
    s = RandStream('mt19937ar','Seed',1);
    while trials < MAX_TRIALS && MIN_COST > THRESHOLD
        trials = trials + 1;
        
        % Random 4 numbers
        idx = randperm(s, n);
        idx = idx(1:4);
        
        H1 = findH(lx(idx,:));
        H2 = findH(rx(idx,:));
        H = inv(H2) * H1;
        
        % Calculate delta
        delta = calDelta(lx, rx, H);
        
        % Calculate error
        error = calError(delta);
        
        % Calculate cost
        cost = calCost(error, TOLERANCE);
        
        if cost < MIN_COST
            MIN_COST = cost;
            best_H = H;
            best_bmap = error < TOLERANCE;
            best_n_in = sum(best_bmap);
            
            w = best_n_in / n;
            MAX_TRIALS = log(1-PROBABILITY) / log(1-w^4);
        end
    end
end

function H = findH(x)
    assert(size(x,1) == 4);
    A = x(1:3,:)';
    b = x(4,:)';
    lambda = A \ b;
    
    lambda_x = [lambda(1,1)*x(1,:)', lambda(2,1)*x(2,:)', ...
     lambda(3,1)*x(3,:)', 1*x(4,:)'];
    e = [[1,0,0]', [0,1,0]', [0,0,1]', [1,1,1]'];
    H = e / lambda_x;
end

function delta = calDelta(lx, rx, H)
    n = size(lx,1);
    vH = vector(H);
    delta = zeros(n,4);
    for i = 1:n
        Ai = [zeros(1,3), -lx(i,:), rx(i,2)*lx(i,:); ...
              lx(i,:), zeros(1,3), -rx(i,1)*lx(i,:)];
        ex = Ai * vH;
        J = [-H(2,1)+rx(i,2)*H(3,1), -H(2,2)+rx(i,2)*H(3,2), ...
             0, lx(i,1)*H(3,1)+lx(i,2)*H(3,2)+H(3,3); ...
             H(1,1)-rx(i,1)*H(3,1), H(1,2)-rx(i,1)*H(3,2), ...
             -(lx(i,1)*H(3,1)+lx(i,2)*H(3,2)+H(3,3)), 0];
        lambda = (J*J') \ (-ex);
        delta(i,:) = (J' * lambda)';
    end
end

function error = calError(delta)
    n = size(delta,1);
    error = zeros(n,1);
    for i = 1:n
        error(i,1) = delta(i,:) * delta(i,:)';
    end
end

function cost = calCost(error, TOLERANCE)
    cost = sum(min(error, TOLERANCE));
end

function vx = vector(x)
    vx = x';
    vx = vx(:);
end
