function RMSE = calRMSE(lx, rx, H)
    px = (H * lx')';
    px = px ./ px(:,3);
    diff = rx(:,1:2) - px(:,1:2);
    RMSE = sqrt(mean(sum(diff.^2,2)));
end