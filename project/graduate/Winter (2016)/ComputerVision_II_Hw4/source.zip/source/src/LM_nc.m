% lx, rx: 2D homogenerous points
function [H, logs] = LM_nc(lx, rx, H)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);
    
    % Data Normalization
    lx_mean = mean(lx);
    lx_var = var(lx);
    lx_s = sqrt(2 / sum(lx_var));
    T = [lx_s, 0, -lx_mean(1)*lx_s;
         0, lx_s, -lx_mean(2)*lx_s; 
         0, 0, 1];
    lx = lx * T';

    rx_mean = mean(rx);
    rx_var = var(rx);
    rx_s = sqrt(2 / sum(rx_var));
    U = [rx_s, 0, -rx_mean(1)*rx_s;
         0, rx_s, -rx_mean(2)*rx_s; 
         0, 0, 1];
    rx = rx * U';
    H = U * H / T;
    
    % Scene Points Initialization
    delta = calDelta(lx, rx, H);
    sx = lx;
    sx(:,1:2) = sx(:,1:2) + delta(:,1:2);

    % Covariance Matrix
    Z = diag([repmat(lx_s^2, 1, 2*n), ...
        repmat(rx_s^2, 1, 2*n)]);

    % Initialization
    lambda = 0.001;
    perr = 1000000;
    
    [n_lx, n_rx] = estimate(sx, H);
    ex = calEpsilon(lx, rx, n_lx, n_rx);
    err = ex'*inv(Z)*ex;

    % Error Log
    logs = err;
    
    % Parameterize H and sx
    vH = vector(H);
    pH = parameterize(vH);
    px = zeros(n,2);
    for i = 1:n
        px(i,:) = parameterize(sx(i,:));
    end

    % Angle Normalize pH and px
    if norm(pH) > pi
        pH = (1 - 2*pi/norm(pH) * ceil((norm(pH)-pi)/(2*pi))) * pH;
    end
    for i = 1:n
        if norm(px(i,:)) > pi
            px(i,:) = (1 - 2*pi/norm(px(i,:)) * ...
                ceil((norm(px(i,:))-pi)/(2*pi))) * px(i,:);
        end
    end

    % Deparameterize pH and px
    vH = deparameterize(pH);
    H = reshape(vH, 3, 3)';
    for i = 1:n
        sx(i,:) = deparameterize(px(i,:)')';
    end

    while abs(perr-err) > 0.0001
        % Estimate Homogeneous 2D Points in 
        % Image 1 and 2 from Scene Points
        [n_lx, n_rx] = estimate(sx, H);
        
        % Calculate J
        J = zeros(4*n,8+2*n);
        
        % Fill up J with A_i''
        partial_hh = [-0.5 * vH(2:end)'; ...
                      _sinc(norm(pH)/2)/2 * eye(8) + ...
                      1/(4*norm(pH)) * _dsinc(norm(pH)/2) * (pH*pH')];
        for i = 1:n
            partial_x2h = 1/n_rx(i,3) * ...
                [sx(i,:), zeros(1,3), -n_rx(i,1)/n_rx(i,3)*sx(i,:);
                 zeros(1,3), sx(i,:), -n_rx(i,2)/n_rx(i,3)*sx(i,:)];                   
            J(2*n+2*i-1:2*n+2*i,1:8) = partial_x2h * partial_hh;
        end
        
        % Fill up J with B_i'
        for i = 1:n
            partial_x1x = 1/n_lx(i,3) * ...
                [1, 0, -n_lx(i,1)/n_lx(i,3);
                 0, 1, -n_lx(i,2)/n_lx(i,3)];
            partial_xx = [-0.5 * sx(i,2:end); ...
                  _sinc(norm(px(i,:))/2)/2 * eye(2) ...
                  + 1/(4*norm(px(i,:))) * _dsinc(norm(px(i,:))/2) ...
                  * (px(i,:)'*px(i,:))];
            J(2*i-1:2*i,8+2*i-1:8+2*i) = partial_x1x * partial_xx;
        end
          
        % Fill up J with B_i''
        for i = 1:n
            partial_x2x = 1/n_rx(i,3) * ...
                [H(1,:) - n_rx(i,1)/n_rx(i,3) * H(3,:);
                 H(2,:) - n_rx(i,2)/n_rx(i,3) * H(3,:)];
            partial_xx = [-0.5 * sx(i,2:end); ...
                  _sinc(norm(px(i,:))/2)/2 * eye(2) ...
                  + 1/(4*norm(px(i,:))) * _dsinc(norm(px(i,:))/2) ...
                  * (px(i,:)'*px(i,:))];
            J(2*n+2*i-1:2*n+2*i,8+2*i-1:8+2*i) ...
                = partial_x2x * partial_xx;
        end
        
        while true
            % Solve delta and update pH and px
            d = (J'*inv(Z)*J + lambda*eye(2*n+8)) \ (J'*inv(Z)*ex);
            n_pH = pH + d(1:8,1);
            n_px = px;
            for i = 1:n
                n_px(i,:) = px(i,:) + d(8+2*i-1:8+2*i)';
            end

            % Angle Normalize n_pH and n_px
            if norm(n_pH) > pi
                n_pH = (1 - 2*pi/norm(n_pH) ...
                    * ceil((norm(n_pH)-pi)/(2*pi))) * n_pH;
            end
            for i = 1:n
                if norm(n_px(i,:)) > pi
                    n_px(i,:) = (1 - 2*pi/norm(n_px(i,:)) ...
                        * ceil((norm(n_px(i,:))-pi)/(2*pi))) ...
                        * n_px(i,:);
                end
            end
            
            % Deparameterize pH and px
            n_vH = deparameterize(n_pH);
            n_H = reshape(n_vH, 3, 3)';
            n_sx = sx;
            for i = 1:n
                n_sx(i,:) = deparameterize(n_px(i,:)')';
            end
            
            [n_lx, n_rx] = estimate(n_sx, n_H);
            nex = calEpsilon(lx, rx, n_lx, n_rx);
            nerr = nex'*inv(Z)*nex;

            if nerr < err
                H = n_H;
                sx = n_sx;
                lambda = 0.1 * lambda;
                break;
            else
                lambda = 10 * lambda;
            end
        end

        % Update error
        perr = err;
        err = nerr;
        logs = [logs, err];
    end

    % Data Denormalization
    H = U \ H * T;
end

function [n_lx, n_rx] = estimate(sx, H)
    n_lx = (eye(3) * sx')';
    n_rx = (H * sx')';
end

% n_lx, n_rx have been normalized by their third columns
function ex = calEpsilon(lx, rx, n_lx, n_rx)
    n_lx = n_lx ./ n_lx(:,3);
    n_rx = n_rx ./ n_rx(:,3);
    ex = [vector(lx(:,1:2)) - vector(n_lx(:,1:2)); ...
          vector(rx(:,1:2)) - vector(n_rx(:,1:2))];
end

function vx = vector(x)
    vx = x';
    vx = vx(:);
end

function p = parameterize(v)
    v = v / norm(v);
    a = v(1);
    b = v(2:end);
    p = 2 / _sinc(acos(a)) * b;
end

function v = deparameterize(p)
    v = [cos(norm(p)/2), _sinc(norm(p)/2)/2 * p']';
end

function ret = _sinc(x)
    if x == 0
        ret = 1;
    else
        ret = sin(x) / x;
    end
end

function ret = _dsinc(x)
    if x == 0
        ret = 0;
    else
        ret = cos(x) / x - sin(x) / x^2;
    end
end

function delta = calDelta(lx, rx, H)
    n = size(lx,1);
    vH = vector(H);
    delta = zeros(n,4);
    for i = 1:n
        Ai = [zeros(1,3), -lx(i,:), rx(i,2)*lx(i,:); ...
              lx(i,:), zeros(1,3), -rx(i,1)*lx(i,:)];
        ex = Ai * vH;
        J = [-H(2,1)+rx(i,2)*H(3,1), -H(2,2)+rx(i,2)*H(3,2), ...
             0, lx(i,1)*H(3,1)+lx(i,2)*H(3,2)+H(3,3); ...
             H(1,1)-rx(i,1)*H(3,1), H(1,2)-rx(i,1)*H(3,2), ...
             -(lx(i,1)*H(3,1)+lx(i,2)*H(3,2)+H(3,3)), 0];
        lambda = (J*J') \ (-ex);
        delta(i,:) = (J' * lambda)';
    end
end
