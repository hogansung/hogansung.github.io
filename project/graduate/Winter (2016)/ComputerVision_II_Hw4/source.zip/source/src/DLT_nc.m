% lx, rx: 2D homogenerous points
function H = DLT_nc(lx, rx)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);

    % Data Normalization
    lx_mean = mean(lx);
    lx_var = var(lx);
    lx_s = sqrt(2 / sum(lx_var));
    T = [lx_s, 0, -lx_mean(1)*lx_s;
         0, lx_s, -lx_mean(2)*lx_s; 
         0, 0, 1];
    lx = lx * T';

    rx_mean = mean(rx);
    rx_var = var(rx);
    rx_s = sqrt(2 / sum(rx_var));
    U = [rx_s, 0, -rx_mean(1)*rx_s;
         0, rx_s, -rx_mean(2)*rx_s; 
         0, 0, 1];
    rx = rx * U';

    % Left Null Space of H
    A = zeros(2*n, 9);
    for i = 1:n
        v = [rx(i,1) + sign(rx(i,1))*norm(rx(i,:)), ...
             rx(i,2), rx(i,3)]';
        Hv = eye(3) - 2 * (v * v') / (v' * v);
        A(2*i-1,:) = [Hv(2,1)*lx(i,:), Hv(2,2)*lx(i,:), ...
                      Hv(2,3)*lx(i,:)];
        A(2*i  ,:) = [Hv(3,1)*lx(i,:), Hv(3,2)*lx(i,:), ...
                      Hv(3,3)*lx(i,:)];
    end

    % Solve for P
    [~, ~, V] = svd(A, 'econ');
    H = V(:,end);
    H = reshape(H, 3, 3)';
    
    % Data Denormalization
    H = U \ H * T;
end
