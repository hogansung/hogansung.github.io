%% Read Files
preI = imread('../dat/price_center20.JPG');
preI = rgb2gray(preI);
nxtI = imread('../dat/price_center21.JPG');
nxtI = rgb2gray(nxtI);

%% Parameters
lambda_threshold = 2200;
nw = 7;

%% Problem 1: Extract Features
pref = featureDetect(preI, lambda_threshold, nw);
fprintf('Number of extracted features: %d\n', size(pref, 1));
nxtf = featureDetect(nxtI, lambda_threshold, nw);
fprintf('Number of extracted features: %d\n', size(nxtf, 1));

% Draw Feature-Deteced Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(pref(:,1),pref(:,2),'bs', 'MarkerSize', nw);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(nxtf(:,1),nxtf(:,2),'bs', 'MarkerSize', nw);
hold off

saveas(res, '../res/pc_detect.jpg');

%% Problem 2: Match Features
[lx, rx] = featureMatch(preI, nxtI, pref, nxtf, nw);
dx = rx-lx;
fprintf('Number of matches: %d\n', size(lx, 1));

% Draw Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(lx(:,1), lx(:,2), 'bs', 'MarkerSize', nw);
quiver(lx(:,1), lx(:,2), dx(:,1), dx(:,2), 0);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(rx(:,1), rx(:,2), 'bs', 'MarkerSize', nw);
quiver(rx(:,1), rx(:,2), -dx(:,1), -dx(:,2), 0);
hold off

saveas(res, '../res/pc_match.jpg');

%% Problem 3: Outlier Reection
% Homogenize
lx(:,3) = ones(size(lx,1),1);
rx(:,3) = ones(size(rx,1),1);
[H, bmap, MAX_TRIALS, cost] = mSAC(lx, rx);
fprintf('\n\nProblem 3\n');
fprintf('Number of Inliers: %d\n', sum(bmap));
fprintf('Number of MaxTrials: %.10f\n', MAX_TRIALS);
fprintf('Final Cost: %.10f\n', cost);
RMSE = calRMSE(lx, rx, H);
fprintf('RMSE: %.10f\n', RMSE);

% Reject Outliers
lx = lx(bmap,:);
rx = rx(bmap,:);
dx = rx-lx;

% Draw Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(lx(:,1), lx(:,2), 'bs', 'MarkerSize', nw);
quiver(lx(:,1), lx(:,2), dx(:,1), dx(:,2), 0);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(rx(:,1), rx(:,2), 'bs', 'MarkerSize', nw);
quiver(rx(:,1), rx(:,2), -dx(:,1), -dx(:,2), 0);
hold off

saveas(res, '../res/pc_robust_match.jpg');

%% Problem 4: DLT Algorithm (Linear Estimation)
H = DLT_nc(lx, rx);
fprintf('\n\nProblem 4\n');
fprintf('H_DLT:\n'); disp(H ./ norm(H,'fro'));
RMSE = calRMSE(lx, rx, H);
fprintf('RMSE: %.10f\n', RMSE);

%% Problem 5: Levenberg-Marquardt Algorithm (NonLinear Estimation)
[H, logs] = LM_nc(lx, rx, H);
fprintf('\n\nProblem 5\n');
fprintf('P_LM:\n'); disp(H ./ norm(H,'fro'));
fprintf('Error log:\n'); disp(logs);
RMSE = calRMSE(lx, rx, H);
fprintf('RMSE: %.10f\n', RMSE);