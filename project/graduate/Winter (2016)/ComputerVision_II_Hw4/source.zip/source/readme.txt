# Codes Folder --- code/

## Problem 1
* featureDetect.m
- (no dependency)
- Input: Gray-scaled Image,
         Lambda Threshold,
         Window Size
- Output: List of Corners


## Problem 2
* featureMatch.m
- (no dependency)
- Input: Left Gray-scaled Image,
         Right Gray-scaled Image,
         List of Corners in Left Image,
         List of Corners in Right Image,
         Window Size
- Output: List of Matched Corners


## Problem 3
* mSAC.m
- (no dependency)
- Input: List of Matched Corners
- Output: Projective Matrix,
          Boolean Map,
          MAX_TRIALS,
          MIN_COST


## Problem 4
* DLT_nc.m
- (no dependency)
- Input: List of Matched Corners
- Output: Projective Matrix


## Problem 5
* LM_nc.m
- (no dependency)
- Input: List of Matched Corners,
         Projective Matrix
- Output: Projective Matrix,
          Error Logs


## Main Script
* main.m
- (depend on featureDetect.m, featureMatch.m, mSAC.m, DLT_nc.m, LM_nc.m, calRMSE.m)
- Input: None
- Output: None


## Helper Function
* calRMSE.m
- (no dependency)
- Input: List of Matched Corners
         Projective Matrix
- Output: RMSE score



# Data Folder --- dat/
* price_center20.JPG
* price_center21.JPG



# Document Folder --- doc/
* hw4.pdf



# Other files
* CSE_252B_hw4_Sung_A53204772.pdf
* readme.txt



# Author: Hao-en Sung (wrangle1005@gmail.com)
