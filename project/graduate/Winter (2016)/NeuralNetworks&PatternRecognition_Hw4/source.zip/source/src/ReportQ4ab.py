from os.path import isfile, isdir
from os import makedirs

from RNNTrain import getTestModelWithWeights, generateMusic, getTemperature, getResult
from utilities import loadTunes, label2code, savefig

QUESTION_ID = 'Q4a'
MODEL_STORAGE = '../model/'
RESULT_STORAGE = '../result/'
TUNE_STORAGE = '%stunes/tune_%s/'%(RESULT_STORAGE, QUESTION_ID)
MAX_TUNE = 30
TUNE_MAX_LEN = 5000

def reportQ4a():
    if not isdir(MODEL_STORAGE):
        makedirs(MODEL_STORAGE)
    
    if not isdir(RESULT_STORAGE):
        makedirs(RESULT_STORAGE)
        
    # Generate folders for tunes storage.
    if not isdir(TUNE_STORAGE):
        makedirs(TUNE_STORAGE)
    model = getTestModelWithWeights()
    if model == None:
        return
    print "Read tunes from input.txt file."
    tunes = loadTunes()
    print "Encode chars to ints."
    encoded_tunes, label_encoder = label2code(tunes)
    # for T in [1, 2, 0.5]: we need to change the TEMPERATURE global variable to theses values.
    for num in range(MAX_TUNE):
        final_tune = generateMusic(model, encoded_tunes, label_encoder, 1, TUNE_MAX_LEN)
        filename = '%s%g_%d.txt'%(TUNE_STORAGE, getTemperature(), num)
        outputfile = open(filename, 'w')
        # print type(final_tune), len(final_tune), final_tune[:50]
        outputfile.write("%s" % ''.join(final_tune))
        model.reset_states()

def reportQ4b():
    acc, loss, val_acc, val_loss = getResult()
    savefig([acc, val_acc], 'model accuracy',
            'number of epochs',
            'Accuracy',
            ['Train', 'Validation'],
            '%sq4_b/q4_b_acc.png'%RESULT_STORAGE)
    savefig([loss, val_loss], 'model loss',
            'number of epochs',
            'Loss',
            ['Train', 'Validation'],
            '%sq4_b/q4_b_loss.png'%RESULT_STORAGE)
    
if __name__ == '__main__':
    reportQ4a()
    reportQ4b()