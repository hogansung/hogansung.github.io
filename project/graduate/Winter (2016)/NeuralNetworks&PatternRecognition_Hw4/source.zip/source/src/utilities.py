
from os.path import isfile
import numpy as np
import random
from sklearn import preprocessing
from keras.utils import np_utils
import cPickle as pickle
import matplotlib.pyplot as plt

def savePkl(dataset, pklfile):
    # Save small pkl files.
    f = file(pklfile, 'wb')
    pickle.dump(dataset, f, protocol=pickle.HIGHEST_PROTOCOL)
    f.close  
      
def loadPkl(pklfile):
    # Load small pkl files.
    f = open(pklfile, 'rb')
    dataset = pickle.load(f)
    f.close
    return dataset
# This file provide tools that can be used to read the data.
def loadTunes(filepath='../data/input.txt'):
    f = open(filepath, 'r')
    tunes = []
    starting_seqs = []
    tune = []
    for line in f:
        tune.extend(list(line))
        if line == '<end>\r\n':
            tunes.append(tune)
            tune = []
    print "Found %d tunes"%(len(tunes))
    statspath = '../data/stats.txt' # stores the length for every tune.
    statsfile = open(statspath, 'w')
    for i in range(len(tunes)):
        statsfile.write("%d:\t%d\n"%(i, len(tunes[i])))
    print "tunes ranges from %d to %d characters"%(min(map(len, tunes)), max(map(len, tunes)))
    return tunes

def label2code(tunes):
    le = preprocessing.LabelEncoder()
    all_chars = []
    map(all_chars.extend, tunes)
    le.fit(all_chars)
    print 'found %d classes.'%(len(list(le.classes_)))
    new_tunes = map(le.transform, tunes)
    return new_tunes, le

def prepDataSeq(data, sequenceLen, sequential = False, noTuneSeparation= True, overlapping = True):
    # slice random sequences from all tunes. Not aligned with the beginning of the file.
    X = []
    y = []
    if sequential:
        print "Sequentially connected sequences will be generated."
    else:
        print "Randomly selected sequences will be generated."
    if noTuneSeparation:
        print "The file will be chopped as a whole sequence."
    else:
        print "Each tune will be chopped as an independent sequence."
    if overlapping:
        print "No overlapping sequences will be generated."
    else:
        print "Overlapping sequences will be generated."
    if noTuneSeparation:
        # Sequences are randomly drawn from the entire input.txt file.
        all_chars = []
        map(all_chars.extend, data)
        N = len(all_chars)
        valid_start_max = N - 1 - 2*sequenceLen
        start  = 0
        while start < valid_start_max:
            if not sequential:
                start = random.randint(start, start+sequenceLen)
            end = start + sequenceLen
            x_seq = all_chars[start:end]
            X.append(x_seq)
            y_seq = all_chars[start+1:end+1]
            y.append(y_seq)
            if overlapping and not sequential:
                start = end - sequenceLen/2
            else:
                start = end
    else:
        # Sequences are only drawn from within every tune sequence.
        for tune in data:
            N = len(tune)
            valid_start_max = N - 1 - 2*sequenceLen
            # randomly select one sequence start per sequenceLen sequentailly from X.
            start = 0
            while start <= valid_start_max:
                if not sequential:
                    start = random.randint(start, start+sequenceLen)
                end = start + sequenceLen
                x_seq = tune[start:end]
                X.append(x_seq)
                y_seq = tune[start+1:end+1]
                y.append(y_seq)
                if overlapping and not sequential:
                    start = end - sequenceLen/2
                else:
                    start = end
            # both X and y are shape of (sequences x sequenceLen)

            # Add last sequence if one does not exist, add it for half of the time.
            if start != N-1 and random.random()>0.5 and N-1 >= sequenceLen:
                X.append(tune[-sequenceLen-1:-1])
                y.append(tune[-sequenceLen:])
                if len(X[-1]) != sequenceLen or  len(y[-1]) != sequenceLen:
                    print len(X[-1]), len(y[-1])
    return X, y

def partition(X, y):
    data = zip(X, y)
    random.shuffle(data)
    # 80% for training, 20% for validation
    n_sequences = len(data)
    n_train = int(n_sequences*0.8)
    n_valid = n_sequences - n_train
    data_train = zip(*data[:n_train])
    data_test = zip(*data[n_train:])
    return list(data_train[0]), list(data_train[1]), list(data_test[0]), list(data_test[1])

def processSample(x, y, nClasses):
    xhot = np_utils.to_categorical(x, nClasses)
    xhot = np.expand_dims(xhot, axis=1)
    yhot = np_utils.to_categorical(y, nClasses)
    return xhot, yhot

def prob2input(y_pred_prob):
    nSamples = y_pred_prob.shape[0]
    nClasses = y_pred_prob.shape[1]
    y_pred_ints = []
    for i in range(nSamples):
        y_pred_int = np.random.choice(range(nClasses), p=y_pred_prob[i, :])
        y_pred_ints.append(y_pred_int)
    y_pred_hot = np_utils.to_categorical(y_pred_ints, nClasses)
    y_pred_hot = np.expand_dims(y_pred_hot, axis=1) 
    return y_pred_hot

def savefig(results, title='', xlabel='', ylabel='', legends = [], savepath = '',  Xs = [], display = False, overwrite = True):
    if not isfile(savepath) or overwrite:
        print "Save %s..."%(savepath)
        
        if Xs == []:
            Xs = range(len(results[0]))
        print "# iterations:", len(Xs)
        for Ys in results:
            plt.plot(Xs, Ys)
                
            plt.title(title)
            plt.ylabel(ylabel)
            plt.xlabel(xlabel)
        
        if legends !=[]:
            plt.legend(legends, loc='upper left')
        plt.savefig(savepath)
        print "Done saving acc figure."
        if display:
            plt.show()
        plt.clf()

if __name__ == "__main__":
    tunes = readTxt()
    samples = np.random.randint(len(tunes), size=3)
    sample_len = 50
    print "example start sequences of length %d:\n%s\n%s\n%s"%(sample_len,
                                                               ''.join(tunes[samples[0]][:sample_len]),
                                                               ''.join(tunes[samples[1]][:sample_len]),
                                                               ''.join(tunes[samples[2]][:sample_len]))
    new_tunes, label_encoder = label2code(tunes)
    sequence_len = 30
    X, y = prepDataSeq(new_tunes, sequence_len)
    print "Found total %d sequences"%(len(X))
    x_train, y_train, x_test, y_test = partition(X, y)
    print "%d train sequences, %d test sequences"%(len(x_train), len(x_test))
    print "train data dimension", np.array(x_train).shape
    print "label data dimension", np.array(x_test).shape
    