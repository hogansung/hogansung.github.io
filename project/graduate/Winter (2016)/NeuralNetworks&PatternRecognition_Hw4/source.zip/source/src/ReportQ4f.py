from os.path import isfile, isdir
from os import makedirs
from keras.layers.recurrent import SimpleRNN
from keras.layers.core import Dense
from keras.models import Sequential
from keras.optimizers import RMSprop, Adagrad
from keras.callbacks import EarlyStopping, Callback
from utilities import loadTunes, partition, label2code, prepDataSeq, processSample, savePkl, loadPkl, savefig, prob2input
import time
from tqdm import *
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import random
from keras.utils import np_utils
from keras import backend as K
from keras.models import Model
from itertools import izip

LR = 0.01
QUESTION_ID = 'Q4e'
N_HIDDEN_UNIT = 100
INCREMENT_TRAINING = True
BATCH_SIZE = 64 # How many samples will be processed simultaneously.
PRIME_LEN = 30 # Prime the music generation with PRIME_LEN characters.
MAX_EPOCH = 50 # How many epoch will be run.
EARLY_STOPPING = 6 # Stop training if validation set's loss stop decreasing.
DATA_STORAGE = '../data/'
# For results and models
MODEL_STORAGE = '../model/'
RESULT_STORAGE = '../result/'
MODEL_FILE = '%smyRNN_%s.h5'%(MODEL_STORAGE, QUESTION_ID)
TEMP_MODEL_FILE = '%stemp_test_model_%s.h5'%(MODEL_STORAGE, QUESTION_ID)
WEIGHT_FILE = '%sweight_me%d_lr%g_%s.h5'%(RESULT_STORAGE, MAX_EPOCH, LR, QUESTION_ID)

RESULT_FILE = '%sresult_%g_%s.pkl'%(RESULT_STORAGE, LR, QUESTION_ID)
ACC_FILE = '%saccuracy_%g_%s.png'%(RESULT_STORAGE, LR, QUESTION_ID)
LOSS_FILE = '%sloss_%g_%s.png'%(RESULT_STORAGE, LR, QUESTION_ID)
# For generateMusic
TUNE_STORAGE = '%stunes/tune_%s/'%(RESULT_STORAGE, QUESTION_ID)

END_TOKEN ="<end>"
TUNE_MAX_LEN = 5000 # maximum length of the tune is around 4900, this ensures that we will stop with some useful information in tune generation checking.

TEMPERATURE = 1
MAX_SEQ_LEN = 110
def getTemperature():
    return TEMPERATURE

def temperature_activation(a):
    T = TEMPERATURE
    return K.softmax(a/T)

def getTestModel(output_dim = 94, lr=LR, n_hidden_units =N_HIDDEN_UNIT, modelfile = MODEL_FILE):
    # as the first layer in a Sequential model
    model = Sequential()
    input_length = 1 # number of timesteps.
    input_dim = output_dim # number of features after one-hot encoding.
    model.add(SimpleRNN(n_hidden_units, 
                        batch_input_shape = (BATCH_SIZE, input_length, input_dim),
                        return_sequences=False, # return last output in the output sequence for length of 1 input.
                        stateful=True, # last state for every sample at index i in a batch will be used as initial state for sample of index i in the following batch.
                        unroll = True)) # network will be unrolled, speedup TF.
    model.add(Dense(output_dim, activation=temperature_activation))
    #opt = RMSprop(lr=lr)
    opt = Adagrad(lr=lr)
    model.compile(optimizer=opt,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    model.summary()
    model.save(modelfile)
    return model

def getModel(output_dim = 94, lr=LR, n_hidden_units =N_HIDDEN_UNIT, modelfile = MODEL_FILE):
    # as the first layer in a Sequential model
    model = Sequential()
    input_length = 1 # number of timesteps.
    input_dim = output_dim # number of features after one-hot encoding.
    model.add(SimpleRNN(n_hidden_units, 
                        batch_input_shape = (BATCH_SIZE, input_length, input_dim),
                        return_sequences=False, # return last output in the output sequence for length of 1 input.
                        stateful=True, # last state for every sample at index i in a batch will be used as initial state for sample of index i in the following batch.
                        unroll = True)) # network will be unrolled, speedup TF.
    model.add(Dense(output_dim, activation='softmax'))
    #opt = RMSprop(lr=lr)
    opt = Adagrad(lr=lr)
    model.compile(optimizer=opt,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    model.summary()
    model.save(modelfile)
    return model

def getTestModelWithWeights():
    # Get default model with the final weights loaded.

    if not isfile(WEIGHT_FILE):
        print "WARNING: Can not load %s, please run RNNTrain.py first."%(WEIGHT_FILE)
        return None
    else:
        model = getTestModel()
        model.load_weights(WEIGHT_FILE)
        return model

def trainModel(model,seqLen, Xtrain, ytrain, Xvalid, yvalid, nClasses, encodedTunes, le, incrementalTraining = False):
    print np.array(Xtrain).shape, np.array(ytrain).shape, np.array(Xvalid).shape, np.array(yvalid).shape
    WEIGHT_FILE_STORE = '../result/weight_me%d_lr%g_seq%d_%s.h5'%(MAX_EPOCH, LR, seqLen, QUESTION_ID)
    print "Training with learning rate %g with sequence %d"%(LR, seqLen)
    mean_tr_accs =[]
    mean_tr_losses =[]
    mean_te_accs =[]
    mean_te_losses =[]
    previous_epoch = 0
    # Load weights if incrementW is true, and previous weights exist.
    if incrementalTraining and isfile(WEIGHT_FILE):
        model.load_weights(WEIGHT_FILE)
        print "Loaded weights from %s"%(WEIGHT_FILE)
        mean_tr_accs, mean_tr_losses, mean_te_accs, mean_te_losses = loadPkl(RESULT_FILE)
        print "Loaded history pkl from %s"%(RESULT_FILE)
        previous_epoch = len(mean_tr_accs)
    elif incrementalTraining and not isfile(WEIGHT_FILE):
        print "Did not find previous weights. Cannot load previous weights."
    elif isfile(WEIGHT_FILE):
        print "Over-writting previous weights %s"%(WEIGHT_FILE)
    else:
        print "Creating %s for the first time."%(WEIGHT_FILE)
        
    pre_test_loss = float("inf")
    incre = 0
    model_pre = model
    optimal_model = None
    for epoch in range(MAX_EPOCH):
        print "train part Epoch:%d/%d"%(previous_epoch+epoch, previous_epoch+MAX_EPOCH)
        tr_accs = []
        tr_losses = []
        n_batch = len(Xtrain)/BATCH_SIZE
        print '%d samples %d batches with batch size of %d'%(len(Xtrain),
                                                             n_batch,
                                                             BATCH_SIZE)
        for i in tqdm(range(n_batch)):
            x_seqs = np.array(Xtrain[i*BATCH_SIZE:(i+1)*BATCH_SIZE])
            y_seqs = np.array(ytrain[i*BATCH_SIZE:(i+1)*BATCH_SIZE])
            for j in range(seqLen):
                # conver every feature to (numsample, lenth, dim) format. 
                # here x_hot is in (batch_size, 1, nClasses) format
                # y_hot is in (batch_size, nClasses) format
                x_hot, y_hot = processSample(x_seqs[:, [j]], 
                                             y_seqs[:, [j]], 
                                             nClasses)
                tr_loss, tr_acc = model.train_on_batch(x_hot, y_hot)
                tr_accs.append(tr_acc)
                tr_losses.append(tr_loss)
            model.reset_states()
        mean_tr_acc = np.mean(tr_accs)
        mean_tr_accs.append(mean_tr_acc)
        mean_tr_loss = np.mean(tr_losses)
        mean_tr_losses.append(mean_tr_loss)
        print ('accuracy trianing = {}'.format(mean_tr_acc))
        print ('loss training = {}'.format(mean_tr_loss))
        print ('___________________________________')
    
        te_accs = []
        te_losses = []
        n_batch = len(Xvalid)/BATCH_SIZE
        for i in tqdm(range(n_batch)):
            x_seqs = np.array(Xvalid[i*BATCH_SIZE:(i+1)*BATCH_SIZE])
            y_seqs = np.array(yvalid[i*BATCH_SIZE:(i+1)*BATCH_SIZE])
            for j in range(seqLen):
                x_hot, y_hot = processSample(x_seqs[:, [j]], 
                                             y_seqs[:, [j]], 
                                             nClasses)
                te_loss, te_acc = model.test_on_batch(x_hot,
                                                      y_hot)
                te_accs.append(te_acc)
                te_losses.append(te_loss)
            model.reset_states()
            
        mean_te_acc = np.mean(te_accs)
        mean_te_accs.append(mean_te_acc)
        mean_te_loss = np.mean(te_losses)
        mean_te_losses.append(mean_te_loss)
        print('accuracy testing = %g'%(mean_te_acc))
        print('loss testing = %g'%(mean_te_loss))
        print('___________________________________')
        
        # Early Stopping
        if pre_test_loss <= mean_te_loss:
            incre += 1
            if incre == 1:
                optimal_model = model_pre
        else:
            incre = 0
            model_pre = model
            optimal_model = None
            
        if incre >= EARLY_STOPPING:
            print "Early stpping at %d - %d steps"%(epoch, EARLY_STOPPING)
            break
        
        pre_test_loss = mean_te_loss
        
        # Check music generation every 20 epoch.
        if epoch%20 ==0:
            model.save_weights(TEMP_MODEL_FILE)
            te_model = getTestModel()
            te_model.load_weights(TEMP_MODEL_FILE)
            final_tune = generateMusic(te_model, encodedTunes, le)
            filename = '%s%d.txt'%(TUNE_STORAGE, epoch + previous_epoch)
            outputfile = open(filename, 'w')
            outputfile.write("%s" % ''.join(final_tune))

    # Save weights.
    if optimal_model != None:
        model = optimal_model
        data = mean_tr_accs[:-EARLY_STOPPING], mean_tr_losses[:-EARLY_STOPPING], mean_te_accs[:-EARLY_STOPPING], mean_te_losses[:-EARLY_STOPPING]
    else:
        data = mean_tr_accs, mean_tr_losses, mean_te_accs, mean_te_losses

    model.save_weights(WEIGHT_FILE)        
    model.save_weights(WEIGHT_FILE_STORE)
    
    savePkl(data, RESULT_FILE)
    mean_tr_accs, mean_tr_losses, mean_te_accs, mean_te_losses = loadPkl(RESULT_FILE)
    savefig([mean_tr_accs, mean_te_accs], 'model accuracy',
            'number of epochs',
            'Accuracy',
            ['Train', 'Test'],
            ACC_FILE)
    savefig([mean_tr_losses, mean_te_losses], 'model loss',
            'number of epochs',
            'Loss',
            ['Train', 'Test'],
            LOSS_FILE)
    print "Done Saving"
    
def generateMusic(model, encodedTunes, le, maxTunes = 6, maxTuneLen = TUNE_MAX_LEN):
    nClasses =len(list(le.classes_))
    # prime the network with a sequence randomly selected from tunes.
    random.shuffle(encodedTunes)
    start_seqs = []
    chosen_tune = random.randint(0, len(encodedTunes)-1)
    # Copy the same selected tune for Batch_Size
    for i in range(BATCH_SIZE):
        start_seqs.append(encodedTunes[chosen_tune][:PRIME_LEN])
    y_prime = le.inverse_transform(start_seqs[0])    
    print "Prime the sequence with [0]x%d: \n------\n%s\n------"%(BATCH_SIZE, ''.join(y_prime))
    start_X = np.array(start_seqs)
    prime_pred = []
    for j in range(PRIME_LEN):
        # convert every feature to (numsample, lenth, dim) format. 
        # here x_hot is in (batch_size, 1, nClasses) format
        # y_hot is in (batch_size, nClasses) format
        x_hot = np_utils.to_categorical(start_X[:, [j]], nClasses)
        x_hot = np.expand_dims(x_hot, axis=1)
        y_pred_prob = model.predict_on_batch(x_hot)
        y_pred_code = np.argmax(y_pred_prob[0])
        # take the prediction for the char j in first prime sequence.
        prime_pred.append(le.inverse_transform(y_pred_code))
        
    print "prime_pred info", len(prime_pred)
    # convert last prob prime output to label to display and check.
    print "Prime result:\n------\n%s\n-------"%(''.join(prime_pred))
    
    lastToken = []
    # Take the last predicted character, continue feeding it to model as input.
    x_next_hot = prob2input(y_pred_prob)
    more_preds = [prime_pred[-1]]
    tunes_count = 0
    while((''.join(lastToken) != END_TOKEN or tunes_count < maxTunes) and len(more_preds) < maxTuneLen - len(y_prime)):
        y_pred_prob = model.predict_on_batch(x_next_hot)
        x_next_hot = prob2input(y_pred_prob)
        y_pred_code = np.argmax(y_pred_prob[0])
        pred_char = le.inverse_transform(y_pred_code)
        lastToken.append(pred_char)
        if len(lastToken) ==  6:
            lastToken = lastToken[1:]
        more_preds.append(pred_char)
        if ''.join(lastToken) == END_TOKEN:
            tunes_count +=1
    result = [y_prime.tolist()[0]] # Add first character
    result.extend(prime_pred) # Add rest to result.
    result.extend(more_preds)
    return result

def runRNN(seqLen):
    # Generate result folders for result and models.
    if not isdir(MODEL_STORAGE):
        makedirs(MODEL_STORAGE)
    
    if not isdir(RESULT_STORAGE):
        makedirs(RESULT_STORAGE)
    
    # Generate folders for tunes storage.
    if not isdir(TUNE_STORAGE):
        makedirs(TUNE_STORAGE)
    
    PRE_PROCESS_STORE = '%spre_proecessed_seq%d_%s'%(DATA_STORAGE, MAX_SEQ_LEN, QUESTION_ID)
    preprocesspkl = '%s.pkl'%(PRE_PROCESS_STORE)
    preprocesstxt = '%s.txt'%(PRE_PROCESS_STORE)    
    
    if not isfile(preprocesspkl):
        print "Read data from file %s."%(preprocesspkl)
        tunes = loadTunes()
        print "Encode chars to ints."
        encoded_tunes, label_encoder = label2code(tunes)
        print "Chop txt to sequences of %d length" %(MAX_SEQ_LEN)
        X, y = prepDataSeq(encoded_tunes, MAX_SEQ_LEN)
        print "Found total %d sequences"%(len(X))
        x_train, y_train, x_valid, y_valid = partition(X, y)
        print "Done partition."
        data = x_train, y_train, x_valid, y_valid, encoded_tunes, label_encoder
        savePkl(data, preprocesspkl)
    else:
        x_train, y_train, x_valid, y_valid, encoded_tunes, label_encoder = loadPkl(preprocesspkl)
        
    f = open(preprocesstxt, 'w')
    for seq in x_train:
        f.write(''.join(label_encoder.inverse_transform(seq)))
        f.write('\n------\n')
    print "Done saving."
    
    nClasses =len(list(label_encoder.classes_))
    print "There are %d tunes. %d classes."%(len(encoded_tunes), nClasses)
    print "%d sequences for training, %d sequences for testing"%(len(x_train), len(x_valid))
    #print label_encoder.classes_

    model = getModel(nClasses)
    trainModel(model, seqLen, x_train, y_train, x_valid, y_valid, nClasses, encoded_tunes, label_encoder , INCREMENT_TRAINING)

def show_values(pc, ax, dchar, fmt="%s", **kw):
    unvisible_char = dict()
    unvisible_char['\t'] = 'bt'
    unvisible_char['\n'] = 'bn'
    unvisible_char['\r'] = 'br'
    unvisible_char[' '] = 'sp'
    unvisible_char[chr(127)] = ''

    pc.update_scalarmappable()
    for p, color, char in izip(pc.get_paths(), pc.get_facecolors(), dchar):
        x, y = p.vertices[:-2, :].mean(0)
        if np.all(color[:3] > 0.5):
            color = (0.0, 0.0, 0.0)
        else:
            color = (1.0, 1.0, 1.0)
        
        if char in unvisible_char:
            char = unvisible_char[char]
        ax.text(x, y, fmt % char, ha="center", va="center", color=color, **kw)
    
if __name__ == "__main__":
    model = getModel()
    model.load_weights(WEIGHT_FILE)

    nmodel = Model(input=model.input, output=model.layers[-2].output)
    nmodel.summary()

    PRE_PROCESS_STORE = '%spre_proecessed_seq%d_%s'%(DATA_STORAGE, MAX_SEQ_LEN, QUESTION_ID)
    preprocesspkl = '%s.pkl'%(PRE_PROCESS_STORE)
    print "Read data from file %s."%(preprocesspkl)
    tunes = loadTunes()
    print "Encode chars to ints."
    encoded_tunes, label_encoder = label2code(tunes)
    
    nClasses = len(list(label_encoder.classes_))

    print "Read data from file generated music file."
    tunes = loadTunes('../result/tunes/tune_Q4e/240.txt')
    print "Encode chars to ints."
    encoded_tunes = map(label_encoder.transform, tunes)

    X = encoded_tunes[5]
    n = len(X)
    print 'Length of selected tune: %d'%(n)

    for neuronID in range(100):
        print 'Choosing NeuronID: %d'%(neuronID)

        echar = []
        value = []
        x_seqs = np.array([X for i in xrange(BATCH_SIZE)])
        for i in range(n):
            # conver every feature to (numsample, lenth, dim) format. 
            # here x_hot is in (batch_size, 1, nClasses) format
            # y_hot is in (batch_size, nClasses) format
            x_hot = np_utils.to_categorical(x_seqs[:, [i]], nClasses)
            x_hot = np.expand_dims(x_hot, axis=1)

            a_pred = nmodel.predict_on_batch(x_hot)

            echar.append(x_seqs[0, i])
            value.append(a_pred[0, neuronID])

        dchar = label_encoder.inverse_transform(echar)
        dchar = np.hstack((dchar, np.array([chr(127) for i in xrange(256-n)])))
        value = np.hstack((value, np.array([0 for i in xrange(256-n)])))
        value = np.reshape(value, (16,16))

        fig, ax = plt.subplots()
        heatmap = ax.pcolor(value, edgecolors='k', linestyle= 'dashed', linewidths=0.2, cmap='RdBu', vmin=-1.0, vmax=1.0)
        plt.gca().invert_yaxis()

        plt.colorbar(heatmap)
        show_values(heatmap, ax, dchar)
        plt.savefig('../result/heatmaps/heatmap_' + str(neuronID) + '.png', dpi=200)
