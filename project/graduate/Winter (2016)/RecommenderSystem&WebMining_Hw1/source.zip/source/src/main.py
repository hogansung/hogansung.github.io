import numpy as np
import pandas as pd
import urllib2
import scipy.optimize
import random
from sklearn import svm
from sklearn import metrics
from sklearn import preprocessing


## Task 1
def parseData(fname):
  for l in urllib2.urlopen(fname):
    yield eval(l)

# read data
data = list(parseData('file:///Users/hogan/Google Drive/Courses/UCSD/258/Hw1/dat/beer_50000.json'))

# generate features
ndata = [d for d in data if d.has_key('review/timeStruct')]
X = [[1, d['review/timeStruct']['year']] for d in ndata]
y = [d['review/overall'] for d in ndata]

# fit model
theta,residuals,rank,s = np.linalg.lstsq(X, y)
print 'Coefficients:', theta
print 'MSE:', residuals[0] / len(ndata)


## Task 2

# generate features
ndata = [d for d in data if d.has_key('review/timeStruct')]
X = [[1, d['review/timeStruct']['year'], \
        d['review/timeStruct']['year']^2, \
        d['review/timeStruct']['year']^3, \
        np.log(d['review/timeStruct']['year'])] for d in ndata]
y = [d['review/overall'] for d in ndata]

# fit model
theta,residuals,rank,s = np.linalg.lstsq(X, y)
print 'Coefficients:', theta
print 'MSE:', residuals[0] / len(ndata)


## Task 3
# read data
data = pd.read_csv('../dat/winequality-white.csv', sep=';')
nr, nc = data.shape

# generate features
X = data[['fixed acidity','volatile acidity','citric acid',\
        'residual sugar','chlorides','free sulfur dioxide',\
        'total sulfur dioxide','density','pH','sulphates','alcohol']]
X['constant'] = np.ones([data.shape[0], 1])
y = data[['quality']]

# split data
tn_X = X[:nr/2]
tn_y = y[:nr/2]
tt_X = X[nr/2:]
tt_y = y[nr/2:]

# fit model
theta,residuals,rank,s = np.linalg.lstsq(tn_X, tn_y)
print 'Coefficients:', theta
print 'MSE for tn:', residuals[0] / (nr/2)

# predict test
tt_p = tt_X.dot(theta)
tt_p.columns = ['predict']

# calculate error
print 'MSE for tt:', \
        np.linalg.norm(tt_p['predict']-tt_y['quality'])**2 / (nr/2)


## Task 4
# enumerate dropped feature
for i in range(11):
    # generate features
    colnames = [list(X)[idx] for idx in range(1,i) + range(i+1,12)]
    nX = X[colnames]

    # split data
    tn_X = nX[:nr/2]
    tn_y = y[:nr/2]
    tt_X = nX[nr/2:]
    tt_y = y[nr/2:]

    # fit model
    theta,residuals,rank,s = np.linalg.lstsq(tn_X, tn_y)
    #print 'Coefficients:', theta
    #print 'MSE for tn:', residuals[0] / (nr/2)

    # predict test
    tt_p = tt_X.dot(theta)
    tt_p.columns = ['predict']

    # calculate error
    tt_e = np.linalg.norm(tt_p['predict']-tt_y['quality'])**2 / (nr/2)
    print 'MSE for tt (w/o ' + list(X)[i] + '):', tt_e


## Task 5
# create labels
y = (y > 5).astype(int)

# split data
tn_X = X[:nr/2]
tn_y = y[:nr/2].iloc[:,0]
tt_X = X[nr/2:]
tt_y = y[nr/2:].iloc[:,0]

# learn
clf = svm.SVC(C=1)
clf.fit(tn_X, tn_y)

# predict
tn_p = clf.predict(tn_X)
tt_p = clf.predict(tt_X)

# calculate error
tn_a = metrics.accuracy_score(tn_y, tn_p)
print 'ACC for tn', tn_a
tt_a = metrics.accuracy_score(tt_y, tt_p)
print 'ACC for tt', tt_a


## Task 6
eps = 1e-10

# utility functions
def calLOSS(w, x, y, p, lb1, lb2):
    assert(x.shape[0] == y.shape[0])

    val = 0.0
    for i in xrange(x.shape[0]):
        val -= y[i] * np.log(p[i]+eps) + (1-y[i]) * np.log(1-p[i]+eps)

    val += lb1 * np.linalg.norm(w, 1)
    val += lb2 * np.linalg.norm(w, 2)
    return val

def calLL(x, y, p):
    assert(x.shape[0] == y.shape[0])

    val = 0.0
    for i in xrange(x.shape[0]):
        val += y[i] * np.log(p[i]+eps) + (1-y[i]) * np.log(1-p[i]+eps)
    return val

def calACC(w, x, y, p):
    assert(x.shape[0] == y.shape[0] and y.shape[0] == p.shape[0])
    return 1.0 / x.shape[0] * np.sum(y == (p > 0.5))

def sigmoid(z):
    return 1.0 / (1 + np.exp(-z))

def predict(w, x):
    v = np.dot(x, np.transpose(w))
    return np.apply_along_axis(sigmoid, 0, v)

def LogisticRegression(x, y, lb1=0, lb2=0, \
        MAX_ITER=200, eta=0.001, eta_decay=0.01):
    assert(x.shape[0] == y.shape[0])
    ft_n = x.shape[1]

    w = np.zeros((1, ft_n))
    p = predict(w, x);
    e = calLOSS(w, x, y, p, lb1, lb2)

    for t in xrange(MAX_ITER):
        nw = np.dot((y-p).transpose(),x) - lb1*np.sign(w) - lb2*2*w

        n_eta = eta / (1 + t * eta_decay)
        w += n_eta * nw
        
        # predict
        p = predict(w, x)

        # calculate err
        err = calLOSS(w, x, y, p, lb1, lb2)

        # stop condition
        if err < 0.1 * e:
            print 'Stop at #' + str(t) + ' with log-likelihood ' \
                    + str(calLL(x, y, p))
            return w

    print 'Maximum iterations are reached with log-likelihood ' \
            + str(calLL(x, y, p))
    
    return w

# transform to ndarray
tn_X = tn_X.as_matrix()
tn_y = tn_y.as_matrix().reshape((-1,1))
tt_X = tt_X.as_matrix()
tt_y = tt_y.as_matrix().reshape((-1,1))

## preprocessing
tn_X = preprocessing.scale(tn_X)
tt_X = preprocessing.scale(tt_X)

# learn 
w = LogisticRegression(tn_X, tn_y)

# predict
tn_p = predict(w, tn_X)
tt_p = predict(w, tt_X)

# calculate accuracy
tn_a = calACC(w, tn_X, tn_y, tn_p)
print 'ACC for tn', tn_a
tt_a = calACC(w, tt_X, tt_y, tt_p)
print 'ACC for tt', tt_a
