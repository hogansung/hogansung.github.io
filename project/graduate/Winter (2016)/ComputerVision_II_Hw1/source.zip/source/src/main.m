%% Read Files
preI = imread('../dat/price_center20.JPG');
preI = rgb2gray(preI);
nxtI = imread('../dat/price_center21.JPG');
nxtI = rgb2gray(nxtI);

%% Parameters
lambda_threshold = 2200;
nw = 7;

%% Write Original Figures
res = figure('visible','off');
ha = tight_subplot(1, 2, 0.02, 0.01, 0.01);

axes(ha(1));
imshow(preI);

axes(ha(2));
imshow(nxtI);

saveas(res, '../res/pc_origin.jpg');

%% Extract Features
pref = featureDetect(preI, lambda_threshold, nw);
fprintf('Number of extracted features: %d\n', size(pref, 1));
nxtf = featureDetect(nxtI, lambda_threshold, nw);
fprintf('Number of extracted features: %d\n', size(nxtf, 1));

%% Write Feature-Deteced Figures
res = figure('visible','off');
ha = tight_subplot(1, 2, 0.02, 0.01, 0.01);

axes(ha(1));
imshow(preI);
hold on
for i = 1:size(pref,1)
    plot(pref(i,1),pref(i,2),'bs', 'MarkerSize', nw);
end
hold off

axes(ha(2));
imshow(nxtI);
hold on
for i = 1:size(nxtf,1)
    plot(nxtf(i,1),nxtf(i,2),'bs', 'MarkerSize', nw);
end
hold off

saveas(res, '../res/pc_detect.jpg');

%% Match Features
[lx, ly, lu, lv, rx, ry] = featureMatch(preI, nxtI, pref, nxtf, nw);
fprintf('Number of matches: %d\n', size(lx, 2));

%% Draw Figures
res = figure('visible','off');

ha = tight_subplot(1, 2, 0.02, 0.01, 0.01);
axes(ha(1));
imshow(preI);
hold on
for i = 1:size(lx,2)
    plot(lx, ly, 'bs', 'MarkerSize', nw);
end
quiver(lx, ly, lu, lv, 0);
hold off

axes(ha(2));
imshow(nxtI);
hold on
for i = 1:size(rx,2)
    plot(rx, ry, 'bs', 'MarkerSize', nw);
end
quiver(rx, ry, -lu, -lv, 0);
hold off

saveas(res, '../res/pc_match.jpg');