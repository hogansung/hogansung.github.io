#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <Eigen/Dense>
#include <random>

using namespace std;
using namespace Eigen;


// Parameters 
int num_tn = 200000;
const int num_stn = 180000;
int num_vld = num_tn - num_stn;
const int num_user = 39249;
const int num_item = 19913;
const int num_latent = 30;
const double learn_rate = 1.2;
const double learn_rate_decay = 0.0001;
const double lambda = 30;
const double momentum = 0.9;
const double momentum_increase = 0.0001;
const double mf_p = 1.0;
const double in_p = 1.0;
const int MAX_ITER = 5000;
const double threshold_prefer = 5;
const double eps = 1e-9;

struct Tuple {
    int user;
    int item;
    double rate;
    Tuple() {}
    Tuple(int u, int i, double r): user(u), item(i), rate(r) {}
};

default_random_engine generator;
//normal_distribution<double> distribution(0.0,1.0/sqrt(num_latent));
uniform_real_distribution<double> distribution(0.0,1.0/sqrt(num_latent));

unordered_map<string, double> map_user_idx;
unordered_map<int, string> map_idx_user;
unordered_map<string, double> map_item_idx;
unordered_map<double, string> map_idx_item;
unordered_map<int, vector<int>> user_prefer;
unordered_map<int, vector<int>> item_prefer;

vector<Tuple> tn_tuple;
vector<Tuple> stn_tuple;
vector<Tuple> vld_tuple;

char in[100010];

// Read Mappings
void readMappings() {
    { // user part
        FILE* pfile = fopen("../tab/userList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_user; i++) {
            fscanf(pfile, "%s", in);
            map_user_idx[in] = i;
            map_idx_user[i] = in;
        }
        fclose(pfile);
    }
    { // item part
        FILE* pfile = fopen("../tab/itemList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_item; i++) {
            fscanf(pfile, "%s", in);
            map_item_idx[in] = i;
            map_idx_item[i] = in;
        }
        fclose(pfile);
    }
}

// Read Data
void readData() {
    FILE* pfile = fopen("../dat/train.dat", "r");
    assert(pfile != NULL);
    char c_user[21], c_item[21];
    double rate;
    for (int i = 0; i < num_tn; i++) {
        fscanf(pfile, "%s%s%lf", c_user, c_item, &rate);
        if (map_user_idx.find(c_user) != map_user_idx.end() and
          map_item_idx.find(c_item) != map_item_idx.end()) {
            tn_tuple.emplace_back(map_user_idx[c_user], map_item_idx[c_item], rate);
        }
    }
    fclose(pfile);

    // Split subtrain, validation
    num_tn = tn_tuple.size(); 
    printf("%d\n", num_tn);
    num_vld = num_tn - num_stn;
    random_shuffle(tn_tuple.begin(), tn_tuple.end());
    for (int i = 0; i < num_stn; i++) {
        stn_tuple.emplace_back(tn_tuple[i]);
    }
    for (int i = 0; i < num_vld; i++) {
        vld_tuple.emplace_back(tn_tuple[num_stn + i]);
    }

    // Preference
    for (int i = 0; i < num_stn; i++) {
        if (stn_tuple[i].rate >= threshold_prefer) {
            user_prefer[stn_tuple[i].user].emplace_back(stn_tuple[i].item);
        }
    }
}

double calERR(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& P, MatrixXd& Q, MatrixXd& X) {
    double err = 0;
    for (int i = 0; i < size; i++) {
        double diff = (pred[i] - data[i].rate);
        err += diff * diff;
    }
    err += lambda * (Bu.squaredNorm() + Bi.squaredNorm() + mf_p * (P.squaredNorm() + Q.squaredNorm()));
    err += lambda * X.squaredNorm();
    return err;
}

double calRMSE(vector<Tuple>& data, vector<double>& pred, int size) {
    double err = 0;
    for (int i = 0; i < size; i++) {
        double diff = (pred[i] - data[i].rate);
        err += diff * diff;
    }
    return sqrt(err / data.size());
}

void predict(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& P, MatrixXd& Q, MatrixXd& sX) {
    for (int i = 0; i < size; i++) {
        int user = data[i].user;
        int item = data[i].item;
        if (sX.row(user).norm() < eps) {
            pred[i] = A + Bu(user,0) + Bi(item,0) + 
              mf_p * P.row(user) * Q.row(item).transpose();
        } else {
            pred[i] = A + Bu(user,0) + Bi(item,0) + 
              mf_p * (P.row(user) + in_p * pow(sX.row(user).norm(), -0.5) * sX.row(user)) * Q.row(item).transpose();
        }
    }
}

void baseline() {
    unordered_map<int, double> sum;
    unordered_map<int, int> cnt;
    double gsum = 0;
    int gcnt = 0;
    for (auto tuple: stn_tuple) {
        int user = tuple.user;
        double rate = tuple.rate;
        sum[user] += rate;
        cnt[user] += 1;
        gsum += rate;
        gcnt += 1;
    }

    double err = 0;
    for (auto tuple: vld_tuple) {
        int user = tuple.user;
        double rate = tuple.rate;
        double p;
        if (sum.find(user) != sum.end()) {
            p = sum[user] / cnt[user];
        } else {
            p = gsum / gcnt;
        }
        printf("%f %f\n", p, rate);
        double diff = p - rate;
        err += diff * diff;
    }
    printf("%f\n", sqrt(err/num_vld));
    exit(0);
}

void setRandom(MatrixXd& M, int nr, int nc) {
    for (int i = 0; i < nr; i++) {
        for (int j = 0; j < nc; j++) {
            M(i, j) = distribution(generator);
        }
    }
}

void saveModel(double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& P, MatrixXd& Q) {
    /* Meta Information
     * num_user num_item 
     * A (1, 1)
     * Bu (1, num_user)
     * Bi (1, num_item) */
    {
        FILE* pfile = fopen("../mdl/meta.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_item);
        fprintf(pfile, "%f\n", A);
        for (int i = 0; i < num_user; i++) {
            fprintf(pfile, "%f%c", Bu(i,0), i == num_user-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_item; i++) {
            fprintf(pfile, "%f%c", Bi(i,0), i == num_item-1 ?'\n' :' ');
        }
    }

    /* User Matrix: 
     * num_user num_latent 
     * P (num_user, num_latent) */
    {
        FILE* pfile = fopen("../mdl/user.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_latent);
        for (int i = 0; i < num_user; i++) {
            for (int j = 0; j < num_latent; j++) {
                fprintf(pfile, "%f%c", P(i, j), j == num_latent-1 ?'\n' :' ');
            }
        }
        fclose(pfile);
    }

    /* Item Matrix: 
     * num_item num_latent 
     * Q (num_item, num_latent) */
    {
        FILE* pfile = fopen("../mdl/item.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_item, num_latent);
        for (int i = 0; i < num_item; i++) {
            for (int j = 0; j < num_latent; j++) {
                fprintf(pfile, "%f%c", Q(i, j), j == num_latent-1 ?'\n' :' ');
            }
        }
        fclose(pfile);
    }
}

int main() {
    srand(514);

    readMappings();
    readData();

    //baseline();

    double A = distribution(generator);
    MatrixXd Bu = MatrixXd::Zero(num_user, 1);
    setRandom(Bu, num_user, 1);
    MatrixXd Bi = MatrixXd::Zero(num_item, 1);
    setRandom(Bi, num_item, 1);
    MatrixXd P = MatrixXd::Zero(num_user, num_latent);
    setRandom(P, num_user, num_latent);
    MatrixXd Q = MatrixXd::Zero(num_item, num_latent);
    setRandom(Q, num_item, num_latent);
    MatrixXd X = MatrixXd::Zero(num_item, num_latent);
    setRandom(X, num_item, num_latent);

    double nA = 0;
    MatrixXd nBu = MatrixXd::Zero(num_user, 1);
    MatrixXd nBi = MatrixXd::Zero(num_item, 1);
    MatrixXd nP = MatrixXd::Zero(num_user, num_latent);
    MatrixXd nQ = MatrixXd::Zero(num_item, num_latent);
    MatrixXd nX = MatrixXd::Zero(num_item, num_latent);

    MatrixXd sX = MatrixXd::Zero(num_user, num_latent);
    for (int i = 0; i < num_user; i++) {
        for (auto t : user_prefer[i]) {
            sX.row(i) += X.row(t);
        }
    }

    vector<double> stn_p(num_stn, 0);
    vector<double> vld_p(num_vld, 0);
    predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, P, Q, sX);
    predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, P, Q, sX);

    int cnt = 0;
    double last_vld_err = calERR(vld_tuple, vld_p, num_vld, A, Bu, Bi, P, Q, X);
    for (int time = 0; time < MAX_ITER; time++) {
        double n_learn_rate = learn_rate / (1 + learn_rate_decay * time) / num_stn;
        double n_momentum = momentum * (1 + momentum_increase * time);

        /* momentum */
        nA *= n_momentum;
        nBu *= n_momentum;
        nBi *= n_momentum;
        nP *= n_momentum;
        nQ *= n_momentum;
        nX *= n_momentum;

        for (int i = 0; i < num_stn; i++) {
            int user = stn_tuple[i].user;
            int item = stn_tuple[i].item;
            double diff = (stn_p[i] - stn_tuple[i].rate);

            nA += 2 * diff;
            nBu(user,0) += 2 * diff;
            nBi(item,0) += 2 * diff;
            nP.row(user) += 2 * diff * Q.row(item);
            if (sX.row(user).norm() < eps) {
                nQ.row(item) += 2 * diff * P.row(user);
            } else {
                nQ.row(item) += 2 * diff * (P.row(user) + in_p * pow(sX.row(user).norm(), -0.5) * sX.row(user));
            }
            for (auto t : user_prefer[user]) {
                nX.row(t) += 2 * diff * Q.row(item) * 
                  (pow(sX.row(user).norm(), -0.5) + 
                   -0.5 * pow(sX.row(user).norm(), -2.5) * sX.row(user) * X.row(t).transpose());
            }
        }

        for (int i = 0; i < num_user; i++) {
            nBu(i,0) += lambda * 2 * Bu(i,0);
            nP.row(i) += lambda * 2 * P.row(i);
        }

        for (int i = 0; i < num_item; i++) {
            nBi(i,0) += lambda * 2 * Bi(i,0);
            nQ.row(i) += lambda * 2 * Q.row(i);
            nX.row(i) += lambda * 2 * X.row(i);
        }

        /* apply gradient */
        A -= n_learn_rate * nA;
        Bu -= n_learn_rate * nBu;
        Bi -= n_learn_rate * nBi;
        P -= n_learn_rate * nP;
        Q -= n_learn_rate * nQ;
        X -= n_learn_rate * nX;

        /* Update sX */
        sX *= 0;
        for (int i = 0; i < num_user; i++) {
            for (auto t : user_prefer[i]) {
                sX.row(i) += X.row(t);
            }
        }

        /* predict */
        predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, P, Q, sX);
        predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, P, Q, sX);

        if (time % 100 != 0) continue;
        double stn_rmse = calRMSE(stn_tuple, stn_p, num_stn);
        double vld_rmse = calRMSE(vld_tuple, vld_p, num_vld);
        double stn_err = calERR(stn_tuple, stn_p, num_stn, A, Bu, Bi, P, Q, X);
        double vld_err = calERR(vld_tuple, vld_p, num_vld, A, Bu, Bi, P, Q, X);
        printf("%d %f %f %f %f\n", time, stn_rmse, vld_rmse, stn_err, vld_err);

        if (last_vld_err <= vld_err) {
            cnt += 1;
        } else {
            last_vld_err = vld_err;
            cnt = 0;
        }

        if (cnt == 3) {
            //printf("Stop at #%d\n", time);
            //break;
        }
    }

    /* Save model */
    saveModel(A, Bu, Bi, P, Q);
}
