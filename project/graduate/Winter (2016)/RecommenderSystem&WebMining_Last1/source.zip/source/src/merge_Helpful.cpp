#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

const int num_tn = 200000;
const int num_stn = 140000;
const int num_vld = num_tn-num_stn;
const int num_tt = 14000;
const int num_rg = 10;

int main() {
    int best_i, best_j, best_k;
    {   
        // train phase
        vector<string> models{"SVR", "GBR", "RFR", "LABEL"};
        vector<vector<double>> scores(4, vector<double>(num_tn));
        
        // read files
        for (int i = 0; i < 4; i++) {
            string fn = "../mdl_Helpful/pred_" + models[i] + ".txt";
            FILE* pfile = fopen(fn.c_str(), "r");
            if (pfile == NULL) {
                fprintf(stderr, "Cannot open file");
                exit(EXIT_FAILURE);
            }

            for (int j = 0; j < num_tn; j++) {
                fscanf(pfile, "%lf", &scores[i][j]);
            }

            fclose(pfile);
        }

        double best_stn_mae, best_vld_mae = 1000000;
        for (int i = 0; i <= num_rg; i++) {
            for (int j = 0; j <= num_rg; j++) {
                for (int k = 0; k <= num_rg; k++) {
                    if (i+j+k == 0) continue;

                    double stn_mae = 0;
                    for (int l = 0; l < num_stn; l++) {
                        double p = (scores[0][l]*i + scores[1][l]*j + scores[2][l]*k) / (i+j+k);
                        double y = scores[3][l];
                        stn_mae += abs(p-y);
                    }
                    stn_mae /= num_stn;

                    double vld_mae = 0;
                    for (int l = num_stn; l < num_tn; l++) {
                        double p = (scores[0][l]*i + scores[1][l]*j + scores[2][l]*k) / (i+j+k);
                        double y = scores[3][l];
                        vld_mae += abs(round(p)-y);
                    }
                    vld_mae /= num_vld;

                    if (vld_mae < best_vld_mae) {
                        best_stn_mae = stn_mae;
                        best_vld_mae = vld_mae;
                        best_i = i;
                        best_j = j;
                        best_k = k;
                    }
                }
            }
        }
        printf("%f %f: %d %d %d\n", best_stn_mae, best_vld_mae, best_i, best_j, best_k);
    }

    {
        // test phase
        vector<string> models{"SVR", "GBR", "RFR"};
        vector<vector<double>> scores(3, vector<double>(num_tn));
        char c_input[50];
        char colname[50];
        vector<string> rownames(num_tt, string(""));
        
        // read files
        for (int i = 0; i < 3; i++) {
            string fn = "../pred/predict_Helpful_" + models[i] + ".txt";
            FILE* pfile = fopen(fn.c_str(), "r");
            if (pfile == NULL) {
                fprintf(stderr, "Cannot open file");
                exit(EXIT_FAILURE);
            }

            fscanf(pfile, "%s", colname);
            for (int j = 0; j < num_tt; j++) {
                fscanf(pfile, "%s", c_input);
                string input = c_input;
                int pos = input.find(",");
                rownames[j] = input.substr(0, pos);
                scores[i][j] = strtod(input.substr(pos+1, string::npos).c_str(), 0);
            }

            fclose(pfile);
        }

        // write files
        string fn = "../pred/predict_Helpful_ensemble.txt";
        FILE* pfile = fopen(fn.c_str(), "w");
        if (pfile == NULL) {
            fprintf(stderr, "Cannot open file");
            exit(EXIT_FAILURE);
        }

        fprintf(pfile, "%s\n", colname);
        for (int i = 0; i < num_tt; i++) {
            double p = (scores[0][i]*best_i + scores[1][i]*best_j + scores[2][i]*best_k) 
              / (best_i+best_j+best_k);
            fprintf(pfile, "%s,%f\n", rownames[i].c_str(), round(p));
        }

        fclose(pfile);
    }
}
