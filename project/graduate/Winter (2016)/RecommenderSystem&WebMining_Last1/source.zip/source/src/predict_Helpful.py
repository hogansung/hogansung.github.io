import numpy as np
import gzip
from collections import defaultdict
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.svm import SVR, LinearSVR
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor


# three models
models = ['SVR', 'GBR', 'RFR', 'LABEL']
model = models[3]

# two modes
modes = ['PRED', 'GEN']
mode = modes[1]

if model == 'SVR':
    clf = SVR(C=0.03, epsilon=0, cache_size=2000, verbose=2, shrinking=False)
elif model == 'GBR':
    clf = GradientBoostingRegressor(loss='ls', n_estimators=80, max_depth=5, learning_rate=0.1, random_state=514, verbose=0)
else:
    clf = RandomForestRegressor(n_estimators=80, max_depth=8, random_state=514)

num_tn = 200000
num_stn = 140000
num_vld = num_tn-num_stn
num_tt = 14000

def readGz(f):
  for l in gzip.open(f):
    yield eval(l)


## TRAIN PHASE
# read data
tn_data = list(readGz('../dat/train.json.gz'))

# generate fatures
stn_X = np.array([[1, len(d['reviewText'].split(' ')), d['rating'], d['helpful']['outOf']] for d in tn_data[:num_stn]])
stn_y = np.array([0 if d['helpful']['outOf'] == 0 \
        else 1.0 * d['helpful']['nHelpful'] / d['helpful']['outOf'] \
        for d in tn_data[:num_stn]])
stn_d = np.array([d['helpful']['outOf'] for d in tn_data[:num_stn]])

vld_X = np.array([[1, len(d['reviewText'].split(' ')), d['rating'], d['helpful']['outOf']] for d in tn_data[num_stn:]])
vld_y = np.array([0 if d['helpful']['outOf'] == 0 \
        else 1.0 * d['helpful']['nHelpful'] / d['helpful']['outOf'] \
        for d in tn_data[num_stn:]])
vld_d = np.array([d['helpful']['outOf'] for d in tn_data[num_stn:]])

# fit model
print 'start train model: ' + model
clf.fit(stn_X[stn_X[:,3] != 0], stn_y[stn_X[:,3] != 0])
print 'end train model'

if mode == 'PRED':
    # predict
    stn_p = np.zeros(shape=(num_stn,))
    vld_p = np.zeros(shape=(num_vld,))
    stn_p[stn_X[:,3] != 0] = clf.predict(stn_X[stn_X[:,3] != 0])
    vld_p[vld_X[:,3] != 0] = clf.predict(vld_X[vld_X[:,3] != 0])
    stn_rp = np.array([min(max(round(p), 0), y) for y, p in zip(stn_d, stn_p*stn_d)])
    vld_rp = np.array([min(max(round(p), 0), y) for y, p in zip(vld_d, vld_p*vld_d)])

    # calculate error
    stn_mae_err = mean_absolute_error(stn_y*stn_d, stn_rp)
    vld_mae_err = mean_absolute_error(vld_y*vld_d, vld_rp)
    print 'MAE for Subtrain: ', stn_mae_err
    print 'MAE for Validate: ', vld_mae_err
elif model == 'LABEL':
    with open('../mdl_Helpful/pred_' + model + '.txt', 'w') as wf:
        for y in stn_y*stn_d:
            wf.write(str(y) + '\n')
        for y in vld_y*vld_d:
            wf.write(str(y) + '\n')
    exit(0)
else:
    # predict
    stn_p = np.zeros(shape=(num_stn,))
    vld_p = np.zeros(shape=(num_vld,))
    stn_p[stn_X[:,3] != 0] = clf.predict(stn_X[stn_X[:,3] != 0])
    vld_p[vld_X[:,3] != 0] = clf.predict(vld_X[vld_X[:,3] != 0])
    stn_rp = np.array([min(max(p, 0), y) for y, p in zip(stn_d, stn_p*stn_d)])
    vld_rp = np.array([min(max(p, 0), y) for y, p in zip(vld_d, vld_p*vld_d)])

    with open('../mdl_Helpful/pred_' + model + '.txt', 'w') as wf:
        for p in stn_rp:
            wf.write(str(p) + '\n')
        for p in vld_rp:
            wf.write(str(p) + '\n')
    exit(0)


## TEST PHASE
tt_data = list(readGz('../dat/test_Helpful.json.gz'))

# generate fatures
tn_X = np.vstack((stn_X, vld_X))
tn_y = np.hstack((stn_y, vld_y))
tn_d = np.hstack((stn_d, vld_d))

tt_X = np.array([[1, len(d['reviewText'].split(' ')), d['rating'], d['helpful']['outOf']] for d in tt_data])
tt_d = np.array([d['helpful']['outOf'] for d in tt_data])

# fit model
clf.fit(tn_X[tn_X[:,3] != 0], tn_y[tn_X[:,3] != 0])

# predict 
tn_p = np.zeros(shape=(num_tn,))
tt_p = np.zeros(shape=(num_tt,))
tn_p[tn_X[:,3] != 0] = clf.predict(tn_X[tn_X[:,3] != 0])
tt_p[tt_X[:,3] != 0] = clf.predict(tt_X[tt_X[:,3] != 0])
tn_rp = np.array([min(max(round(p), 0), y) for y, p in zip(tn_d, tn_p*tn_d)])
tt_rp = np.array([min(max(round(p), 0), y) for y, p in zip(tt_d, tt_p*tt_d)])

# calculate error
tn_err = mean_absolute_error(tn_y*tn_d, tn_rp)
print 'MAE for Train: ', tn_err

# record results in dict
resMap = {}
for d, p in zip(tt_data, tt_rp):
    uid = d['reviewerID']
    iid = d['itemID']
    resMap[uid + '-' + iid] = p

# write results in file
with open('../dat/pairs_Helpful.txt') as f, \
        open('../pred/predict_Helpful_' + model + '.txt', 'w') as wf:
    lines = f.readlines()
    wf.write(lines[0])
    for line in lines[1:]:
        line = line.strip()
        uid, iid, outOf = line.split(' ')
        wf.write('-'.join([uid, iid, outOf]) + ',' \
                + str(resMap[uid + '-' + iid]) + '\n')
