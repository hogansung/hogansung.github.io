#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <Eigen/Dense>
#include <random>

using namespace std;
using namespace Eigen;

// Parameters 
const int num_tn = 200000;
const int num_stn = 50000;
const int num_vld = num_tn - num_stn;
const int num_user = 39249;
const int num_item = 19913;
const int num_cate = 5;
const int num_rate = 6;
const double lambda = 10;
const int MAX_ITER = 100;
const double eps = 1e-6;

struct Tuple {
    int user;
    int item;
    int cate;
    int rate;
    int nHelpful;
    int outOf;
    double ratio;
    Tuple() {}
    Tuple(int u, int i, int c, int r, int h, int o, double rt): 
        user(u), item(i), cate(c), rate(r), nHelpful(h), outOf(o), ratio(rt) {}
};

unordered_map<string, int> map_user_idx;
unordered_map<int, string> map_idx_user;
unordered_map<string, int> map_item_idx;
unordered_map<int, string> map_idx_item;

vector<Tuple> tn_tuple;
vector<Tuple> stn_tuple;
vector<Tuple> vld_tuple;

unordered_map<int, double> user_sum;
unordered_map<int, int> user_cnt;
unordered_map<int, double> item_sum;
unordered_map<int, int> item_cnt;
double sum;
int cnt;

char in[100010];

// Read Mappings
void readMappings() {
    { // user part
        FILE* pfile = fopen("../tab/userList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_user; i++) {
            fscanf(pfile, "%s", in);
            map_user_idx[in] = i;
            map_idx_user[i] = in;
        }
        fclose(pfile);
    }
    { // item part
        FILE* pfile = fopen("../tab/itemList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_item; i++) {
            fscanf(pfile, "%s", in);
            map_item_idx[in] = i;
            map_idx_item[i] = in;
        }
        fclose(pfile);
    }
}

// Read Data
void readData() {
    FILE* pfile = fopen("../dat/train_Helpful.dat", "r");
    assert(pfile != NULL);
    char c_user[21], c_item[21];
    int cate, rate, nHelpful, outOf, time, nw, nl;

    for (int i = 0; i < num_tn; i++) {
        fscanf(pfile, "%s%s%d%d%d%d%d%d%d", c_user, c_item, &cate, &rate, &nHelpful, &outOf, &time, &nw, &nl);

        double ratio = outOf == 0 ?0 :1.0 * nHelpful / outOf;
        int user = map_user_idx.at(c_user);
        int item = map_item_idx.at(c_item);
        tn_tuple.emplace_back(user, item, cate, rate, nHelpful, outOf, ratio);

        if (i < num_stn and outOf != 0) {
            user_sum[user] += ratio;
            user_cnt[user] += 1;
            item_sum[item] += ratio;
            item_cnt[item] += 1;
            sum += ratio;
            cnt += 1;
        }
    }
    fclose(pfile);

    for (int i = 0; i < num_stn; i++) {
        stn_tuple.emplace_back(tn_tuple[i]);
    }
    for (int i = 0; i < num_vld; i++) {
        vld_tuple.emplace_back(tn_tuple[num_stn + i]);
    }
}

double calERR(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& Br) {
    assert(data.size() == size and pred.size() == size);
    double err = 0;
    for (int i = 0; i < size; i++) {
        double ratio = data[i].ratio;
        double diff = (pred[i] - ratio);
        //double diff = (pred[i] - data[i].nHelpful);
        err += diff*diff;
        //err += abs(diff);
    }
    err += lambda * (Bu.squaredNorm() + Bi.squaredNorm() + Bc.squaredNorm() + Br.squaredNorm());
    return err;
}

double calMAE(vector<Tuple>& data, vector<double>& pred, int size) {
    assert(data.size() == size and pred.size() == size);
    double err = 0;
    for (int i = 0; i < size; i++) {
        double p = min(max(int(round(pred[i]*data[i].outOf)),0),data[i].outOf);
        int diff = (p - data[i].nHelpful);
        err += abs(diff);
    }
    return err / data.size();
}

/* Note that the prediction is round to closest integer */
void predict(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& Br) {
    for (int i = 0; i < size; i++) {
        int user = data[i].user;
        int item = data[i].item;
        int cate = data[i].cate;
        int rate = data[i].rate;
        if (data[i].outOf == 0) {
            pred[i] = 0;
        } else {
            //int outOf = data[i].outOf;
            pred[i] = A + Bu(user,0) + Bi(item,0) + Bc(cate,0) + Br(rate,0);
            //pred[i] *= outOf;
            //printf("%f %d\n", pred[i], data[i].nHelpful);
            //pred[i] = round(pred[i]);
        }
    }
}

void saveModel(double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& Br) {
    /* Average Information
     * num_user, num_item
     * all average
     * user average
     * item average
     * */
    {
        FILE* pfile = fopen("../mdl_Helpful/average.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_item);
        fprintf(pfile, "%f\n", sum/cnt);
        for (int i = 0; i < num_user; i++) {
            double val = user_cnt[i] == 0 ?0 :user_sum[i]/user_cnt[i];
            fprintf(pfile, "%f%c", val, i == num_user-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_item; i++) {
            double val = item_cnt[i] == 0 ?0 :item_sum[i]/item_cnt[i];
            fprintf(pfile, "%f%c", val, i == num_item-1 ?'\n' :' ');
        }
    }

    /* Meta Information
     * num_user num_item 
     * A (1, 1)
     * Bu (1, num_user)
     * Bi (1, num_item) */
    {
        FILE* pfile = fopen("../mdl_Helpful/meta.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_item);
        fprintf(pfile, "%f\n", A);
        for (int i = 0; i < num_user; i++) {
            fprintf(pfile, "%f%c", Bu(i,0), i == num_user-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_item; i++) {
            fprintf(pfile, "%f%c", Bi(i,0), i == num_item-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_cate; i++) {
            fprintf(pfile, "%f%c", Bc(i,0), i == num_cate-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_rate; i++) {
            fprintf(pfile, "%f%c", Br(i,0), i == num_rate-1 ?'\n' :' ');
        }
    }
}

int main() {
    srand(514);

    readMappings();
    readData();

    double A = 0;
    MatrixXd Bu = MatrixXd::Zero(num_user, 1);
    MatrixXd Bi = MatrixXd::Zero(num_item, 1);
    MatrixXd Bc = MatrixXd::Zero(num_cate, 1);
    MatrixXd Br = MatrixXd::Zero(num_rate, 1);

    vector<double> stn_p(num_stn, 0);
    vector<double> vld_p(num_vld, 0);
    predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, Br);
    predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, Br);

    double last_stn_err = calERR(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, Br);
    for (int time = 0; time < MAX_ITER; time++) {
        double nA = 0;
        int ca = 0;
        MatrixXd nBu = MatrixXd::Zero(num_user, 1);
        MatrixXd nBi = MatrixXd::Zero(num_item, 1);
        MatrixXd nBc = MatrixXd::Zero(num_cate, 1);
        MatrixXd nBr = MatrixXd::Zero(num_rate, 1);
        VectorXd cu = VectorXd::Zero(num_user);
        VectorXd ci = VectorXd::Zero(num_item);
        VectorXd cc = VectorXd::Zero(num_cate);
        VectorXd cr = VectorXd::Zero(num_rate);
        
        for (auto tuple : stn_tuple) {
            int user = tuple.user;
            int item = tuple.item;
            int cate = tuple.cate;
            int rate = tuple.rate;
            double ratio = tuple.ratio;

            if (tuple.outOf == 0) {
                continue;
            }
            
            double p = A + Bu(user,0) + Bi(item,0) + Bc(cate,0) + Br(rate,0);
            double diff = (p - ratio);

            nA += -diff + A;
            ca += 1;
            nBu(user,0) += -diff + Bu(user,0);
            cu(user) += 1;
            nBi(item,0) += -diff + Bi(item,0);
            ci(item) += 1;
            nBc(cate,0) += -diff + Bc(cate,0);
            cc(cate) += 1;
            nBr(rate,0) += -diff + Br(rate,0);
            cr(rate) += 1;
        }

        if (time % 5 == 0) { 
            A = nA / ca;
        } else if (time % 5 == 1) {
            //Bu = nBu.array() / (cu.array() + lambda);
        } else if (time % 5 == 2) {
            //Bi = nBi.array() / (ci.array() + lambda);
        } else if (time % 5 == 3) {
            Bc = nBc.array() / (cc.array() + lambda);
        } else {
            Br = nBr.array() / (cr.array() + lambda);
        }

        if (time % 5 == 0) {
            predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, Br);
            predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, Br);

            double stn_mse = calMAE(stn_tuple, stn_p, num_stn);
            double vld_mse = calMAE(vld_tuple, vld_p, num_vld);
            double stn_err = calERR(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, Br);
            double vld_err = calERR(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, Br);
            printf("%d %f %f %f %f\n", time, stn_mse, vld_mse, stn_err, vld_err);

            if (abs(last_stn_err - stn_err) / stn_err < eps) {
                break;
            } else {
                last_stn_err = stn_err;
            }
        }
    }

    /* Save model */
    saveModel(A, Bu, Bi, Bc, Br);
}
