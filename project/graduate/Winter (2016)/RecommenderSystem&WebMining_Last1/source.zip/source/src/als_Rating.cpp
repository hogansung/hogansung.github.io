#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <Eigen/Dense>
#include <random>

using namespace std;
using namespace Eigen;


// Parameters 
const int num_tn = 200000;
const int num_stn = 140000;
const int num_vld = num_tn - num_stn;
const int num_user = 39249;
const int num_item = 19913;
const int num_cate = 5;
const int num_latent = 10;
const double lambda = 6;
const double mf_p = 1;
const int MAX_ITER = 100;
const double eps = 1e-4;

struct Tuple {
    int user;
    int item;
    int cate;
    int rate;
    Tuple() {}
    Tuple(int u, int i, int c, int r): user(u), item(i), cate(c), rate(r) {}
};

default_random_engine generator;
uniform_real_distribution<double> distribution(0.0,1.0/sqrt(num_latent));

unordered_map<string, int> map_user_idx;
unordered_map<int, string> map_idx_user;
unordered_map<string, int> map_item_idx;
unordered_map<int, string> map_idx_item;

vector<Tuple> tn_tuple;
vector<Tuple> stn_tuple;
vector<Tuple> vld_tuple;

char in[100010];

// Read Mappings
void readMappings() {
    { // user part
        FILE* pfile = fopen("../tab/userList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_user; i++) {
            fscanf(pfile, "%s", in);
            map_user_idx[in] = i;
            map_idx_user[i] = in;
        }
        fclose(pfile);
    }
    { // item part
        FILE* pfile = fopen("../tab/itemList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_item; i++) {
            fscanf(pfile, "%s", in);
            map_item_idx[in] = i;
            map_idx_item[i] = in;
        }
        fclose(pfile);
    }
}

// Read Data
void readData() {
    FILE* pfile = fopen("../dat/train_Rating.dat", "r");
    assert(pfile != NULL);
    char c_user[21], c_item[21];
    int cate, rate;
    for (int i = 0; i < num_tn; i++) {
        fscanf(pfile, "%s%s%d%d", c_user, c_item, &cate, &rate);
        tn_tuple.emplace_back(map_user_idx.at(c_user), map_item_idx.at(c_item), cate, rate);
    }
    fclose(pfile);

    for (int i = 0; i < num_stn; i++) {
        stn_tuple.emplace_back(tn_tuple[i]);
    }
    for (int i = 0; i < num_vld; i++) {
        vld_tuple.emplace_back(tn_tuple[num_stn + i]);
    }
}

double calERR(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& P, MatrixXd& Q) {
    double err = 0;
    for (int i = 0; i < size; i++) {
        double diff = (pred[i] - data[i].rate);
        err += diff * diff;
    }
    err += lambda * (Bu.squaredNorm() + Bi.squaredNorm() + Bc.squaredNorm() 
      + mf_p * (P.squaredNorm() + Q.squaredNorm()));
    return err;
}

double calMSE(vector<Tuple>& data, vector<double>& pred, int size) {
    double err = 0;
    for (int i = 0; i < size; i++) {
        double diff = (pred[i] - data[i].rate);
        err += diff * diff;
    }
    return err / data.size();
}

void predict(vector<Tuple>& data, vector<double>& pred, int size,
  double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& P, MatrixXd& Q) {
    for (int i = 0; i < size; i++) {
        int user = data[i].user;
        int item = data[i].item;
        int cate = data[i].cate;
        pred[i] = A + Bu(user,0) + Bi(item,0) + Bc(cate,0) + mf_p * P.row(user) * Q.row(item).transpose();
    }
}

void setRandom(MatrixXd& M, int nr, int nc) {
    for (int i = 0; i < nr; i++) {
        for (int j = 0; j < nc; j++) {
            M(i, j) = distribution(generator);
        }
    }
}

void saveModel(double A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& P, MatrixXd& Q) {
    /* Meta Information
     * num_user num_item 
     * A (1, 1)
     * Bu (1, num_user)
     * Bi (1, num_item) */
    {
        FILE* pfile = fopen("../mdl_Rating/meta.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_item);
        fprintf(pfile, "%f\n", A);
        for (int i = 0; i < num_user; i++) {
            fprintf(pfile, "%f%c", Bu(i,0), i == num_user-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_item; i++) {
            fprintf(pfile, "%f%c", Bi(i,0), i == num_item-1 ?'\n' :' ');
        }
        for (int i = 0; i < num_cate; i++) {
            fprintf(pfile, "%f%c", Bc(i,0), i == num_cate-1 ?'\n' :' ');
        }
    }

    /* User Matrix: 
     * num_user num_latent 
     * P (num_user, num_latent) */
    {
        FILE* pfile = fopen("../mdl_Rating/user.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_user, num_latent);
        for (int i = 0; i < num_user; i++) {
            for (int j = 0; j < num_latent; j++) {
                fprintf(pfile, "%f%c", P(i, j), j == num_latent-1 ?'\n' :' ');
            }
        }
        fclose(pfile);
    }

    /* Item Matrix: 
     * num_item num_latent 
     * Q (num_item, num_latent) */
    {
        FILE* pfile = fopen("../mdl_Rating/item.mat", "w");
        assert(pfile != NULL);
        fprintf(pfile, "%d %d\n", num_item, num_latent);
        for (int i = 0; i < num_item; i++) {
            for (int j = 0; j < num_latent; j++) {
                fprintf(pfile, "%f%c", Q(i, j), j == num_latent-1 ?'\n' :' ');
            }
        }
        fclose(pfile);
    }
}

int main() {
    srand(514);

    readMappings();
    readData();

    double A = 0;
    MatrixXd Bu = MatrixXd::Zero(num_user, 1);
    MatrixXd Bi = MatrixXd::Zero(num_item, 1);
    MatrixXd Bc = MatrixXd::Zero(num_cate, 1);
    MatrixXd P = MatrixXd::Zero(num_user, num_latent);
    setRandom(P, num_user, num_latent);
    MatrixXd Q = MatrixXd::Zero(num_item, num_latent);
    setRandom(Q, num_item, num_latent);

    vector<double> stn_p(num_stn, 0);
    vector<double> vld_p(num_vld, 0);
    predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, P, Q);
    predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, P, Q);

    double last_stn_err = calERR(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, P, Q);
    for (int time = 0; time < MAX_ITER; time++) {
        double nA = 0;
        double ca = 0;
        MatrixXd nBu = MatrixXd::Zero(num_user, 1);
        MatrixXd nBi = MatrixXd::Zero(num_item, 1);
        MatrixXd nBc = MatrixXd::Zero(num_cate, 1);
        VectorXd cu = VectorXd::Zero(num_user);
        VectorXd ci = VectorXd::Zero(num_item);
        VectorXd cc = VectorXd::Zero(num_cate);
        MatrixXd nP = MatrixXd::Zero(num_user, num_latent);
        MatrixXd nQ = MatrixXd::Zero(num_item, num_latent);
        VectorXd cP = VectorXd::Zero(num_user);
        VectorXd cQ = VectorXd::Zero(num_item);
        
        for (auto tuple : stn_tuple) {
            int user = tuple.user;
            int item = tuple.item;
            int cate = tuple.cate;
            double rate = tuple.rate;
            double p = A + Bu(user,0) + Bi(item,0) + Bc(cate,0) + mf_p * P.row(user) * Q.row(item).transpose();
            double diff = (p - rate);

            nA += -diff + A;
            ca += 1;
            nBu(user,0) += -diff + Bu(user,0);
            cu(user) += 1;
            nBi(item,0) += -diff + Bi(item,0);
            ci(item) += 1;
            nBc(cate,0) += -diff + Bc(cate,0);
            cc(cate) += 1;
            nP.row(user) += (-diff + P.row(user) * Q.row(item).transpose()) * Q.row(item);
            nQ.row(item) += (-diff + P.row(item) * Q.row(item).transpose()) * P.row(user);
            cP(user) += Q.row(item).squaredNorm();
            cQ(item) += P.row(user).squaredNorm();
        }

        if (time % 6 == 0) { 
            A = nA / ca;
        } else if (time % 6 == 1) {
            Bu = nBu.array() / (cu.array() + lambda);
        } else if (time % 6 == 2) {
            Bi = nBi.array() / (ci.array() + lambda);
        } else if (time % 6 == 3) {
            Bc = nBc.array() / (cc.array() + lambda);    
        } else if (time % 6 == 4) {
            P = nP.array().colwise() / (cP.array() + lambda);
        } else {
            Q = nQ.array().colwise() / (cQ.array() + lambda);
        }

        if (time % 6 == 0) {
            predict(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, P, Q);
            predict(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, P, Q);

            double stn_mse = calMSE(stn_tuple, stn_p, num_stn);
            double vld_mse = calMSE(vld_tuple, vld_p, num_vld);
            double stn_err = calERR(stn_tuple, stn_p, num_stn, A, Bu, Bi, Bc, P, Q);
            double vld_err = calERR(vld_tuple, vld_p, num_vld, A, Bu, Bi, Bc, P, Q);
            printf("%d %f %f %f %f\n", time, stn_mse, vld_mse, stn_err, vld_err);

            if (abs(last_stn_err - stn_err) / stn_err < eps) {
                break;
            } else {
                last_stn_err = stn_err;
            }
        }
    }

    /* Save model */
    saveModel(A, Bu, Bi, Bc, P, Q);
}
