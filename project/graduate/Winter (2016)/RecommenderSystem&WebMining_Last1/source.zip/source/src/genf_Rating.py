import gzip
from collections import defaultdict
import numpy 
import random

def readGz(f):
  for l in gzip.open(f):
    yield eval(l)

userID = set()
itemID = set()
map_item_cate = dict()
with open("../dat/train_Rating.dat", "w") as wf:
    for l in readGz("../dat/train.json.gz"):
        user,item,cate,rate = l['reviewerID'],l['itemID'],l['categoryID'],l['rating']
        wf.write(' '.join([user, item, str(cate), str(int(rate))]) + '\n')
        map_item_cate[item] = str(cate)

        userID.add(user)
        itemID.add(item)

with open('../tab/userList', 'w') as wf:
    for user in list(userID):
        wf.write(user + '\n')

with open('../tab/itemList', 'w') as wf1, \
        open('../tab/cateList', 'w') as wf2:
    for item in list(itemID):
        wf1.write(item + '\n')
        wf2.write(map_item_cate[item] + '\n')
