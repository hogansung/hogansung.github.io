import gzip
from collections import defaultdict
import numpy 
import random

def readGz(f):
  for l in gzip.open(f):
    yield eval(l)

userID = set()
itemID = set()
with open("../dat/train_Helpful.dat", "w") as wf:
    for l in readGz("../dat/train.json.gz"):
        user,item,cate,rate = l['reviewerID'],l['itemID'],l['categoryID'],l['rating']
        nHelpful,outOf = l['helpful']['nHelpful'], l['helpful']['outOf']
        time,nw,nl = l['unixReviewTime'],len(l['reviewText'].split(' ')),len(l['reviewText'])
        wf.write(' '.join([user, item, str(cate), str(int(rate)), str(nHelpful), str(outOf), \
                str(time), str(nw), str(nl)]) + '\n')

        userID.add(user)
        itemID.add(item)

with open("../dat/test_Helpful.dat", "w") as wf:
    for l in readGz("../dat/test_Helpful.json.gz"):
        user,item,cate,rate = l['reviewerID'],l['itemID'],l['categoryID'],l['rating']
        outOf = l['helpful']['outOf']
        time,nw,nl = l['unixReviewTime'],len(l['reviewText'].split(' ')),len(l['reviewText'])
        wf.write(' '.join([user, item, str(cate), str(int(rate)), str(outOf), \
                str(time), str(nw), str(nl)]) + '\n')

        #userID.add(user)
        #itemID.add(item)

with open('../tab/userList', 'w') as wf:
    for user in list(userID):
        wf.write(user + '\n')

with open('../tab/itemList', 'w') as wf:
    for item in list(itemID):
        wf.write(item + '\n')
