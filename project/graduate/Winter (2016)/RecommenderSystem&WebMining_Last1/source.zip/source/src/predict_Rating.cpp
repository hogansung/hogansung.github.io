#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <Eigen/Dense>
#include <random>

using namespace std;
using namespace Eigen;

unordered_map<string, int> map_user_idx;
unordered_map<int, string> map_idx_user;
unordered_map<string, int> map_item_idx;
unordered_map<int, string> map_idx_item;
vector<int> map_itemIdx_cate;

unordered_map<int, double> user_sum;
unordered_map<int, int> user_cnt;
unordered_map<int, double> item_sum;
unordered_map<int, int> item_cnt;
double sum;
double cnt;

//const int num_tn = 200000;
const int num_stn = 200000;
const int num_user = 39249;
const int num_item = 19913;
const int num_cate = 5;
const int num_latent = 30;
const double mf_p = 1.0;
char in[100010];

// Read Mappings
void readMappings() {
    { // user part
        FILE* pfile = fopen("../tab/userList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_user; i++) {
            fscanf(pfile, "%s", in);
            map_user_idx[in] = i;
            map_idx_user[i] = in;
        }
        fclose(pfile);
    }
    { // item part
        FILE* pfile = fopen("../tab/itemList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_item; i++) {
            fscanf(pfile, "%s", in);
            map_item_idx[in] = i;
            map_idx_item[i] = in;
        }
        fclose(pfile);
    }
    { // cate part
        FILE* pfile = fopen("../tab/cateList", "r");
        assert(pfile != NULL);
        for (int i = 0; i < num_item; i++) {
            int cate;
            fscanf(pfile, "%d", &cate);
            map_itemIdx_cate.push_back(cate);
        }
        fclose(pfile);
    }
}

// Read Data
void readData() {
    FILE* pfile = fopen("../dat/train_Rating.dat", "r");
    assert(pfile != NULL);
    char c_user[21], c_item[21];
    int cate, rate;
    for (int i = 0; i < num_stn; i++) {
        fscanf(pfile, "%s%s%d%d", c_user, c_item, &cate, &rate);
        int user = map_user_idx.at(c_user);
        int item = map_item_idx.at(c_item);
        user_sum[user] += rate;
        user_cnt[user] += 1;
        item_sum[item] += rate;
        item_cnt[item] += 1;
        sum += rate;
        cnt += 1;
    }
    fclose(pfile);
}

void readModel(double& A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& P, MatrixXd &Q) {
    int dump;
    /* Meta Information
     * num_user num_item 
     * A (1, 1)
     * Bu (1, num_user)
     * Bi (1, num_item) 
     * Bc (1, num_cate) */
    {
        FILE* pfile = fopen("../mdl_rating/meta.mat", "r");
        assert(pfile != NULL);
        fscanf(pfile, "%d%d", &dump, &dump);
        fscanf(pfile, "%lf", &A);
        for (int i = 0; i < num_user; i++) {
            fscanf(pfile, "%lf", &Bu(i,0));
        }
        for (int i = 0; i < num_item; i++) {
            fscanf(pfile, "%lf", &Bi(i,0));
        }
        for (int i = 0; i < num_cate; i++) {
            fscanf(pfile, "%lf", &Bc(i,0));
        }
    }

    /* User Matrix: 
     * num_user num_latent 
     * P (num_user, num_latent) */
    {
        FILE* pfile = fopen("../mdl_rating/user.mat", "r");
        assert(pfile != NULL);
        fscanf(pfile, "%d%d", &dump, &dump);
        for (int i = 0; i < num_user; i++) {
            for (int j = 0; j < num_latent; j++) {
                fscanf(pfile, "%lf", &P(i, j));
            }
        }
        fclose(pfile);
    }

    /* Item Matrix: 
     * num_item num_latent 
     * Q (num_item, num_latent) */
    {
        FILE* pfile = fopen("../mdl_rating/item.mat", "r");
        assert(pfile != NULL);
        fscanf(pfile, "%d%d", &dump, &dump);
        for (int i = 0; i < num_item; i++) {
            for (int j = 0; j < num_latent; j++) {
                fscanf(pfile, "%lf", &Q(i, j));
            }
        }
        fclose(pfile);
    }
}

// Predict Test
void predictTest(double& A, MatrixXd& Bu, MatrixXd& Bi, MatrixXd& Bc, MatrixXd& P, MatrixXd &Q) {
    FILE* pfin = fopen("../dat/pairs_Rating.txt", "r");
    assert(pfin != NULL);
    
    FILE* pfout = fopen("../pred/predict_Rating.txt", "w");
    assert(pfout != NULL);

    char dump[31];
    fscanf(pfin, "%s", dump);
    fprintf(pfout, "%s\n", "userID-itemID,prediction");
    
    char c_user[21], c_item[21];
    for (int i = 0; i < 14000; i++) {
        fscanf(pfin, "%s%s", c_user, c_item);
        double rate;
        if (map_user_idx.find(c_user) != map_user_idx.end() and
          map_item_idx.find(c_item) != map_item_idx.end()) {
            int user = map_user_idx.at(c_user);
            int item = map_item_idx.at(c_item);
            int cate = map_itemIdx_cate.at(item);
            rate = A + Bu(user,0) + Bi(item,0) + Bc(cate,0)
              + mf_p * P.row(user) * Q.row(item).transpose();
        } else if (map_user_idx.find(c_user) != map_user_idx.end()) {
            int user = map_user_idx[c_user];
            rate = user_sum[user] / user_cnt[user]; 
        } else if (map_item_idx.find(c_item) != map_item_idx.end()) {
            int item = map_item_idx[c_item];
            rate = item_sum[item] / item_cnt[item]; 
        } else {
            assert(false);
            rate =  sum / cnt;
        }
        rate = min(max(rate, 0.0), 5.0);
        fprintf(pfout, "%s-%s,%f\n", c_user, c_item, rate);
    }

    fclose(pfin);
    fclose(pfout);
}

int main() {
    readMappings();
    readData();

    double A;
    MatrixXd Bu = MatrixXd::Zero(num_user, 1);
    MatrixXd Bi = MatrixXd::Zero(num_item, 1);
    MatrixXd Bc = MatrixXd::Zero(num_cate, 1);
    MatrixXd P = MatrixXd::Zero(num_user, num_latent);
    MatrixXd Q = MatrixXd::Zero(num_item, num_latent);
    readModel(A, Bu, Bi, Bc, P, Q);

    predictTest(A, Bu, Bi, Bc, P, Q);
}
