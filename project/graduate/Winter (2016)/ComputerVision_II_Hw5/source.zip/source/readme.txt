# Codes Folder --- code/

## Problem 1
* featureDetect.m
- (no dependency)
- Input: Gray-scaled Image,
         Lambda Threshold,
         Window Size
- Output: List of Corners


## Problem 2
* featureMatch.m
- (no dependency)
- Input: Left Gray-scaled Image,
         Right Gray-scaled Image,
         List of Corners in Left Image,
         List of Corners in Right Image,
         Window Size
- Output: List of Matched Corners


## Problem 3
* mSAC.m
- (no dependency)
- Input: List of Matched Corners
- Output: Fundamental Matrix,
          Boolean Map,
          MAX_TRIALS,
          MIN_COST


## Problem 4
* DLT_nc.m
- (no dependency)
- Input: List of Matched Corners
- Output: Fundamental Matrix


## Problem 5
* LM_nc.m
- (no dependency)
- Input: List of Matched Corners,
         Projective Matrix
- Output: Fundamental Matrix,
          Error Logs


## Problem 6
* epiline.m
- (no dependency)
- Input: Epipolar Line,
         Xmin,
         Xmax,
         Ymin,
         Ymax


## Main Script
* main.m
- (depend on featureDetect.m, featureMatch.m, mSAC.m, DLT_nc.m, LM_nc.m, epiline.m, calRMSE.m)
- Input: None
- Output: None


## Helper Function
* calRMSE.m
- (no dependency)
- Input: List of Matched Corners
         Projective Matrix
- Output: RMSE score



# Data Folder --- dat/
* IMG_5030.JPG
* IMG_5031.JPG



# Document Folder --- doc/
* hw5.pdf



# Temporary Folder --- tmp/
* features.mat
* match_features.mat
* optimal.mat
* outlier.mat



# Other files
* CSE_252B_hw5_Sung_A53204772.pdf
* readme.txt



# Author: Hao-en Sung (wrangle1005@gmail.com)
