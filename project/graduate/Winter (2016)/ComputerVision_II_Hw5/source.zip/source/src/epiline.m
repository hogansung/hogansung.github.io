function [pts] = epiline(line, xmin, xmax, ymin, ymax)
    c_pts = [-(line(2)*ymin+line(3)) / line(1), ymin; ... % bottom
             -(line(2)*ymax+line(3)) / line(1), ymax; ... % top
             xmin, -(line(1)*xmin+line(3)) / line(2); ... % left
             xmax, -(line(1)*xmax+line(3)) / line(2)]; ... % right
             
    pts = [];
    for i = 1:4
        if c_pts(i,1) >= xmin && c_pts(i,1) <= xmax && ...
                c_pts(i,2) >= ymin && c_pts(i,2) <= ymax
            pts = [pts; c_pts(i,:)];
        end
    end
    assert(size(pts,1) == 2);
end