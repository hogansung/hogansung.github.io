% lx, rx: 2D homogenerous points
function [best_F, best_bmap, MAX_TRIALS, MIN_COST] = mSAC(lx, rx)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);

    % Data Normalization
    lxm = mean(lx);
    lxv = var(lx);
    lxs = sqrt(2 / (lxv(1)+lxv(2)));
    lT = [lxs, 0, -lxm(1)*lxs; 0, lxs, -lxm(2)*lxs; 0, 0, 1];
    lx = lx * lT';

    rxm = mean(rx);
    rxv = var(rx);
    rxs = sqrt(2 / (rxv(1)+rxv(2)));
    rT = [rxs, 0, -rxm(1)*rxs; 0, rxs, -rxm(2)*rxs; 0, 0, 1];
    rx = rx * rT';

    % Parameters
    MIN_COST = Inf;
    MAX_TRIALS = Inf;
    THRESHOLD = 1;
    TOLERANCE = chi2inv(0.95,1);
    PROBABILITY = 0.99;
    IMAG_EPS = 1e-8;
    
    % Initialize return values
    best_F = zeros(3,3);
    best_bmap = false(n,1);
    
    trials = 0;
    s = RandStream('mt19937ar','Seed',514);
    while trials < MAX_TRIALS && MIN_COST > THRESHOLD
        trials = trials + 1;
        
        % Random 7 numbers
        idx = randperm(s, n);
        idx = idx(1:7);
        
        % Create matrix x_i' kron x_i
        A = zeros(7,9);
        for i = 1:7
            A(i, :) = kron(rx(idx(i),:), lx(idx(i),:));
        end

        % Find out f = vec(F)
        [~,~,V] = svd(A);
        f1 = reshape(V(:,end-1), 3, 3)';
        f2 = reshape(V(:,end), 3, 3)';
        
        syms a;
        F = a * f1 + f2;
        detF = det(F);
        equ = collect(detF, a);
        sol = double(root(equ, a));
        
        % Enumerate all results
        sbest_cost = Inf;
        for i = 1:size(sol,1)
            if imag(sol(i)) < IMAG_EPS
                a = real(sol(i));
                F = a * f1 + f2;
                
                % Calculate delta
                delta = calDelta(lx, rx, lT, rT, F);

                % Calculate error
                error = calError(delta);

                % Calculate cost
                cost = calCost(error, TOLERANCE);
                
                % Preserve the best model
                if cost < sbest_cost
                    sbest_F = F;
                    sbest_bmap = error < TOLERANCE;
                    sbest_n_in = sum(sbest_bmap);
                    sbest_cost = cost;
                end
            end
        end

        if sbest_cost < MIN_COST
            MIN_COST = sbest_cost;
            best_F = sbest_F;
            best_bmap = sbest_bmap;
            best_n_in = sbest_n_in;
            
            w = best_n_in / n;
            MAX_TRIALS = log(1-PROBABILITY) / log(1-w^7);
        end
    end
    
    % Data Denormalization
    best_F = rT' * best_F * lT;
end

function delta = calDelta(lx, rx, lT, rT, F)
    n = size(lx,1);
    lx = lx / lT';
    lx = lx ./ lx(:,3);
    rx = rx / rT';
    rx = rx ./ rx(:,3);
    F = rT' * F * lT;
    
    delta = zeros(n,4);
    for i = 1:n
        J = [rx(i,1)*F(1,1)+rx(i,2)*F(2,1)+F(3,1), ...
             rx(i,1)*F(1,2)+rx(i,2)*F(2,2)+F(3,2), ...
             lx(i,1)*F(1,1)+lx(i,2)*F(1,2)+F(1,3), ...
             lx(i,1)*F(2,1)+lx(i,2)*F(2,2)+F(2,3)];
        e = rx(i,:) * F * lx(i,:)';
        lambda = -e / (J*J');
        delta(i,:) = J * lambda;
    end
end

function error = calError(delta)
    n = size(delta,1);
    error = zeros(n,1);
    for i = 1:n
        error(i,1) = delta(i,:) * delta(i,:)';
    end
end

function cost = calCost(error, TOLERANCE)
    cost = sum(min(error, TOLERANCE));
end