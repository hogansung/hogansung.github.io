function RMSE = calRMSE(lx, rx, F)
    res = rx * F * lx';
    RMSE = sqrt(sum(sum(res.^2)));
end