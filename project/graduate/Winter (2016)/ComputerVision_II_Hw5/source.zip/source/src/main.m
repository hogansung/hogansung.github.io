%% Read Files
preI = imread('../dat/IMG_5030.JPG');
preI = rgb2gray(preI);
nxtI = imread('../dat/IMG_5031.JPG');
nxtI = rgb2gray(nxtI);

%% Parameters
lambda_threshold = 65;
nw = 7;

%% Problem 1: Extract Features
fprintf('\n\nProblem 1\n');

% Draw Original Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);

saveas(res, '../res/pc_origin.jpg');

if exist('../tmp/features.mat', 'file') == 2
    load('../tmp/features.mat');
else
    % Extract features
    pref = featureDetect(preI, lambda_threshold, nw);
    nxtf = featureDetect(nxtI, lambda_threshold, nw);
    save('../tmp/features.mat', 'pref', 'nxtf');
end
fprintf('Number of extracted features: %d\n', size(pref, 1));
fprintf('Number of extracted features: %d\n', size(nxtf, 1)); 

% Draw Feature-Deteced Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(pref(:,1),pref(:,2),'bs', 'MarkerSize', nw);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(nxtf(:,1),nxtf(:,2),'bs', 'MarkerSize', nw);
hold off

saveas(res, '../res/pc_detect.jpg');

%% Problem 2: Match Features
fprintf('\n\nProblem 2\n');

if exist('../tmp/match_features.mat', 'file') == 2
    load('../tmp/match_features.mat');
else
    % Match Features
    [lx, rx] = featureMatch(preI, nxtI, pref, nxtf, nw);
    save('../tmp/match_features.mat', 'lx', 'rx');
end
dx = rx-lx;
fprintf('Number of matches: %d\n', size(lx, 1));

% Draw Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(lx(:,1), lx(:,2), 'bs', 'MarkerSize', nw);
quiver(lx(:,1), lx(:,2), dx(:,1), dx(:,2), 0);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(rx(:,1), rx(:,2), 'bs', 'MarkerSize', nw);
quiver(rx(:,1), rx(:,2), -dx(:,1), -dx(:,2), 0);
hold off

saveas(res, '../res/pc_match.jpg');

%% Problem 3: Outlier Reection
% Homogenize
lx(:,3) = ones(size(lx,1),1);
rx(:,3) = ones(size(rx,1),1);

if exist('../tmp/outlier.mat', 'file') == 2
    load('../tmp/outlier.mat');
else
    % Outlier Rejection
    [F, bmap, MAX_TRIALS, cost] = mSAC(lx, rx);
    save('../tmp/outlier.mat', 'F', 'bmap', 'MAX_TRIALS', 'cost');
end
fprintf('\n\nProblem 3\n');
fprintf('Number of Inliers: %d\n', sum(bmap));
fprintf('Number of MaxTrials: %.10f\n', MAX_TRIALS);
fprintf('Final Cost: %.10f\n', cost);
F = F ./ norm(F,'fro');
RMSE = calRMSE(lx, rx, F);
fprintf('RMSE: %.10f\n', RMSE);

% Reject Outliers
rej_lx = lx(~bmap,:);
lx = lx(bmap,:);
rx = rx(bmap,:);
dx = rx-lx;

% Draw Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(lx(:,1), lx(:,2), 'bs', 'MarkerSize', nw);
quiver(lx(:,1), lx(:,2), dx(:,1), dx(:,2), 0);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
plot(rx(:,1), rx(:,2), 'bs', 'MarkerSize', nw);
quiver(rx(:,1), rx(:,2), -dx(:,1), -dx(:,2), 0);
hold off

saveas(res, '../res/pc_robust_match.jpg');

%% Problem 4: DLT Algorithm (Linear Estimation)
F = DLT_nc(lx, rx);
F = F ./ norm(F,'fro');
fprintf('\n\nProblem 4\n');
fprintf('F_DLT:\n'); disp(F);
RMSE = calRMSE(lx, rx, F);
fprintf('RMSE: %.10f\n', RMSE);

%% Problem 5: Levenberg-Marquardt Algorithm (NonLinear Estimation)
[F, logs] = LM_nc(lx, rx, F);
F = F ./ norm(F,'fro');
fprintf('\n\nProblem 5\n');
fprintf('F_LM:\n'); disp(F);
fprintf('Error log:\n'); disp(logs);
RMSE = calRMSE(lx, rx, F);
fprintf('RMSE: %.10f\n', RMSE);

%% Problem 6: Point to Line Mapping
s = RandStream('mt19937ar','Seed',514);

% Random 3 Numbers
idx = randperm(s, size(rej_lx,1));
idx = idx(1:3);

% Select Points
lp = rej_lx(idx,:);

% Find Epilines
rl = (F * lp')';

% Draw Figures
res = figure('visible','off');
res.PaperPosition = [0 0 8 3];

subaxis(1, 2, 1, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(preI);
hold on
plot(lp(:,1), lp(:,2),'bs', 'MarkerSize', nw);
hold off

subaxis(1, 2, 2, 'sh', 0.01, 'sv', 0, 'padding', 0, 'margin', 0.01);
imshow(nxtI);
hold on
for i = 1:3
    pts = epiline(rl(i,:), 1, size(preI,2), 1, size(preI,1));
    plot(pts(:,1), pts(:,2), 'r-');
end
hold off

saveas(res, '../res/pc_mapping.jpg');