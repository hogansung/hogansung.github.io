function [lx, rx] = featureMatch(preI, nxtI, pref, nxtf, nw)

%% Parameters
hw = floor(nw/2);
[n,m] = size(preI);
similarity_threshold = 0.8;
dist_threshold = 0.7;

preI = double(preI);
nxtI = double(nxtI);

%% Create Correlations
corrw = zeros(size(pref,1), size(nxtf,1));
for i = 1:size(pref,1)
    for j = 1:size(nxtf,1)
        % check proximality
        if abs(pref(i,1) - nxtf(j,1)) > 100 ...
                || abs(pref(i,2) - nxtf(j,2)) > 100 ...
            continue
        end
        
        [px, py] = ...
            meshgrid(max(pref(i,1)-hw,1):min(pref(i,1)+hw,m), ...
                     max(pref(i,2)-hw,1):min(pref(i,2)+hw,n));
        [nx, ny] = ...
            meshgrid(max(nxtf(j,1)-hw,1):min(nxtf(j,1)+hw,m), ...
                     max(nxtf(j,2)-hw,1):min(nxtf(j,2)+hw,n));
        
        prew = interp2(preI, px, py);
        nxtw = interp2(nxtI, nx, ny);
        corrw(i,j) = corr2(prew,nxtw);
    end
end

%% Find Largest Element Iteratively
lx = [];
rx = [];
while true
    [maxv,maxi] = max(corrw(:));
    % stop while the maximum one is not large enough
    if maxv < similarity_threshold
        break
    end

    % get the window corrdinate
    [r,c] = ind2sub(size(corrw),maxi);
    corrw(r,c) = -1;
    
    % get the potential two window corrdinates
    [nrv,~] = max(corrw(r,:));
    [ncv,~] = max(corrw(:,c));
   
    % stack them into arrays
    if nrv > ncv
        if (1-maxv) < (1-nrv) * dist_threshold
            lx = [lx; [pref(r,1), pref(r,2)]];
            rx = [rx; [nxtf(c,1), nxtf(c,2)]];
        end
    else
        if (1-maxv) < (1-ncv) * dist_threshold
            lx = [lx; [pref(r,1), pref(r,2)]];
            rx = [rx; [nxtf(c,1), nxtf(c,2)]];
        end
    end
    
    % reset to -1
    for j = 1:size(nxtf,1)
        corrw(r,j) = -1;
    end
    for i = 1:size(pref,1)
        corrw(i,c) = -1;
    end
end
