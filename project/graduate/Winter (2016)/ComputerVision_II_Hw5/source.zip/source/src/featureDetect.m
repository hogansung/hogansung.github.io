function mat = featureDetect(I, lambda_threshold, nw)

%% Parameters
hw = int32(floor(nw/2));
[n, m] = size(I);

%% Convolutional Kernel
k = [-1; 8; 0; -8; 1] / 12;

%% Calculate Gradient
Gx = conv2(double(I), k', 'same');
Gy = conv2(double(I), k, 'same');

%% Precalculate Squared Gradient
Gxx = Gx .* Gx;
Gxy = Gx .* Gy;
Gyy = Gy .* Gy;

%% Corner Detection
em = zeros(n, m);
for r = 1+nw:n-nw
    for c = 1+nw:m-nw
        vxx = sum(sum(Gxx(r-hw:r+hw, c-hw:c+hw)));
        vyy = sum(sum(Gyy(r-hw:r+hw, c-hw:c+hw)));
        vxy = sum(sum(Gxy(r-hw:r+hw, c-hw:c+hw)));
        ATA = [vxx, vxy; vxy, vyy] / (nw * nw);
        val = max(trace(ATA)^2 - 4*det(ATA), 0);
        em(r, c) = (trace(ATA) - sqrt(val)) / 2;
    end
end

%% Non-maximum Suppression
mat = [];
for r = 1+nw:n-nw
    for c = 1+nw:m-nw
        vmax = max(max(em(r-hw:r+hw, c-hw:c+hw)));
        if em(r, c) == vmax && vmax > lambda_threshold
            mat = [mat; [c, r]];
        end
    end
end

%% Find Real Corners
[idx_x, idx_y] = meshgrid(1:m, 1:n);
xGxx = idx_x .* Gxx;
xGxy = idx_x .* Gxy;
yGxy = idx_y .* Gxy;
yGyy = idx_y .* Gyy;

for i = 1:size(mat,1)
    c = mat(i, 1);
    r = mat(i, 2);
    vxx = sum(sum(Gxx(r-hw:r+hw, c-hw:c+hw)));
    vyy = sum(sum(Gyy(r-hw:r+hw, c-hw:c+hw)));
    vxy = sum(sum(Gxy(r-hw:r+hw, c-hw:c+hw)));
    xVxx = sum(sum(xGxx(r-hw:r+hw, c-hw:c+hw)));
    xVxy = sum(sum(xGxy(r-hw:r+hw, c-hw:c+hw)));
    yVxy = sum(sum(yGxy(r-hw:r+hw, c-hw:c+hw)));
    yVyy = sum(sum(yGyy(r-hw:r+hw, c-hw:c+hw)));
    A = [vxx, vxy; vxy, vyy];
    b = [xVxx + yVxy; xVxy + yVyy];
    mat(i, :) = (A \ b)';
end
