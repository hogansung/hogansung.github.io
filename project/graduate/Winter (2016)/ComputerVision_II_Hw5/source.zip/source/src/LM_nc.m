% lx, rx: 2D homogenerous points
function [F, logs] = LM_nc(lx, rx, F)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);
    
    % Data Normalization
    lxm = mean(lx);
    lxv = var(lx);
    lxs = sqrt(2 / (lxv(1)+lxv(2)));
    lT = [lxs, 0, -lxm(1)*lxs; 0, lxs, -lxm(2)*lxs; 0, 0, 1];
    lx = lx * lT';

    rxm = mean(rx);
    rxv = var(rx);
    rxs = sqrt(2 / (rxv(1)+rxv(2)));
    rT = [rxs, 0, -rxm(1)*rxs; 0, rxs, -rxm(2)*rxs; 0, 0, 1];
    rx = rx * rT';
   
    F = inv(rT') * F * inv(lT);
    
    % Parameterize F
    [U,D,V] = svd(F);
    S = [D(1,1), D(2,2)];
    
    % Constrain U, V
    if det(U) < 0
        U = -U;
    end
    if det(V) < 0
        V = -V;
    end
    
    % Parameterize Wu, Wv, S
    Wu = angleParameterize(U);
    Wv = angleParameterize(V);
    pS = homoParameterize(S);

    % Angle Normalize Wu, Wv, S
    if norm(Wu) > pi
        Wu = (1 - 2*pi/norm(Wu) * ceil((norm(Wu)-pi)/(2*pi))) * Wu;
    end
    if norm(Wv) > pi
        Wv = (1 - 2*pi/norm(Wv) * ceil((norm(Wv)-pi)/(2*pi))) * Wv;
    end
    if norm(pS) > pi
        pS = (1 - 2*pi/norm(pS) * ceil((norm(pS)-pi)/(2*pi))) * pS;
    end

    % DeParameterize Wu, Wv, S, and pX
    U = angleDeparameterize(Wu);
    V = angleDeparameterize(Wv);
    S = homoDeparameterize(pS)';
    
    % DeParameterize F
    F = U * diag([S, 0]) * V';
     
    % Sampson Correction
    delta = calDelta(lx, rx, lT, rT, F);
    s_lx = lx / lT';
    s_lx(:,1:2) = s_lx(:,1:2) + delta(:,1:2);
    s_lx = s_lx * lT';
    s_rx = rx / rT';
    s_rx(:,1:2) = s_rx(:,1:2) + delta(:,3:4);
    s_rx = s_rx * rT';
    
    if exist('../tmp/optimal.mat', 'file') == 2
        load('../tmp/optimal.mat');
    else
        % Optimal Triangulation
        [s_lx, s_rx] = optimalTriangulate(s_lx, s_rx, F);
        save('../tmp/optimal.mat', 's_lx', 's_rx');
    end

    % 3D Scene Points Initialization
    sX = getScenePoints(s_lx, s_rx, U, S, V, F);
    
    % Parameterize sX
    pX = zeros(n,3);
    for i = 1:n
        pX(i,:) = homoParameterize(sX(i,:));
    end
    
    % Angle Normalize pX
    for i = 1:n
        if norm(pX(i,:)) > pi
            pX(i,:) = (1 - 2*pi/norm(pX(i,:)) * ...
                ceil((norm(pX(i,:))-pi)/(2*pi))) * pX(i,:);
        end
    end
    
    % Deparameterize pX
    for i = 1:n
        sX(i,:) = homoDeparameterize(pX(i,:)')';
    end

    % Covariance Matrix
    Z = diag([repmat(lxs^2, 1, 2*n), ...
        repmat(rxs^2, 1, 2*n)]);

    % Initialization
    lambda = 0.001;
    perr = Inf;
    
    % Estimate
    [n_lx, n_rx] = estimate(sX, U, S, V);
    
    ex = calEpsilon(lx, rx, n_lx, n_rx);
    err = ex'*inv(Z)*ex;

    % Error Log
    logs = err;

    while abs(perr-err) > 0.0001
        % Get Right P
        rP = getRP(U, S, V);
        
        % Calculate J
        J = zeros(4*n,7+3*n);
        
        % Fill up J with A_i''
        partial_F = zeros(12,7);
        
        u = [-S(2)*V(:,2), S(1)*V(:,1), (S(1)+S(2))/2*V(:,3); 0, 0, -1];
        partial_u = kron(eye(3), u);
        partial_F(:,1:3) = partial_u * angleJacobian(Wu);
        
        partial_v = zeros(12,9);
        partial_v(1:3,:) = kron(eye(3), ...
            [S(1)*U(1,2), -S(2)*U(1,1), (S(1)+S(2))/2*U(1,3)]);
        partial_v(5:7,:) = kron(eye(3), ...
            [S(1)*U(2,2), -S(2)*U(2,1), (S(1)+S(2))/2*U(2,3)]);
        partial_v(9:11,:) = kron(eye(3), ...
            [S(1)*U(3,2), -S(2)*U(3,1), (S(1)+S(2))/2*U(3,3)]);
        partial_F(:,4:6) = partial_v * angleJacobian(Wv);

        partial_s = [U(1,2)*V(:,1) + U(1,3)/2*V(:,3), ...
             U(1,3)/2*V(:,3) - U(1,1)*V(:,2); ...
             0, 0;
             U(2,2)*V(:,1) + U(2,3)/2*V(:,3), ...
             U(2,3)/2*V(:,3) - U(2,1)*V(:,2); ...
             0, 0;
             U(3,2)*V(:,1) + U(3,3)/2*V(:,3), ...
             U(3,3)/2*V(:,3) - U(3,1)*V(:,2); ...
             0, 0];
        partial_ss = [-0.5 * S(2:end); ...
             SINC(norm(pS)/2)/2 * eye(1) ...
             + 1/(4*norm(pS)) * DSINC(norm(pS)/2) ...
             * (pS'*pS)];
        partial_F(:,7) = partial_s * partial_ss;
        
        for i = 1:n
            partial_xp = 1/n_rx(i,3) * ...
                [sX(i,:), zeros(1,4), -n_rx(i,1)/n_rx(i,3)*sX(i,:); ...
                 zeros(1,4), sX(i,:), -n_rx(i,2)/n_rx(i,3)*sX(i,:)];
            J(2*n+2*i-1:2*n+2*i,1:7) = partial_xp * partial_F;
        end

        % Fill up J with B_i'
        for i = 1:n
            partial_x1x = 1/n_lx(i,3) * ...
                [1, 0, -n_lx(i,1)/n_lx(i,3), 0;
                 0, 1, -n_lx(i,2)/n_lx(i,3), 0];
            partial_xx = [-0.5 * sX(i,2:end); ...
                  SINC(norm(pX(i,:))/2)/2 * eye(3) ...
                  + 1/(4*norm(pX(i,:))) * DSINC(norm(pX(i,:))/2) ...
                  * (pX(i,:)'*pX(i,:))];
            J(2*i-1:2*i,7+3*i-2:7+3*i) = partial_x1x * partial_xx;
        end
          
        % Fill up J with B_i''
        for i = 1:n
            partial_x2x = 1/n_rx(i,3) * ...
                [rP(1,:) - n_rx(i,1)/n_rx(i,3) * rP(3,:);
                 rP(2,:) - n_rx(i,2)/n_rx(i,3) * rP(3,:)];
            partial_xx = [-0.5 * sX(i,2:end); ...
                  SINC(norm(pX(i,:))/2)/2 * eye(3) ...
                  + 1/(4*norm(pX(i,:))) * DSINC(norm(pX(i,:))/2) ...
                  * (pX(i,:)'*pX(i,:))];
            J(2*n+2*i-1:2*n+2*i,7+3*i-2:7+3*i) ...
                = partial_x2x * partial_xx;
        end
        
        while true
            % Solve delta and update Wu, Wv, pS, and pX
            d = (J'*inv(Z)*J + lambda*eye(7+3*n)) \ (J'*inv(Z)*ex);
            n_Wu = Wu + d(1:3);
            n_Wv = Wv + d(4:6);
            n_pS = pS + d(7);
            n_pX = pX;
            for i = 1:n
                n_pX(i,:) = n_pX(i,:) + d(7+3*i-2:7+3*i)';
            end

            % Angle Normalize Wu, Wv, S, and pX
            if norm(n_Wu) > pi
                n_Wu = (1 - 2*pi/norm(n_Wu) * ...
                    ceil((norm(n_Wu)-pi)/(2*pi))) * n_Wu;
            end
            if norm(n_Wv) > pi
                n_Wv = (1 - 2*pi/norm(n_Wv) * ...
                    ceil((norm(n_Wv)-pi)/(2*pi))) * n_Wv;
            end
            if norm(n_pS) > pi
                n_pS = (1 - 2*pi/norm(n_pS) * ...
                    ceil((norm(n_pS)-pi)/(2*pi))) * n_pS;
            end
            for i = 1:n
                if norm(n_pX(i,:)) > pi
                    n_pX(i,:) = (1 - 2*pi/norm(n_pX(i,:)) ...
                        * ceil((norm(n_pX(i,:))-pi)/(2*pi))) ...
                        * n_pX(i,:);
                end
            end

            % DeParameterize Wu, Wv, S, and pX
            n_U = angleDeparameterize(n_Wu);
            n_V = angleDeparameterize(n_Wv);
            n_S = homoDeparameterize(n_pS)';
            n_sX = zeros(n,4);
            for i = 1:n
                n_sX(i,:) = homoDeparameterize(n_pX(i,:)')';
            end
            
            % Constrain U, V
            if det(n_U) < 0
                n_U = -n_U;
            end
            if det(n_V) < 0
                n_V = -n_V;
            end
            
            % Parameterize Wu, Wv
            n_Wu = angleParameterize(n_U);
            n_Wv = angleParameterize(n_V);
            
            % DeParameterize F
            n_F = n_U * diag([n_S, 0]) * n_V';
            
            % Estimate
            [n_lx, n_rx] = estimate(n_sX, n_U, n_S, n_V);
            
            % Calculate Error
            nex = calEpsilon(lx, rx, n_lx, n_rx);
            nerr = nex'*inv(Z)*nex;
            
            % Check Error
            if nerr < err
                U = n_U;
                V = n_V;
                S = n_S;
                F = n_F;
                sX = n_sX;
                Wu = n_Wu;
                Wv = n_Wv;
                pS = n_pS;
                pX = n_pX;
                lambda = 0.1 * lambda;
                break;
            else
                lambda = 10 * lambda;
            end
        end
        
        % Update error
        perr = err;
        err = nerr;
        logs = [logs, err];
    end

    % Data Denormalization
    F = rT' * F * lT;
end

function rP = getRP(U, S, V)
    z = [0, -1, 0; 1, 0, 0; 0, 0, 1];
    d = [S(1), S(2), (S(1) + S(2)) / 2];
    m = U * z * diag(d) * V';
    rP = [m, -U(:,3)];
end

function [n_lx, n_rx] = optimalTriangulate(lx, rx, F)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);
    
    n_lx = zeros(size(lx));
    n_rx = zeros(size(rx));
    for i = 1:n
        % Special Fundamental Matrix
        lT = [lx(i,3), 0, -lx(i,1); ...
              0, lx(i,3), -lx(i,2); ...
              0, 0, lx(i,3)];
        rT = [rx(i,3), 0, -rx(i,1); ...
              0, rx(i,3), -rx(i,2); ...
              0, 0, rx(i,3)];
        Fs = inv(rT') * F * inv(lT);
        
        % epipoles
        le = null(Fs);
        re = null(Fs');
        
        % scale epipoles
        le = le ./ sqrt(le(1)^2 + le(2)^2);
        re = re ./ sqrt(re(1)^2 + re(2)^2);
        
        % Special Fundamental Matrix
        lR = [le(1), le(2), 0; ...
              -le(2), le(1), 0; ...
              0, 0, 1];
        rR = [re(1), re(2), 0; ...
              -re(2), re(1), 0; ...
              0, 0, 1];
        Fs = rR * Fs * lR';
        
        % solve t
        syms t;
        lf = le(3);
        rf = re(3);
        a = Fs(2,2);
        b = Fs(2,3);
        c = Fs(3,2);
        d = Fs(3,3);
        gt = t * ((a*t+b)^2 + rf^2*(c*t+d)^2)^2 ...
            - (a*d-b*c) * (1+lf^2*t^2)^2 * (a*t+b) * (c*t+d);
        equ = collect(gt, t);
        sol = double(root(equ, t));
        
        % find t with smallest cost
        mmin = Inf;
        for j = 1:size(sol,1)
            t = real(sol(j));
            st = t^2/(1+lf^2*t^2) + (c*t+d)^2/((a*t+b)^2+rf^2*(c*t+d)^2);
            if st < mmin
                mmin = st;
                best_t = t;
            end
        end
        
        ll = [best_t * lf, 1, -best_t];
        rl = [-rf*(c*best_t+d), a*best_t+b, c*best_t+d];
        
        n_lx(i,:) = (inv(lT) * lR' * ...
            [-ll(1)*ll(3), -ll(2)*ll(3), ll(1)^2+ll(2)^2]')';
        n_rx(i,:) = (inv(rT) * rR' * ...
            [-rl(1)*rl(3), -rl(2)*rl(3), rl(1)^2+rl(2)^2]')';
    end
end

function sX = getScenePoints(lx, rx, U, S, V, F)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);
    
    rP = getRP(U, S, V);
    sX = zeros(n, 4);
    for i = 1:n
        rl = (F * lx(i,:)')';
        nl = [-rl(2)*rx(i,3), rl(1)*rx(i,3),...
              rl(2)*rx(i,1)-rl(1)*rx(i,2)];
        p = nl * rP;
        
        sX(i,1:3) = p(4) * lx(i,:)';
        sX(i,4) = -p(1:3) * lx(i,:)';
    end
end

function partialW = angleJacobian(W)
    I = eye(3);
    theta = norm(W);
    nW = W/norm(W);
    nWx = skewMatrix(nW);
    
    partialW = zeros(9,3);
    for i = 1:3
        dW = cos(theta)*nW(i,1)*nWx + sin(theta)*nW(i,1)*nWx*nWx ...
            + sin(theta)/theta*skewMatrix(I(i,:)'-nW(i,1)*nW) ...
            + (1-cos(theta))/theta ...
            * (I(i,:)'*nW' + nW*I(i,:) - 2*nW(i,1)*(nW*nW'));
        partialW(1:9,i) = vector(dW);
    end   
end

function [n_lx, n_rx] = estimate(sX, U, S, V)
    rP = getRP(U, S, V);
    n_lx = ([eye(3), zeros(3,1)] * sX')';
    n_rx = (rP * sX')';
end

% n_lx, n_rx have been normalized by their third columns
function ex = calEpsilon(lx, rx, n_lx, n_rx)
    n_lx = n_lx ./ n_lx(:,3);
    n_rx = n_rx ./ n_rx(:,3);
    ex = [vector(lx(:,1:2)) - vector(n_lx(:,1:2)); ...
          vector(rx(:,1:2)) - vector(n_rx(:,1:2))];
end

function vx = vector(x)
    vx = x';
    vx = vx(:);
end

function p = homoParameterize(v)
    v = v / norm(v);
    a = v(1);
    b = v(2:end);
    p = 2 / SINC(acos(a)) * b;
end

function v = homoDeparameterize(p)
    v = [cos(norm(p)/2), SINC(norm(p)/2)/2 * p']';
end

function ret = SINC(x)
    if x == 0
        ret = 1;
    else
        ret = sin(x) / x;
    end
end

function ret = DSINC(x)
    if x == 0
        ret = 0;
    else
        ret = cos(x) / x - sin(x) / x^2;
    end
end

function W = angleParameterize(M) 
    [~, ~, V] = svd(M - eye(3));
    a = V(:,end);
    b = [M(3,2)-M(2,3); M(1,3)-M(3,1); M(2,1)-M(1,2)];
    
    sin_theta = 0.5 * a' * b;
    cos_theta = 0.5 * (trace(M)-1);
    theta = atan2(sin_theta, cos_theta);
    
    W = theta * a / norm(a);
end

function M = angleDeparameterize(W)
    theta = norm(W);
    
    if theta < 1e-7
        assert(false);
    else
        sin_theta = sin(theta);
        cos_theta = cos(theta);
        nW = W / norm(W);
        nWx = skewMatrix(nW);

        M = cos_theta*eye(3) + sin_theta*nWx ...
            + (1-cos_theta)*(nW*nW');
    end
end

function Wx = skewMatrix(W)
    Wx = [0, -W(3,1), W(2,1); ...
          W(3,1), 0, -W(1,1); ...
          -W(2,1), W(1,1), 0];
end

function delta = calDelta(lx, rx, lT, rT, F)
    n = size(lx,1);
    lx = lx / lT';
    lx = lx ./ lx(:,3);
    rx = rx / rT';
    rx = rx ./ rx(:,3);
    F = rT' * F * lT;
    
    delta = zeros(n,4);
    for i = 1:n
        J = [rx(i,1)*F(1,1)+rx(i,2)*F(2,1)+F(3,1), ...
             rx(i,1)*F(1,2)+rx(i,2)*F(2,2)+F(3,2), ...
             lx(i,1)*F(1,1)+lx(i,2)*F(1,2)+F(1,3), ...
             lx(i,1)*F(2,1)+lx(i,2)*F(2,2)+F(2,3)];
        e = rx(i,:) * F * lx(i,:)';
        lambda = -e / (J*J');
        delta(i,:) = J * lambda;
    end
end