% lx, rx: 2D homogenerous points
function F = DLT_nc(lx, rx)
    assert(size(lx,1) == size(rx,1));
    n = size(lx,1);

    % Data Normalization
    lxm = mean(lx);
    lxv = var(lx);
    lxs = sqrt(2 / (lxv(1)+lxv(2)));
    lT = [lxs, 0, -lxm(1)*lxs; 0, lxs, -lxm(2)*lxs; 0, 0, 1];
    lx = lx * lT';

    rxm = mean(rx);
    rxv = var(rx);
    rxs = sqrt(2 / (rxv(1)+rxv(2)));
    rT = [rxs, 0, -rxm(1)*rxs; 0, rxs, -rxm(2)*rxs; 0, 0, 1];
    rx = rx * rT';
    
    % Left Null Space of F
    A = zeros(n,9);
    for i = 1:n
        A(i, :) = kron(rx(i,:), lx(i,:));
    end

    % Solve for F
    [~,~,V] = svd(A,'econ');
    f = V(:,end);
    F = reshape(f, 3, 3)';
    
    % Add constraint to F
    [U,D,V] = svd(F,'econ');
    D(3,3) = 0;
    F = U * D * V';
    
    % Data Denormalization
    F = rT' * F * lT;
end
