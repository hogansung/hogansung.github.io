import caffe
import surgery, score

import numpy as np
import os
import sys

try:
    import setproctitle
    setproctitle.setproctitle(os.path.basename(os.getcwd()))
except:
    pass

# init
caffe.set_mode_cpu()

solver = caffe.SGDSolver('solver.prototxt')
weights = './facade.caffemodel'

if not os.path.exists(weights):
    net = caffe.Net('../../VGG_ILSVRC_16_layers_deploy.prototxt', '../../VGG_ILSVRC_16_layers.caffemodel', caffe.TEST)
    fc_net = caffe.Net('./trainval.prototxt', caffe.TEST)
    surgery.transplant(fc_net, net)
    fc_net.save(weights)
    print 'weight saved'

solver.net.copy_from(weights)
print 'weight loaded'

for layername, layerparam in solver.net.params.items():
    print layername, layerparam[0].data.shape

# surgeries
interp_layers = [k for k in solver.net.params.keys() if 'up' in k]
surgery.interp(solver.net, interp_layers)

# scoring
test = np.loadtxt('../../data/facade/test.txt', dtype=str)

for _ in range(1):
    '''
    solver.step(378)
    solver.net.save(weights)
    print 'weight saved'
    '''

    # N.B. metrics on the semantic labels are off b.c. of missing classes;
    # score manually from the histogram instead for proper evaluation
    score.seg_tests(solver, False, test, layer='score_sem', gt='sem')
