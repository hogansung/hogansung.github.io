import numpy as np
import matplotlib.pyplot as plt
import cv2
import operator
from os.path import isfile, join
from os import listdir
from scipy.interpolate import interp1d
from collection import defaultdict

predict_dict = {'cGAN': "../datasets/cityscapes/output_cGAN", \
				'GAN': "../datasets/cityscapes/output_GAN", \
				'GAN_l1': "../datasets/cityscapes/output_GAN_l1", \
				'l1': "../datasets/cityscapes/output_l1", \
				'cGAN_l1': "../datasets/cityscapes/output_cGAN_l1"}

real_path = "../datasets/cityscapes/val_Images_resize"

def getValues(dic_l, dic_a, dic_b, img_predict):

	height, width, channel = img_predict.shape

	# L, a, b channels
	L_channel = np.zeros((height, width))
	a_channel = np.zeros((height, width))
	b_channel = np.zeros((height, width))

	# convert to Lab color space
	Lab_image = cv2.cvtColor(img_predict, cv2.COLOR_RGB2LAB)
	L_channel, a_channel, b_channel = cv2.split(Lab_image)
	L_channel = L_channel / 255.0 * 100

	for i in range(height):
		for j in range(width):
			# L dictionary
			dic_l[L_channel[i,j]] += 1
			# a dictionary
			dic_a[a_channel[i,j]] += 1
			# b dictionary
			dic_b[b_channel[i,j]] += 1

	return dic_l, dic_a, dic_b

def getDistribution():
	# load data
	l = {}
	a = {}
	b = {}
	ff_l = {}
	ff_a = {}
	ff_b = {}
	for k in predict_dict.keys():

		predict_path = predict_dict[k]
		predict_files = [predict_f for predict_f in listdir(predict_path) if isfile(join(predict_path, predict_f))]

		num_pixel = 0
		# store values and numbers
		dic_l = defaultdict(int)
		dic_a = defaultdict(int)
		dic_b = defaultdict(int)

		for f in predict_files:
			if f == '.DS_Store':
			    continue
			img_predict = cv2.imread(join(predict_path, f))
			img_predict = np.asarray(img_predict)

			height, width, channel = img_predict.shape
			num_pixel += height * width

			dic_l, dic_a, dic_b = getValues(dic_l, dic_a, dic_b, img_predict)

		list_l = sorted(dic_l.items(), key=operator.itemgetter(0))
		list_a = sorted(dic_a.items(), key=operator.itemgetter(0))
		list_b = sorted(dic_b.items(), key=operator.itemgetter(0))

		# interpolation for L space
		l_key = np.array([item[0] for item in list_l])
		l_value = [item[1] for item in list_l]
		l_value = np.log(np.double(l_value) / num_pixel)
		f_l = interp1d(l_key, l_value, kind='cubic')
		min_l = np.min(l_key)
		max_l = np.max(l_key)
		num_l = max_l - min_l
		l_key_new = np.linspace(min_l, max_l, num = 30, endpoint = True)
		l[k] = l_key_new
		ff_l[k] = f_l

		# interpolation for a space
		a_key = np.array([item[0] for item in list_a])
		a_value = [item[1] for item in list_a]
		a_value = np.log(np.double(a_value) / num_pixel)
		f_a = interp1d(a_key, a_value, kind='cubic')
		min_a = np.min(a_key)
		max_a = np.max(a_key)
		num_a = max_a - min_a
		a_key_new = np.linspace(min_a, max_a, num = 30, endpoint = True)
		a[k] = a_key_new
		ff_a[k] = f_a

		# interpolation for b space
		b_key = np.array([item[0] for item in list_b])
		b_value = [item[1] for item in list_b]
		b_value = np.log(np.double(b_value) / num_pixel)
		f_b = interp1d(b_key, b_value, kind='cubic')
		min_b = np.min(b_key)
		max_b = np.max(b_key)
		num_b = max_b - min_b
		b_key_new = np.linspace(min_b, max_b, num = 30, endpoint = True)
		b[k] = b_key_new
		ff_b[k] = f_b

	
	# color distribution for L space
	plt.figure()
	for k in predict_dict.keys():
		plt.plot(l[k], ff_l[k](l[k]), '-', label = k)
	plt.legend()
	plt.xlabel('L', labelpad=10)
	plt.ylabel('logP(L)', labelpad=10)
	plt.title('Color Distribution for L Space')
	plt.savefig('result/L_distribution.jpg')

	# color distribution for a space
	plt.figure()
	for k in predict_dict.keys():
		plt.plot(a[k], ff_a[k](a[k]), '-', label = k)
	plt.legend()
	plt.xlabel('a', labelpad=10)
	plt.ylabel('logP(a)', labelpad=10)
	plt.title('Color Distribution for a Space')
	plt.savefig('result/a_distribution.jpg')

	# color distribution for b space
	plt.figure()
	for k in predict_dict.keys():
		plt.plot(b[k], ff_b[k](b[k]), '-', label = k)
	plt.legend()
	plt.xlabel('b', labelpad=10)
	plt.ylabel('logP(b)', labelpad=10)
	plt.title('Color Distribution for b Space')
	plt.savefig('result/b_distribution.jpg')

	return

def getLabels(list_real, list_predict, img_real, img_predict):

	assert img_real.shape == img_predict.shape
	height, width, channel = img_real.shape
	for i in range(height):
		for j in range(width):
			for k in range(channel):
				# real list
				if img_real[i,j,k] not in list_real:
					list_real.append(img_real[i,j,k])
				# predict list
				if img_predict[i,j,k] not in list_predict:
					list_predict.append(img_predict[i,j,k])
	return list_real, list_predict

def getScore(method, predict_path):
	# load data

	real_files = [real_f for real_f in listdir(real_path) if isfile(join(real_path, real_f))]
	predict_files = [predict_f for predict_f in listdir(predict_path) if isfile(join(predict_path, predict_f))]
	
	# store labels
	list_real = []
	list_predict = []

	for f in real_files:
		if f == '.DS_Store':
		    continue

		# there are corresponding images
		if f in predict_files:
			img_real = cv2.imread(join(real_path, f))
			img_predict = cv2.imread(join(predict_path, f))
			img_real = np.asarray(img_real)
			img_predict = np.asarray(img_predict)

			assert img_real.shape == img_predict.shape
			list_real, list_predict = getLabels(list_real, list_predict, img_real, img_predict)

	# sort lists
	list_real.sort()
 	list_predict.sort()

	len_real = len(list_real)
	len_predict = len(list_predict)

	assert len_real == len_predict

	dict_real = dict(zip(list_real, range(len_real)))
	dict_predict = dict(zip(list_predict, range(len_predict)))
	

	# confusion matrix
	confusion = np.zeros((len_real, len_predict))

	for f in real_files:
		if f == '.DS_Store':
		    continue

		# there are corresponding images
		if f in predict_files:
			img_real = cv2.imread(join(real_path, f))
			img_predict = cv2.imread(join(predict_path, f))
			img_real = np.asarray(img_real)
			img_predict = np.asarray(img_predict)

			assert img_real.shape == img_predict.shape
			height, width, channel = img_real.shape

			for i in range(height):
				for j in range(width):
					for k in range(channel):
						row = dict_real[img_real[i,j,k]]
						col = dict_predict[img_predict[i,j,k]]
						confusion[row, col] += 1

	diag = confusion.diagonal()
	row_sum = confusion.sum(1)
	col_sum = confusion.sum(0)
	all_sum = confusion.sum()
	# per-pixel
	OP = diag.sum() / all_sum

	# per-class
	PC = np.mean(diag / row_sum)

	# OIU
	IOU = np.mean(diag / (row_sum + col_sum - diag))

	print 

	print method + ": " + "OP = %f, PC = %f, IOU = %f" % (OP, PC, IOU)


if __name__ == "__main__":

	# FCN-scores: per-pixel, per-class, IOU
	for k in predict_dict.keys():
		getScore(k, predict_dict[k])