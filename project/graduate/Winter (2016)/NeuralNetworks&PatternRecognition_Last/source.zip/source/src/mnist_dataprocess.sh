SCRIPT="../pix2pix/scripts/combine_A_and_B.py"
#DATASET='../data/mnist/'
DATASET2='../data/mnist_red/'
DATASET3='../data/mnist_cn/'
DATASET4='../data/mnist_font/'
DATASET5='../data/mnist_back_cn/'
DATASET6='../data/mnist_back_giddyup59/'

A="A/"
B="B/"
train="train/"
val="val/"

#python $SCRIPT --fold_A $DATASET1$A --fold_B $DATASET1$B --fold_AB $DATASET1
#python $SCRIPT --fold_A $DATASET2$A --fold_B $DATASET2$B --fold_AB $DATASET2
#python $SCRIPT --fold_A $DATASET3$A --fold_B $DATASET3$B --fold_AB $DATASET3
#python $SCRIPT --fold_A $DATASET4$A --fold_B $DATASET4$B --fold_AB $DATASET4
python $SCRIPT --fold_A $DATASET5$A --fold_B $DATASET5$B --fold_AB $DATASET5
python $SCRIPT --fold_A $DATASET6$A --fold_B $DATASET6$B --fold_AB $DATASET6


