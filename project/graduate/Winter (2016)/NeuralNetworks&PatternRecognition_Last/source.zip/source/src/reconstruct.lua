-- usage: DATA_ROOT=/path/to/data/ name=expt1 which_direction=BtoA th test.lua
--
-- code derived from https://github.com/soumith/dcgan.torch
--

require 'image'
require 'nn'
require 'nngraph'
require 'optim'
util = paths.dofile('util/util.lua')
torch.setdefaulttensortype('torch.FloatTensor')

opt = {
    DATA_ROOT = '',           -- path to images (should have subfolders 'train', 'val', etc)
    batchSize = 1,            -- # images in batch
    loadSize = 256,           -- scale images to this size
    fineSize = 256,           --  then crop to this size
    flip=0,                   -- horizontal mirroring data augmentation
    display = 1,              -- display samples while training. 0 = false
    display_id = 200,         -- display window id.
    gpu = 1,                  -- gpu = 0 is CPU mode. gpu=X is GPU mode on GPU X
    how_many = 'all',         -- how many test images to run (set to all to run on every image found in the data/phase folder)
    which_direction = 'BtoA', -- AtoB or BtoA
    phase = 'val',            -- train, val, test ,etc
    preprocess = 'regular',   -- for special purpose preprocessing, e.g., for colorization, change this (selects preprocessing functions in util.lua)
    aspect_ratio = 1.0,       -- aspect ratio of result images
    name = '',                -- name of experiment, selects which model to run, should generally should be passed on command line
    input_nc = 3,             -- #  of input image channels
    output_nc = 3,            -- #  of output image channels
    serial_batches = 1,       -- if 1, takes images in order to make batches, otherwise takes them randomly
    serial_batch_iter = 1,    -- iter into serial image list
    cudnn = 1,                -- set to 0 to not use cudnn (untested)
    checkpoints_dir = './checkpoints', -- loads models from here
    results_dir='./results/',          -- saves results here
    which_epoch = 'latest',            -- which epoch to test? set to 'latest' to use latest cached model
}


-- one-line argument parser. parses enviroment variables to override the defaults
for k,v in pairs(opt) do opt[k] = tonumber(os.getenv(k)) or os.getenv(k) or opt[k] end
opt.nThreads = 1 -- test only works with 1 thread...
-- print(opt)
if opt.display == 0 then opt.display = false end


local netG = util.load('checkpoints/cityscapes/latest_net_G.t7', opt)
local net = nn.Sequential()
for i=1,5 do
    local layer = netG:get(i)
    print(torch.type(layer))
    net:add(layer)
end

local data = image.load('datasets/cityscapes/val/15.jpg',3)
data = data[{{}, {}, {257, 512}}]
local input = util.preprocess(data)
input:resize(1, 3, 256, 256)
local save = util.deprocess_batch(input):float()
image.save('results/input.jpg', save[1])
input = input:cuda()

local target = net:forward(input):cuda():clone()

-- Initialize the image
local img = torch.randn(input:size()):float():mul(0.01)
save = util.deprocess_batch(img):float()
image.save('results/noise.jpg', save[1])
img = img:cuda()

local crit = nn.MSECriterion():cuda()

local function df_dx(x)
    local y = net:forward(x):cuda()
    local loss = crit:forward(y, target)
    local gradOutput = crit:backward(y, target)
    -- local loss = forward(y)
    -- local gradOutput = backward(y)
    local gradInput = net:updateGradInput(x, gradOutput)
    return loss, gradInput
end

optim_state = {
  learningRate = 0.01,
}

for t = 1, 1000 do
    optim.adam(df_dx, img, optim_state)
end

save = util.deprocess_batch(img):float()
image.save('results/recon.jpg', save[1])
