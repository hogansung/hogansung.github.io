from keras.models import Model, Sequential
from keras.layers import Activation, Input, Reshape, merge, Lambda, Dropout, Flatten, Dense
from keras.layers.convolutional import Convolution2D, Deconvolution2D, ZeroPadding2D, Cropping2D
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.normalization import BatchNormalization
from keras.utils.visualize_util import plot

import keras.backend as K
import numpy as np

def conv(x, nf, norm=True):
    y = LeakyReLU(0.2)(x)
    y = ZeroPadding2D(padding=(1, 1))(y)
    y = Convolution2D(nf, 4, 4, subsample=(2, 2))(y)
    if norm:
        y = BatchNormalization(epsilon=1e-5)(y)
    return y

def deconv(x, nf, output_size, norm=True):
    y = Activation('relu')(x)
    y = Deconvolution2D(nf, 4, 4, output_shape=(None, output_size, output_size, nf),border_mode='same',subsample=(2,2))(y)
    if norm:
        y = BatchNormalization(epsilon=1e-5)(y)
    return y

def generator(input_size, nf=64, p=0.5):
    g_inputs = Input(shape=(input_size, input_size, 3))

    # input_size * input_size * 3 
    e1 = ZeroPadding2D(padding=(1, 1))(g_inputs)
    e1 = Convolution2D(nf, 4, 4, subsample=(2, 2))(e1)
    # input_size/2 * input_size/2 * nf
    e2 = conv(e1, nf * 2)
    # input_size/4 * input_size/4 * (nf*2)
    e3 = conv(e2, nf * 4)
    # input_size/8 * input_size/8 * (nf*4)
    e4 = conv(e3, nf * 8)
    # input_size/16 * input_size/16 * (nf*8)
    e5 = conv(e4, nf * 8)
    # input_size/32 * input_size/32 * (nf*8)
    e6 = conv(e5, nf * 8)
    # input_size/64 * input_size/64 * (nf*8)
    e7 = conv(e6, nf * 8)
    # input_size/128 * input_size/128 * (nf*8)
    if input_size == 256:
        e8 = conv(e7, nf*8)
        # input_size/256 * input_size/256 * (nf*8)
        g0 = deconv(e8, nf*8, output_size=input_size/128)
        g0 = Dropout(p)(g0)
        g0 = merge([g0, e7], mode='concat', concat_axis=-1)
        # input_size/128 * input_size/128 * (nf*8)
    g1 = deconv(e7, nf * 8, output_size=input_size/64)
    g1 = Dropout(p)(g1)
    g1 = merge([g1, e6], mode='concat', concat_axis=-1)
    # input_size/64 * input_size/64 * (nf*8)
    g2 = deconv(g1, nf * 8, output_size=input_size/32)
    g2 = Dropout(p)(g2)
    g2 = merge([g2, e5], mode='concat', concat_axis=-1)
    # input_size/32 * input_size/32 * (nf*8)
    g3 = deconv(g2, nf * 8, output_size=input_size/16)
    g3 = Dropout(p)(g3)
    g3 = merge([g3, e4], mode='concat', concat_axis=-1)
    # input_size/16 * input_size/16 * (nf*8)
    g4 = deconv(g3, nf * 4, output_size=input_size/8)
    g4 = merge([g4, e3], mode='concat', concat_axis=-1)
    # input_size/8 * input_size/8 * (nf*4)
    g5 = deconv(g4, nf * 2, output_size=input_size/4)
    g5 = merge([g5, e2], mode='concat', concat_axis=-1)
    # input_size/4 * input_size/4 * (nf*2)
    g6 = deconv(g5, nf, output_size=input_size/2)
    g6 = merge([g6, e1], mode='concat', concat_axis=-1)
    # input_size/2 * input_size/2 * nf
    g7 = deconv(g6, 3, output_size=input_size, norm=False)
    g_outputs = Activation('tanh')(g7)
    # input_size * input_size * 3 

    G = Model(input=g_inputs, output=g_outputs)
    plot(G, to_file='../model/model_G.png', show_shapes=True)
    return G

def discriminator(input_size, channel, nf=64, n_layers=3):
    d_inputs = Input(shape=(input_size, input_size, channel))
    # input_size * input_size * out_put
    d_hidden = ZeroPadding2D(padding=(1, 1))(d_inputs)
    d_hidden = Convolution2D(nf, 4, 4, subsample=(2, 2))(d_hidden)
    # input_size/2 * input_size/2 * nf
    if input_size == 256:
        n_layers = n_layers+1
    ndf = nf
    for i in range(n_layers-1):
        ndf = min(nf * 8, ndf * 2)
        d_hidden = conv(d_hidden, ndf)
    ndf = min(nf * 8, ndf * 2)
    d_hidden = LeakyReLU(0.2)(d_hidden)
    d_hidden = ZeroPadding2D(padding=(1, 1))(d_hidden)
    d_hidden = Convolution2D(ndf, 4, 4, subsample=(1, 1))(d_hidden)
    d_hidden = BatchNormalization(epsilon=1e-5)(d_hidden)
    d_hidden = LeakyReLU(0.2)(d_hidden)
    d_hidden = ZeroPadding2D(padding=(1, 1))(d_hidden)
    d_hidden = Convolution2D(1, 4, 4, subsample=(1, 1))(d_hidden)
    d_outputs = Activation('sigmoid')(d_hidden)
    # d2 = conv(d1, nf * 2)
    # # 32 * 32 * (nf * 2)
    # d3 = conv(d2, nf * 4)
    # # 16 * 16 * (nf * 4)
    # d4 = conv(d3, nf * 8)
    # # 8 * 8 * (nf * 8)
    # d5 = conv(d4, nf * 8)
    # # 4 * 4 * (nf * 8)
    # d6 = conv(d5, nf * 8)
    # # 2 * 2 * (nf * 8)
    # d7 = conv(d6, nf * 8)
    # # 1 * 1 * (nf * 8)
    # d8 = Flatten()(d7)
    # d8 = Dense(1)(d8)
    # d_outputs = Activation('sigmoid')(d8)

    D = Model(input=d_inputs, output=d_outputs)
    plot(D, to_file='../model/model_D.png', show_shapes=True)
    return D

def cGAN(G, D, input_size=128):
    gan_inputs = Input(shape=(input_size, input_size, 3))
    g_outputs = G(gan_inputs)
    d_inputs = merge([gan_inputs, g_outputs], mode='concat', concat_axis=-1)
    d_outputs = D.layers[1](d_inputs)
    for i in range(2, len(D.layers)):
        d_outputs = D.layers[i](d_outputs)
    GAN = Model(input=gan_inputs, output=[g_outputs, d_outputs])
    plot(GAN, to_file='../model/model_GAN.png', show_shapes=True)
    return GAN

def GAN(G, D, input_size=128):
    gan_inputs = Input(shape=(input_size, input_size, 3))
    g_outputs = G(gan_inputs)
    d_outputs = D.layers[1](g_outputs)
    for i in range(2, len(D.layers)):
        d_outputs = D.layers[i](d_outputs)
    GAN = Model(input=gan_inputs, output=[g_outputs, d_outputs])
    return GAN

if __name__ == "__main__":
    G = generator(256)
    D = discriminator(256, 6)
    cGAN = cGAN(G, D,256)


