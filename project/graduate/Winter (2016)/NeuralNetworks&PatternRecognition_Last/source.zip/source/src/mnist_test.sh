python test.py 128 'AtoB' 'mnist' 'mnist_cGAN_l1'
python test.py 128 'AtoB' 'mnist_red' 'mnist_cGAN_l1'
python test.py 128 'AtoB' 'mnist_font' 'mnist_cGAN_l1'
python test.py 128 'AtoB' 'mnist_cn' 'mnist_cGAN_l1'
python test.py 128 'AtoB' 'mnist_back_gibbyup59' 'mnist_cGAN_l1'
python test.py 128 'AtoB' 'mnist_back_cn' 'mnist_cGAN_l1'

