from PIL import Image
import numpy as np
from os.path import isdir
from os import makedirs

def preprocess(x):
    # Scale input 0 to 255 to -1 to 1.
    func = np.vectorize(lambda x: x/127.5-1)
    return func(x)

def deprocess(x):
    # Scale output -1 to 1 back to 0 to 255.
    func = np.vectorize(lambda x: (x+1)*127.5)
    return func(x)

def readData(dataset='../data/cityscapes/', size=128, n_train=1024, n_valid=128):
    print("Reading Data...")
    x_train = np.empty([n_train, size, size, 3])
    y_train = np.empty([n_train, size, size, 3])

    img = Image.open(dataset + 'train/1.jpg')
    w, h = img.size
    for i in range(1, n_train+1):
        s = dataset + "train/" + str(i) + ".jpg"
        img = Image.open(s)
        limg = img.crop((0, 0, w/2, h)).resize((size, size))
        rimg = img.crop((w/2, 0, w, h)).resize((size, size))

        x_train[i-1] = np.array(rimg.getdata()).reshape(size, size, 3)
        y_train[i-1] = np.array(limg.getdata()).reshape(size, size, 3)

    x_test = np.empty([n_valid, size, size, 3])
    y_test = np.empty([n_valid, size, size, 3])

    for i in range(1, n_valid+1):
        s = dataset + "val/" + str(i) + ".jpg"
        img = Image.open(s)
        limg = img.crop((0, 0, w/2, h)).resize((size, size))
        rimg = img.crop((w/2, 0, w, h)).resize((size, size))

        x_test[i-1] = np.array(rimg.getdata()).reshape(size, size, 3)
        y_test[i-1] = np.array(limg.getdata()).reshape(size, size, 3)

    x_train = preprocess(x_train)
    y_train = preprocess(y_train)
    x_test = preprocess(x_test)
    y_test = preprocess(y_test)

    print("Finish")
    print("Training samples: %d\nTesting samples: %d"%(len(x_train), len(x_test)))

    return x_train, y_train, x_test, y_test


def showImage(x, y, gx, title='image', size=128):
    img = Image.new("RGB", (size*3, size))
    im = np.append(x, y, axis=1)
    im = np.append(im, gx, axis=1)
    im = list(im.reshape(size * size * 3, 3))
    im = [map(int, z) for z in im]
    im = map(tuple, im)
    img.putdata(im)
    img.show(title)

def saveImage(x, y, gx, title='', saveDir='', size=128):
    img = Image.new("RGB", (size*3, size))
    im = np.append(x, y, axis=1)
    im = np.append(im, gx, axis=1)
    im = list(im.reshape(size * size * 3, 3))
    im = [map(int, z) for z in im]
    im = map(tuple, im)
    img.putdata(im)
    if not isdir(saveDir):
        makedirs(saveDir)
    img.save(saveDir + str(title) + '.png')

if __name__ == '__main__':
    readData()
