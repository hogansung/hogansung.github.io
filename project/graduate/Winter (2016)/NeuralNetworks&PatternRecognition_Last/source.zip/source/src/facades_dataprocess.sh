#!/bin/sh
# Download facades base and extended datasets
facades_web="http://cmp.felk.cvut.cz/~tylecr1/facade/"
facades_base="CMP_facade_DB_base.zip"
facades_ext="CMP_facade_DB_extended.zip"
facades_base_url=$facades_web$facades_base
facades_ext_url=$facades_web$facades_ext
data_folder="../data/"
if [ ! -f "$data_folder$facades_base" ]
then
    wget -P $data_folder $facades_base_url 
fi

if [ ! -f "$data_folder$facades_ext" ]
then
    wget -P $data_folder $facades_ext_url
fi
TRAIN="../data/base/"
VAL="../data/extended/"

if [ ! -d "$TRAIN" ]
then
    unzip $data_folder$facades_base -d $data_folder
fi

if [ ! -d "$VAL" ]
then
    echo "No $VAL direcotry. unzip"
    unzip $data_folder$facades_ext -d $data_folder 
fi
# initialize 
SCRIPT="../pix2pix/scripts/combine_A_and_B.py"
DATA="../data/facades/"
A="A/"
B="B/"
TR_FOLDER="train/"
VAL_FOLDER="val/"

# create target folder
mkdir -p $DATA
echo "created $DATA"

# create train and val for A folder.
pathA=$DATA$A
pathB=$DATA$B
# create folders.
mkdir -p $pathA
echo "created $pathA"
mkdir -p $pathB
echo "created $pathB"

# move all labels to folder A and all photos to folder B. remove the rest of the files.
trainPathA=$pathA$TR_FOLDER
valPathA=$pathA$VAL_FOLDER
trainPathB=$pathB$TR_FOLDER
valPathB=$pathB$VAL_FOLDER
mkdir -p $trainPathA
mkdir -p $trainPathB
mkdir -p $valPathA
mkdir -p $valPathB

cp $TRAIN*.png $trainPathA
cp $VAL*.png $valPathA
cp $TRAIN*.jpg $trainPathB
cp $VAL*.jpg $valPathB

mogrify -format jpg $trainPathA*.png
mogrify -format jpg $valPathA*.png

rm $trainPathA*.png
rm $valPathA*.png
# create folder train and val under facades.
echo $pathA
echo $pathB
echo $DATA
python $SCRIPT --fold_A $pathA --fold_B $pathB --fold_AB $DATA
