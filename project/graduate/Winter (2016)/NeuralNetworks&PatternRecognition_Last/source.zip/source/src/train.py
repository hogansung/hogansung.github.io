from tqdm import *
from model import generator, discriminator, cGAN
from preprocess import readData, showImage, saveImage, preprocess, deprocess
from keras.models import Model
from keras.optimizers import Adam
import numpy as np
from PIL import Image
import math
import keras.backend as K


EPOCH = 50
BATCH_SIZE = 8
N_FILTER = 64
N_LAYER = 4
L1_WEIGHT = 100
N_TRAIN = 2968
N_VALID = 256
INPUT_SIZE = 128
DATASET = '../datasets/cityscapes/'

G = generator(nf=N_FILTER)
D = discriminator(nf=N_FILTER, n_layers=N_LAYER)
GAN = cGAN(G, D)

G_optim = Adam(lr=0.0002, beta_1=0.5)
G.compile(optimizer=G_optim, loss='binary_crossentropy')
G.summary()

D_optim = Adam(lr=0.0002, beta_1=0.5)
D.compile(optimizer=D_optim, loss='binary_crossentropy')
D.summary()

GAN.compile(optimizer=G_optim, loss=['mean_absolute_error', 'binary_crossentropy'], loss_weights=[L1_WEIGHT, 1])

x_train, y_train, x_valid, y_valid = readData(dataset=DATASET, n_train=N_TRAIN, n_valid=N_VALID, size=INPUT_SIZE)

patch_size = D.output_shape[1]

real_label = np.array([1] * BATCH_SIZE * patch_size * patch_size).reshape(BATCH_SIZE, patch_size, patch_size, 1)
fake_label = np.array([0] * BATCH_SIZE * patch_size * patch_size).reshape(BATCH_SIZE, patch_size, patch_size, 1)

real_vlabel = np.array([1] * len(x_valid) * patch_size * patch_size).reshape(len(x_valid), patch_size, patch_size, 1)
fake_vlabel = np.array([0] * len(x_valid) * patch_size * patch_size).reshape(len(x_valid), patch_size, patch_size, 1)

print("Start training")
print("Batch size = %d"%(BATCH_SIZE))
print("# of filter for first layer = %d"%(N_FILTER))
print("# of layer for discriminator = %d"%(N_LAYER))
print("lambda for L1 = %d"%(L1_WEIGHT))

for epo in range(1, EPOCH+1):
    print("Epoch %d/%d"%(epo, EPOCH))
    train_size = len(x_train)
    valid_size = len(x_valid)
    n_batch = train_size / BATCH_SIZE

    # train on batch
    for i in tqdm(range(n_batch)):
        x_batch = x_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
        y_batch = y_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]

        gen = G.predict_on_batch(x_batch)
        fake = np.append(x_batch, gen, axis=3)
        real = np.append(x_batch, y_batch, axis=3)

        D.trainable = True
        D.train_on_batch(real, real_label)
        D.train_on_batch(fake, fake_label)

        D.trainable = False
        GAN.train_on_batch(x_batch, [y_batch, real_label])

    # test on validation set
    gen = G.predict_on_batch(x_valid)
    fake = np.append(x_valid, gen, axis=3)
    real = np.append(x_valid, y_valid, axis=3)

    lossD_real = D.test_on_batch(real, real_vlabel)
    lossD_fake = D.test_on_batch(fake, fake_vlabel)
    errG = GAN.test_on_batch(x_valid, [y_valid, real_vlabel])
    lossD = (lossD_fake + lossD_real) / 2
    print("On validation set, lossD = %f, L1_G = %f, lossG = %f"%(lossD, errG[0], errG[1]))
    for i in range(5):
        #showImage(deprocess(x_valid[i]), deprocess(y_valid[i]), deprocess(fake[i,:,:,3:]), str(epo+1))
        saveImage(deprocess(x_valid[i]), deprocess(y_valid[i]), deprocess(fake[i,:,:,3:]), str(epo)+'_'+str(i+1))
    # save weights for every 10 epoch
    if epo % 10 == 0:
        G.save_weights("../model/G_weight.h5")
        D.save_weights("../model/D_weight.h5")

G.save_weights("../model/G_weight.h5")
D.save_weights("../model/D_weight.h5")
