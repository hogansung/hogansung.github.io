from tqdm import *
from model import generator, discriminator, cGAN, GAN
from preprocess import readData, showImage, saveImage, preprocess, deprocess
from keras.models import Model
from keras.optimizers import Adam
import numpy as np
from PIL import Image
import math
import keras.backend as K
import argparse
import random
#import matplotlib.pyplot as plt
from os.path import isdir, basename
from os import makedirs
import cPickle as pickle

parser = argparse.ArgumentParser('train the cGAN')
parser.add_argument('batchSize', 
    help='images in batch', 
    type=int, default=32)
parser.add_argument('fineSize',
    help='crop size', 
    type=int, default=256)
parser.add_argument('niter',
    help='# of iter at starting learning rate', 
    type=int, default=200)
parser.add_argument('which_direction', 
    help='AtoB or BtoA', 
    type=str, default='AtoB')
parser.add_argument('condition_GAN',
    help='set to 0 use unconditional discriminator', 
    type=int, default=1)
parser.add_argument('use_GAN', 
    help='set to 0 to turn off GAN term', 
    type=int, default=1)
parser.add_argument('use_L1', 
    help='set to 0 to turn off L1 term', 
    type=int, default=1)
parser.add_argument('dataset')
parser.add_argument('run_name')
args = parser.parse_args()

EPOCH = args.niter
BATCH_SIZE = args.batchSize
N_FILTER = 64
N_LAYER = 3
L1_WEIGHT = 100
INPUT_SIZE = args.fineSize
COND_GAN = args.condition_GAN
use_GAN = args.use_GAN
use_L1 = args.use_L1
WHICH_DIRECTION = args.which_direction
DATASET = '../data/%s/'%(args.dataset)
RESULT = '../result/keras/%s/%s/'%(args.dataset, args.run_name)

G = generator(INPUT_SIZE, nf=N_FILTER)

if use_L1 == 0:
    L1_WEIGHT=0

if COND_GAN == 1:
    D = discriminator(INPUT_SIZE, 6 , nf=N_FILTER, n_layers=N_LAYER)
    GAN = cGAN(G, D, INPUT_SIZE)
else:
    D = discriminator(INPUT_SIZE, 3 , nf=N_FILTER, n_layers=N_LAYER)
    GAN = GAN(G, D, INPUT_SIZE)
    
G_optim = Adam(lr=0.0002, beta_1=0.5)
G.compile(optimizer=G_optim, loss='mean_absolute_error')
G.summary()

D_optim = Adam(lr=0.0002, beta_1=0.5)
D.compile(optimizer=D_optim, loss='binary_crossentropy')
D.summary()

if use_GAN == 1:
    GAN.compile(optimizer=G_optim, loss=['mean_absolute_error', 'binary_crossentropy'],
                loss_weights=[L1_WEIGHT, 1])
else:
    GAN.compile(optimizer=G_optim, loss=['mean_absolute_error', 'binary_crossentropy'],
                loss_weights=[L1_WEIGHT, 0]) # When use_GAN = 0, use_L1 is always 1.
x_train, y_train, files_train, x_valid, y_valid, files_valid = readData(DATASET, WHICH_DIRECTION, INPUT_SIZE)

patch_size = D.output_shape[1]

real_label = np.ones((BATCH_SIZE, patch_size, patch_size, 1))
fake_label = np.zeros((BATCH_SIZE, patch_size, patch_size, 1))
real_vlabel = np.ones((len(x_valid), patch_size, patch_size, 1))
fake_vlabel = np.zeros((len(x_valid), patch_size, patch_size, 1))

print("Start training")
print("Batch size = %d"%(BATCH_SIZE))
print("# of filter for first layer = %d"%(N_FILTER))
print("# of layer for discriminator = %d"%(N_LAYER))
print("lambda for L1 = %d"%(L1_WEIGHT))

trlossDs = []
trL1_Gs = []
trlossGs = []

valossDs = []
vaL1_Gs = []
valossGs = []

for epo in range(1, EPOCH+1):
    print("Epoch %d/%d"%(epo, EPOCH))
    train_size = len(x_train)
    valid_size = len(x_valid)
    n_batch = train_size / BATCH_SIZE

    # train on batch
    for i in tqdm(range(n_batch)):
        x_batch = x_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
        y_batch = y_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]

        gen = G.predict_on_batch(x_batch)
        if COND_GAN == 1:
            fake = np.append(x_batch, gen, axis=3)
            real = np.append(x_batch, y_batch, axis=3)
        else:
            fake = gen
            real = y_batch

        for layer in D.layers:
            layer.trainable = True
        
        D.train_on_batch(real, real_label)
        D.train_on_batch(fake, fake_label)

        for layer in D.layers:
            layer.trainable = False
        
        GAN.train_on_batch(x_batch, [y_batch, real_label])

    # test on a random training set
    i = random.randint(0, n_batch-1)
    x_batch = x_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
    y_batch = y_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
    x_nams = files_train[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
    gen = G.predict_on_batch(x_batch)
    
    if COND_GAN==1:
        fake = np.append(x_batch, gen, axis=3)
        real = np.append(x_batch, y_batch, axis=3)
    else:
        fake = gen
        real = y_batch

    lossD_real = D.test_on_batch(real, real_label)
    lossD_fake = D.test_on_batch(fake, fake_label)
    errG = GAN.test_on_batch(x_batch, [y_batch, real_label])
    lossL1 = errG[0]
    lossG = errG[1]
    lossD = (lossD_fake + lossD_real) / 2
    print("On training set, lossD = %f, L1_G = %f, lossG = %f"%(lossD, lossL1, lossG))
    for i in range(5):
        img_name = basename(x_nams[i]).split('.')[0]
        saveImage(deprocess(x_batch[i]), deprocess(y_batch[i]), deprocess(gen[i]), str(epo)+'_'+str(i+1), "%strain/%s/"%(RESULT, img_name), INPUT_SIZE)
       
    
    # test on validation set
    gen = G.predict_on_batch(x_valid)
    
    if COND_GAN==1:
        fake = np.append(x_valid, gen, axis=3)
        real = np.append(x_valid, y_valid, axis=3)
    else:
        fake = gen
        real = y_valid

    lossD_real = D.test_on_batch(real, real_vlabel)
    lossD_fake = D.test_on_batch(fake, fake_vlabel)
    errG = GAN.test_on_batch(x_valid, [y_valid, real_vlabel])
    lossL1 = errG[0]
    lossG = errG[1]
    lossD = (lossD_fake + lossD_real) / 2
    valossDs.append(lossD)
    valossGs.append(lossG)
    print("On validation set, lossD = %f, L1_G = %f, lossG = %f"%(lossD, lossL1, lossG))
    trlossDs.append(lossD)
    trlossGs.append(lossG)
    
    for i in range(5):
        img_name = basename(files_valid[i]).split('.')[0]
        saveImage(deprocess(x_valid[i]), deprocess(y_valid[i]), deprocess(gen[i]), str(epo)+'_'+str(i+1), "%sval/%s/"%(RESULT, img_name), INPUT_SIZE)
    # save weights for every 10 epoch
    if epo % 10 == 0:
        G.save_weights("%sG_weight.h5"%RESULT)
        D.save_weights("%sD_weight.h5"%RESULT)
        GAN.save_weights("%sGAN_weight.h5"%RESULT)

data = trlossDs, trL1_Gs, trlossGs, valossDs, vaL1_Gs, valossGs
f = file('%slosses.pkl'%(RESULT), 'wb')
pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
f.close

G.save_weights("%slatest_G_weight.h5"%RESULT)
D.save_weights("%slatest_D_weight.h5"%RESULT)
GAN.save_weights("%slatest_GAN_weight.h5"%RESULT)

