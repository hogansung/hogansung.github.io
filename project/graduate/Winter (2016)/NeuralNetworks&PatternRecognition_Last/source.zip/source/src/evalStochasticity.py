from os import walk
from os.path import isfile, isdir
import numpy as np
from keras.preprocessing import image
# visualize using TSNE
from sklearn.manifold import TSNE
# We'll use matplotlib for graphics.
import matplotlib.pyplot as plt
import matplotlib.patheffects as PathEffects
# We import seaborn to make nice plots. Reference:https://github.com/oreillymedia/t-SNE-tutorial
import seaborn as sns

import cPickle as pickle

import matplotlib.patches as mpatches

def savePkl(dataset, pklfile):
    # Save small pkl files.
    f = file(pklfile, 'wb')
    pickle.dump(dataset, f, protocol=pickle.HIGHEST_PROTOCOL)
    f.close  
      
def loadPkl(pklfile):
    # Load small pkl files.
    f = open(pklfile, 'rb')
    dataset = pickle.load(f)
    f.close
    return dataset


sns.set_style('darkgrid')
sns.set_palette('muted')
sns.set_context("notebook", font_scale=1.5,
                rc={"lines.linewidth": 2.5})

#LUA_FOLDER = 'cityscapes_cGAN_yesl1_bs_32'
LUA_FOLDERS = ['cityscapes_dropout_0.1', 'cityscapes_dropout_0.3', 'cityscapes_cGAN_yesl1_bs_32', 'cityscapes_nodropout']
LEGENDS = ['dropout=0.1', 'dropout=0.3', 'dropout=0.5', 'no dropout']
COLORCHANNELS=['R', 'G', 'B', 'ALL']

#LUA_FOLDER = 'cityscapes_dropout_0.3'
#LUA_FOLDER = 'cityscapes_nodropout'
RESULT_FOLDER = '../result/lua/'
IMAGES_FOLDERS = ['../result/lua/%s/latest_net_G_val/images/'%(LUA_FOLDER) for LUA_FOLDER in LUA_FOLDERS]
INPUT_FOLDER = 'input'
OUTPUT_FOLDER = 'output'
TARGET_FOLDER = 'target'
N_REPEAT = 10
IMG_ID = 100 # first input image.
N_BINS=256
def getImgInfo(imageFileName):
    id_and_rest = imageFileName.split('_')
    img_id = id_and_rest[0]
    rep_and_extension = id_and_rest[1].split('.')
    repeat = rep_and_extension[0]
    extension = rep_and_extension[1]
    return img_id, repeat, extension

def getOutput(img_id, images_folder = IMAGES_FOLDERS[0], channel = 'ALL', n_repeat = N_REPEAT):
    output_path = '%s%s/'%(images_folder, OUTPUT_FOLDER)
    X = []
    for i in range(n_repeat):
        img_path = '%s%d_%d.jpg'%(output_path, img_id, i+1)
        # load image
        img = image.load_img(img_path, False) # false for color image.
        # vectorize image
        x = image.img_to_array(img)
        if channel == 'R':
            x = x[:, :, 0]
        elif channel == 'G':
            x = x[:, :, 1]
        elif channel == 'B':
            x = x[:, :, 2]
        flat_x = x.flatten()
        # add to imgs list.
        X.append(flat_x)
    return X

def scatter(x, colors, nClasses):
    print x.shape, colors.shape, x.dtype, colors.dtype
    # We choose a color palette with seaborn.
    palette = np.array(sns.color_palette("hls", nClasses))

    # We create a scatter plot.
    f = plt.figure(figsize=(8, 8))
    ax = plt.subplot(aspect='equal')
    sc = ax.scatter(x[:,0], x[:,1], lw=0,# s=40,# s: scalar or array_like, shape(n, )
                    c=palette[colors.astype(np.int)])
    plt.xlim(-25, 25)
    plt.ylim(-25, 25)
    ax.axis('off')
    ax.axis('tight')
    # We add the labels for each digit.
    txts = []
    print np.unique(colors)
    for i in range(nClasses):
        # Position of each label.
        xtext, ytext = np.median(x[colors == i, :], axis=0)
        txt = ax.text(xtext, ytext, LEGENDS[i], fontsize=24)
        txt.set_path_effects([
            PathEffects.Stroke(linewidth=5, foreground="w"),
            PathEffects.Normal()])
        txts.append(txt)
    plt_path = '%sTSNE_img%d.png'%(RESULT_FOLDER, IMG_ID)
    #plt.show()
    plt.savefig(plt_path, dpi=120)
    return f, ax, sc, txts

def visualizeTSNE(imgs, labels, N):
    print "visualizing TSNE"
    Xa = np.vstack([imgs[labels==i]
                   for i in range(N)])
    ya = np.hstack([labels[labels==i]
                   for i in range(N)])
    print Xa.shape, ya.shape
    # Create data projections.
    RS = 20170309
    # Save positions into the global variable.
    #sklearn.manifold.t_sne._gradient_descent = _gradient_descent
    proj = TSNE(random_state=RS).fit_transform(Xa)
    # calculate variance np.hstack([np.std(proj[labels==i]) for i in range(TempN)])
    f,ax, sc, txts = scatter(proj, ya, N)
    return proj, labels
def getInputImageIds(image_folder = IMAGES_FOLDERS[0]):
    input_path = '%s%s/'%(image_folder, INPUT_FOLDER)
    for root, dirs, files in walk(input_path):
        return [int(f.split('.')[0]) for f in files]

def TSNEReport():
    imgs = []
    labels = []
    count = 0
    for img_folder in IMAGES_FOLDERS:
        X = getOutput(IMG_ID, img_folder)
        y = np.ones(len(X), dtype=np.int)*count
        imgs.extend(X)
        labels.extend(y)
        count += 1
        data = imgs, labels
#        savePkl(data, tempfile)
#        print ('saving %s...')%(tempfile)
    print ('data loaded.')
    return visualizeTSNE(np.matrix(imgs), np.array(labels), len(IMAGES_FOLDERS))
    
def HistReport(channel = 'ALL'):
    print "Generating histogram reports..."
    # Or look at histograms.
    palette = np.array(sns.color_palette("hls", len(IMAGES_FOLDERS)))
    count = 0
    handles = []
    for img_folder in IMAGES_FOLDERS:
        X = getOutput(IMG_ID, img_folder, channel)
        Xmat = np.matrix(X)
        Xvec = Xmat.flatten()
        plt.hist(np.transpose(Xvec), N_BINS, normed=1, 
                               facecolor=palette[int(count)], alpha=0.75)
        handles.append(mpatches.Patch(color=palette[int(count)],
                                      label=LEGENDS[count]))
        count += 1
    plt.xlabel('pixel values')
    plt.ylabel('frequency')
    channelstr = 'across RGB'
    if channel == 'R':
        channelstr = 'in Red'
    elif channel == 'G':
        channelstr = 'in Green'
    elif channel == 'B':
        channelstr = 'in Blue'
        
    plt.title('Histogram of pixel value %s'%(channelstr))
    plt.grid(True)
    plt.legend(handles=handles)
    filepath = '%shist_%s_img%d.png'%(RESULT_FOLDER, channel, IMG_ID)
    plt.savefig(filepath, dpi=120)
    #plt.show()
    print "Done."
if __name__ == '__main__':
    #proj, labels = TSNEReport()
    #print "projected data shape:", proj.shape # nx 2
    #HistReport2D(proj, labels)
    for color in COLORCHANNELS:
        HistReport(color) # R, G, B, ALL
    # or look at the variance of each dimension.
