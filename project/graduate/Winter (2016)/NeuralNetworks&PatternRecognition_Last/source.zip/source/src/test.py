from tqdm import *
from model import generator, discriminator, cGAN, GAN
from preprocess import readData, showImage, saveImage, preprocess, deprocess
from keras.models import Model
from keras.optimizers import Adam
import numpy as np
from PIL import Image
import math
import keras.backend as K
import argparse
import random
import matplotlib.pyplot as plt
from os.path import isdir, basename
from os import makedirs
import cPickle as pickle
from scipy.misc import imsave

parser = argparse.ArgumentParser('test the cGAN')
parser.add_argument('fineSize',
    help='crop size', 
    type=int, default=256)
parser.add_argument('which_direction', 
    help='AtoB or BtoA', 
    type=str, default='AtoB')
parser.add_argument('dataset')
parser.add_argument('run_name')
args = parser.parse_args()
use_L1 = True
N_FILTER = 64
INPUT_SIZE = args.fineSize
WHICH_DIRECTION = args.which_direction
DATASET = '../data/%s/'%(args.dataset)
RESULT = '../result/keras/%s/%s/'%(args.dataset, args.run_name)

G = generator(INPUT_SIZE, nf=N_FILTER)
G_optim = Adam(lr=0.0002, beta_1=0.5)
G.compile(optimizer=G_optim, loss='mean_absolute_error')
G.summary()

_, _, _, x_valid, y_valid, files_valid = readData(DATASET, WHICH_DIRECTION, INPUT_SIZE)

print("Start testing")

# Load weights
weightpath = "%slatest_G_weight.h5"%RESULT
G.load_weights(weightpath)
gen = G.predict_on_batch(x_valid)
inputdir = "%sinput/"%(RESULT)
outputdir = "%soutput/"%(RESULT)
targetdir = "%starget/"%(RESULT)
dirs = [inputdir, outputdir, targetdir]
for d in dirs:
    if not isdir(d):
        makedirs(d)
        
for i in range(len(y_valid)):
    img_name = basename(files_valid[i]).split('.')[0]
    path_in = "%s%s.png"%(inputdir, img_name)
    path_out = "%s%s.png"%(outputdir, img_name)
    path_target = "%s%s.png"%(targetdir, img_name)
    imsave(path_in, x_valid[i])
    imsave(path_out, gen[i])
    imsave(path_target, y_valid[i])

# load losses
loss_path = "%slosses.pkl"%(RESULT)
f = open(loss_path, 'rb')
dataset = pickle.load(f)
f.close
trlossDs, trL1_Gs, trlossGs, valossDs, vaL1_Gs, valossGs = dataset

# Save and plot losses.
plt.plot(valossDs)
if use_L1:
    plt.plot(vaL1_Gs)
plt.plot(valossGs)
plt.title('Validation losses over Epoch')
plt.xlabel('Number of Epochs')
plt.ylabel('Training Losses')
if use_L1:
    plt.legend(['Descriminator Loss', 'Generator L1 Loss', 'Generator Loss'])
else:
    plt.legend(['Descriminator Loss', 'Generator Loss'])
plt.savefig('%svalidation_loss_graph.png'%(RESULT))
plt.clf()

plt.plot(trlossDs)
if use_L1:
    plt.plot(trL1_Gs)
plt.plot(trlossGs)
plt.title('Train losses over Epoch')
plt.xlabel('Number of Epochs')
plt.ylabel('Training Losses')
if use_L1:
    plt.legend(['Descriminator Loss', 'Generator L1 Loss', 'Generator Loss'])
else:
    plt.legend(['Descriminator Loss', 'Generator Loss'])
plt.savefig('%straining_loss_graph.png'%(RESULT))
plt.clf()

