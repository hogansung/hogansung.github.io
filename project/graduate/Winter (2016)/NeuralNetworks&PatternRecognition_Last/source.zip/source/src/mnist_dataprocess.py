from keras.datasets import mnist
(x_train, y_train), (x_test, y_test) = mnist.load_data()
# grayscale image data with shape nx28x28
print x_train.shape, len(y_train)
import numpy as np
import argparse

DATASET = 'mnist_back_cn' # mnist, mnist_cn, mnist_red, mnist_font, mnist_back_giddyup59, mnist_back_cn
folderA = '../data/%s/A/'%(DATASET)
folderB = '../data/%s/B/'%(DATASET)

from os import makedirs
from os.path import isdir
from scipy.misc import imsave
from PIL import Image

def createB(label, savepath):
    folderpng = '../data/%s/png/'%(DATASET)
    img = Image.open('%s%d.png'%(folderpng, label))
    w, h = img.size
    diff = int((h-w)/2)
    cropsize = 55
    adj = -20
    img = img.crop((cropsize, diff+adj+cropsize, w-cropsize, diff+adj+w-cropsize))
    img = img.resize((128, 128))
    img.save(savepath)

def createData(start, end, folderA, folderB):
    count = np.zeros(10)
    for i in range(start, end):
        label = y_train[i]
        img = x_train[i]
        im = Image.fromarray(img)
        # save to folder A
        im = im.resize((128, 128))
        im.save('%s%d_%d.png'%(folderA, label, count[label]))
        createB(label, '%s%d_%d.png'%(folderB, label, count[label]))
        count[label]+=1
        
    print "Final distribution", count

if not isdir(folderA):
    makedirs(folderA)

savetrainA = '%strain/'%(folderA)
if not isdir(savetrainA):
    makedirs(savetrainA)
savetrainB = '%strain/'%(folderB)
if not isdir(savetrainB):
    makedirs(savetrainB)

savevalA = '%sval/'%(folderA)
if not isdir(savevalA):
    makedirs(savevalA)
savevalB = '%sval/'%(folderB)
if not isdir(savevalB):
    makedirs(savevalB)

createData(0, 1000, savetrainA, savetrainB)
createData(1000, 1200, savevalA, savevalB)
print "Done"
