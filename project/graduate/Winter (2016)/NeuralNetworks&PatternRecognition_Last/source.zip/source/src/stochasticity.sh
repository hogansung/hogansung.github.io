#DATA_ROOT=../data/cityscapes/ name=cityscapes_cGAN_yesl1_bs_32 loadSize=158 fineSize=128 batchSize=32 which_direction=BtoA qlua stochasticity.lua

DATA_ROOT=../data/cityscapes/ name=cityscapes_dropout_0.1 loadSize=158 fineSize=128 batchSize=32 which_direction=BtoA qlua stochasticity.lua

#DATA_ROOT=../data/cityscapes/ name=cityscapes_dropout_0.3 loadSize=158 fineSize=128 batchSize=32 which_direction=BtoA qlua stochasticity.lua

#DATA_ROOT=../data/cityscapes/ name=cityscapses_nodropout loadSize=158 fineSize=128 batchSize=32 which_direction=BtoA qlua stochasticity.lua

