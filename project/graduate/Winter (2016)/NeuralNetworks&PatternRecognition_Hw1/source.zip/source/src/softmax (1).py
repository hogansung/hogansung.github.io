import os, struct
from array import array as pyarray
import numpy as np
import matplotlib.pyplot as plt

from sklearn import preprocessing
from sklearn import model_selection
from sklearn.model_selection import ShuffleSplit

tn_n = 20000
tt_n = 2000
ft_n = 784

INF = 10000000
MAX_ITER = 1000
eta = 0.001
eta_decay = 0.01
eps = 1e-10

img_folder = '../res/'

ss = ShuffleSplit(n_splits=1, test_size=0.1, random_state=0)


def load_mnist(dataset, digits=np.arange(10), path="../dat/"):
    """
    Loads MNIST files into 3D numpy arrays

    Adapted from: http://abel.ee.ucla.edu/cvxopt/_downloads/mnist.py
    """
    
    if dataset == "training":
        fname_img = os.path.join(path, 'train-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 'train-labels-idx1-ubyte')
    elif dataset == "testing":
        fname_img = os.path.join(path, 't10k-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 't10k-labels-idx1-ubyte')
    else:
        raise ValueError("dataset must be 'testing' or 'training'")

    flbl = open(fname_lbl, 'rb')
    magic_nr, size = struct.unpack(">II", flbl.read(8))
    lbl = pyarray("b", flbl.read())
    flbl.close()

    fimg = open(fname_img, 'rb')
    magic_nr, size, rows, cols = struct.unpack(">IIII", fimg.read(16))
    img = pyarray("B", fimg.read())
    fimg.close()

    ind = [ k for k in range(size) if lbl[k] in digits ]
    N = len(ind)

    images = np.zeros((N, rows, cols), dtype=np.uint8)
    labels = np.zeros((N, 1), dtype=np.int8)
    for i in range(len(ind)):
        images[i] = np.array(img[ ind[i]*rows*cols : \
                (ind[i]+1)*rows*cols ]).reshape((rows, cols))
        labels[i] = lbl[ind[i]]

    return images, labels


def calLOSS(w, x, y, p, lb):
    assert(x.shape[0] == y.shape[0])
    val = 0.0
    E_mat = y * np.log(p + eps)
    val = - E_mat.sum()

    val += lb * np.linalg.norm(w, 2)
    return val

def calACC(w, x, y, p):
    assert(x.shape[0] == y.shape[0] and y.shape[0] == p.shape[0])
    num=0
    for row in range(p.shape[0]):
        largest=0
        index=0
        for col in range(10):
            if p[row,col]>largest:
                index=col
                largest=p[row,col]
        if y[row,index]==1:
            num+=1
    return 1.0 / x.shape[0] * num


def predict(w, x):
    v = np.dot(x, np.transpose(w))
    v=np.matrix(np.exp(v))
    return np.array(v/(v.sum(1)+eps))

def SoftmaxRegression(sx, sy, vx, vy, tx, ty, lb):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    w = np.zeros((10, ft_n+1))
    bw = np.zeros((10, ft_n+1))
    sp = predict(w, sx);
    vld_v = INF
    cnt = 0

    # results
    stn_loss = []
    vld_loss = []
    tt_loss = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    for t in xrange(MAX_ITER):
        nw = np.dot((sy-sp).transpose(), sx) - lb * 2 * w

        n_eta = eta / (1 + t * eta_decay)
        w += n_eta * nw
        
        # predict
        sp = predict(w, sx)
        vp = predict(w, vx)
        tp = predict(w, tx)

        # calculate loss
        n_stn_v = calLOSS(w, sx, sy, sp, lb)
        n_vld_v = calLOSS(w, vx, vy, vp, lb)
        n_tt_v = calLOSS(w, tx, ty, tp, lb)
        stn_loss.append(n_stn_v)
        vld_loss.append(n_vld_v)
        tt_loss.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(w, sx, sy, sp)
        n_vld_a = calACC(w, vx, vy, vp)
        n_tt_a = calACC(w, tx, ty, tp)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bw = np.copy(w)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print 'Stop at #' + str(t)
            return bw, stn_loss[:-3], vld_loss[:-3], tt_loss[:-3], \
                    stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

    print 'Maximum iterations are reached'
    return bw, stn_loss[:-3], vld_loss[:-3], tt_loss[:-3], \
            stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]


## read dataset
tn_x, tn_y = load_mnist('training')
tn_x, tn_y = tn_x[:tn_n, :, :], tn_y[:tn_n, :]
tn_x = tn_x.reshape(tn_n, ft_n)
tn_x = np.hstack([tn_x, np.ones((tn_n, 1))])
tn_y_new = np.zeros((tn_n,10))
for i in range(tn_n):
    tn_y_new[i,tn_y[i,0]]=1.0

tt_x, tt_y = load_mnist('testing')
tt_x, tt_y = tt_x[:tt_n, :, :], tt_y[:tt_n, :]
tt_x = tt_x.reshape(tt_n, ft_n)
tt_x = np.hstack([tt_x, np.ones((tt_n, 1))])
tt_y_new = np.zeros((tt_n,10))
for i in range(tt_n):
    tt_y_new[i,tt_y[i,0]]=1.0

## preprocessing
tn_x = preprocessing.scale(tn_x)
tt_x = preprocessing.scale(tt_x)


# hold out 10% train as validation
stn_idx, vld_idx = \
        list(ss.split(np.arange(tn_x.shape[0])))[0]
stn_x = tn_x[stn_idx, :]
stn_y = tn_y_new[stn_idx, :]
vld_x = tn_x[vld_idx, :]
vld_y = tn_y_new[vld_idx, :]


# main model
w, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
      SoftmaxRegression(stn_x, stn_y, vld_x,\
      vld_y, tt_x, tt_y_new, 0.01)

# plot loss
plt.figure()
plt.plot(stn_loss, label='stn-train')
plt.plot(vld_loss, label='validation')
plt.plot(tt_loss, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function for 10-way Classification')
plt.legend(loc=1)
plt.savefig(img_folder + 'loss_10_way.png')

# plot acc
plt.figure()
plt.plot(stn_acc, label='stn-train')
plt.plot(vld_acc, label='validation')
plt.plot(tt_acc, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy for 10-way Classification')
plt.legend(loc=4)
plt.savefig(img_folder + 'acc_10_way.png')
