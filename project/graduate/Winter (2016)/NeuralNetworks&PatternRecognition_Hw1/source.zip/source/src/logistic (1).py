import os, struct
from array import array as pyarray
import numpy as np
import matplotlib.pyplot as plt

from sklearn import preprocessing
from sklearn import model_selection
from sklearn.model_selection import ShuffleSplit

tn_n = 20000
tt_n = 2000
ft_n = 784

INF = 10000000
MAX_ITER = 1000
eta = 0.001
eta_decay = 0.01
eps = 1e-10

img_folder = '../res/'

ss = ShuffleSplit(n_splits=1, test_size=0.1, random_state=0)


def load_mnist(dataset, digits=np.arange(10), path="../dat/"):
    """
    Loads MNIST files into 3D numpy arrays

    Adapted from: http://abel.ee.ucla.edu/cvxopt/_downloads/mnist.py
    """

    if dataset == "training":
        fname_img = os.path.join(path, 'train-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 'train-labels-idx1-ubyte')
    elif dataset == "testing":
        fname_img = os.path.join(path, 't10k-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 't10k-labels-idx1-ubyte')
    else:
        raise ValueError("dataset must be 'testing' or 'training'")

    flbl = open(fname_lbl, 'rb')
    magic_nr, size = struct.unpack(">II", flbl.read(8))
    lbl = pyarray("b", flbl.read())
    flbl.close()

    fimg = open(fname_img, 'rb')
    magic_nr, size, rows, cols = struct.unpack(">IIII", fimg.read(16))
    img = pyarray("B", fimg.read())
    fimg.close()

    ind = [ k for k in range(size) if lbl[k] in digits ]
    N = len(ind)

    images = np.zeros((N, rows, cols), dtype=np.uint8)
    labels = np.zeros((N, 1), dtype=np.int8)
    for i in range(len(ind)):
        images[i] = np.array(img[ ind[i]*rows*cols : \
                (ind[i]+1)*rows*cols ]).reshape((rows, cols))
        labels[i] = lbl[ind[i]]

    return images, labels


def calLOSS(w, x, y, p, lb1, lb2):
    assert(x.shape[0] == y.shape[0])

    val = 0.0
    for i in xrange(x.shape[0]):
        val -= y[i] * np.log(p[i]+eps) + (1-y[i]) * np.log(1-p[i]+eps)

    val *= 1.0 / x.shape[0]
    val += lb1 * np.linalg.norm(w, 1)
    val += lb2 * np.linalg.norm(w, 2)
    return val


def calACC(w, x, y, p):
    assert(x.shape[0] == y.shape[0] and y.shape[0] == p.shape[0])
    return 1.0 / x.shape[0] * np.sum(y == (p > 0.5))


def sigmoid(z):
    return 1.0 / (1 + np.exp(-z))


def predict(w, x):
    v = np.dot(x, np.transpose(w))
    return np.apply_along_axis(sigmoid, 0, v)


def LogisticRegression(sx, sy, vx, vy, tx, ty, lb1=0, lb2=0):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    w = np.zeros((1, ft_n+1))
    bw = np.zeros((1, ft_n+1))
    sp = predict(w, sx);
    vld_v = INF
    cnt = 0

    # results
    stn_loss = []
    vld_loss = []
    tt_loss = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    for t in xrange(MAX_ITER):
        nw = np.dot((sy-sp).transpose(),sx) - lb1*np.sign(w) - lb2*2*w

        n_eta = eta / (1 + t * eta_decay)
        w += n_eta * nw
        
        # predict
        sp = predict(w, sx)
        vp = predict(w, vx)
        tp = predict(w, tx)

        # calculate loss
        n_stn_v = calLOSS(w, sx, sy, sp, lb1, lb2)
        n_vld_v = calLOSS(w, vx, vy, vp, lb1, lb2)
        n_tt_v = calLOSS(w, tx, ty, tp, lb1, lb2)
        stn_loss.append(n_stn_v)
        vld_loss.append(n_vld_v)
        tt_loss.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(w, sx, sy, sp)
        n_vld_a = calACC(w, vx, vy, vp)
        n_tt_a = calACC(w, tx, ty, tp)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bw = np.copy(w)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print 'Stop at #' + str(t)
            return bw, stn_loss[:-3], vld_loss[:-3], tt_loss[:-3], \
                    stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

    print 'Maximum iterations are reached'
    return bw, stn_loss[:-3], vld_loss[:-3], tt_loss[:-3], \
            stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]


## read dataset
tn_x, tn_y = load_mnist('training')
tn_x, tn_y = tn_x[:tn_n, :, :], tn_y[:tn_n, :]
tn_x = tn_x.reshape(tn_n, ft_n)
tn_x = np.hstack([tn_x, np.ones((tn_n, 1))])

tt_x, tt_y = load_mnist('testing')
tt_x, tt_y = tt_x[:tt_n, :, :], tt_y[:tt_n, :]
tt_x = tt_x.reshape(tt_n, ft_n)
tt_x = np.hstack([tt_x, np.ones((tt_n, 1))])


## preprocessing
tn_x = preprocessing.scale(tn_x)
tt_x = preprocessing.scale(tt_x)


## Problem 4 (a), (b): 2 v.s 3

# training part
tn_two_idx = np.transpose(tn_y == 2)[0]
tn_three_idx = np.transpose(tn_y == 3)[0]
tn_two_x = tn_x[tn_two_idx, :]
tn_two_y = np.ones((tn_two_x.shape[0], 1))
tn_three_x = tn_x[tn_three_idx, :]
tn_three_y = np.zeros((tn_three_x.shape[0], 1))
tn_two_three_x = np.vstack((tn_two_x, tn_three_x))
tn_two_three_y = np.vstack((tn_two_y, tn_three_y))

# testing part
tt_two_idx = np.transpose(tt_y == 2)[0]
tt_three_idx = np.transpose(tt_y == 3)[0]
tt_two_x = tt_x[tt_two_idx, :]
tt_two_y = np.ones((tt_two_x.shape[0], 1))
tt_three_x = tt_x[tt_three_idx, :]
tt_three_y = np.zeros((tt_three_x.shape[0], 1))
tt_two_three_x = np.vstack((tt_two_x, tt_three_x))
tt_two_three_y = np.vstack((tt_two_y, tt_three_y))

# hold out 10% train as validation
stn_two_three_idx, vld_two_three_idx = \
        list(ss.split(np.arange(tn_two_three_x.shape[0])))[0]
stn_two_three_x = tn_two_three_x[stn_two_three_idx, :]
stn_two_three_y = tn_two_three_y[stn_two_three_idx, :]
vld_two_three_x = tn_two_three_x[vld_two_three_idx, :]
vld_two_three_y = tn_two_three_y[vld_two_three_idx, :]

# main model
two_three_w, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
        LogisticRegression(stn_two_three_x, stn_two_three_y, \
        vld_two_three_x, vld_two_three_y, tt_two_three_x, \
        tt_two_three_y, lb1=0, lb2=0)

# plot loss
plt.figure()
plt.plot(stn_loss, label='stn-train')
plt.plot(vld_loss, label='validation')
plt.plot(tt_loss, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function for two_three')
plt.legend(loc=1)
plt.savefig(img_folder + 'loss_two_three.png')

# plot acc
plt.figure()
plt.plot(stn_acc, label='stn-train')
plt.plot(vld_acc, label='validation')
plt.plot(tt_acc, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy for two_three')
plt.legend(loc=4)
plt.savefig(img_folder + 'acc_two_three.png')


## Problem 4 (c): 2 v.s 8

# training part
tn_two_idx = np.transpose(tn_y == 2)[0]
tn_eight_idx = np.transpose(tn_y == 8)[0]
tn_two_x = tn_x[tn_two_idx, :]
tn_two_y = np.ones((tn_two_x.shape[0], 1))
tn_eight_x = tn_x[tn_eight_idx, :]
tn_eight_y = np.zeros((tn_eight_x.shape[0], 1))
tn_two_eight_x = np.vstack((tn_two_x, tn_eight_x))
tn_two_eight_y = np.vstack((tn_two_y, tn_eight_y))

# testing part
tt_two_idx = np.transpose(tt_y == 2)[0]
tt_eight_idx = np.transpose(tt_y == 8)[0]
tt_two_x = tt_x[tt_two_idx, :]
tt_two_y = np.ones((tt_two_x.shape[0], 1))
tt_eight_x = tt_x[tt_eight_idx, :]
tt_eight_y = np.zeros((tt_eight_x.shape[0], 1))
tt_two_eight_x = np.vstack((tt_two_x, tt_eight_x))
tt_two_eight_y = np.vstack((tt_two_y, tt_eight_y))

# hold out 10% train as validation
stn_two_eight_idx, vld_two_eight_idx = \
        list(ss.split(np.arange(tn_two_eight_x.shape[0])))[0]
stn_two_eight_x = tn_two_eight_x[stn_two_eight_idx, :]
stn_two_eight_y = tn_two_eight_y[stn_two_eight_idx, :]
vld_two_eight_x = tn_two_eight_x[vld_two_eight_idx, :]
vld_two_eight_y = tn_two_eight_y[vld_two_eight_idx, :]

# main model
two_eight_w, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
        LogisticRegression(stn_two_eight_x, stn_two_eight_y, \
        vld_two_eight_x, vld_two_eight_y, tt_two_eight_x, \
        tt_two_eight_y, lb1=0, lb2=0)

# plot loss
plt.figure()
plt.plot(stn_loss, label='stn-train')
plt.plot(vld_loss, label='validation')
plt.plot(tt_loss, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function for two_eight')
plt.legend(loc=1)
plt.savefig(img_folder + 'loss_two_eight.png')

# plot acc
plt.figure()
plt.plot(stn_acc, label='stn-train')
plt.plot(vld_acc, label='validation')
plt.plot(tt_acc, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy for two_eight')
plt.legend(loc=4)
plt.savefig(img_folder + 'acc_two_eight.png')


## Problem 4 (d): plot weights

# weight for two_three
plt.figure()
plt.imshow(two_three_w[0,:-1].reshape(28, 28))
plt.title('Weight for two_three')
plt.savefig(img_folder + 'weight_two_three.png')

# weight for two_eight
plt.figure()
plt.imshow(two_eight_w[0,:-1].reshape(28, 28))
plt.title('Weight for two_eight')
plt.savefig(img_folder + 'weight_two_eight.png')

# weight difference
plt.figure()
plt.imshow((two_eight_w[0,:-1]-two_three_w[0,:-1]).reshape(28, 28))
plt.title('Weight Difference')
plt.savefig(img_folder + 'weight_difference.png')


## Problem 5
lb_lst = [0.01, 0.001, 0.0001]

w_l1 = []
w_l2 = []
err_tt_l1 = []
err_tt_l2 = []

# Problem 5 (b)
plt.figure()
for lb in lb_lst:
    # l1 norm
    w, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
            LogisticRegression(stn_two_three_x, stn_two_three_y, \
            vld_two_three_x, vld_two_three_y, tt_two_three_x, \
            tt_two_three_y, lb1=lb, lb2=0)
    plt.plot(stn_acc, label='sub-train l1_' + str(lb))
    w_l1.append(w)
    err_tt_l1.append(1 - tt_acc[-1])

    # l2 norm
    w, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
            LogisticRegression(stn_two_three_x, stn_two_three_y, \
            vld_two_three_x, vld_two_three_y, tt_two_three_x, \
            tt_two_three_y, lb1=0, lb2=lb)
    plt.plot(stn_acc, label='sub-train l2_' + str(lb))
    w_l2.append(w)
    err_tt_l2.append(1 - tt_acc[-1])

plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Sub-train Accuracy for two_three_regularization')
plt.legend(loc=4)
plt.savefig(img_folder + 'acc_stn_two_three_regularization.png')

# Problem 5 (c)
plt.figure()
plt.plot(range(len(lb_lst)), [np.linalg.norm(w, 2) for w in w_l1], \
        marker='o', label='l1 norm')
plt.plot(range(len(lb_lst)), [np.linalg.norm(w, 2) for w in w_l2], \
        marker='o', label='l2 norm')
plt.xticks(range(len(lb_lst)), ['0.01', '0.001', '0.0001'])
plt.xlabel('Lambda')
plt.ylabel('Length')
plt.title('Length of w with different regularizations')
plt.legend(loc=4)
plt.savefig(img_folder + 'len_w_two_three_regularization.png')

# Problem 5 (d)
plt.figure()
plt.plot(lb_lst, err_tt_l1, label='test l1 norm')
plt.plot(lb_lst, err_tt_l2, label='test l2 norm')
plt.xscale('log')
plt.xlabel('Lambda (Log)')
plt.ylabel('Test Error')
plt.title('Test Error for two_three_regularization')
plt.legend(loc=4)
plt.savefig(img_folder + 'err_tt_two_three_regularization.png')

# Problem 5 (e)
for w, lb in zip(w_l1, lb_lst):
    plt.figure()
    plt.imshow(w[0,:-1].reshape(28, 28))
    plt.title('')
    plt.savefig(img_folder + 'weight_two_three_l1_' + str(lb) + '.png')

for w, lb in zip(w_l2, lb_lst):
    plt.figure()
    plt.imshow(w[0,:-1].reshape(28, 28))
    plt.title('')
    plt.savefig(img_folder + 'weight_two_three_l2_' + str(lb) + '.png')

