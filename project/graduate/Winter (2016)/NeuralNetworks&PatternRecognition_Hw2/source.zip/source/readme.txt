## Directory Structure
├── dat: data
├── doc: documents, like Hw2 description
├── res: all generated image files
└── src: source codes



## Code Execution

# Run Command
python2 backProp.py

# Input: read MNIST data, which is stored in *dat* folder

# Output: output png files, which is stored in *res* folder

# Parameters:
* nh: number of hidden neurons for single-layer network
* nh_1: number of hidden neurons for first layer of double-layer network
* nh_2: number of hidden neurons for second layer of double-layer network
* batch: number of batches for mini-batches strategy
* problem: predefined strings for different tasks 
    - gradient: for gradient check
    - prob_3  : for problem 3
    - prob_4  : for problem 4
    - prob_5  : for problem 5
* trick: predefined strings for problem 4 tasks
    - a   : for task (a) mini-batches
    - c   : for task (c) funny-tanh
    - d   : for task (d) w initialization
    - e   : for task (e) momentum
    - all : full tricks are triggered



### Authors
Hao-en Sung (wrangle1005@gmail.com)
Haifeng Hwang (hah086@ucsd.edu)
