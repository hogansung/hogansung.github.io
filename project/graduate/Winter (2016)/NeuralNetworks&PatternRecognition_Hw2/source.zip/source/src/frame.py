import os, struct
from array import array as pyarray
import numpy as np
import matplotlib.pyplot as plt

from sklearn import preprocessing
from sklearn import model_selection
from sklearn.model_selection import ShuffleSplit

tn_n = 1000
tt_n = 200
ft_n = 784

INF = 10000000
MAX_ITER = 1000
eta = 0.00001
eps = 1e-10

img_folder = '../fig/'

ss = ShuffleSplit(n_splits=1, test_size=0.1, random_state=0)


def load_mnist(dataset="training", digits=np.arange(10), path="../dat/"):
    """
    Loads MNIST files into 3D numpy arrays

    Adapted from: http://abel.ee.ucla.edu/cvxopt/_downloads/mnist.py
    """
    
    if dataset == "training":
        fname_img = os.path.join(path, 'train-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 'train-labels-idx1-ubyte')
    elif dataset == "testing":
        fname_img = os.path.join(path, 't10k-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 't10k-labels-idx1-ubyte')
    else:
        raise ValueError("dataset must be 'testing' or 'training'")

    flbl = open(fname_lbl, 'rb')
    magic_nr, size = struct.unpack(">II", flbl.read(8))
    lbl = pyarray("b", flbl.read())
    flbl.close()

    fimg = open(fname_img, 'rb')
    magic_nr, size, rows, cols = struct.unpack(">IIII", fimg.read(16))
    img = pyarray("B", fimg.read())
    fimg.close()

    ind = [ k for k in range(size) if lbl[k] in digits ]
    N = len(ind)

    images = np.zeros((N, rows, cols), dtype=np.uint8)
    labels = np.zeros((N, 1), dtype=np.int8)
    for i in range(len(ind)):
        images[i] = np.array(img[ ind[i]*rows*cols : (ind[i]+1)*rows*cols ]).reshape((rows, cols))
        labels[i] = lbl[ind[i]]

    return images, labels


def calLOSS(x, y, p):
    assert(x.shape[0] == y.shape[0])
    val = 0.0
    E_mat = y * np.log(p + eps)
    val = - E_mat.sum()/float(x.shape[0])
    return val

def calACC(x, y, p):
    assert(x.shape[0] == y.shape[0] and y.shape[0] == p.shape[0])
    num=0
    for row in range(p.shape[0]):
        largest=0
        index=0
        for column in range(y.shape[1]):
            if p[row,column]>largest:
                index=column
                largest=p[row,column]
        if y[row,index]==1:
            num+=1
    return 1.0 / x.shape[0] * num

def predict(W_ij, W_jk, x):
	A_j = np.dot(x, W_ij)
	Y_j = 1.0 / (1 + np.exp(-A_j))
	X_k = np.hstack((Y_j, np.ones((Y_j.shape[0],1))))
	A_k = np.dot(X_k, W_jk)
	E_k = np.matrix(np.exp(A_k))
	Y_k = np.array(E_k/(E_k.sum(1)+eps))
	return Y_k, X_k, Y_j

def forward(W, B, x):
    Z = [x, 1.0 / (1 + np.exp(-(np.dot(x, w)+b)))
        for w, b in zip(W[:-1], B[:-1])
    ]
    E = np.matrix(np.exp(np.dot(Z[-1], W[-1]) + B[-1]))
    Y = np.array(E / (E.sum(1) + eps))
    return Z, E, Y

def backprop(W, B, Z, E, Y, x, y):
    nW = [np.dot(Z[-1], Y - y)]
    for i in range(len(Z))[::-1][1:]:
        nW.append(Z[i].transpose(), )
        nW_ij = np.dot(sx.transpose(), np.dot(sy - Ys_k, W_jk.transpose()[:,:middle]) * Ys_j * (1 - Ys_j))

def backProp(sx, sy, vx, vy, tx, ty):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    n_neuron = [sx.shape[1], 100, ty.shape[1]]
    W = [
        np.random.normal(0, 1.0/n_neuron[i]**0.5, (n_neuron[i],n_neuron[i+1]))
        for i in range(len(n_neuron)-1)
    ]
    B = [
        np.zeros((,n_neuron[i+1]))
        for i in range(len(n_neuron-1))
    ]

    Z, E, Y = forward(W, B, sx)

    Ys_k, Xs_k, Ys_j = predict(W_ij, W_jk, sx)
    forward(W, sx)
    vld_v = INF
    cnt = 0

    # results
    stn_loss = []
    vld_loss = []
    tt_loss = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    for t in xrange(MAX_ITER):
        n_eta = eta / (1 + t)

        forward()

        nW_jk = np.dot(Xs_k.transpose(), sy - Ys_k)
        nW_ij = np.dot(sx.transpose(), np.dot(sy - Ys_k, W_jk.transpose()[:,:middle]) * Ys_j * (1 - Ys_j))
        W_jk = W_jk + n_eta * nW_jk
        W_ij = W_ij + n_eta * nW_ij
        Ys_k, Xs_k, Ys_j = predict(W_ij, W_jk, sx)
        Yv_k, Xv_k, Yv_j = predict(W_ij, W_jk, vx)
        Yt_k, Xt_k, Yt_j = predict(W_ij, W_jk, tx)

        # calculate loss
        n_stn_v = calLOSS(sx, sy, Ys_k)
        n_vld_v = calLOSS(vx, vy, Yv_k)
        n_tt_v = calLOSS(tx, ty, Yt_k)
        stn_loss.append(n_stn_v)
        vld_loss.append(n_vld_v)
        tt_loss.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(sx, sy, Ys_k)
        n_vld_a = calACC(vx, vy, Yv_k)
        n_tt_a = calACC(tx, ty, Yt_k)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bW_ij = np.copy(W_ij)
            bW_jk = np.copy(W_jk)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print "Stop at #" + str(t)
            return bW_ij, bW_jk, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc

    print 'Maximum iterations are reached'
    return bW_ij, bW_jk, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc


## read dataset
tn_x, tn_y = load_mnist('training')
tn_x, tn_y = tn_x[:tn_n, :, :], tn_y[:tn_n, :]
tn_x = tn_x.reshape(tn_n, ft_n)
tn_x = np.hstack([tn_x, np.ones((tn_n, 1))])
tn_cy = np.zeros((tn_n, 10))
for i in range(tn_n):
    tn_cy[i, tn_y[i, 0]]=1.0

tt_x, tt_y = load_mnist('testing')
tt_x, tt_y = tt_x[:tt_n, :, :], tt_y[:tt_n, :]
tt_x = tt_x.reshape(tt_n, ft_n)
tt_x = np.hstack([tt_x, np.ones((tt_n, 1))])
tt_cy = np.zeros((tt_n, 10))
for i in range(tt_n):
    tt_cy[i, tt_y[i, 0]]=1.0

## preprocessing
tn_x = preprocessing.scale(tn_x)
tt_x = preprocessing.scale(tt_x)

# hold out 10% train as validation
stn_idx, vld_idx = \
        list(ss.split(np.arange(tn_x.shape[0])))[0]
stn_x = tn_x[stn_idx, :]
stn_y = tn_cy[stn_idx, :]
vld_x = tn_x[vld_idx, :]
vld_y = tn_cy[vld_idx, :]

# main model
W_ij, W_jk, stn_loss, vld_loss, tt_loss, stn_acc, vld_acc, tt_acc =\
      backProp(stn_x, stn_y, vld_x, vld_y, tt_x, tt_cy)

# plot loss
plt.figure()
plt.plot(stn_loss, label='stn-train')
plt.plot(vld_loss, label='validation')
plt.plot(tt_loss, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function for 10-way Classification')
plt.legend(loc=1)
plt.savefig(img_folder + 'loss_10_way.png')

# plot acc
plt.figure()
plt.plot(stn_acc, label='stn-train')
plt.plot(vld_acc, label='validation')
plt.plot(tt_acc, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy for 10-way Classification')
plt.legend(loc=4)
plt.savefig(img_folder + 'acc_10_way.png')
