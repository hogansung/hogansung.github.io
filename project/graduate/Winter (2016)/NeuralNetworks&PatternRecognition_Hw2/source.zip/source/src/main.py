import os, struct
from array import array as pyarray
import numpy as np
import matplotlib.pyplot as plt
import math

from sklearn import preprocessing
from sklearn import model_selection
from sklearn.model_selection import ShuffleSplit

np.random.seed(514)
np.set_printoptions(suppress=True, precision=10)

INF = 10000000
MAX_ITER = 1000
eps = 1e-10

tn_n = 60000
tt_n = 10000
ft_n = 784

nh = 40
nh_1 = 40
nh_2 = 40
batch = 128

problem = 'prob_4' # gradient, prob_3, prob_4, prob_5
trick = 'a' # a, c, d, e, all
img_folder = '../res/'

if problem == 'prob_3':
    eta = 0.00001
elif problem == 'prob_4':
    # trick (a)
    if trick == 'a':
        eta = 0.002
    elif trick == 'c':
        eta = 0.00005
    elif trick == 'd':
        eta = 0.0001
    elif trick == 'e':
        eta = 0.0001
    else:
        eta = 0.0001
    # trick (e)
    if trick == 'e' or trick == 'all':
        mu = 0.9
    else:
        mu = 0.0
else:
    eta = 0.0001
    mu = 0.9

def load_mnist(dataset, digits=np.arange(10), path='../dat/'):
    if dataset == 'training':
        fname_img = os.path.join(path, 'train-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 'train-labels-idx1-ubyte')
    elif dataset == 'testing':
        fname_img = os.path.join(path, 't10k-images-idx3-ubyte')
        fname_lbl = os.path.join(path, 't10k-labels-idx1-ubyte')
    else:
        raise ValueError("dataset must be 'testing' or 'training'")

    flbl = open(fname_lbl, 'rb')
    magic_nr, size = struct.unpack('>II', flbl.read(8))
    lbl = pyarray('b', flbl.read())
    flbl.close()

    fimg = open(fname_img, 'rb')
    magic_nr, size, rows, cols = struct.unpack('>IIII', fimg.read(16))
    img = pyarray('B', fimg.read())
    fimg.close()

    ind = [ k for k in range(size) if lbl[k] in digits ]
    N = len(ind)

    images = np.zeros((N, rows, cols), dtype=np.uint8)
    labels = np.zeros((N, 1), dtype=np.int8)
    for i in range(len(ind)):
        images[i] = np.array(img[ ind[i]*rows*cols : \
                (ind[i]+1)*rows*cols ]).reshape((rows, cols))
        labels[i] = lbl[ind[i]]

    return images, labels

def calERR(x, y, p):
    assert(x.shape[0] == y.shape[0])
    val = 0.0
    E_mat = y * np.log(p + eps)
    val = - E_mat.sum()/float(x.shape[0])
    return val

def calACC(x, y, p):
    assert(x.shape[0] == y.shape[0] and y.shape[0] == p.shape[0])
    num=0
    for row in range(p.shape[0]):
        largest=0
        index=0
        for column in range(y.shape[1]):
            if p[row,column]>largest:
                index=column
                largest=p[row,column]
        if y[row,index]==1:
            num+=1
    return 1.0 / x.shape[0] * num

# single hidden layer
def predict_s(W_ij, W_jk, x):
    A_j = np.dot(x, W_ij)
    # trick (c)
    if problem == 'prob_4' and (trick == 'c' or trick == 'all'):
        Y_j = 1.7159 * np.tanh(2.0 / 3 * A_j)
    else:
        Y_j = 1.0 / (1 + np.exp(-A_j))
    X_k = np.hstack((Y_j, np.ones((Y_j.shape[0],1))))
    A_k = np.dot(X_k, W_jk)
    E_k = np.matrix(np.exp(A_k))
    Y_k = np.array(E_k/(E_k.sum(1)+eps))
    return Y_k, X_k, Y_j, A_j

# two hidden layer
def predict_t(W_ij, W_jk, W_kl, x):
    A_j = np.dot(x, W_ij)
    Y_j = 1.7159 * np.tanh(2.0 / 3 * A_j)  # tanh
    X_k = np.hstack((Y_j, np.ones((Y_j.shape[0],1))))
    A_k = np.dot(X_k, W_jk)
    Y_k = 1.7159 * np.tanh(2.0 / 3 * A_k)  # tanh
    X_l = np.hstack((Y_k, np.ones((Y_k.shape[0],1))))
    A_l = np.dot(X_l, W_kl)
    E_l = np.matrix(np.exp(A_l))
    Y_l = np.array(E_l/(E_l.sum(1)+eps))
    return Y_l, X_l, A_k, X_k, A_j

def checkGradient(x, y):
    x_d, y_d = x.shape[1], y.shape[1]
    W_ij = np.random.normal(0, 1.0/(x_d**0.5), (x_d, nh))
    W_jk = np.random.normal(0, 1.0/((nh+1)**0.5), (nh+1, y_d))
    Yk, Xk, Yj, Aj = predict_s(W_ij, W_jk, x)

    nW_jk = np.dot(Xk.transpose(), y - Yk)
    nW_ij = np.dot(x.transpose(), \
            np.dot(y - Yk, W_jk.transpose()[:,:nh]) \
            * Yj * (1 - Yj))

    epsilon = 0.01

    # output layer
    max_diff_output = 0.0
    for j in range(nh+1):
        for k in range(y.shape[1]):
            W_p = np.copy(W_jk)
            W_p[j,k] += epsilon
            Yp, _, _, _ = predict_s(W_ij, W_p, x)
            ep = calERR(x, y, Yp)

            W_m = np.copy(W_jk)
            W_m[j,k] -= epsilon
            Ym, _, _, _ = predict_s(W_ij, W_m, x)
            em = calERR(x, y, Ym)

            diff = abs(nW_jk[j,k] + (ep-em) / (2 * epsilon))
            max_diff_output = max(max_diff_output, diff)

    # hidden layer 
    max_diff_hidden= 0.0
    for i in range(x.shape[1]):
        for j in range(nh):
            W_p = np.copy(W_ij)
            W_p[i,j] += epsilon
            Yp, _, _, _ = predict_s(W_p, W_jk, x)
            ep = calERR(x, y, Yp)

            W_m = np.copy(W_ij)
            W_m[i,j] -= epsilon
            Ym, _, _, _ = predict_s(W_m, W_jk, x)
            em = calERR(x, y, Ym)

            diff = abs(nW_ij[i,j] + (ep-em) / (2 * epsilon))
            max_diff_hidden = max(max_diff_hidden, diff)
            
    # results
    print('Maximum Difference for Output Layer: ' \
            + str(max_diff_output))
    print('Maximum Difference for Hidden Layer: ' \
            + str(max_diff_hidden))

def backProp_prob_3(sx, sy, vx, vy, tx, ty):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    # initialization
    sx_d, sy_d = sx.shape[1], sy.shape[1]
    W_ij = np.random.uniform(-1.0, 1.0, (sx_d, nh))
    W_jk = np.random.uniform(-1.0, 1.0, (nh+1, sy_d))

    Ys_k, Xs_k, Ys_j, As_j = predict_s(W_ij, W_jk, sx)
    vld_v = INF
    cnt = 0

    # results
    stn_err = []
    vld_err = []
    tt_err = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    for t in xrange(MAX_ITER):
        n_eta = eta / (1 + 0.01 * t)

        # gradient
        nW_jk = np.dot(Xs_k.transpose(), sy - Ys_k)
        nW_ij = np.dot(sx.transpose(), \
                np.dot(sy - Ys_k, W_jk.transpose()[:,:nh]) \
                * Ys_j * (1 - Ys_j))

        # update
        W_jk = W_jk + n_eta * nW_jk
        W_ij = W_ij + n_eta * nW_ij

        # predict
        Ys_k, Xs_k, Ys_j, As_j = predict_s(W_ij, W_jk, sx)
        Yv_k, Xv_k, Yv_j, Av_j = predict_s(W_ij, W_jk, vx)
        Yt_k, Xt_k, Yt_j, At_j = predict_s(W_ij, W_jk, tx)

        # calculate err
        n_stn_v = calERR(sx, sy, Ys_k)
        n_vld_v = calERR(vx, vy, Yv_k)
        n_tt_v = calERR(tx, ty, Yt_k)
        stn_err.append(n_stn_v)
        vld_err.append(n_vld_v)
        tt_err.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(sx, sy, Ys_k)
        n_vld_a = calACC(vx, vy, Yv_k)
        n_tt_a = calACC(tx, ty, Yt_k)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bW_ij = np.copy(W_ij)
            bW_jk = np.copy(W_jk)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print 'Stop at #' + str(t)
            return bW_ij, bW_jk, stn_err[:-3], vld_err[:-3], \
                tt_err[:-3], stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

    print 'Maximum iterations are reached'
    return bW_ij, bW_jk, stn_err[:-3], vld_err[:-3], \
        tt_err[:-3], stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

def backProp_prob_4(sx, sy, vx, vy, tx, ty):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    # initialization
    sx_d, sy_d = sx.shape[1], sy.shape[1]

    # trick (d)
    if trick == 'd' or trick == 'all':
        W_ij = np.random.normal(0, 1.0/(sx_d)**0.5, (sx_d, nh))
        W_jk = np.random.normal(0, 1.0/(nh+1)**0.5, (nh+1, sy_d))
    else:
        W_ij = np.random.uniform(-1.0, 1.0, (sx_d, nh))
        W_jk = np.random.uniform(-1.0, 1.0, (nh+1, sy_d))

    nW_ij = np.zeros((sx_d, nh))
    nW_jk = np.zeros((nh+1, sy_d))

    vld_v = INF
    cnt = 0

    # results
    stn_err = []
    vld_err = []
    tt_err = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    num_batch = int(math.ceil(sx.shape[0]/batch))
    for t in range(MAX_ITER):
        i = t % num_batch

        # trick (a)
        if trick == 'a' or trick == 'all':
            sx_batch = sx[i*batch: min((i+1)*batch, sx.shape[0]), :]
            sy_batch = sy[i*batch: min((i+1)*batch, sx.shape[0]), :]
        else:
            sx_batch = sx;
            sy_batch = sy;

        n_eta = eta / (1 + 0.01 * t)

        # gradient
        Ys_k, Xs_k, Ys_j, As_j = predict_s(W_ij, W_jk, sx_batch)
        nW_jk = np.dot(Xs_k.transpose(), sy_batch - Ys_k) + mu * nW_jk

        # trick (c)
        if trick == 'c' or trick == 'all':
            nW_ij = np.dot(sx_batch.transpose(), \
                    np.dot(sy_batch - Ys_k, W_jk.transpose()[:,:nh]) \
                    * 1.7159 * 8 * np.exp(4.0 / 3 * As_j) / 3 / \
                    (np.exp(4.0 / 3 * As_j) + 1) ** 2) + mu * nW_ij
        else:
            nW_ij = np.dot(sx_batch.transpose(), \
                    np.dot(sy_batch - Ys_k, W_jk.transpose()[:,:nh]) \
                    * Ys_j * (1 - Ys_j)) + mu * nW_ij

        # update
        W_jk = W_jk + n_eta * nW_jk
        W_ij = W_ij + n_eta * nW_ij

        # predict
        Ys_k, Xs_k, Ys_j, As_j = predict_s(W_ij, W_jk, sx)
        Yv_k, Xv_k, Yv_j, Av_j = predict_s(W_ij, W_jk, vx)
        Yt_k, Xt_k, Yt_j, At_j = predict_s(W_ij, W_jk, tx)

        # calculate err
        n_stn_v = calERR(sx, sy, Ys_k)
        n_vld_v = calERR(vx, vy, Yv_k)
        n_tt_v = calERR(tx, ty, Yt_k)
        stn_err.append(n_stn_v)
        vld_err.append(n_vld_v)
        tt_err.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(sx, sy, Ys_k)
        n_vld_a = calACC(vx, vy, Yv_k)
        n_tt_a = calACC(tx, ty, Yt_k)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bW_ij = np.copy(W_ij)
            bW_jk = np.copy(W_jk)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print 'Stop at #' + str(t)
            return bW_ij, bW_jk, stn_err[:-3], vld_err[:-3], \
                tt_err[:-3], stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

    print 'Maximum iterations are reached'
    return bW_ij, bW_jk, stn_err[:-3], vld_err[:-3], \
        tt_err[:-3], stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

def backProp_prob_5(sx, sy, vx, vy, tx, ty):
    assert(sx.shape[0] == sy.shape[0])
    assert(vx.shape[0] == vy.shape[0])
    assert(tx.shape[0] == ty.shape[0])

    # initialization
    sx_d, sy_d = sx.shape[1], sy.shape[1]
    W_ij = np.random.normal(0, 1.0/(sx_d)**0.5, (sx_d, nh_1))
    W_jk = np.random.normal(0, 1.0/(nh_1+1)**0.5, (nh_1+1, nh_2))
    W_kl = np.random.normal(0, 1.0/(nh_2+1)**0.5, (nh_2+1, sy_d))
    nW_ij = np.zeros((sx_d, nh_1))
    nW_jk = np.zeros((nh_1+1, nh_2))
    nW_kl = np.zeros((nh_2+1, sy_d))

    vld_v = INF
    cnt = 0

    # results
    stn_err = []
    vld_err = []
    tt_err = []
    stn_acc = []
    vld_acc = []
    tt_acc = []

    num_batch = int(math.ceil(sx.shape[0]/batch))
    for t in range(MAX_ITER):
        i = t % num_batch
        sx_batch = sx[i*batch: min((i+1)*batch, sx.shape[0]), :]
        sy_batch = sy[i*batch: min((i+1)*batch, sx.shape[0]), :]

        n_eta = eta / (1 + 0.01 * t)

        # gradient
        Ys_l, Xs_l, As_k, Xs_k, As_j = \
                predict_t(W_ij, W_jk, W_kl, sx_batch)

        delta_l = sy_batch - Ys_l
        nW_kl = np.dot(Xs_l.transpose(), delta_l) + mu * nW_kl

        delta_k = np.dot(delta_l, W_kl.transpose()[:,:nh_2]) \
                * 1.7159 * 8 * np.exp(4.0 / 3 * As_k) / 3 / \
                (np.exp(4.0 / 3 * As_k) + 1) ** 2
        nW_jk = np.dot(Xs_k.transpose(), delta_k) + mu * nW_jk

        delta_j = np.dot(delta_k, W_jk.transpose()[:,:nh_1]) \
                * 1.7159 * 8 * np.exp(4.0 / 3 * As_j) / 3 / \
                (np.exp(4.0 / 3 * As_j) + 1) ** 2
        nW_ij = np.dot(sx_batch.transpose(), delta_j) + mu * nW_ij

        # update
        W_kl = W_kl + n_eta * nW_kl
        W_jk = W_jk + n_eta * nW_jk
        W_ij = W_ij + n_eta * nW_ij

        # predict
        Ys_l, Xs_l, As_k, Xs_k, As_j = predict_t(W_ij, W_jk, W_kl, sx)
        Yv_l, Xv_l, Av_k, Xv_k, Av_j = predict_t(W_ij, W_jk, W_kl, vx)
        Yt_l, Xt_l, At_k, Xt_k, At_j = predict_t(W_ij, W_jk, W_kl, tx)

        # calculate err
        n_stn_v = calERR(sx, sy, Ys_l)
        n_vld_v = calERR(vx, vy, Yv_l)
        n_tt_v = calERR(tx, ty, Yt_l)
        stn_err.append(n_stn_v)
        vld_err.append(n_vld_v)
        tt_err.append(n_tt_v)

        # calculate acc
        n_stn_a = calACC(sx, sy, Ys_l)
        n_vld_a = calACC(vx, vy, Yv_l)
        n_tt_a = calACC(tx, ty, Yt_l)
        stn_acc.append(n_stn_a)
        vld_acc.append(n_vld_a)
        tt_acc.append(n_tt_a)

        # stop condition
        if n_vld_v >= vld_v:
            cnt += 1
        else:
            bW_ij = np.copy(W_ij)
            bW_jk = np.copy(W_jk)
            bW_kl = np.copy(W_kl)
            vld_v = n_vld_v
            cnt = 0

        if cnt == 3:
            print 'Stop at #' + str(t)
            return bW_ij, bW_jk, bW_kl, \
                    stn_err[:-3], vld_err[:-3], tt_err[:-3], \
                    stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

    print 'Maximum iterations are reached'
    return bW_ij, bW_jk, bW_kl, \
            stn_err[:-3], vld_err[:-3], tt_err[:-3], \
            stn_acc[:-3], vld_acc[:-3], tt_acc[:-3]

## read dataset
tn_x, tn_y = load_mnist('training')
tn_x, tn_y = tn_x[:tn_n, :, :], tn_y[:tn_n, :]
tn_x = tn_x.reshape(tn_n, ft_n)
tn_cy = np.zeros((tn_n,10))
for i in range(tn_n):
    tn_cy[i,tn_y[i,0]]=1.0

tt_x, tt_y = load_mnist('testing')
tt_x, tt_y = tt_x[:tt_n, :, :], tt_y[:tt_n, :]
tt_x = tt_x.reshape(tt_n, ft_n)
tt_cy = np.zeros((tt_n,10))
for i in range(tt_n):
    tt_cy[i,tt_y[i,0]]=1.0

## preprocessing
tn_x = 1.0 * (tn_x - np.mean(tn_x, axis=1, keepdims=True)) / 255
tt_x = 1.0 * (tt_x - np.mean(tt_x, axis=1, keepdims=True)) / 255

## append 1s
tn_x = np.hstack([tn_x, np.ones((tn_n, 1))])
tt_x = np.hstack([tt_x, np.ones((tt_n, 1))])

# hold out 10000 train as validation
ss = ShuffleSplit(n_splits=1, test_size=1.0/6, random_state=0)
stn_idx, vld_idx = \
        list(ss.split(np.arange(tn_x.shape[0])))[0]
stn_x = tn_x[stn_idx, :]
stn_y = tn_cy[stn_idx, :]
vld_x = tn_x[vld_idx, :]
vld_y = tn_cy[vld_idx, :]

if problem == 'gradient':
    checkGradient(tn_x[[0], :], tn_cy[[0], :])
    exit(0)
elif problem == 'prob_3':
    W_ij, W_jk, stn_err, vld_err, tt_err, \
            stn_acc, vld_acc, tt_acc = backProp_prob_3( \
            stn_x, stn_y, vld_x, vld_y, tt_x, tt_cy)
elif problem == 'prob_4':
    W_ij, W_jk, stn_err, vld_err, tt_err, \
            stn_acc, vld_acc, tt_acc = backProp_prob_4( \
            stn_x, stn_y, vld_x, vld_y, tt_x, tt_cy)
else:
    W_ij, W_jk, W_kl, stn_err, vld_err, tt_err, \
            stn_acc, vld_acc, tt_acc = backProp_prob_5( \
            stn_x, stn_y, vld_x, vld_y, tt_x, tt_cy)

if problem == 'prob_4':
    problem = problem + '_' + trick

# plot err
plt.figure()
plt.plot(stn_err, label='subtrain')
plt.plot(vld_err, label='validate')
plt.plot(tt_err, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function for 10-way Classification')
plt.legend(loc=1)
plt.savefig(img_folder + problem + '_err.png')

# plot acc
plt.figure()
plt.plot(stn_acc, label='subtrain')
plt.plot(vld_acc, label='validate')
plt.plot(tt_acc, label='test') 
plt.xlabel('Iterations')
plt.ylabel('Accuracy')
plt.title('Accuracy for 10-way Classification')
plt.legend(loc=4)
plt.savefig(img_folder + problem + '_acc.png')

# output performance
print(problem + ', eta(' + str(eta) + '), nh(' + str(nh) + ')') 
print('subtrain: ' + str(stn_acc[-1]) + ' (' + str(stn_err[-1]) + ')')
print('validate: ' + str(vld_acc[-1]) + ' (' + str(vld_err[-1]) + ')')
print('test: ' + str(tt_acc[-1]) + ' (' + str(tt_err[-1]) + ')')
