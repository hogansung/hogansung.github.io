import numpy as np

np.random.seed(1)

class HiddenLayer(object):
    def __init__(self, input, n_in, n_out, activation=None):
        self.input = input
        self.W = np.random.normal(0, 1, (n_in, n_out))
        self.b = np.zeros((n_out, ))
        self.params = [self.W, self.b]
        
        linear_output = np.dot(input, self.W) + self.b
        self.output = (
            linear_output if activation is None
            else activation(linear_output)
        )

class Softmax(object):


class LogisticRegressionLayer(object):
    def __init__(self, input, n_in, n_out):
        self.input = input
        self.W = np.zeros((n_in, n_out))
        self.b = np.zeros((n_out, ))
        self.params = [self.W, self.b]

        self.p_y_given_x = T.nnet.softmax(T.dot(input, self.W) + self.b)

        self.y_pred = T.argmax(self.p_y_given_x, axis=1)

    def negative_log_likelihood(self, y):
        return -T.mean(T.log(self.p_y_given_x)[T.arange(y.shape[0]), y])

    def error(self, y):
        return T.mean(T.neq(self.y_pred, y))


class MultiLayer():
    def __init__(self, input, n_in, n_hidden, n_out):
        self.hiddenLayer = HiddenLayer(
            input = input,
            n_in = n_in,
            n_out = n_hidden
        )

        self.logisticRegressionLayer = LogisticRegressionLayer(
            input = self.hiddenLayer.output,
            n_in = n_hidden,
            n_out = n_out
        )
        
        self.params = self.hiddenLayer.params 
            + self.logisticRegressionLayer.params

        self.error = self.logisticRegressionLayer.error

        self.input = input


classifier = MultiLayer(
    input = x,
    n_in = 28 * 28,
    n_hidden = n_hidden,
    n_out = 10
)
