import numpy as np
import urllib
import scipy.optimize
import random
from math import exp
from math import log
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression

random.seed(0)

def parseData(fname):
  for l in urllib.urlopen(fname):
    yield eval(l)

print "Reading data..."
dataFile = open("../dat/winequality-white.csv")
header = dataFile.readline()
fields = ["constant"] + header.strip().replace('"','').split(';')
featureNames = fields[:-1]
labelName = fields[-1]
lines = [[1.0] + [float(x) for x in l.split(';')] for l in dataFile]
X = [l[:-1] for l in lines]
y = [l[-1] > 5 for l in lines]
r = [l[-1] for l in lines]
print "done"

def inner(x,y):
  return sum([x[i]*y[i] for i in range(len(x))])

def sigmoid(x):
  return 1.0 / (1 + exp(-x))

##################################################
# Logistic regression by gradient ascent         #
##################################################

# NEGATIVE Log-likelihood
def f(theta, X, y, lam):
  loglikelihood = 0
  for i in range(len(X)):
    logit = inner(X[i], theta)
    loglikelihood -= log(1 + exp(-logit))
    if not y[i]:
      loglikelihood -= logit
  for k in range(len(theta)):
    loglikelihood -= lam * theta[k]*theta[k]
  # for debugging
  # print "ll =", loglikelihood
  return -loglikelihood

# NEGATIVE Derivative of log-likelihood
def fprime(theta, X, y, lam):
  dl = [0]*len(theta)
  for i in range(len(X)):
    logit = inner(X[i], theta)
    for k in range(len(theta)):
      dl[k] += X[i][k] * (1 - sigmoid(logit))
      if not y[i]:
        dl[k] -= X[i][k]
  for k in range(len(theta)):
    dl[k] -= lam*2*theta[k]
  return np.array([-x for x in dl])


##################################################
# Train                                          #
##################################################

def train(lam):
  theta,_,_ = scipy.optimize.fmin_l_bfgs_b(f, [0]*len(X[0]), 
          fprime, pgtol = 10, args = (X_tn, y_tn, lam))
  return theta

##################################################
# Predict                                        #
##################################################

def score(theta):
  s_tn = [inner(theta,x) for x in X_tn]
  s_vl = [inner(theta,x) for x in X_vl]
  s_tt = [inner(theta,x) for x in X_tt]
  return s_tn, s_vl, s_tt

def predict(theta):
  s_tn, s_vl, s_tt = score(theta)

  p_tn = [s > 0 for s in s_tn]
  p_vl = [s > 0 for s in s_vl]
  p_tt = [s > 0 for s in s_tt]
  return p_tn, p_vl, p_tt

def calACC(theta):
  p_tn, p_vl, p_tt = predict(theta)

  correct_tn = [(a==b) for (a,b) in zip(p_tn,y_tn)]
  correct_vl = [(a==b) for (a,b) in zip(p_vl,y_vl)]
  correct_tt = [(a==b) for (a,b) in zip(p_tt,y_tt)]
  
  acc_tn = sum(correct_tn) * 1.0 / len(correct_tn)
  acc_vl = sum(correct_vl) * 1.0 / len(correct_vl)
  acc_tt = sum(correct_tt) * 1.0 / len(correct_tt)
  return acc_tn, acc_vl, acc_tt

def calPERF(y, s):
  ys =  sorted(zip(y,s), key=lambda x: x[1], reverse=True)
  y, _ = zip(*ys)

  TP, TPLst = 0, []
  FP, FPLst = 0, []
  TN, TNLst = 0, []
  FN, FNLst = 0, []
  precisionLst = []
  recallLst = []
  
  # Default Threshold
  for i in range(len(y)):
    if y[i] == 1:
      FN += 1
    else:
      TN += 1
  TPLst.append(TP)
  FPLst.append(FP)
  TNLst.append(TN)
  FNLst.append(FN)
  precisionLst.append(0)
  recallLst.append(0)

  # Move Threshold Downward
  for i in range(len(y)):
    if y[i] == 1:
      TP += 1
      FN -= 1
    if y[i] == 0:
      TN -= 1
      FP += 1
    TPLst.append(TP)
    FPLst.append(FP)
    TNLst.append(TN)
    FNLst.append(FN)
    precisionLst.append(1.0*TP/(TP+FP))
    recallLst.append(1.0*TP/(TP+FN))

  return TPLst, FPLst, TNLst, FNLst, precisionLst, recallLst
   
##################################################
# Classifier Evaluation                          #
##################################################

# Shuffle Data
data = zip(X, y, r)
random.shuffle(data)
X, y, r = zip(*data)

# Partition Data
X_tn = X[:int(len(X)/3)]
y_tn = y[:int(len(y)/3)]
r_tn = r[:int(len(y)/3)]
X_vl = X[int(len(X)/3):int(2*len(X)/3)]
y_vl = y[int(len(y)/3):int(2*len(y)/3)]
r_vl = r[int(len(y)/3):int(2*len(y)/3)]
X_tt = X[int(2*len(X)/3):]
y_tt = y[int(2*len(X)/3):]
r_tt = r[int(2*len(X)/3):]

## Problem 1
for lam in [0, 0.01, 1.0, 100.0]:
  theta = train(lam)
  
  acc_tn, acc_vl, acc_tt = calACC(theta)
  print("lambda = " + str(lam) + ";\ttrain=" + str(acc_tn) 
          + "; valid=" + str(acc_vl) + "; test=" + str(acc_tt))

## Problem 2
lam = 0.01
theta = train(lam)
_, _, s_tt = score(theta)
_, _, p_tt = predict(theta)

TPLst, FPLst, TNLst, FNLst, _, _ = calPERF(y_tt, s_tt)
num = sum([1 if v > 0 else 0 for v in s_tt])
TP, FP, TN, FN = TPLst[num], FPLst[num], TNLst[num], FNLst[num]
BER = 0.5 * (1.0*FP/(TN+FP) + 1.0*FN/(FN+TP))
print("Test Performance:")
print("TP=" + str(TP) + "; TN=" + str(TN) + "; FP=" + str(FP) 
        + "; FN=" + str(FN) + "; BER=" + str(BER))

## Problem 3
for n in [10, 500, 1000]:
  _, _, _, _, precisionLst, recallLst = calPERF(y_tt, s_tt)
  print("With " + str(n) + " confident label:\tPrecision=" 
          + str(precisionLst[n]) + "; Recall=" + str(recallLst[n]))

## Problem 4
_, _, _, _, precisionLst, recallLst = calPERF(y_tt, s_tt)
plt.figure()
plt.plot(recallLst, precisionLst)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.savefig('../res/precision_recall.png')

##################################################
# Dimensionality reduction                       #
##################################################

## Problem 5
Xmean = np.mean(X, axis=0)
err = np.sum((X_tn - Xmean) ** 2)
print("Reconstuction Error for Mean: " + str(err))

## Problem 6
np.set_printoptions(suppress=True, precision=6)
pca = PCA()
pca.fit(X)
print("PCA Tranform Matrix:")
print pca.components_[:5,:].T

## Problem 7
tX = (X - pca.mean_).dot(pca.components_[:5,:].T)
iX = tX.dot(pca.components_[:5,:]) + pca.mean_
err = np.sum((X - iX) ** 2)
print("Reconstuction Error for PCA: " + str(err))

## Problem 8
tnMSE = []
ttMSE = []
for i in range(1, 12):
  tX_tn = (X_tn - pca.mean_).dot(pca.components_[:i,:].T)
  tX_tt = (X_tt - pca.mean_).dot(pca.components_[:i,:].T)
  nX_tn = np.concatenate([np.ones((tX_tn.shape[0],1)), tX_tn], axis=1)
  nX_tt = np.concatenate([np.ones((tX_tt.shape[0],1)), tX_tt], axis=1)

  regr = LinearRegression()
  regr.fit(nX_tn, y_tn)
  tnMSE.append(np.mean((regr.predict(nX_tn) - y_tn) ** 2))
  ttMSE.append(np.mean((regr.predict(nX_tt) - y_tt) ** 2))

plt.figure()
plt.plot(range(1,12), tnMSE, label='train')
plt.plot(range(1,12), ttMSE, label='test')
plt.xlim([1,11])
plt.xlabel('Number of PCA Components')
plt.ylabel('Mean Squared Error')
plt.legend(loc=1)
plt.savefig('../res/mse.png')
