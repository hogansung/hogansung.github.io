#include <cstdio>
#include <climits>
#include <vector>

using namespace std;

int f(int i, const int n, const vector<int>& a, 
  vector<int>& memory, vector<int>& trace) {
    if (i == n) {
        /* base case: return 0 */
        return 0;
    } else if (memory[i] != -1) {
        /* memorization:
         * -1: not visited
         * other values: visited */
        return memory[i];
    } else {
        int flag = -1;
        int mmin = INT_MAX;
        for (int j = i+1; j <= n; j++) {
            int cst = a[j] - a[i] - 200;
            int res = f(j, n, a, memory, trace) + cst * cst;

            /* if cost if smaller,
             * update minimum and remember the flag */
            if (res < mmin) {
                mmin = res;
                flag = j;
            }
        }

        /* memorization: best trace */ 
        trace[i] = flag;

        /* memorization: minimum value */ 
        return memory[i] = mmin;
    }
}

int main() {
    int n, d;
    vector<int> a;
    a.push_back(0);

    /* process input */
    while (scanf("%d", &d) != EOF) {
        a.push_back(d);
    }
    n = a.size()-1; // a_0 = 0, n is input size

    vector<int> memory(n+1, -1);
    vector<int> trace(n+1, -1);
    
    /* main procedure call */
    int res = f(0, n, a, memory, trace);
    printf("Penalty: %d\n", res);

    /* best trace */
    printf("Trace: ");
    int flag = 0;
    do {
        flag = trace[flag];
        printf("%d ", a[flag]);
    } while (flag != n);
    puts("");
}
