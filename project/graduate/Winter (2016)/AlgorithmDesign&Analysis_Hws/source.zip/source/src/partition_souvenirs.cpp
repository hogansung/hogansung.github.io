#include <cstdio>
#include <vector>

using namespace std;

bool f(int i, const int n,
  int sum_1, int sum_2, int target,
  const vector<int>& value,
  vector<vector<vector<bool>>>& memory,
  vector<vector<vector<bool>>>& visit) {

    if (i == n) { 
        /* base case: check summation */
        return sum_1 == sum_2 and sum_2 == target;
    } else if (visit[i][sum_1][sum_2] == true) {
        /* memorization */
        return memory[i][sum_1][sum_2];
    } else {
        bool suc = false;

        /* 1st person get value_i */
        if (sum_1 + value[i] <= target) {
            suc |= f(i+1, n, sum_1+value[i], sum_2, 
              target, value, memory, visit);
        }
        /* 2nd person get value_i */
        if (sum_2 + value[i] <= target) {
            suc |= f(i+1, n, sum_1, sum_2+value[i], 
              target, value, memory, visit);
        }
        /* 3rd person get value_i */
        suc |= f(i+1, n, sum_1, sum_2, 
          target, value, memory, visit);

        /* memorization */
        visit[i][sum_1][sum_2] = true;

        /* major case: if one of them is true, return true */
        return memory[i][sum_1][sum_2] = suc;
    }
}

int main() {
    int n, d, sum=0;
    vector<int> value;

    /* process input */
    while (scanf("%d", &d) != EOF) {
        value.push_back(d);
        sum += d;
    }
    n = value.size();

    if (sum % 3 != 0) { 
        /* addition test for multiple of 3 */
        printf("0");
    } else {
        auto memory = vector<vector<vector<bool>>>(
          n, vector<vector<bool>>(
              sum/3+1, vector<bool>(
                  sum/3+1, false)));
        auto visit = vector<vector<vector<bool>>>(
          n, vector<vector<bool>>(
              sum/3+1, vector<bool>(
                  sum/3+1, false)));

        /* main procedure call */
        bool res = f(0, n, 0, 0, sum/3, value, memory, visit);
        printf("%d\n", res);
    }
}
