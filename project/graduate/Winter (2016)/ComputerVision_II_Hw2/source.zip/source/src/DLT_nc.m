function P = DLT_nc(x, X, n)

% Data Normalization
xm = mean(x);
xv = var(x);
xs = sqrt(2 / (xv(1)+xv(2)));
T = [xs, 0, -xm(1)*xs; 0, xs, -xm(2)*xs; 0, 0, 1];
x = x * T';

Xm = mean(X);
Xv = var(X);
Xs = sqrt(3 / (Xv(1)+Xv(2)+Xv(3)));
U = [Xs, 0, 0, -Xm(1)*Xs; 0, Xs, 0, -Xm(2)*Xs; ...
    0, 0, Xs, -Xm(3)*Xs; 0, 0, 0, 1];
X = X * U';

% Left Null Space of P
A = zeros(2*n, 12);
for i = 1:n
    v = [x(i,1) + sign(x(i,1)) * norm(x(i,:)), x(i,2), x(i,3)]';
    H_v = eye(3) - 2 * (v * v') / (v' * v);
    A(2*i-1,:) = [H_v(2,1)*X(i,:), H_v(2,2)*X(i,:), H_v(2,3)*X(i,:)];
    A(2*i  ,:) = [H_v(3,1)*X(i,:), H_v(3,2)*X(i,:), H_v(3,3)*X(i,:)];
end

% Solve for P
[~, ~, V] = svd(A, 'econ');
P = V(:,end);
P = reshape(P, 4, 3)';

% Data Denormalization
P = T \ P * U;