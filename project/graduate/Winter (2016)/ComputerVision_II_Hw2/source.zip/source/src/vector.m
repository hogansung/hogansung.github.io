function vx = vector(x)
    vx = x';
    vx = vx(:);
end