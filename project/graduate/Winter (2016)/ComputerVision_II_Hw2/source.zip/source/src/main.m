% Read data
x = dlmread('../dat/hw2_points2D.txt');
X = dlmread('../dat/hw2_points3D.txt');
n = size(x,1);

% inhomogeneous -> homogeneous
x(:,3) = ones(n,1);
X(:,4) = ones(n,1);

% DLT Procedure
P = DLT_nc(x, X, n);
fprintf('P_DLT:\n'); disp(P ./ norm(P,'fro'));

% LEVENBERG-MARQUARDT
[P, log] = LM_nc(x, X, n, P);
fprintf('P_LM:\n'); disp(P ./ norm(P,'fro'));
fprintf('Error log:\n'); disp(log);
