function Pp = parameterize(Pn)
    a = Pn(1);
    b = Pn(2:end);
    Pp = 2 / my_sinc(acos(a)) * b;
end