function [P, log] = LM_nc(x, X, n, P)

% Data Normalization
xm = mean(x);
xv = var(x);
xs = sqrt(2 / (xv(1)+xv(2)));
T = [xs, 0, -xm(1)*xs; 0, xs, -xm(2)*xs; 0, 0, 1];
x = x * T';

Xm = mean(X);
Xv = var(X);
Xs = sqrt(3 / (Xv(1)+Xv(2)+Xv(3)));
U = [Xs, 0, 0, -Xm(1)*Xs; 0, Xs, 0, -Xm(2)*Xs; ...
    0, 0, Xs, -Xm(3)*Xs; 0, 0, 0, 1];
X = X * U';

P = T * P / U;

% Covariance Matrix
Z = diag(repmat(xs^2, 1, 2*n));

% Initialization
lambda = 0.001;
ex = calEpsilon(x, X, P);
perr = 10000000;
err = ex'*inv(Z)*ex;

% Error Log
log = err;

while abs(perr-err) > 0.0001
    vP = vector(P);
    v = parameterize(vP);

    % Angle Normalization
    if norm(v) > pi
        v = (1 - 2*pi/norm(v) * ceil((norm(v)-pi)/(2*pi))) * v;
    end
    vP = deparameterize(v);
    P = reshape(vP, 4, 3)';

    partial_vv = [-0.5 * vP(2:end)'; ...
                 my_sinc(norm(v)/2)/2 * eye(11) + ...
                 1/(4*norm(v)) * my_dsinc(norm(v)/2) * (v * v')];
                 
    % Calculate J
    J = zeros(2*n,11);
    for i = 1:n
        w = P * X(i,:)';
        partial_xp = 1/w(3,1) * [X(i,:), zeros(1,4), -w(1,1)/w(3,1)*X(i,:);
                           zeros(1,4), X(i,:), -w(2,1)/w(3,1)*X(i,:)];                   
        J(2*i-1:2*i,:) = partial_xp * partial_vv;
    end
    
    while true
        % Solve delta
        d = (J'*inv(Z)*J + lambda*eye(11)) \ (J'*inv(Z)*ex);
        nv = v + d;
        
        % Angle Normalization
        if norm(nv) > pi
            nv = (1 - 2*pi/norm(nv) * ceil((norm(nv)-pi)/(2*pi))) * nv;
        end
        nvP = deparameterize(nv);
        nP = reshape(nvP, 4, 3)';
        
        nex = calEpsilon(x, X, nP);
        if nex'*inv(Z)*nex < ex'*inv(Z)*ex
            P = nP;
            ex = nex;
            lambda = 0.1 * lambda;
            break;
        else
            lambda = 10 * lambda;
        end
    end
    
    % Update error
    perr = err;
    err = nex'*inv(Z)*nex;
    log = [log, err];
end

% Data Denormalization
P = T \ P * U;