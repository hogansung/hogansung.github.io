function ret = my_sinc(x)
    if x == 0
        ret = 1;
    else
        ret = sin(x) / x;
    end
end