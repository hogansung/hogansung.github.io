function Pn = deparameterize(Pp)
    Pn = [cos(norm(Pp)/2), my_sinc(norm(Pp)/2)/2 * Pp']';
end