function ex = calEpsilon(x, X, P)
    px = X * P';
    px = px ./ px(:,3);
    ex = vector(x(:,1:2)) - vector(px(:,1:2));
end