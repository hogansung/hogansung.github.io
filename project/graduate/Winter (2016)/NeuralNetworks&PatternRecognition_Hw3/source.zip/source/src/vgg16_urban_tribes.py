import keras
from keras.applications import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.models import Model
from keras.layers.core import Activation, Dense, Flatten
from keras.layers.pooling import MaxPooling2D
from keras.preprocessing.image import ImageDataGenerator, array_to_img, \
    img_to_array, load_img
from keras.utils import np_utils
from keras import backend as K

from os import listdir
from os.path import isfile, join

import numpy as np
import scipy
from scipy.misc import imsave

from collections import defaultdict
import matplotlib.pyplot as plt


datapath = '../data/pictures_all/'
#datapath = '../data/urban_tribe/'

np.random.seed(514)


def getModel(output_dim):
    vgg_model = VGG16(weights='imagenet', include_top=True)
    vgg_out = vgg_model.layers[-2].output #Last FC layer's output  
    softmax_layer_output = Dense(output_dim, activation='softmax', name='predictions') \
    (vgg_out)

    # create new transfer learning model
    tl_model = Model(input=vgg_model.input, output=softmax_layer_output)

    # freeze all layers of VGG16
    for layer in vgg_model.layers[:-1]:
        layer.trainable = False

    # compile the model
    tl_model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

    # confirm the model is appropriate
    print tl_model.summary()

    return tl_model


def loadData():
    # create label dictionary
    label = ['biker', 'clubber', 'country', 'formal', 'goth', 'heavy', 'hiphop', 'hipster', \
     'others', 'ravers', 'surfer']
    map_label_idx = dict()
    for l, idx in zip(label, range(len(label))):
        map_label_idx[l] = idx
    
    # load and categorize each file with its label
    labelData = defaultdict(list)
    files = [f for f in listdir(datapath) if isfile(join(datapath, f))]
    for f in files:
        if f == '.DS_Store':
            continue
        img = load_img(join(datapath, f), target_size=(224, 224))
        img = img_to_array(img)
        img = np.expand_dims(img, axis=0)
        img = preprocess_input(img)
        lb = map_label_idx[f.split('_')[0]]
        labelData[lb].append(img[0])

    # shuffle and split data
    lstData = []
    for lb, data in labelData.iteritems():
        data = list(np.random.permutation(data))
        lstData.append(data)
    return lstData


def splitData(lstData, num_inst=2):
    stn_X = []
    stn_y = []
    vld_X = []
    vld_y = []
    for lb in xrange(len(lstData)):
        data = lstData[lb]
        stn_X += data[:num_inst]
        stn_y += [lb for i in xrange(num_inst)]
        vld_X += data[-32:]
        vld_y += [lb for i in xrange(32)]

    stn_y = np_utils.to_categorical(stn_y, len(lstData))
    vld_y = np_utils.to_categorical(vld_y, len(lstData))
    stn_X, stn_y = np.array(stn_X), np.array(stn_y)
    vld_X, vld_y = np.array(vld_X), np.array(vld_y)
    return stn_X, stn_y, vld_X, vld_y


# util function to convert a tensor into a valid image
def deprocess_image(img):
    # normalize tensor: center on 0., ensure std is 0.1
    img -= img.mean()
    img /= (img.std() + 1e-5)
    img *= 0.1

    # clip to [0, 1]
    img += 0.5
    img = np.clip(img, 0, 1)

    # convert to RGB array
    img *= 255
    img = np.clip(img, 0, 255).astype('uint8')
    return img


def visualize(img, layer_dict, layer_name, size):
    filters = []

    input_img = layer_dict['input_1'].input
    layer_output = layer_dict[layer_name].output

    for filter_idx in range(size):
        # build a loss function that maximizes the activation
        # of the nth filter of the layer considered
        loss = K.mean(layer_output[:, :, :, filter_idx])

        # compute the gradient of the input picture wrt this loss
        grads = K.gradients(loss, input_img)[0]

        # normalization trick: we normalize the gradient
        grads /= (K.sqrt(K.mean(K.square(grads))) + 1e-5)

        # this function returns the loss and grads given the input picture
        iterate = K.function([input_img], [loss, grads])

        # step size for gradient ascent
        step = 1.

        # we start from a gray image with some noise
        #input_img_data = np.random.random((1, 224, 224, 3))
        #input_img_data = (input_img_data - 0.5) * 20 + 128
        input_img_data = np.float32(np.expand_dims(img, axis=0))

        # run gradient ascent for 20 steps
        for i in range(20):
            loss_value, grads_value = iterate([input_img_data])
            input_img_data += grads_value * step

            # some filters get stuck to 0, we can skip them
            if loss_value <= 0.:
                break

        if loss_value > 0:
            # deprocess
            img = deprocess_image(input_img_data[0])
            filters.append((img, loss_value))

    n = 4
    # the filters that have the highest loss are assumed to be better-looking.
    # we will only keep the top 64 filters.
    filters.sort(key=lambda x: x[1], reverse=True)
    filters = filters[:n * n]

    margin = 5
    width = n * 224 + (n - 1) * margin
    height = n * 224 + (n - 1) * margin
    stitched_filters = np.zeros((width, height, 3))

    for i in range(n):
        for j in range(n):
            img, loss = filters[i * n + j]
            stitched_filters[(224 + margin) * i: (224 + margin) * i + 224,
                             (224 + margin) * j: (224 + margin) * j + 224, :] = img

    imsave('../result/%s_filter_new_%dx%d.png' % (layer_name, n, n), stitched_filters)


if __name__ == '__main__':
    # retrieve model
    output_dim = 11
    tl_model = getModel(output_dim) 
    print 'finish loading model'

    # load data
    lstData = loadData()
    print 'finish loading data'


    ## 4. Inference (a), (b), (c)
    num_inst_lst = [2, 4, 8, 16, 32]
    stn_acc_lst = []
    vld_acc_lst = []
    for num_inst in num_inst_lst:
        print('\nNow is using ' + str(num_inst) + ' instances')

        # split dataset
        stn_X, stn_y, vld_X, vld_y = splitData(lstData, num_inst)

        # preprocessing
        datagen = ImageDataGenerator()
        datagen.fit(stn_X)

        # train model
        earlyStopping=keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, \
            verbose=0, mode='auto')
        hist = tl_model.fit_generator(datagen.flow(stn_X, stn_y, batch_size=11), \
                samples_per_epoch=stn_X.shape[0], \
                nb_epoch=100, \
                callbacks=[earlyStopping], \
                validation_data=datagen.flow(vld_X, vld_y, batch_size=11), \
                nb_val_samples=vld_X.shape[0])


        # loss history
        stn_loss = hist.history['loss']
        vld_loss = hist.history['val_loss']
        print stn_loss, vld_loss

        plt.figure()
        plt.plot(stn_loss, label='subtrain')
        plt.plot(vld_loss, label='validate')
        plt.xlabel('Iterations', labelpad=10)
        plt.ylabel('Loss', labelpad=10)
        plt.margins(0)
        plt.title('Loss for 11-way Classification through Iterations with ' + \
            str(num_inst) + ' Instances')
        plt.legend(loc=1)
        plt.subplots_adjust(bottom=0.15)
        plt.savefig('../result/loss_' + str(num_inst) + '.png')

        # accuracy history
        stn_acc = hist.history['acc']
        stn_acc_lst.append(stn_acc[-1])
        vld_acc = hist.history['val_acc']
        vld_acc_lst.append(vld_acc[-1])
        print stn_acc, vld_acc

        plt.figure()
        plt.plot(stn_acc, label='subtrain')
        plt.plot(vld_acc, label='validate')
        plt.xlabel('Iterations', labelpad=10)
        plt.ylabel('Accuracy', labelpad=10)
        plt.ylim(0, 1)
        plt.margins(0)
        plt.title('Accuracy for 11-way Classification through Iterations with ' + \
            str(num_inst) + ' Instances')
        plt.legend(loc=1)
        plt.subplots_adjust(bottom=0.15)
        plt.savefig('../result/acc_' + str(num_inst) + '.png')

    # accuracy history
    plt.figure()
    plt.plot([0] + num_inst_lst, [0] + stn_acc_lst, label='subtrain')
    plt.plot([0] + num_inst_lst, [0] + vld_acc_lst, label='validate')
    plt.xlabel('Number of Instances per Class', labelpad=10)
    plt.ylabel('Accuracy', labelpad=10)
    plt.ylim(0, 1)
    plt.margins(0)
    plt.title('Accuracy for 11-way Classification with Increasing Instances')
    plt.legend(loc=1)
    plt.subplots_adjust(bottom=0.15)
    plt.savefig('../result/acc_instances.png')


    ## 4. Inference (e)
    layer_dict = dict([(layer.name, layer) for layer in tl_model.layers])

    # split dataset
    #stn_X, stn_y, vld_X, vld_y = splitData(lstData, 1)

    # visualize filters
    visualize(vld_X[0], layer_dict, 'block1_conv1', 64) # 64 filters
    visualize(vld_X[0], layer_dict, 'block5_conv3', 512) # 512 filters

    # visualize output
    vgg_model = VGG16(weights='imagenet', include_top=True)
	margin = 5
	width1 = 4 * 224 + 3 * margin
	height1 = 4 * 224 + 3 * margin
	width2 = 4 * 14 + 3 * margin
	height2 = 4 * 14 + 3 * margin
	block1_conv1_filter = np.ones((height1, width1)) * 255
	block5_conv3_filter = np.ones((height2, width2)) * 255
	for m in range(4):
		img = load_img("../data/urban_tribe/biker_group_pic0000%d.jpg" % \
            (m + 1), target_size=(224, 224))
		img = img_to_array(img)
		img = np.expand_dims(img, axis=0)
		img = preprocess_input(img)
		for i in range(2):
		    if i == 0:
		        layer_name = 'block1_conv1'
		        side = 224
		    else:
		        layer_name = 'block5_conv3'
		        side = 14
		    intermediate_layer_model = Model(input=vgg_model.input,
		                          output=vgg_model.get_layer(layer_name).output)
		    intermediate_output = intermediate_layer_model.predict(img)[0]
		    for j in range(4):
		    	if i == 0:
		    		block1_conv1_filter[(side + margin) * m: \
                    (side + margin) * m + side,
		                         (side + margin) * j: (side + margin) * j + side] \
                                  = intermediate_output[:,:,j]
		        else:
		        	block5_conv3_filter[(side + margin) * m: \
                    (side + margin) * m + side,
		                         (side + margin) * j: (side + margin) * j + side] \
                                 = intermediate_output[:,:,j]
	imsave('../result/block1_conv1_filter.png', block1_conv1_filter)
	imsave('../result/block5_conv3_filter.png', block5_conv3_filter)


    ## 5. Feature Extraction (a)
    '''
    layer_names = ['block1_conv1', 'block1_conv2',
                   'block2_conv1', 'block2_conv2', 
                   'block3_conv1', 'block3_conv2', 'block3_conv3',
                   'block4_conv1', 'block4_conv2', 'block4_conv3',
                   'block5_conv1', 'block5_conv2', 'block5_conv3']
    '''
    layer_names = ['block5_conv1', 'block5_conv2', 'block5_conv3']

    stn_acc_lst = []
    vld_acc_lst = []

    # split dataset
    stn_X, stn_y, vld_X, vld_y = splitData(lstData, 32)

    for layer_name in layer_names:
        # create new transfer learning model
        layer_output = layer_dict[layer_name].output
        pooling_output = MaxPooling2D(pool_size=(2, 2), strides=None, \
            border_mode='valid')(layer_output)
        flatten_layer_output = Flatten()(pooling_output)
        softmax_layer_output = Dense(output_dim, activation='softmax', name='predictions') \
            (flatten_layer_output)
        intermediate_layer_model = Model(input=tl_model.input, output=softmax_layer_output)

        # define learning rate
        rmsprop = keras.optimizers.RMSprop(lr=0.00001, rho=0.9, epsilon=1e-08, decay=0.0)

        # compile the model
        intermediate_layer_model.compile(loss='categorical_crossentropy',
                optimizer=rmsprop,
                metrics=['accuracy'])


        # confirm the model is appropriate
        print intermediate_layer_model.summary()

        print('\nNow is working on ' + layer_name)

        # preprocessing
        datagen = ImageDataGenerator()
        datagen.fit(stn_X)

        # train model
        earlyStopping=keras.callbacks.EarlyStopping(monitor='val_loss', patience=6, \
            verbose=0, mode='auto')
        hist = intermediate_layer_model.fit_generator(datagen.flow(stn_X, stn_y, \
                batch_size=11), \
                samples_per_epoch=stn_X.shape[0], \
                nb_epoch=100, \
                callbacks=[earlyStopping], \
                validation_data=datagen.flow(vld_X, vld_y, batch_size=11), \
                nb_val_samples=vld_X.shape[0])

        stn_acc = hist.history['acc']
        stn_acc_lst.append(stn_acc[-1])
        vld_acc = hist.history['val_acc']
        vld_acc_lst.append(vld_acc[-1])


    # accuracy history
    plt.figure()
    plt.plot(range(len(layer_names)), stn_acc_lst, label='subtrain')
    plt.plot(range(len(layer_names)), vld_acc_lst, label='validate')
    plt.xticks(range(len(layer_names)), layer_names, rotation=70)
    plt.xlabel('Concatenate Different Convolutional Layers', labelpad=10)
    plt.ylabel('Accuracy', labelpad=10)
    plt.ylim(0, 1)
    plt.title('Accuracy for 11-way Classification with Different Layers')
    plt.legend(loc=1)
    plt.subplots_adjust(bottom=0.3)
    plt.margins(0)
    plt.savefig('../result/acc_layers.png')
