from os import makedirs
from os.path import isdir

def getSampleSetupInfo():
    trainNs = [2, 4, 8, 16, 32]
    # 256 classes, 29780 sample images, 29780*20%/256 = 23.26
    valNs = [24, 24, 24, 24, 24]
    testNs = [24, 24 ,24 ,24 ,24]
    return trainNs, valNs, testNs

def getTrainSetupInfo():
    batchSize = 32
    maxEpoch = 20
    earlyStoppingMaxIncre = 6
    resultDir = '../result'
    modelname = 'vgg16'
    datasetname = 'cal256'
    #output_dim = 256 #For Caltech256

    return batchSize, maxEpoch, earlyStoppingMaxIncre, resultDir, modelname, datasetname

def getImgPathsInfo(z, classNames):
    imgFolder = '../data/256_ObjectCategories'
    paths  =[] 
    for i in range(len(z)):
        classId = int(z[i][0])
        classLabel = int(classId + 1)
        imgId = int(z[i][1])
        imgLabel = int(imgId+1)
        imgpath = "%s/%s/%03d_%04d.jpg"%(imgFolder, classNames[classId], classLabel, imgLabel)
        paths.append(imgpath)
    return paths

def getPathSetupInfo(topdir, modelname, datasetname, 
                     batchSize, maxEpoch, earlyStoppingMaxIncre, trainN):
    prefix = '%s/%s_%s_result/'%(topdir,
                           modelname,
                           datasetname)
    if not isdir(prefix):
        makedirs(prefix)
    postfix = '_bs%d_me%d_esi%d_train%d'%(batchSize, maxEpoch,
                                  earlyStoppingMaxIncre, trainN)
    weighth5path = '%sweights%s.h5'%(prefix, postfix)
    trainresultpklpath = '%strainresult%s.pkl'%(prefix, postfix)
    accfigpath = '%saccs%s.png'%(prefix, postfix)
    lossfigpath = '%sloss%s.png'%(prefix, postfix)
    summarytxtpath = '%ssummary%s.txt'%(prefix, postfix)
    testresultpklpath = '%stestresult%s.pkl'%(prefix, postfix)
    partitionpklpath = '%spartition%s.pkl'%(prefix, postfix)
    return weighth5path, trainresultpklpath, testresultpklpath, partitionpklpath, accfigpath, lossfigpath, summarytxtpath

def getFinalReportFigInfo(resultDir, qname):
    return '%s/vgg16_cal256_figs/%s.png'%(resultDir, qname)

def getAnalysisSetupInfo(layer_name):
    trainN = 32
    valN = 24
    testN = 24
    batchSize = 32
    maxEpoch = 30
    earlyStoppingMaxIncre = 6
    resultDir = '../result'
    modelname = 'vgg16_%s'%(layer_name)
    datasetname = 'cal256'
    return trainN, valN, testN, batchSize, maxEpoch, earlyStoppingMaxIncre, resultDir, modelname, datasetname

def getLayerNamesInfo():
    return ['block5_conv3', 'block5_conv2', 'block5_conv1']