from vgg16_model import trainByLayer
 
if __name__ == "__main__":
    layer_names = ['block5_conv1', 'block5_conv2', 'block5_conv3']
    lr = [ 0.0000001, 0.000001, 0.00001]
    for trainpara in zip(layer_names, lr):
        trainByLayer(trainpara[0], trainpara[1])
        