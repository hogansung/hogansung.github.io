
# coding: utf-8

# In[25]:


# coding: utf-8

# In[25]:

import cPickle as pickle
import numpy as np
import os
import progressbar as pb
import tarfile
import urllib

from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input
from keras.utils import np_utils
from random import shuffle

def downloadAndUntarFolder(url, directory, datasetname):
    tarfilename = directory + datasetname + ".tar"
    savefolder = directory + datasetname
    # check if the folder exsits.
    if not os.path.isdir(savefolder):
        print savefolder + " does not exsit, check if file has been downloaded."
        # download tar file first if the folder does not exist.
        if not os.path.isfile(tarfilename):
            print tarfilename + " does not exist."
            # make data folder if not yet created.
            if not os.path.isdir(directory):
                print directory + " does not exist, create the folder."
                os.mkdir(directory)
            # download the file 
            print "downloading from: "
            print url
            urllib.urlretrieve(url, tarfilename)

        else:
            print tarfilename + " exists under" + directory
        print "untar " + tarfilename
        tar = tarfile.open(tarfilename)
        tar.extractall(directory)
        tar.close
        print "done."

def saveTempPkl(dataset, pklfile):
    f = file(pklfile, 'wb')
    pickle.dump(dataset, f, protocol=pickle.HIGHEST_PROTOCOL)
    f.close  
      
def loadTempPkl(pklfile):
    f = open(pklfile, 'rb')
    dataset = pickle.load(f)
    f.close
    return dataset

def getImgInfo(imgTopDir, infotxt, infopkl, overwrite = False):
    print "Reading information of images from " + imgTopDir
    classNames = []
    imgCounts = []
    nClasses = 0
    if not os.path.isfile(infotxt) or not os.path.isfile(infopkl) or overwrite:
        bar = pb.ProgressBar(maxval=260).start()
        i = 0
        for subdir, dirs, files in os.walk(imgTopDir):
            if i == 0:
                classNames = dirs
                classNames.sort()
                classNames = classNames[:-1] # drop clutters
                nClasses = len(classNames)
                imgCounts = np.zeros(nClasses)
                print "found ", nClasses, " classes"
            for f in files:               
                filepath = os.path.join(subdir, f)
                if not f.startswith(".") and not f.endswith(".mat") and subdir.split(".")[-1] != "clutter":
                    labelpart = f.split("_")[0]
                    try:
                        labelidx = int(labelpart) - 1
                        imgCounts[labelidx] += 1
                    except:
                        print labelpart, "returns error while being case to int, skip."
            bar.update(i+1)           
            i += 1

        bar.finish()
        print "Done."
        f = open(infotxt, 'w')
        for i in range(nClasses):
            f.write("{}\t\t\t{}\n".format(classNames[i], imgCounts[i]))
            
        stats = classNames, imgCounts
        saveTempPkl(stats, infopkl)
    else:
        print "found " + infotxt + " and " + infopkl  
        classNames, imgCounts = loadTempPkl(infopkl)

    print "There are %d classes with a total of %d sample images\n"%(len(classNames), np.sum(imgCounts))
    return classNames, imgCounts

def partition(classCounts, trainNperClass, valNperClass, testNperClass):
    print "partition image ids per class."
    nClasses = len(classCounts)
    
    leftTrainN = trainNperClass*nClasses
    leftValN = valNperClass*nClasses
    leftTestN = testNperClass*nClasses
    z_train = []
    z_valid = []
    z_test = []   
    
    for i in range(nClasses):
        # Randomize images per class.
        classLabel = i+1
        imgN = int(classCounts[i])
        randIdSeq = np.random.permutation(imgN)
        
        # take the first selectTrainN as training data. If there are less than 2 samples left after selecting training, we force it to leave 1 each for validation and testing.
        selectTrainN = int(min(leftTrainN, imgN-2, trainNperClass))
        leftTrainN -= selectTrainN
        # take the next selectValN as validation. If what is left is not enough for validation set, force to take one from this set, leave one for test.
        selectValN = int(min(leftValN, max(1, imgN - selectTrainN), valNperClass))
        leftValN -= selectValN
        # take the last selectTestN as test. If what is left is not enough for testing, force to take the last one for test.
        selectTestN = int(min(leftTestN, max(1, imgN - selectTrainN - selectValN), testNperClass))
        leftTestN -= selectTestN
        
        temp_z_train = zip(np.ones(selectTrainN)*i, randIdSeq[:selectTrainN])
        temp_z_valid = zip(np.ones(selectValN)*i,
                           randIdSeq[selectTrainN:selectTrainN+selectValN])
        temp_z_test = zip(np.ones(selectTestN)*i,
                          randIdSeq[selectTrainN+selectValN:selectTrainN+selectValN+selectTestN])
        
        z_train.extend(temp_z_train)
        z_valid.extend(temp_z_valid)
        z_test.extend(temp_z_test)                
        
    accTrainCount = len(z_train)
    accValCount = len(z_valid)
    accTestCount = len(z_test)
                
    print "selected %d trainIds, %d valIds, %d testIds"%(accTrainCount, accValCount, accTestCount)
    return z_train, z_valid, z_test

def getCal256Info():
    # check if the data has been downloaded.
    url = "http://www.vision.caltech.edu/Image_Datasets/Caltech256/256_ObjectCategories.tar"
    saveDir = "../data/"
    zipFolderName = "256_ObjectCategories"
    downloadAndUntarFolder(url, saveDir, zipFolderName)
    
    # get information from the image directories.
    imgTopDir = saveDir + zipFolderName
    infotxt = "{}_summary.txt".format(imgTopDir)
    infopkl = "{}_summary.pkl".format(imgTopDir)
    classNames, classCounts = getImgInfo(imgTopDir, infotxt, infopkl)
    return classNames, classCounts

def prepData(trainN, valN, testN, classCounts, partitionpklpath, overwrite=False):
    if not os.path.isfile(partitionpklpath) or overwrite:
        z_train, z_valid, z_test = partition(classCounts, trainN, valN, testN)
        data = z_train, z_valid, z_test
        saveTempPkl(data, partitionpklpath)
    else:
        z_train, z_valid, z_test = loadTempPkl(partitionpklpath)
    return z_train, z_valid, z_test

def getData(z, classNames, imgFolder= '../data/256_ObjectCategories', targetsize=(224, 224), channels=3):
    nClasses = len(classNames)
    X = np.empty((0, targetsize[0], targetsize[1], channels))
    y = np.empty(0, dtype=np.int64)
    
    for i in range(len(z)):
        classId = int(z[i][0])
        classLabel = int(classId + 1)
        imgId = int(z[i][1])
        imgLabel = int(imgId+1)
        y = np.append(y, [classId],axis=0)

        imgpath = "%s/%s/%03d_%04d.jpg"%(imgFolder, classNames[classId], classLabel, imgLabel)
        img = image.load_img(imgpath, False, target_size = targetsize)
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis =0)
        x = preprocess_input(x, dim_ordering='tf')
        X = np.append(X, x, axis=0)            
    yhot = np_utils.to_categorical(y, nClasses)

    return X, yhot
        
def genSample(z, batch_size, classNames):
    i = 0
    while 1:
        X, y = getData(z[i:i+batch_size], classNames)
        i = i + batch_size
        if i + batch_size > len(z):
            shuffle(z)
            i = 0
        yield X, y
        
#unit test
if __name__ == '__main__':
    getCal256Info()