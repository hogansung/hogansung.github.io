import keras
from keras.preprocessing import image
from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.models import Model
from keras.utils import np_utils
from keras.layers.core import Dense
from keras.layers.core import Activation
from keras import backend as K
from keras.callbacks import EarlyStopping
import numpy as np
from random import shuffle
import os
import re
import gc

def temperature_activation(a):
    T = 8
    return K.softmax(a/T)

def getModel( output_dim ):
    '''
        * output_dim: the number of classes (int)

        * return: compiled model (keras.engine.training.Model)
    '''
    vgg_model = VGG16( weights='imagenet', include_top=True )
    vgg_out = vgg_model.layers[-2].output #Last FC layer's output
    fc_layer = Dense(1000, activation=temperature_activation, weights=vgg_model.layers[-1].get_weights())(vgg_out)
    softmax_layer = Dense(256, activation='softmax')(fc_layer) #Create softmax layer taking input as vgg_out
    #Create new transfer learning model
    tl_model = Model( input=vgg_model.input, output=softmax_layer )

    #Freeze all layers of VGG16 and Compile the model
    for l in tl_model.layers:
        l.trainable = False
    tl_model.layers[-1].trainable = True
    tl_model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    #Confirm the model is appropriate
    tl_model.summary()
    return tl_model

category = [''] * 256

def prepData(train_size=30, valid_size=3, test_size=10):
    x_train = []
    x_valid = []
    x_test = []
    y_train = []
    y_valid = []
    y_test = []
    p = '256_ObjectCategories'
    for c in os.listdir(p):
        categ = int(c.split('.')[0]) - 1
        if categ >= 256: break
        category[categ] = c
        x = []
        for i in os.listdir(os.path.join(p, c)):
            s = re.split('_|\.', i)
            if len(s) != 3 or s[2] != 'jpg': continue
            x.append(int(s[1]))
        shuffle(x)
        x_train += x[:train_size]
        x_valid += x[train_size:train_size+valid_size]
        x_test += x[train_size+valid_size:train_size+valid_size+test_size]
        y_train += [categ] * train_size
        y_valid += [categ] * valid_size
        y_test += [categ] * test_size
    z_train = list(zip(x_train, y_train))
    shuffle(z_train)
    z_valid = list(zip(x_valid, y_valid))
    shuffle(z_valid)
    z_test = list(zip(x_test, y_test))
    shuffle(z_test)
    return z_train, z_valid, z_test

def getData(z_data):
    p = '256_ObjectCategories'
    x_data = []
    y_data = []
    for z in z_data:
        pa = os.path.join(p, category[z[1]])
        pa = os.path.join(pa, str(z[1]+1).zfill(3)+'_'+str(z[0]).zfill(4)+'.jpg')
        img = image.load_img(pa, target_size=(224,224))
        x_data.append(image.img_to_array(img))
        y_data.append(z[1])
    x_data = np.array(x_data)
    x_data = preprocess_input(x_data)
    y_data = np_utils.to_categorical(y_data, 256)
    return x_data, y_data

def genSample(z_train):
    batch_size = 32
    i = 0
    while 1:
        x_train, y_train = getData(z_train[i:i+batch_size])
        i = i + batch_size
        if i + batch_size > len(z_train):
            shuffle(z_train)
            i = 0
        yield x_train, y_train


if __name__ == '__main__':
    #Output dim for your dataset
    output_dim = 256 #For Caltech256
    tl_model = getModel( output_dim )

    train_size = 10
    z_train, z_valid, z_test = prepData(train_size)
    x_valid, y_valid = getData(z_valid)
    #Train the model
    early_stopping = EarlyStopping(monitor='val_loss', min_delta=0.001, patience=0)
    tl_model.fit_generator(genSample(z_train), samples_per_epoch=256*train_size, nb_epoch=15, validation_data=(x_valid, y_valid), callbacks=[early_stopping])
    #Test the model
    gc.collect()
    x_test, y_test = getData(z_test)
    result = tl_model.evaluate(x_test, y_test)
    print("On test set")
    for (v,n) in zip (result, tl_model.metrics_names):
        print(n + ": " + str(v))
