from os.path import isfile, split, basename
from os import rename
from shutil import copy
import matplotlib.pyplot as plt
from scipy.misc import imsave
from keras.applications import VGG16
from keras.models import load_model
from keras import backend as K
from keras.preprocessing import image

import time
import numpy as np
from vgg16_cal256_setup import getSampleSetupInfo, getTrainSetupInfo, getPathSetupInfo, getFinalReportFigInfo, getAnalysisSetupInfo, getImgPathsInfo, getLayerNamesInfo
from vgg16_cal256_utils import saveTempPkl, loadTempPkl, getCal256Info, prepData, getData

def printpklhistory(historypkl):
    keys, acc, loss, val_acc, val_loss = historypkl
    summary_train = "last accuracy:%0.4f, last loss:%0.4f, best accuracy: %0.4f, best loss: %0.4f"%(acc[-1], loss[-1], max(acc), min(loss))
    summary_val = "last val accuracy:%0.4f, last val loss:%0.4f, best val_accuracy: %0.4f, best val_loss: %0.4f"%(val_acc[-1], val_loss[-1], max(val_acc), min(val_loss))
    
    print summary_train
    print summary_val
    return summary_train, summary_val

def savehistory(history, historypklpath,
                accfigpath, lossfigpath,
                summarytxtpath, fig=True):
    print 'Start saving history...'
    acc = history.history['acc']
    loss = history.history['loss']
    val_acc = history.history['val_acc']
    val_loss = history.history['val_loss']
    pklhistory = history.history.keys(), acc, loss, val_acc, val_loss
    saveTempPkl(pklhistory, historypklpath)
    sum_train, sum_val = printpklhistory(pklhistory)
    savesummary(sum_val, summarytxtpath)
    if fig:
        savefig([acc, val_acc],
                'model accuracy',
                'epoch', 'accuracy',
                ['train', 'validation'],
                accfigpath)
        savefig([loss, val_loss],
               'model loss',
               'epoch',
               'loss',
               ['train', 'valication'],
               lossfigpath)
        
    print 'Done saving history.'
    
def loadhistory(historypklpath):
    if isfile(historypklpath):
        print "Found previous historypkl. Loading %s."%(historypklpath)
        pklhistory = loadTempPkl(historypklpath)
        printpklhistory(pklhistory)
        keys, acc, loss, val_acc, val_loss  = pklhistory
    else:
        print "Cannot find previous historypkl at path: %s"%(historypklpath)
        keys = None
        acc = None
        loss = None
        val_acc = None
        val_loss = None
    return acc, loss, val_acc, val_loss

def savesummary(summary, summarytxtpath):
    if not isfile(summarytxtpath):
        print "Saving %s"%(summarytxtpath)
        with open(summarytxtpath, 'w') as f:
            f.write(summary)

def savefig(results, title='', xlabel='', ylabel='', legends = [], savepath = '',  Xs = [], display = False, overwrite = True):
    if not isfile(savepath) or overwrite:
        print "Save %s..."%(savepath)
        
        if Xs == []:
            Xs = range(len(results[0]))
        print "# iterations:", len(Xs)
        for Ys in results:
            plt.plot(Xs, Ys)
                
            plt.title(title)
            plt.ylabel(ylabel)
            plt.xlabel(xlabel)
        
        if legends !=[]:
            plt.legend(legends, loc='upper left')
        plt.savefig(savepath)
        print "Done saving acc figure."
        if display:
            plt.show()
        plt.clf()

def genReportQ3():
    # 3, 4.c
    trainNs, _, _ = getSampleSetupInfo()
    
    batchSize, maxEpoch, earlyStoppingMaxIcre, resultDir, modelname, datasetname = getTrainSetupInfo()
    
    final_val_accs = []
    for trainN in trainNs:
        _, historypklpath, testresultpklpath,_, _, _, _ = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre, trainN)
        _, _, val_acc, _ = loadhistory(historypklpath)
        if val_acc != None:
            final_val_accs.append(val_acc[-1])
    print final_val_accs
    if final_val_accs != []:
        title = 'model accuracy'
        xlabel = 'Training images per-class'
        ylabel = 'Accuracy'
        legends = []
        reportfig = getFinalReportFigInfo(resultDir, 'q3')
        savefig([final_val_accs], title, xlabel, ylabel, legends, reportfig, trainNs,  True)
    else:
        print "Could not find validation accuracies."

def genReportQ4ab():
    # 4.a, 4.b
    trainNs, _, _ = getSampleSetupInfo()
    trainN = trainNs[-1]
    batchSize, maxEpoch, earlyStoppingMaxIcre, resultDir, modelname, datasetname = getTrainSetupInfo()
    _, historypklpath, _, _, _, _, _ = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre, trainN)
    
    acc, loss, val_acc, val_loss = loadhistory(historypklpath)

    if loss != []:
        reportfig = getFinalReportFigInfo(resultDir,'q4_a')
        savefig([loss, val_loss], 
                'model loss',
                'Number of epoch', 
                'Loss', 
                ['Train', 'Test'], 
                reportfig,
                range(len(loss)+1)[1:])
        reportfig = getFinalReportFigInfo(resultDir, 'q4_b')
        savefig([acc, val_acc], 
                'model accuracy',
                'Number of epoch', 
                'Accuracy', 
                ['Train', 'Test'], 
                reportfig, 
                range(len(loss)+1)[1:])
    else:
        print "Could not find validation accuracies."

def normalize(x):
    # utility function to normalize a tensor by its L2 norm
    return x / (K.sqrt(K.mean(K.square(x))) + 1e-5)

def stitch(activations, n = 8):
    img_width = activations.shape[0]
    img_height = img_width
    print '%dx%d'%(img_width, img_height)
    # we will stich the best 64 filters on a 224 x 224grid.
    n = int(np.sqrt(activations.shape[2]))

    # the filters that have the highest loss are assumed to be better-looking.
    # we will only keep the top 64 filters.
    # activations = activations[:, :, 0:n * n]

    # build a black picture with enough space for
    margin = 5
    width = n * img_width + (n - 1) * margin
    height = n * img_height + (n - 1) * margin
    stitched_filters = np.zeros((width, height, 3))

    # fill the picture with our saved filters

    for i in range(n):
        for j in range(n):
            img = activations[..., i * n + j]
            img = np.expand_dims(img, axis=2)
            stitched_filters[(img_width + margin) * i: (img_width + margin) * i + img_width,
                             (img_height + margin) * j: (img_height + margin) * j + img_height, :] = img

    return stitched_filters

def stitch4(activations, indices):
    img_width = activations.shape[0]
    img_height = img_width
    print '%dx%d'%(img_width, img_height)
    # we will stich the best 64 filters on a 224 x 224grid.
    margin = 5
    n =2
    width = n * img_width + (n - 1) * margin
    height = n * img_height + (n - 1) * margin
    stitched_filters = np.zeros((width, height, 3))

    # fill the picture with our saved filters
    
    count = 0
    for i in range(n):
        for j in range(n):
            img = activations[..., indices[count]]
            img = np.expand_dims(img, axis=2)
            stitched_filters[(img_width + margin) * i: (img_width + margin) * i + img_width,
                             (img_height + margin) * j: (img_height + margin) * j + img_height, :] = img
            count += 1
    return stitched_filters
    
def deprocessImage(x):
    # normalize tensor: center on 0., ensure std is 0.1
    x -= x.mean()
    x /= (x.std() + 1e-5)
    x *= 0.1

    # clip to [0, 1]
    x += 0.5
    x = np.clip(x, 0, 1)

    # convert to RGB array
    x *= 255
    if K.image_dim_ordering() == 'th':
        x = x.transpose((1, 2, 0))
    x = np.clip(x, 0, 255).astype('uint8')
    return x

def visualizeLayer(layer_name, X, save=True):
    # Setup model
    model = VGG16( weights='imagenet', include_top=True )
    model.summary()
    input_img = model.input
 
    # get the symbolic outputs of each "key" layer (we gave them unique names).
    layer_dict = dict([(layer.name, layer) for layer in model.layers[1:]])
    
    kept_filters = []
    nFilters = layer_dict[layer_name].output_shape[-1]
    # Get layer output
    layer_output = layer_dict[layer_name].output
    # create a function that returns the loss and grads given the input picture.
    get_activation = K.function([input_img], [layer_output])        
    activations = get_activation([X])[0]
    activations = np.squeeze(activations)
    
    gridsize = 2
    indices = np.random.randint(activations.shape[2], size=gridsize*gridsize)
    stitched_filters = stitch4(activations, indices)
    # save the result to disk
    return 'stitched_filters_%dx%d.png' % (gridsize, gridsize), stitched_filters
    
def genReportQ4d():
    # Get test info for 32 samples.
    trainNs, valNs, testNs = getSampleSetupInfo()
    batchSize, maxEpoch, earlyStoppingMaxIcre,resultDir, modelname, datasetname = getTrainSetupInfo()
    classNames, classCounts = getCal256Info()
    
    trainN = trainNs[-1]
    valN = valNs[-1]
    testN = testNs[-1]
    
    _, _, _, partitionpklpath, _, _, _ = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre, trainN)
    prepData(trainN, valN, testN, classCounts, partitionpklpath)
    
    z_train, z_valid, z_test = prepData(trainN, valN, testN, classCounts, partitionpklpath)
    
    # z_test contains the test data that were not used for training or validation.
    X, yhot = getData(z_test[:5], classNames)
    paths = getImgPathsInfo(z_test, classNames)
    # Decide which layer to look at.
    layer_name1 = 'block1_conv1' 
    layer_name2 = 'block5_conv3'
    maxfilterpool = 200 # 512 available.
    
    for i in range(3):
        reportfigImg = getFinalReportFigInfo(resultDir, 'q4_d_img%d'%(i+1))
        imgPath = paths[i]
        img = image.load_img(imgPath, False, (224, 224))
        x = image.img_to_array(img)
        imsave(reportfigImg, x)
        #imsave(reportfigImg, img)
        reportfig1 = getFinalReportFigInfo(resultDir, 'q4_d_feature_conv1_%d'%(i+1))
        reportfig2 = getFinalReportFigInfo(resultDir, 'q4_d_feature_conv3_%d'%(i+1))

        filename, filters = visualizeLayer(layer_name1, np.expand_dims(X[i, ...], axis=0))
        print "filters", type(filters), filters.shape
        imsave(reportfig1, filters)
        filename, filters = visualizeLayer(layer_name2, np.expand_dims(X[i, ...], axis=0))
        imsave(reportfig2, filters)
        
def genReportQ5():
    layer_names = getLayerNamesInfo()
    for layer_name in layer_names:
        trainN, _, _, batchSize, maxEpoch, earlyStoppingMaxIncre, resultDir, modelname, datasetname = getAnalysisSetupInfo(layer_name)
        _, historypklpath, _, _, _, _, _ = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIncre, trainN)
        print "try load %s"%(historypklpath)
        acc, loss, val_acc, val_loss = loadhistory(historypklpath)
        print type(acc)
        if loss != []:
            reportfig = getFinalReportFigInfo(resultDir, 'q5_a_%s'%(layer_name))
            print "saving reports to %s"%(reportfig)
            savefig([loss, val_loss], 
                    'model loss',
                    'Number of epoch', 
                    'Loss', 
                    ['Train', 'Test'], 
                    reportfig, 
                    range(len(loss)+1)[1:])
            reportfig = getFinalReportFigInfo(resultDir, 'q5_b_%s'%(layer_name))
            print "saving reports to %s"%(reportfig)
            
            savefig([acc, val_acc], 
                    'model accuracy',
                    'Number of epoch', 
                    'Accuracy', 
                    ['Train', 'Test'], 
                    reportfig,
                    range(len(loss)+1)[1:])
        else:
            print "Could not find validation accuracies."
# Unit tests          
if __name__ == "__main__":
    #genReportQ3()
    #genReportQ4ab()
    genReportQ4d()
    #genReportQ5()