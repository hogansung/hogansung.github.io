if __name__ == '__main__':
    # Output dim for your dataset

    # Setup parameters.
    trainNs, valNs, testNs = getSampleSetupInfo()
    classNames, classCounts = getTribesInfo()
    output_dim = len(classNames)
    verboseFlag = 2
    
    Ns = zip(trainNs, valNs, testNs)
    for N in Ns:
        trainN = N[0]
        valN = N[1]
        testN = N[2]
        batchSize, maxEpoch, earlyStoppingMaxIcre,resultDir, modelname, datasetname = getTrainSetupInfo()
        if not isdir(resultDir):
            makedirs(resultDir)

        print 'Start training...'
        # Load a new model every time.
        tl_model = getModel(output_dim)

        trainModel(trainN, valN, testN, tl_model, classNames, classCounts, batchSize, maxEpoch, earlyStoppingMaxIcre, resultDir, modelname, datasetname, verboseFlag)

        test = False
        if test:
            testModel(z_test, classNames, resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre,trainN)