from keras.applications import VGG16
from keras.layers import Dense, Flatten
from keras.models import Model, load_model
from keras.optimizers import RMSprop, SGD
from keras.callbacks import EarlyStopping

from os import makedirs
from os.path import isfile, isdir

from MyTensorBoard import TensorBoard

from vgg16_cal256_setup import getSampleSetupInfo, getTrainSetupInfo, getPathSetupInfo, getAnalysisSetupInfo
from vgg16_cal256_utils import saveTempPkl, loadTempPkl, getCal256Info, prepData, getData, genSample
from vgg16_cal256_report import savehistory, loadhistory, printpklhistory, savesummary, savefig

def getModel( output_dim, modelfile='../model/myvgg16.h5'):
    ''' 
         * output_dim: the number of classes (int)
         * return: compiled model (keras.engine.training.Model)
    '''
    if isfile(modelfile):
        # identical to the previous one
        tl_model = load_model(modelfile)
    else:

        vgg_model = VGG16( weights='imagenet', include_top=True )
        #Last FC layer's output
        vgg_out = vgg_model.layers[-2].output   
        #Create softmax layer taking input as vgg_out
        softmax_layer = Dense(output_dim, activation='softmax')(vgg_out)
        #Create new transfer learning model
        tl_model = Model( input=vgg_model.input, output=softmax_layer )

        #Freeze all layers of VGG16 and Compile the model
        for layer in tl_model.layers:
            layer.trainable = False
        tl_model.layers[-1].trainable = True
        #Confirm the model is appropriate
        opt = RMSprop(lr=0.001)
        tl_model.compile(optimizer=opt, 
                         loss='categorical_crossentropy', 
                         metrics=['accuracy'])
        tl_model.summary()
        tl_model.save(modelfile)  # creates a HDF5 file

    # returns a compiled model
    return tl_model

def trainModel(trainN, valN, testN,  # samples per class count.
               tl_model, classNames, classCounts, # model and dataset info
               batchSize, maxEpoch, earlyStoppingMaxIcre, # training related
               resultDir, modelname, datasetname, verboseFlag=2, earlystopping=False):# saving related.
    # set up filenames for storage.
    weighth5path, historypklpath, _, partitionpklpath, accfigpath, lossfigpath, summarytxtpath = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre, trainN)

    z_train, z_valid, z_test = prepData(trainN, valN, testN, classCounts, partitionpklpath)

    # Setup callbacks.
    bd = TensorBoard(log_dir='%s/%s_logs'%(resultDir, datasetname),
                     histogram_freq=2, 
                     write_graph=True)
    es = EarlyStopping(
        monitor='val_loss',
        min_delta=0, # minimum change for improvement
        patience = earlyStoppingMaxIcre, # number of epochs with no improvement after which training will be stoped
        verbose = verboseFlag, # print more information
        mode='auto') # infer min from monitoring loss, and infer max for monitoring accuracy.
    if earlystopping:
        callbackList = [bd, es]
    else:
        callbackList = [bd]
    output_dim = len(classCounts)
    # Train the model
    print "--------->>Training<<---------"
    if not isfile(weighth5path) or not isfile(historypklpath):
        #Train the model
        history = tl_model.fit_generator(genSample(z_train, batchSize, classNames),
                                         samples_per_epoch=output_dim*trainN,
                                         nb_epoch=maxEpoch, verbose = verboseFlag,
                                         callbacks=callbackList,
                                         validation_data=genSample(z_valid, batchSize, classNames),
                                         nb_val_samples=output_dim*valN)
        print 'Done training.'
        print 'Start saving weights...'
        tl_model.save_weights(weighth5path)
        print 'Done saving weights.'
        savehistory(history, 
                    historypklpath, 
                    accfigpath, 
                    lossfigpath, 
                    summarytxtpath)

    else:     
        print 'Found history and weights, printing...'
        loadhistory(historypklpath)

        print "---------------------------------"

def testModel(z_test, classNames, resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre,trainN):
    #Test the model
    _, _, testresultpklpath, _, _, _, _ = getPathSetupInfo(resultDir, modelname, datasetname, batchSize,maxEpoch,earlyStoppingMaxIcre, trainN)
    testN = len(z_test)
    if ispath(weighth5path):
        print 'Found previous weights, and load from %s'%(weighth5path)
        tl_model = getModel(output_dim)
        tl_model.load_weights(weighth5path)
    output_dim = len(classNames)
    if not isfile(testresultpklpath):
        print "--------->>Testing<<---------"
        print "Testing with %d samples per class with %d samples."%(testN, len(z_test))
        testResult = tl_model.evaluate_generator(genSample(z_test, batchSize, classNames), 
                                                 val_samples=output_dim*testN)
        zipresult = zip(testResult, tl_model.metrics_names)
        saveTempPkl(zipresult, testresultpklpath)
    else:
        print "Found test result in %s"%(testresultpklpath)
        zipresult = loadTempPkl(testresultpklpath)

    for (v,n) in zipresult:
        print(n + ": " + str(v))
        print "---------------------------------"

def getModelByLayer(layer_name, lr, output_dim, overwrite = False):
    modelfile='../model/vgg16_%s.h5'%(layer_name)
    print 'get model from %s'%(modelfile)
    if isfile(modelfile) and not overwrite:
        # identical to the previous one
        tl_model = load_model(modelfile)
       
    else:
        vgg_model = VGG16( weights='imagenet', include_top=True )
        # get the symbolic outputs of each "key" layer (we gave them unique names).
        layer_dict = dict([(layer.name, layer) for layer in vgg_model.layers[1:]])
        
        # Selected cnn layer output.
        vgg_out = layer_dict[layer_name].output 
        
        print layer_dict[layer_name].output_shape
        flatten = Flatten()(vgg_out)
        #Create softmax layer taking input as vgg_out
        softmax_layer = Dense(output_dim, activation='softmax')(flatten)
        #Create new transfer learning model
        tl_model = Model(input=vgg_model.input, output=softmax_layer )

        #Freeze all layers of VGG16 and Compile the model
        for layer in tl_model.layers:
            layer.trainable = False
        tl_model.layers[-1].trainable = True
        #Confirm the model is appropriate
        prop = RMSprop(lr=0.0001)
        print "learning rate is:%0.4f"%(lr)
        #sgd = SGD(lr=lr, decay=1e-6, momentum=0.9, nesterov=True)
        tl_model.compile(optimizer=prop, 
                         loss='categorical_crossentropy', 
                         metrics=['accuracy'])
        tl_model.save(modelfile)  # creates a HDF5 file
    tl_model.summary()
    return tl_model

def trainByLayer(layer_name, lr):    
    classNames, classCounts = getCal256Info()
    output_dim = len(classNames)
    verboseFlag = 2
    trainN, valN, testN, batchSize, maxEpoch, earlyStoppingMaxIncre, resultDir, modelname, datasetname = getAnalysisSetupInfo(layer_name)
    # get all training info.
    if not isdir(resultDir):
        makedirs(resultDir)
    # get model.
    l_model = getModelByLayer(layer_name, lr, output_dim)
    # trainModel.
    trainModel(trainN, valN, testN, l_model, classNames, classCounts, batchSize, maxEpoch, earlyStoppingMaxIncre, resultDir, modelname, datasetname)

# Unit test.
if __name__ == '__main__':
    model = getModel(256)
    model.summary()