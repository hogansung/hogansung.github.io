#include<cstdio>

int main(int argc, char *argv[]){
   char ch = argv[1][0];

   puts("#include<syscall.h>\n");
   puts("int main(){");
   puts("   int i;");
   puts("   for (i=1; i<30; i++){");

   for (int i=0; i<=10; i++){
      printf("      OSPrint(\"%%d%c0%d%d\\n\", i);\n", ch, i/10, i%10);
   }

   puts("   }");
   puts("}");
}
