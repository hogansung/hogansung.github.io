/**************************************************************
 *
 * userprog/ksyscall.h
 *
 * Kernel interface for systemcalls 
 *
 * by Marcus Voelp  (c) Universitaet Karlsruhe
 *
 **************************************************************/

#ifndef __USERPROG_KSYSCALL_H__ 
#define __USERPROG_KSYSCALL_H__ 

#include "synchconsole.h"
#include "kernel.h"
#include<cstring>


void SysHalt()
{
  kernel->interrupt->Halt();
}

int SysAdd(int op1, int op2)
{
  return op1 + op2;
}

int SysOSAdd(int op1, int op2)
{
   return op1 + op2;
}

int SysOSSub(int op1, int op2)
{
   return op1 - op2;
}

int SysOSMul(int op1, int op2)
{
   return op1 * op2;
}

int SysOSDiv(int op1, int op2)
{
   return op1 / op2;
}

int SysPrint(char* op1, int op2)
{
   int cnt = 0, con[1024];
   bool err = false;

   for (int i=0; i<op2; i++){
      if (!kernel->machine->ReadMem((int)op1 + i, 1, con + i))  err = true;
   }

   for (int i=0; i<op2 && !err; i++){
      if (con[i] == 0)   break;
      kernel->synchConsoleOut->PutChar(con[i]);
      cnt++;
   }

   return cnt;
}

int SysOSPrint(char* op1, int op2)
{
   int cnt = 0, flag = 0, d;
   char con[1024];
   bool err = false;

   while (true){
      if (!kernel->machine->ReadMem((int)op1 + flag, 1, &d))  err = true;
      con[cnt] = (char)d;
      cnt++;   flag++;
      if (cnt > 1 && con[cnt - 2] == '%' && con[cnt - 1] == 'd')  break;
   }
   cnt += sprintf(con + cnt - 2, "%d", op2) - 2;
   while (true){
      if (!kernel->machine->ReadMem((int)op1 + flag, 1, &d))  err = true;
      con[cnt] = (char)d;
      cnt++;   flag++;
      if (con[cnt - 1] == '\0'){
         con[cnt] = 0;
         break;
      }
   }
   kernel->synchConsoleOut->PutString(con);
   return cnt;
}

void PutChar(char* op1, int op2){
   for (int i=0; i<op2; i++){
      if (op1[i] == 0)  break;
      kernel->synchConsoleOut->PutChar(op1[i]);
   }
}

void PutNum(int opt){
   int t = 1;

   while (opt / t >= 10){
      t *= 10;
   }

   while (t >= 1){
      kernel->synchConsoleOut->PutChar(opt/t + '0');
      opt %= t;
      t /= 10;
   }

}


#endif /* ! __USERPROG_KSYSCALL_H__ */
