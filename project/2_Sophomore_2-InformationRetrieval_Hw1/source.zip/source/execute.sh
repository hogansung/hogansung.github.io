#!/bin/bash

test ! -f ./src/vocab.revised && ./bin/vocParser $@
test ! -f ./src/file.revised && ./bin/docParser $@
./bin/parser $@
