#!/bin/bash

./compile.sh
./execute.sh -i ./queryFile/query-30.xml -o ./outputFile/ranked-30 -m ./model-files/ -d ./CIRB010/
