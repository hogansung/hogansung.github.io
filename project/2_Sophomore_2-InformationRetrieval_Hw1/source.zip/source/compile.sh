#!/bin/bash

make compile -C ./src 
