bool skip(char line[]){
   if (strstr(line, "<xml>") != NULL) return true;
   if (strstr(line, "</xml>") != NULL) return true;
   if (strstr(line, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>") != NULL)  return true;
   if (line[0] == '\n')  return true;
   return false;
}

bool btopic(char line[]){
   if (strstr(line, "<topic>") != NULL)   return true;
   return false;
}

bool etopic(char line[]){
   if (strstr(line, "</topic>") != NULL)   return true;
   return false;
}

bool bquestion(char line[]){
   if (strstr(line, "<question>") != NULL)   return true;
   return false;
}

bool equestion(char line[]){
   if (strstr(line, "</question>") != NULL)   return true;
   return false;
}

bool bnarrative(char line[]){
   if (strstr(line, "<narrative>") != NULL)   return true;
   return false;
}

bool enarrative(char line[]){
   if (strstr(line, "</narrative>") != NULL)   return true;
   return false;
}

bool bconcepts(char line[]){
   if (strstr(line, "<concepts>") != NULL)   return true;
   return false;
}

bool econcepts(char line[]){
   if (strstr(line, "</concepts>") != NULL)   return true;
   return false;
}

bool ttitle(char line[]){
   if (strstr(line, "<title>") != NULL)   return true;
   return false;
}

bool tnumber(char line[]){
   if (strstr(line, "<number>") != NULL) return true;
   return false;
}

bool docskip(char line[]){
   if (strstr(line, "<doc>") != NULL)  return true;
   if (strstr(line, "</doc>") != NULL)  return true;
   if (strstr(line, "<id>") != NULL)  return true;
   if (strstr(line, "<date>") != NULL)  return true;
   if (strstr(line, "<p>") != NULL)  return true;
   if (strstr(line, "</p>") != NULL)  return true;
   return false;
}

bool btext(char line[]){
   if (strstr(line, "<text>") != NULL) return true;
   return false;
}

bool etext(char line[]){
   if (strstr(line, "</text>") != NULL) return true;
   return false;
}
