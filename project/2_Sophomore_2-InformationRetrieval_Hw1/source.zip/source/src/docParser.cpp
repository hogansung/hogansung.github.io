#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<algorithm>
#include"check.h"

const int LMAX = 1024;
const int transferValue = 40000;
   
bool REJUDGE = false;

std::string queryFile, rankedList, modelDir, NTUIRDir;
FILE *qfile, *ofile, *voc, *flist, *file_revised, *invIndex, *sfile, *dvoclist;

void parseArgument(int argc, char *argv[]){
   for (int i=1; i<argc; i++){
      if (argv[i][1] == 'i')  queryFile = std::string(argv[++i]);
      else if (argv[i][1] == 'o')   rankedList = std::string(argv[++i]);   
      else if (argv[i][1] == 'm')   modelDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'd')   NTUIRDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'r')   REJUDGE = true; 
      else  fprintf(stderr, "Exception error occurred!");
   }
}

std::map<std::string, int> voc_list, s_list;

std::vector<std::string> files_name;
std::vector<int>  files_term_num, maxTerm, totalTerm;

void getVoc(){
   char in[LMAX + 1] = {0};
   int cnt = 0;

   fgets(in, LMAX, voc);
   while (fgets(in, LMAX, voc) != NULL){
      in[strlen(in) - 1] = 0;
      voc_list[std::string(in)] = cnt++;
   }
}

void getStop(){
   char in[LMAX + 1] = {0};
   int cnt = 0;

   while (fgets(in, LMAX, sfile) != NULL){
      in[strlen(in) - 1] = 0;
      s_list[std::string(in)] = cnt++;
   }
}

void openFile(){
   file_revised = fopen("./src/file.revised", "w+");
   voc = fopen((modelDir + std::string("vocab.all")).c_str(), "r");
   flist = fopen((modelDir + std::string("file-list")).c_str(), "r");
   sfile = fopen("./src/stoplist", "r");
}

void closeFile(){
   fclose(file_revised);
   fclose(voc);
   fclose(flist);
   fclose(sfile);
}

int findinVoc(std::string word){
   if (voc_list.count(word) != 0)   return voc_list[word];
   return -1;
}

bool findinSlist(std::string word){
   if (s_list.count(word) != 0)   return true;
   return false;
}

void countTerm(std::vector<int> &target, char con[]){
   char word[4];
   int len = strlen(con) - 1, last;
   bool first = true;

   for (int i=0; i<len; i+=3){
      word[0] = con[i];
      word[1] = con[i + 1];
      word[2] = con[i + 2];
      word[3] = 0; 

      if (findinSlist(std::string(word))){
         first = true;
         continue;
      }

      int tar = findinVoc(std::string(word));

      if (first)  target.push_back(tar * transferValue);
      else {
         target.push_back(tar * transferValue);
         target.push_back(last * transferValue + tar);
      }

      last = tar;
      first = false;
   }
}

int Max(int a, int b){return a<b?b:a;}

void countWord(std::string my_string){
   char con[LMAX + 1], word[4], in[4];
   FILE *pfile = fopen((NTUIRDir + my_string).c_str(), "r");
   bool st = false;
   int cnt = 0, my_max = 0;

   std::vector<int> temp = std::vector<int>();
   
   while (fgets(con, LMAX, pfile) != NULL){
      if (skip(con) || docskip(con));
      else if (btext(con)) st = true;
      else if (st == true){
         countTerm(temp, con);
      }
   }

   std::sort(temp.begin(), temp.end());
   std::vector<int>::iterator flag = temp.begin(), tmp;

   while (flag != temp.end()){
      tmp = flag;
      int sum = 0;
      while (*tmp == *flag && flag != temp.end()){
         flag++;
         sum++;
      }
      my_max = Max(my_max, sum);
      cnt++;
   }

   fclose(pfile);
   files_term_num.push_back(cnt);
   maxTerm.push_back(my_max);
   totalTerm.push_back(temp.size());
}

int countFfile(){
   char in[LMAX + 1];
   int cnt = 0;

   while (fgets(in, LMAX, flist) != NULL){
      in[strlen(in) - 1] = 0;
      std::string my_string = std::string(in); 
   
      unsigned int tar = my_string.rfind("/") + 1;
      files_name.push_back(my_string.substr(tar));
      cnt++;
      countWord(my_string.substr(10));
      if (cnt % 10000 == 0) fprintf(stderr, "Now is concering %dth file!\n", cnt);
   }
   return cnt;
}

void printRes(int n){
   for (int i=0; i<n; i++){
      fprintf(file_revised, "%s %d %d %d\n", files_name[i].c_str(), files_term_num[i], totalTerm[i], maxTerm[i]);
   }
}

int main(int argc, char *argv[]){
   parseArgument(argc, argv);
   openFile();
   getVoc();
   getStop();

   fprintf(stderr, "Begin to get info from file-list.\n");
   int fileNum = countFfile();
   fprintf(stderr, "Finish to get info from file-list.\n");

   fprintf(stderr, "Begin to create ./src/file.revised.\n");
   printRes(fileNum);
   fprintf(stderr, "Finish to create ./src/file.revised.\n");
   
   closeFile();
}
