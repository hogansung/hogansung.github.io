#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<algorithm>
#include<cmath>
#include"check.h"

const int LMAX = 1024;
const int transferValue = 40000;
const int CARE = 25;
const double beta = 0.05;

bool REJUDGE = false;

std::string queryFile, rankedList, modelDir, NTUIRDir;
FILE *qfile, *ofile, *voc, *file_revised, *invIndex, *sfile, *dvoclist;

int fileNum, vctSize;
double file_avg_length;

std::map<std::string, int> voc_list, s_list;

struct Final{
   Final(double a, int b){res=a, fileno=b;}
   bool operator < (const Final &c) const {return res > c.res;}
   double res;
   int fileno;
};
std::vector<Final> finalGrade_list;

std::map<int, int> voc_detailed_list, newword_list;

struct DocVector{
   DocVector(){}
   DocVector(int n){con.resize(n);}
   std::vector<double>  con;
};
std::map<int, DocVector> doc_vec_map;

std::vector<double>  wordCnt;
std::vector<int>  biword_list, store_list, files_wordCnt, totalTerm, maxTerm;
std::vector<std::string>  files_name;

void parseArgument(int argc, char *argv[]){
   for (int i=1; i<argc; i++){
      if (argv[i][1] == 'i')  queryFile = std::string(argv[++i]);
      else if (argv[i][1] == 'o')   rankedList = std::string(argv[++i]);   
      else if (argv[i][1] == 'm')   modelDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'd')   NTUIRDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'r')   REJUDGE = true; 
      else  fprintf(stderr, "Exception error occurred!");
   }
}

void openFile(){
   qfile = fopen(queryFile.c_str(), "r");
   ofile = fopen(rankedList.c_str(), "w");
   voc = fopen((modelDir + std::string("vocab.all")).c_str(), "r");
   file_revised = fopen("./src/file.revised", "r");
   invIndex = fopen((modelDir + std::string("inverted-index")).c_str(), "r");
   sfile = fopen("./src/stoplist", "r");
   dvoclist = fopen("./src/vocab.revised", "r");
}

void getVoc(){
   char in[LMAX + 1] = {0};
   int cnt = 1;

   fgets(in, LMAX, voc);
   while (fgets(in, LMAX, voc) != NULL){
      in[strlen(in) - 1] = 0;
      voc_list[std::string(in)] = cnt++;
   }
}

void getDVoc(){
   char in[LMAX + 1] = {0};
   int a, b, c;

   while (fgets(in, LMAX, dvoclist) != NULL){
      sscanf(in, "%d%d%d", &a, &b, &c);
      voc_detailed_list[a * transferValue + b] = c;
   }
}

void getStop(){
   char in[LMAX + 1] = {0};
   int cnt = 0;

   while (fgets(in, LMAX, sfile) != NULL){
      in[strlen(in) - 1] = 0;
      s_list[std::string(in)] = cnt++;
   }
}

void getFile(){
   char in[LMAX + 1], con[LMAX + 1];
   int cnt = 0, num, total, my_max;
   
   while (fgets(in, LMAX, file_revised) != NULL){
      sscanf(in, "%s%d%d%d", con, &num, &total, &my_max);

      files_name.push_back(std::string(con));
      files_wordCnt.push_back(num);
      totalTerm.push_back(total);
      maxTerm.push_back(my_max);

      file_avg_length += total;
      cnt++;
   }
   file_avg_length /= cnt;
   fileNum = cnt;
}

int findinVoc(std::string word){
   if (voc_list.count(word) != 0)  return voc_list[word];
   return -1;
}

bool findinSlist(std::string word){
   if (s_list.count(word) != 0)  return true;
   return false;
}

int buildWord(char word[], char con[]){
   if (con[0] > 0){
      word[0] = con[0];
      word[1] = 0;
   }
   else if (con[0] >= -16){
      for (int i=0; i<4; i++) word[i] = con[i];
      word[4] = 0;
   }
   else if (con[0] >= -32){
      for (int i=0; i<3; i++) word[i] = con[i];
      word[3] = 0;
   }
   else if (con[0] >= -64){
      for (int i=0; i<2; i++) word[i] = con[i];
      word[2] = 0;
   }
   return strlen(word);
}

void countTerm(char con[]){
   char word[5], sentence[LMAX + 1] = {0};
   int len = strlen(con) - 1, flag = 0, last;
   bool first = true, succ = false;

   while (flag < len){
      int res = buildWord(word, con + flag);
      flag += res;

      if (res == 1 && word[0] != ' '){
         succ = true;
         strcat(sentence, word);
         continue;
      }
      else if (succ){
         succ = false;
         memset(sentence, 0, sizeof(sentence));

         int tar = findinVoc(std::string(sentence));
         if (tar == -1){
            last = -1;
            first = true;
            continue;
         }
         biword_list.push_back(tar * transferValue);
         first = true;  
      }

      if (findinSlist(std::string(word))){
         last = -1;
         first = true;
         continue;
      }

      int tar = findinVoc(std::string(word));
      if (tar == -1){
         last = -1;
         first = true;
         continue;
      }

      if (first)  biword_list.push_back(tar * transferValue);
      else {
         biword_list.push_back(tar * transferValue);
         biword_list.push_back(last * transferValue + tar);
      }

      last = tar;
      first = false;
   }
   if (succ){
      int tar = findinVoc(std::string(sentence));
      if (tar == -1){
         last = -1;
         first = true;
         return;
      }
      biword_list.push_back(tar * transferValue);
      first = true;  
   }
}

void storeTerm(char con[]){
   char word[5], sentence[LMAX + 1] = {0};
   int len = strlen(con) - 1, flag = 0, last;
   bool first = true, succ = false;

   while (flag < len){
      int res = buildWord(word, con + flag);
      flag += res;

      if (res == 1 && word[0] != ' '){
         succ = true;
         strcat(sentence, word);
         continue;
      }
      else if (succ){
         succ = false;
         memset(sentence, 0, sizeof(sentence));

         int tar = findinVoc(std::string(sentence));
         if (tar == -1){
            last = -1;
            first = true;
            continue;
         }
         store_list.push_back(tar * transferValue);
         first = true;  
      }      

      if (findinSlist(std::string(word))){
         first = true;
         continue;
      }

      int tar = findinVoc(std::string(word));
      if (tar == -1){
         first = true;
         continue;
      }

      if (first)  store_list.push_back(tar * transferValue);
      else {
         store_list.push_back(tar * transferValue);
         store_list.push_back(last * transferValue + tar);
      }
      last = tar;
      first = false;
   }
   if (succ){
      int tar = findinVoc(std::string(sentence));
      if (tar == -1){
         last = -1;
         first = true;
         return;
      }
      store_list.push_back(tar * transferValue);
      first = true;  
   }
}

void getWordCnt(){
   for (std::vector<int>::iterator it = biword_list.begin(); it!=biword_list.end(); it++) newword_list[*it] = 0;
   vctSize = newword_list.size();

   for (std::vector<int>::iterator it=store_list.begin(); it!=store_list.end(); it++){
      if (newword_list.count(*it) != 0)   newword_list[*it]++;
   }
}

void bindDoc(){
   char in[LMAX + 1];
   int a, b, c, flag = 0;

   for (std::map<int, int>::iterator it=newword_list.begin(); it!=newword_list.end(); it++, flag++){
      int pos = voc_detailed_list[it->first];
      if (fseek(invIndex, pos, SEEK_SET) < 0)  while(1);
      
      fgets(in, LMAX, invIndex);
      sscanf(in, "%d%d%d", &a, &b, &c);
      wordCnt.push_back(it->second * log((double)fileNum/c));
      
      for (int i=0; i<c; i++){
         fgets(in, LMAX, invIndex);
         sscanf(in, "%d%d", &a, &b);

         if (doc_vec_map.count(a) == 0)   doc_vec_map[a] = DocVector(vctSize);
         doc_vec_map[a].con[flag] = (4 + log(b)) / (5 + log((double)totalTerm[a]/files_wordCnt[a])) * 100; // 0.7339, 0.6954
         //doc_vec_map[a].con[flag] = (4 + log(b)) * 200;  // 0.7339, 0.6851
         //doc_vec_map[a].con[flag] = (1 + log(b)) * log((double)fileNum/c);
      }
   }
}

void analyze(){
   for (std::map<int, DocVector>::iterator it=doc_vec_map.begin(); it!=doc_vec_map.end(); it++){
      double ans = 0, sum = 0;
      for (int i=0; i<vctSize; i++){
         ans += wordCnt[i] * it->second.con[i];
         sum += it->second.con[i] * it->second.con[i];
      }
      finalGrade_list.push_back(Final(ans/sqrt(sum), it->first));
   }
   std::sort(finalGrade_list.begin(), finalGrade_list.end());
}

void rejudge(){
   int flag = 0;
   for (std::vector<Final>::iterator it=finalGrade_list.begin(); it!=finalGrade_list.end() && flag < CARE; it++, flag++){
      for (int i=0; i<vctSize; i++){
         wordCnt[i] += beta / CARE * doc_vec_map[it->fileno].con[i];
      }
   }
}

void printRes(int n){
   int i = 0;
   for (std::vector<Final>::iterator it=finalGrade_list.begin(); it!=finalGrade_list.end() && i<100; it++, i++){
      fprintf(ofile, "%d%d%d ", n%1000/100, n%100/10, n%10);
      for (int j=0; j<files_name[it->fileno].size(); j++)   fprintf(ofile, "%c", tolower(files_name[it->fileno][j]));
      fprintf(ofile, "\n");
   }
}

void closeFile(){
   fclose(qfile);
   fclose(ofile);
   fclose(voc);
   fclose(file_revised);
   fclose(invIndex);
   fclose(sfile);
   fclose(dvoclist);
}

void refresh(){
   newword_list.clear();
   doc_vec_map.clear();
   wordCnt = std::vector<double>();
   finalGrade_list = std::vector<Final>();
   biword_list = std::vector<int>();
   store_list = std::vector<int>();
}

void parseFile(){
   int st = 0, cnt = 1;
   char con[LMAX + 1];
   bool first = true;

   while (fgets(con, LMAX, qfile) != NULL){
      if (skip(con) || btopic(con)) continue;
      else if (etopic(con)){
         getWordCnt();
         bindDoc();
         analyze();

         if (REJUDGE){
            rejudge();
            finalGrade_list = std::vector<Final>();
            analyze();
            printRes(cnt);            
         }
         else  printRes(cnt);

         refresh();
         first = true;
         cnt++;
      }
      else if (ttitle(con)){
         char tmp[LMAX + 1];
         int len = strlen(con) - 1;

         if (first){
            first = false;
            fprintf(stderr, "Now is concerning query #%d.\n", cnt);
         }
         
         for (int i=0; i<len; i++){
            if (con[i + 7] == '<'){
               tmp[i] = 0;
               break;
            }
            tmp[i] = con[i + 7];
         }
         countTerm(tmp);
         storeTerm(tmp);
      }
      else if (bquestion(con))   st = 1;
      else if (equestion(con) || enarrative(con) || econcepts(con))   st = 0;
      else if (bnarrative(con))  st = 2;
      else if (bconcepts(con))   st = 3;
      else if (tnumber(con));
      else if (st == 1 || st == 2 || st == 3){
         countTerm(con);
         storeTerm(con);
      }
   }
}

int main(int argc, char *argv[]){
   
   parseArgument(argc, argv);
   openFile();

   getVoc();
   getStop();
   getDVoc();
   getFile();

   fprintf(stderr, "Begin to judge the related grade.\n");
   parseFile();
   fprintf(stderr, "Finish to judge the related grade.\n");

   closeFile();
}
