#include<cstdio>
#include<string>

const int LMAX = 1024;
bool REJUDGE = false;
   
std::string queryFile, rankedList, modelDir, NTUIRDir;
FILE *qfile, *ofile, *file_revised, *invIndex, *sfile, *dvoclist, *voc_revised;

void parseArgument(int argc, char *argv[]){
   for (int i=1; i<argc; i++){
      if (argv[i][1] == 'i')  queryFile = std::string(argv[++i]);
      else if (argv[i][1] == 'o')   rankedList = std::string(argv[++i]);   
      else if (argv[i][1] == 'm')   modelDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'd')   NTUIRDir = std::string(argv[++i] + std::string("/"));   
      else if (argv[i][1] == 'r')   REJUDGE = true; 
      else  fprintf(stderr, "Exception error occurred!");
   }
}

void openFile(){
   invIndex = fopen((modelDir + std::string("inverted-index")).c_str(), "r");
   if (invIndex == NULL)   puts("error 1");
   voc_revised = fopen("./src/vocab.revised", "w+");
   if (voc_revised == NULL)   puts("error 2");
}

void closeFile(){
   fclose(invIndex);
   fclose(voc_revised);
}

void createVocRevised(){
   char in[LMAX + 1] = {0};

   fseek(voc_revised, 0, SEEK_SET);
   int pos = ftell(invIndex), a, b, c;

   while (fgets(in, LMAX, invIndex) != NULL){
      sscanf(in, "%d%d%d", &a, &b, &c);
      for (int i=0; i<c; i++){
         fgets(in, LMAX, invIndex);
      }
      fprintf(voc_revised, "%d %d %d\n", a, b==-1?0:b, pos);
      pos = ftell(invIndex);
   }
}

int main(int argc, char *argv[]){

   parseArgument(argc, argv);
   openFile();

   fprintf(stderr, "Begin to create ./src/vocab.revised.\n");
   createVocRevised();
   fprintf(stderr, "Finish to create ./src/vocab.revised.\n");

   closeFile();
}
