import operator

with open('../dat/test') as inf, open('../dat/scores.txt') as sf, open('../dat/cnt') as cntf, open('../dat/res', 'w') as outf:
    text = [line.strip() for line in inf.readlines()]
    mark = [float(line.strip()) for line in sf.readlines()]
    
    readIdx = 0
    for line in cntf.readlines():
        num = int(line.strip())

        s_text = text[readIdx:readIdx+num]
        s_mark = mark[readIdx:readIdx+num]
        readIdx += num

        idx, val = max(enumerate(s_mark), key=operator.itemgetter(1))
        outf.write(s_text[idx] + '\n')

