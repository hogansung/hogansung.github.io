with open('../dat/sub') as inf
