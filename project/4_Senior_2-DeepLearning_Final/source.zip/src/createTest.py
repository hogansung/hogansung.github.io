with open('../dat/hw2_output_N100.txt') as inf, open('../dat/test', 'w') as outf, open('../dat/cnt', 'w') as cntf:
    lines = inf.readlines()
    readIdx = 0

    while readIdx < len(lines):
        num = int(lines[readIdx].strip())
        cntf.write(str(num) + '\n')
        readIdx += 1
        
        for i in xrange(num):
            outf.write(lines[readIdx])
            readIdx += 1
