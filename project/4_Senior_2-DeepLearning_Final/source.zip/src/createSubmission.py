wordMap = {}
with open('../dat/timit.chmap') as mapf:
    for line in mapf.readlines():
        key, val = line.strip().split()
        wordMap[key] = val


careSet = set()
with open('../dat/testname.txt') as cf:
    for line in cf.readlines():
        careSet.add(line.strip())


with open('../dat/res') as inf, open('../dat/hw2.out') as tagf, open('../dat/sub', 'w') as outf:
    resLines = inf.readlines()

    outf.write('id,sequence\n')
    tagLines = tagf.readlines()[1:]

    assert(len(resLines) == len(tagLines))

    for rl, tl in zip(resLines, tagLines):
        tag = tl.strip().split(',')[0]
        if tag not in careSet:
            continue

        outf.write(tag + ',')
        for w in rl.strip().split():
            if w in wordMap:
                outf.write(wordMap[w])
        outf.write('\n')
    
