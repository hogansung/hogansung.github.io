import re

with open('../dat/train.set') as inf, open('../dat/train', 'w') as outf:
    for line in inf.readlines():
        p = line.find(',')
        sent = line[p+1:]

        sent = re.sub(r'[,.?!"]', r'', sent)
        outf.write(sent)
