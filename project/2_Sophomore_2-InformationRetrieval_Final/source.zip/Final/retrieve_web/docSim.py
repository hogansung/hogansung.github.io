# -*- encoding: utf-8 -*-
import sys
sys.path.append("/nfs/undergrad/00/b00902053/python_plugin/lib/python2.7/site-packages")
import itertools

import nltk
import ast      #string->dict
import retrieve

from gensim import corpora, models, similarities

def createSim(docTokens):

    print "createSim begin"

    dictionary = corpora.Dictionary([doc for labels in docTokens for doc in labels])
    corpus = [dictionary.doc2bow(doc) for labels in docTokens for doc in labels]

    tfidf = models.TfidfModel(corpus)
    corpus_tfidf = tfidf[corpus]

    lsi = models.LsiModel(corpus_tfidf, id2word = dictionary, num_topics = 200)
    index = similarities.MatrixSimilarity(lsi[corpus])

    output = []

    for labels in docTokens:
        subOutput = []
        for doc in labels:
            ml_bow = dictionary.doc2bow(doc)
            ml_lsi = lsi[ml_bow]
            
            sims = index[ml_lsi]
            subOutput.append(sims)

        output.append(subOutput)

    print "createSim end"
    return output


def createLabelSim(docSim):
    print "createLabelSim begin"

    labelNum = len(docSim)
    if labelNum != 0:
        docNum = len(docSim[0])

    labelSim = [[0 for x in xrange(labelNum)] for x in xrange(labelNum)]

    for i in xrange(labelNum):
        for j in xrange(docNum):
            s = 0
            t = 0
            for stat in docSim[i][j]:
                labelSim[i][t] += stat
                labelSim[t][i] += stat 
                s += 1
                if s == docNum:
                    s = 0
                    t += 1

    print "createLabelSim end"
    return labelSim

#------------------------------------------------------------------------------


def main():
    #searchTxt('haha')
    ret = searchImg('wow', 3)
    docTokens = []
    label = []
    
    for idx, res in enumerate(ret):
        print '---id = %d ---' % (idx)
        print 'title ' + res.title
        print 'url : ' + res.imgUrl
        print 'src : ' + res.url
        print 'des : ' + res.snip
         
        print "id #%d begin parsing" % idx
        label.append(urlToTokenList(res.imgUrl))
        print "id #%d end parsing" % idx

    docTokens.append(label);

    # Assume: docTokens = [ label01[doc01[word01, word02, ...], doc02[...], ...], label02[], ...]
    # In other words: docTokens > label > doc > word
    documentSim = createSim(docTokens)


    # Output: documentSim = [ label01[array([doc01's relationship with 10*10 docs, ...]), label02[...], ...] 
    # In other words: documentSim > label > doc's 10 * 10 corresponding docs (compacted in array) 
    LabelSim = createLabelSim(documentSim)
    #print LabelSim
            

if __name__ == '__main__':
    main()
