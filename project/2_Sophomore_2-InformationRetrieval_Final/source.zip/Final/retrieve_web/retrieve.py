# -*- encoding: utf-8 -*-
import string
import unicodedata

import re
import urllib2
import StringIO
import gzip

import chardet

import nltk
#from nltk.corpus import stopwords

import ast      #string->dict
import BeautifulSoup    #Beautiful Soup 3
import collections    #for namedtuple
import lxml.html
from lxml import etree


'''
function:
    1.searchTxt(query, maxNum)   return : list of TxtResult
    2.searchImg(query, maxNum)   return : list of ImgResult
    3.autoComplete(query)        return : list of (txt,num)
'''

#-== Definition of Object ==----------------------------------------------------

TxtResult = collections.namedtuple('TxtResult','title snip url')
ImgResult = collections.namedtuple('ImgResult','title snip url imgUrl')

#------------------------------------------------------------------------------

def getHTML(url, timelimit=10):
    if isinstance(url, unicode):
        url = url.encode('utf-8')
    #print 'start'
    headers = {
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0',
            'connection':'keep-alive',
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language':'zh-tw,zh;q=0.8,en-us;q=0.5,en;q=0.3',
            'Accept-Encoding':'plain,gzip'
    }

    req = urllib2.Request(
            url = url,
            headers = headers
            )
    try:
        response = urllib2.urlopen(req, timeout=timelimit)
    except:
        print '[Error] failed @ getHTML()'
        return u''
    
    content = response.read()
    if response.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO(content)
        f = gzip.GzipFile(fileobj=buf)
        content = f.read()

    # encoding detect
    if not isinstance(content, unicode):
        encoding = chardet.detect(content)['encoding']
        if encoding is not None:
            content = content.decode(encoding, 'ignore')
        else:
            print '[Error] failed @ encoding parse'
            context = u''

    #print 'end'
    return content


def getParseTree(url):
    #tree = BeautifulSoup.BeautifulSoup(getHTML(url))
    tree = lxml.html.fromstring(getHTML(url))
    #print 'parse'
    return tree

#------------------------------------------------------------------------------

def clearify(txt):
    '''
        replace HTML thing
    '''
    return re.sub('&.*?;', '', txt)


def mergeQuery(query, dequeryList = None):
    '''
        replace +/- to query
        return type: str
    '''
    if dequeryList == None:
        return query.replace(' ', '+')

    dequery = ''
    for dq in dequeryList:
        dequery += ' ' + dq
    return query.replace(' ', '+') + dequery.replace(' ', '+-')


def concStr(node):
    return nltk.clean_html(etree.tostring(node))


def concStr_BS(node):
    '''
        BeautifulSoup version of concStr
        Since we're going to use lxml instead of bs, this func is not used now
        return type : str
    '''
    if type(node) == BeautifulSoup.NavigableString:
        return str(node)
    s = ''.join([concStr(c) for c in node.contents])
    return s

#------------------------------------------------------------------------------

def urlToText(url):
    html_source = getHTML(url)
    text = nltk.clean_html(html_source)
    return text



def TextToTokens(text):

    latin_letters = {}
    def isLatin(uni_char):
        try: 
            return latin_letters[uni_char]
        except KeyError:
            return latin_letters.setdefault(uni_char, 'LATIN' in unicodedata.name(uni_char))

    def allRomanChars(uni_str):
        return all(isLatin(uni_char) for uni_char in uni_str)

    token = nltk.wordpunct_tokenize(text)
    token = tuple(word.lower() for word in token)
    
    # Chinese Tokenize
    new_token = []
    for s in token:
        if s.isalpha() and not allRomanChars(s):
            new_token += s
        else:
            new_token.append(s)

    return new_token


def ReplaceChinesePunctuation(text):
    replace_table = { 
        u'，' : u', ',
        u'。' : u'. ',
        u'！' : u'! ',
        u'？' : u'? ',
        u'；' : u'; ',
        u'：' : u': ',
        u'（' : u'( ',
        u'）' : u') ',
        u'【' : u'[ ',
        u'】' : u'] ',
        u'、' : u', ',
        u'～' : u'~',
    }

    for a, b in replace_table.iteritems():
        text = text.replace(a, b)

    return text


def RemoveStopword(token):
    ignored_words = nltk.corpus.stopwords.words('english')
    ignored_words = set(ignored_words)
    return [word for word in token if word not in ignored_words]


def RemovePunctuation(token):
    puncutation = set(string.punctuation)
    return [word for word in token 
                if not all(char in puncutation for char in word)]


def urlToTokenList(url):
    '''
        get all tokens
        return type: list(unicode())
    '''
    text = urlToText(url)

    text = ReplaceChinesePunctuation(text)
    token = TextToTokens(text)
 
    token = RemoveStopword(token)

    token = RemovePunctuation(token)

    stemmer = nltk.PorterStemmer()
    token = [stemmer.stem(word) for word in token]

    return token

#------------------------------------------------------------------------------

def extractImgResult(node):
    '''
        every single image has its owned info-page.
        This function open the info-page of an image and retrieve its info.
    '''
    try:
        #imgresUrl = node.find('a')['href']
        imgresUrl = node.find('a').get('href')
        refUrl = re.search('&imgrefurl=(.*?)&', imgresUrl).group(1).split('&')[0]
        imgUrl = re.search('&imgurl=(.*?)&', imgresUrl).group(1).split('&')[0]
        
        tree = getParseTree( imgresUrl )
        
        #meta = tree.find('div' , attrs={"id":"md", "class":"rg_meta"}).contents[0]
        meta = tree.find(".//div[@class='rg_meta']").text
        metaDict = ast.literal_eval(meta)
        
        title = clearify(metaDict['pt'])
        desc  = clearify(metaDict['s'])
    except AttributeError:
        return None
    #return ImgResult(title=title, snip=desc, url=refUrl, imgUrl=imgUrl)
    return (title, desc, refUrl, imgUrl)

def searchImg(query, maxNum = 10, dequeryList = None):
    '''
        search query(text) to google images and return #maxNum results
        return type: list of ImgResult ( namedtuple('title snip url imgUrl') )
        ( not support un-alphabet query yet )
    '''
    query = mergeQuery(query, dequeryList)
    url = 'https://www.google.com/search?q=' + query + '&um=1&tbm=isch&biw=1366&bih=638'
    ret = []      #list of TxtResult
    tree = getParseTree(url)
    # results = tree.findAll('div', attrs={'class':'rg_di'})   
    results = tree.findall(".//div[@class='rg_di']")
    for r in results:
        rx = extractImgResult(r)
        if rx != None :
            ret.append(rx)
        if len(ret) >= maxNum :
            break
    return ret

#------------------------------------------------------------------------------

def extractTxtResult(node):
    try:
        #---title & url: <h3 class="r"><a href='url'> title </a></h3>---
        #titleNode = node.find('h3', attrs={'class' : 'r'}).find('a')
        titleNode = node.find(".//h3[@class='r']").find(".//a")
        url = titleNode.get('href')

        #---snippet : <div class="s"> ... <span class="st"> snippet </span>...</div>---
        #snipNode = node.find('span', attrs={'class' : 'st'})
        snipNode = node.find(".//span[@class='st']")
        
        if titleNode == None or snipNode == None:
            return None
        title = clearify(concStr(titleNode))
        snip = clearify(concStr(snipNode))
    except AttributeError:
        return None
    #return TxtResult(title=title, url=url, snip=snip)
    return (title, desc, refUrl, imgUrl)


def extractTxtResults(url, ret):
    tree = getParseTree(url)
    results = tree.findall(".//li[@class='g']")
    #results = tree.findAll('li', attrs={'class' : 'g'})
    if len(results) == 0:
        return False

    for r in results:
        rx = extractTxtResult(r)
        if rx != None:
            ret.append(rx)
    return True


def searchTxt(query, maxNum = 10, dequeryList = None):
    '''
        search query(text) to google and return #maxNum results
        return type: list of TxtResult ( namedtuple('title snip url') )
        ( not support un-alphabet query yet )
    '''
    query = mergeQuery(query, dequeryList)
    url = 'https://www.google.com/search?q=' + query + '&num=' + str(maxNum+10)
    ret = []      #list of TxtResult
    start = 0
    while len(ret) < maxNum:
        nowUrl = url + ('&start=%d' % start)
        start += 10
        if not extractTxtResults(nowUrl, ret):
            break
    if len(ret) >maxNum:
        ret = ret[:maxNum]
    return ret


#------------------------------------------------------------------------------

def autoComplete(query):
    '''
        get google autocomplete list of the query
        return type: list of (text, #num)
    '''
    query = mergeQuery(query)
    url = 'http://suggestqueries.google.com/complete/search?q=' + query + '&output=toolbar'
    tree = getParseTree(url)
    
    #--- Beautiful Soup version ---
    #t = lambda x : (x.suggestion['data'], int(x.suggestion.num_queries['int']))
    #ret = [ t(x) for x in tree.findAll('completesuggestion')]
    
    #--- lxml version---
    t = lambda x : (x.find('suggestion').get('data'), int(x.find('num_queries').get('int')))
    ret = [ t(x) for x in tree.findall('.//completesuggestion')]
    return ret

#------------------------------------------------------------------------------

def testForTxt():
    ret = searchTxt('joker', 2, dequeryList=None)
    for idx, res in enumerate(ret):
        print '---id = %d ---' % (idx)
        print 'title: ' + res.title
        print 'src  : ' + res.url
        print 'des  : ' + res.snip


def testForImg():
    ret = searchImg('joker', 25, dequeryList=None)
    for idx, res in enumerate(ret):
        print '---id = %d ---' % (idx)
        print 'title: ' + res.title
        print 'src  : ' + res.url
        print 'src  : ' + res.imgUrl
        print 'des  : ' + res.snip


def testForComplete():
    ret = autoComplete('egg')
    for r in ret:
        print r

def testForToken():
    url = 'http://nltk.org/_modules/nltk/stem/porter.html'
    result = urlToTokenList(url)
    for s in result:
        print s

def main():
    #testForTxt()    
    #testForImg()
    #testForComplete()
    testForToken()

if __name__ == '__main__':
    main()

