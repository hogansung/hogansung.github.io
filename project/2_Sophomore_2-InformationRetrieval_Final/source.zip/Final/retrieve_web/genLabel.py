# -*- encoding: utf-8 -*-
import sys
import math
import re
import itertools
import nltk

import retrieve

def clearify(txt):
    '''
        remove symbol and transfer to lowercase
        may become empty string ''
    '''
    return re.sub(r'\W+','',txt.lower())


def clearifyList(txtList):
    return filter(lambda x: x, map(clearify,txtList) )


def tokenize( text ):
    '''
        get all tokens from input
        return type: list(unicode())
    '''
    #print text
    tokens = [nltk.word_tokenize(s) for s in nltk.sent_tokenize(text)]
    return clearifyList(itertools.chain.from_iterable(tokens))


#------------------------------------------------------------------------------

#--- global variable for IDF --- 
g_idfDict = None   # IDF
g_defIdf = None    # default IDF
#-------------------------------

def openIdfFile():
    '''
        read IDF from IdfFileName
        format of IDF file : rank word times\n
        return type: dict, float
    '''
    #parameter
    IdfFileName = 'idf'
    swFileName = 'stopword'
    
    #read stopword
    stopword = None
    with open(swFileName,'r') as f:
        stopword = f.readlines()
    stopword = set(clearifyList(stopword))

    #read idf
    ls = None
    with open(IdfFileName,'r') as f:
        ls = f.readlines()
    extract = lambda x: (clearify(x[1]), int(x[2]))
    dfList = [extract(l.split()) for l in ls]

    N = sum([x[1] for x in dfList])
    idfDict = dict(map(lambda x: (x[0], math.log(1.0*N/x[1])), dfList))

    #add stopword
    for sw in stopword:
        idfDict[sw] = 0
    return idfDict, math.log(1.0*N/5)

#------------------------------------------------------------------------------

def getRelatedTerms( query, tokenList, retNum, thres ):
    global g_idfDict, g_defIdf
    if not g_idfDict:
        g_idfDict, g_defIdf = openIdfFile()
    
    tokens = {} 
    for t in tokenList:
        tokens[t] = tokens.get(t,0)+1

    # calc TFIDF
    tfIdf = lambda t:  tokens[t]*g_idfDict.get(t,g_defIdf)/retNum
    score = [(t,tfIdf(t)) for t in tokens]
    score = sorted(score, key=lambda(w,s):(s,w), reverse=True)
    #for r in score:
    #    print r,tokens[r[0]],g_idfDict.get(r[0],g_defIdf)
    #print '---'
    
    good  = lambda x: tokens[x[0]]>2 and x[1]>thres and x[0].lower()!=query.lower()
    score = filter(good, score)
    return [x[0] for x in score]


def genLabelMethod_03(query):
    '''
        gen labels from img search
        the basic idea is same with method02
    '''
    # parameter
    retNum = 40
    thres = 0.6

    query = retrieve.mergeQuery(query)
    labels = []
    for times in xrange(4):
        imgRes = retrieve.searchImg(query, retNum, dequeryList=labels)
        tokenList = []
        for res in imgRes:
            #print res.title
            tokenList.extend( list(set(tokenize( res[0] ))) ) #title
        rel = getRelatedTerms(query, tokenList, retNum, thres)
        print rel
        if not rel:
            break
        labels += rel
    return labels


def genLabelMethod_02(query):
    '''
        gen labels from txt search
        extract and find the words that have largest TF-IDF
        then ban these words and search again
    '''
    # parameter
    retNum = 40
    thres = 0.7

    query = retrieve.mergeQuery(query)
    labels = []
    for times in xrange(4):
        txtRes = retrieve.searchTxt(query, retNum, dequeryList=labels)
        tokenList = []
        for res in txtRes:
            #res[0] = title, res[1] = snip
            tokenList.extend( list(set(tokenize( res[0] )+tokenize(res[1]))) )
        rel = getRelatedTerms(query, tokenList, retNum, thres)
        print rel
        if not rel:
            break
        labels += rel
    return labels

#------------------------------------------------------------------------------

def genLabelMethod_01(query, maxNum = 10):
    ''' 
        gen labels from autoComplete
    '''
    ret = map(lambda x: x[0], retrieve.autoComplete(query+' '))
    if not query in ret:
        ret = [query] + ret
    if maxNum < len(ret):
        ret = ret[:maxNum]
    print 'Complete' + str(ret)
    return ret
    


#------------------------------------------------------------------------------

def genLabel(query, maxNum):
    return genLabelMethod_01(query, maxNum)


def main():
    genLabelMethod_01('kiss')
    #genLabelMethod_02('apple')
    #genLabelMethod_03('ninja')
    

if __name__ == '__main__':
    main()
