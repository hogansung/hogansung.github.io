    # -*- encoding: utf-8 -*-
import re
import genLabel
import retrieve
import docSim
import  sys
sys.path.append("/nfs/undergrad/00/b00902053/ir/final/retrieve_web/pp-1.6.4")
import pp
import collections

'''
    Main function that connect every module
'''

def imageResultCluster(query):
    print(query)
    # parameter
    numLabels = 10
    numImgsPerClus = 10
    
    '''
    Step 1: 
        generate labels by searchTxt or autoComplete 
        labels : list(str)
    '''
    labels = genLabel.genLabel(query, numLabels)
    #print(labels)
    print("step 1 done")
    
    '''
    Step 2: 
        retrieve imgInfos for each label by searchImg
        imgClus : list(list(ImgResult))
    '''
    #imgClus = [retrieve.searchImg(l,numImgsPerClus) for l in labels]
    ppservers = ()
    job_server = pp.Server(numLabels)
    jobs = [(l, job_server.submit(retrieve.searchImg,(l,numImgsPerClus), (retrieve.mergeQuery,retrieve.getParseTree,retrieve.getHTML,retrieve.extractImgResult,retrieve.clearify,), ("re","retrieve","BeautifulSoup","urllib2","chardet","ast","collections","lxml","gzip"))) for l in labels]
    imgClus = []
    ImgResult = collections.namedtuple('ImgResult','title snip url imgUrl')
    for l, job in jobs:
        tmp = []
        for i in job():
            tmp.append(ImgResult(title=i[0], snip=i[1], url=i[2], imgUrl=i[3]))
        imgClus.append(tmp)
    #print imgClus

    print("step 2 done")
    '''
    Stpe 3: 
        tokenize websites of imgInfos
        webTokens : list(list(list(unicode)))
    '''
    #webTokens = [[retrieve.urlToTokenList(x.url) for x in k ] for k in imgClus] 
    webTokens = []
    #jobs = [[job_server.submit(retrieve.urlToTokenList,(x.url,), (retrieve.urlToText,retrieve.ReplaceChinesePunctuation,retrieve.TextToTokens,retrieve.RemoveStopword,), ("retrieve","nltk","itertools","unicodedata","nltk.corpus","string")) for x in k]for k in imgClus]
    jobs = [job_server.submit(retrieve.urlToTokenList,((imgClus[x / numLabels][x % numImgsPerClus]).url,), (retrieve.urlToText,retrieve.getHTML,retrieve.ReplaceChinesePunctuation,retrieve.TextToTokens,retrieve.RemoveStopword,retrieve.RemovePunctuation, ), ("retrieve","nltk","unicodedata","nltk.corpus","string",)) for x in range(0,len(labels)*numImgsPerClus)]
    counter = 0
    tmp = []
    for job in jobs:    
        tmp.append(job())
        counter += 1
        if(counter == numImgsPerClus):
            webTokens.append(tmp)
            counter = 0
            tmp = []
    print("step 3 done")
    '''
    Step 4: by Sung
    '''
    webSim = docSim.createSim(webTokens)
    #print webSim
    print("step 4 done")
    '''
    Step 5: by Sung
    '''
    labelSim = docSim.createLabelSim(webSim)

    print("step 5 done")
    job_server.destroy()
    return locals()


def main():
    query = 'apple'
    imageResultCluster(query)

if __name__ == '__main__':
    main()

