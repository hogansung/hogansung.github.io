    # -*- encoding: utf-8 -*-
from django.shortcuts import render, render_to_response, HttpResponse
import sys

sys.path.append("/nfs/undergrad/00/b00902053/ir/final/retrieve_web")
import re_system

def search_f(request):
    return render(request, "new_result.html")


def search(request):
    imgarray = "qwr"
    isindex = False
    if "r" in request.GET or "q"  in request.GET:
        if "r" in request.GET:
            query = 'Seraching: %s' % request.GET["r"].encode("U8")
            fromindex = True
        elif "q" in request.GET:
            query = 'Seraching: %s' % request.GET["q"].encode("U8")
            fromindex = False
            
        res = re_system.imageResultCluster(query[11:])
        
        labels = map(lambda a: a.encode("U8"), res["labels"])
        
        imgarray = []
        numImgsPerClus = res["numImgsPerClus"]
        numLabels = res["numLabels"]
        for i in res["imgClus"]:
            tmp = []
            for j in i:
                tmp.append([j.title,j.imgUrl.encode("U8"),j.url.encode("U8")])
            imgarray.append(tmp)

        labelSim = res["labelSim"]
        linkarray = []        
        for tmpi in range(numLabels):
            for tmpj in range(tmpi):
                linkarray.append("{ from: "+str(tmpi)+", to: "+str(tmpj)+", color: go.Brush.randomColor("+str(125-(labelSim[tmpi][tmpj]*1.5))+","+str(125-(labelSim[tmpi][tmpj]*1.5))+"), strokeWidth: "+str(labelSim[tmpi][tmpj]/3)+"}")
            tmpi += 1
        linkarray = ",\n".join(linkarray)
        #print(linkarray)
            
    else:
        query = "Input your query here"
        fromindex = False
        isindex = True
    return render(request, 'result.html', locals())
