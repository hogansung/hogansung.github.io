#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<map>
#include<vector>

/* Files tag */
File *inv, *voc, *fileA, *fileB;

/* Used to open files */
bool FileOpen(){
   inv = fopen("InvertedFile", "r");
   if (inv == NULL)  return false;
   
   voc = fopen("Vocabulary", "r");
   if (voc == NULL)  return false;

   return true;
}

/* Used to close files */
bool FileClose(){
   if (!fclose(inv)) return false;
   if (!fclose(voc)) return false;
   
   return true;
}

int main(){
   if (!FileOpen()){
      fprintf(stderr, "Open error\n");
      exit(-1);
   }

   std::string fileName = std::string("File");
   
   for (int i=0; i<100; i++){
      for (int j=i+1; j<100; j++){
         std::string fileNameA = fileName + std::string(i/10) + std::string(i%10);
         std::string fileNameB = fileName + std::string(j/10) + std::string(j%10);
         fileA = fopen(fileNameA.c_str());
         fileB = fopen(fileNameB.c_str());
      }
   }

   if (!FileClose()){
      fprintf(stderr, "Close error\n");
      exit(-1);
   }
}
