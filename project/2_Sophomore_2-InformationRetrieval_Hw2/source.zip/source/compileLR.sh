#!/bin/bash

lexRank=lexrankCompute

g++-4.7  -O2   ${lexRank}.cpp   -o   ${lexRank}
