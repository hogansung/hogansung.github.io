#!/bin/bash

lexRank=lexrankCompute

./${lexRank}   $@

