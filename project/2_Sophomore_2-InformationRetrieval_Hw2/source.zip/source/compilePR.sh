#!/bin/bash

pageRank=pagerankCompute

g++-4.7  -O2   ${pageRank}.cpp   -o   ${pageRank}
