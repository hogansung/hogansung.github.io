#!/bin/bash

pageRank=pagerankCompute

./${pageRank}   $@

