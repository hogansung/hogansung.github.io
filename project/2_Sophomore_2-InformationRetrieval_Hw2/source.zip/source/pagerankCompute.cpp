#include<cstdio>
#include<vector>

#define eps 1e-12

std::vector<double>  old_con, new_con;
std::vector<std::vector<int> >   edge;

int main(int argc, char *argv[]){
   if (argc != 2){
      fprintf(stderr, "Insufficient parameters.\n");
      return -1;
   }

   FILE *pfile = freopen(argv[1], "r", stdin);
   if (pfile == NULL){
      fprintf(stderr, "No such file.\n");
      return -1;
   }

   char in[10];
   int node_num, n, c, d;

   scanf("%s%d", in, &node_num);
   edge.resize(node_num);

   while(scanf("%d:%d", &n, &c) != EOF){
      for (int i=0; i<c; i++){
         scanf("%d", &d);
         edge[n - 1].push_back(d - 1);
      }
   }

   old_con.resize(node_num), new_con.resize(node_num);
   for (int i=0; i<node_num; i++){
      old_con[i] = 1;
      new_con[i] = 0.15;
   }
   
   while (true){
      double sum = 0;
      for (int i=0; i<node_num; i++)   if (edge[i].size() == 0)   sum += old_con[i];
      sum = 0.85 * sum / node_num;

      for (int i=0; i<node_num; i++){
         for (std::vector<int>::iterator it=edge[i].begin(); it!=edge[i].end(); it++){
            new_con[*it] += 0.85 * old_con[i] / edge[i].size();
         }
         new_con[i] += sum;
      }

      double total = 0;
      for (int i=0; i<node_num; i++)   total += (old_con[i] - new_con[i]) * (old_con[i] - new_con[i]);

      if (total < eps) break;

      for (int i=0; i<node_num; i++){
         old_con[i] = new_con[i];
         new_con[i] = 0.15;
      }
   }

   for (int i=0; i<node_num; i++)   printf("%d:%lf\n", i + 1, old_con[i]);
}
