#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
#include<map>
#include<vector>
#include<algorithm>

#define idfValue log(40252.0)
#define eps 1e-12
#define threshold 0.1

std::map<std::string, double> idfData;
std::vector<std::map<std::string, double> > Data;
std::vector<double> divider;

std::vector<double>  old_con, new_con;
std::vector<std::vector<int> >   edge;

struct myStruct{
   bool operator < (const myStruct &c) const {return y > c.y;}
   int x;
   double y;
};

int main(int argc, char *argv[]){
   if (argc != 2){
      fprintf(stderr, "Insufficient parameters.\n");
      return -1;
   }

   FILE *pfile = freopen("idf", "r", stdin);
   if (pfile == NULL){
      fprintf(stderr, "No such file.\n");
      return -1;
   }

   char word[100], sentence[1025], *flag;
   double value;
   while(scanf("%s%lf", word, &value) != EOF)   idfData[std::string(word)] = value; 

   pfile = freopen(argv[1], "r", stdin);
   if (pfile == NULL){
      fprintf(stderr, "No such file.\n");
      return -1;
   }
   
   int offset;
   while(fgets(sentence, 1024, stdin) != NULL){
      std::map<std::string, double> OneLine = std::map<std::string, double>();
      flag = sentence;

      while(sscanf(flag, "%s%n", word, &offset) != EOF){
         std::string OneWord = std::string(word);
         flag += offset;

         if (OneLine.count(OneWord) == 0) OneLine[OneWord] = 1;
         else  OneLine[OneWord] += 1;
      }

      double tmp = 0;
      for (std::map<std::string, double>::iterator it=OneLine.begin(); it!=OneLine.end(); it++){
         if (idfData.count(it->first) != 0)  it->second *= idfData[it->first];
         else  it->second *= idfValue;
         tmp += it->second * it->second;
      }
      divider.push_back(sqrt(tmp));
      Data.push_back(OneLine);
   }
   
   int node_num = Data.size();
   edge.resize(node_num);
   
   for (unsigned int i=0; i<node_num; i++){
      for (unsigned int j=i+1; j<node_num; j++){
         
         double weight = 0;
         for (std::map<std::string, double>::iterator it=Data[i].begin(); it!=Data[i].end(); it++){
            if (Data[j].count(it->first) != 0){
               weight += it->second * Data[j][it->first];
            }
         }
         if (weight / divider[i] / divider[j] > threshold){
            edge[i].push_back(j);
            edge[j].push_back(i);
         }
      }
   }
   
   old_con.resize(node_num), new_con.resize(node_num);
   for (int i=0; i<node_num; i++){
      old_con[i] = 1;
      new_con[i] = 0.15;
   }
   
   while (true){
      double sum = 0;
      for (int i=0; i<node_num; i++)   if (edge[i].size() == 0)   sum += old_con[i];
      sum = 0.85 * sum / node_num;

      for (int i=0; i<node_num; i++){
         for (std::vector<int>::iterator it=edge[i].begin(); it!=edge[i].end(); it++){
            new_con[*it] += 0.85 * old_con[i] / edge[i].size();
         }
         new_con[i] += sum;
      }

      double total = 0;
      for (int i=0; i<node_num; i++)   total += (old_con[i] - new_con[i]) * (old_con[i] - new_con[i]);

      if (total < eps) break;

      for (int i=0; i<node_num; i++){
         old_con[i] = new_con[i];
         new_con[i] = 0.15;
      }
   }

   myStruct con[node_num];
   for (int i=0; i<node_num; i++){
      con[i].x = i + 1;
      con[i].y = old_con[i];
   }

   std::sort(con, con + node_num);
   for (int i=0; i<node_num; i++)   printf("%d:%lf\n", con[i].x, con[i].y);
} 
