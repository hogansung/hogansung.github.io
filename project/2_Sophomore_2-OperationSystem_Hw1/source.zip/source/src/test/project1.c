#include "syscall.h"

int main(){
   int a, b, c;
   a = OSAdd(10, 15);
   b = OSSub(a, 15);
   c = OSDiv(140, b);
   OSMul(112, c);

   Print("Hello, we are student B00902008 & student B00902064\n", 52);
   Halt();
}
