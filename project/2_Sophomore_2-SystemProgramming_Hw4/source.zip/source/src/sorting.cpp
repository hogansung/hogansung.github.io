#include<cstdio>
#include<algorithm>
#include<unistd.h>
#include<errno.h>
#include<sys/epoll.h>
#include<ctime>
#include<cstdlib>

int n, con[1514514];

void quit(){perror("");}

int Min(int a, int b){return a<b ?a:b;}

void my_read(int fd, char *pos,  int num){
   int size = 0, subsize;
   
   while(size < num){
      while ((subsize = read(fd, pos + size, Min(num - size, 4096))) < 0){
         if (errno == EINTR)  continue;
         else quit();
      }
      size += subsize;
   }
}

void my_write(int fd, char *pos,int num){
   int size = 0, subsize;
   
   while(size < num){
      while ((subsize = write(fd, pos + size, Min(num - size, 4096))) < 0){
         if (errno == EINTR)  continue;
         else quit();
      }
      size += subsize;
   }
}

int main(){
   srand(time(NULL) + getpid());

   while(rand()){
      if (read(STDIN_FILENO, &n, sizeof(int)) < 0) perror("read error");

      my_read(STDIN_FILENO, (char*)con, n * sizeof(int));
      std::sort(con, con + n);
      my_write(STDOUT_FILENO, (char*)con, n * sizeof(int));
   }
}
