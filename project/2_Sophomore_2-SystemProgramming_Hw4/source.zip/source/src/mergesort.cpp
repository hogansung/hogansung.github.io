#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<queue>
#include<ctime>
#include<fcntl.h>
#include<unistd.h>
#include<errno.h>
#include<signal.h>
#include<sys/epoll.h>
#include<sys/stat.h>
#include<sys/time.h>
#include<sys/wait.h>

typedef std::string  ST;

const int limit = 1514514;
const int num_pros = 514;
const int num_blocks = 2048;

int NUM_P, NUM_J, NUM_O, NUM_I, patch, left, my_data, my_epoll, num_clocks, t_flag, ac, target;
int con[limit], nowpos[num_blocks], boundary[num_blocks], cpid[num_pros], occupied[num_pros], vis[num_blocks];
bool doing_w[num_pros], doing_r[num_pros];
long long run_time[num_pros];
ST PATH;

bool first;

struct my_pipe{
   int fd[2];
}pipefd[num_pros][2];

struct my_item{
   bool operator < (const my_item &d) const {return c > d.c;}
   my_item(){}
   my_item(int a, int b){c=a, t=b;}
   int c, t;
}things;

struct epoll_event ready_list[40], ev;
struct timeval curr_clock;

void quit(){perror("");}

void recreate(int child){   
   close(pipefd[child][0].fd[0]);
   close(pipefd[child][1].fd[1]);

   kill(cpid[child], SIGKILL);

   int status;
   waitpid(-1, &status, 0);
   if (pipe(pipefd[child][0].fd) || pipe(pipefd[child][1].fd)) quit();

   int arg1, arg2;
   arg1 = fcntl(pipefd[child][0].fd[0], F_GETFL);
   arg2 = fcntl(pipefd[child][1].fd[1], F_GETFL);
   if (fcntl(pipefd[child][0].fd[0], F_SETFL, arg1 | O_NONBLOCK) < 0)  quit();
   if (fcntl(pipefd[child][1].fd[1], F_SETFL, arg2 | O_NONBLOCK) < 0)  quit();

   cpid[child] = fork();
   if (cpid[child] < 0) quit();
   else if (cpid[child] == 0){
      close(pipefd[child][0].fd[0]);
      close(pipefd[child][1].fd[1]);
      if (dup2(pipefd[child][1].fd[0], STDIN_FILENO) < 0) quit();
      if (dup2(pipefd[child][0].fd[1], STDOUT_FILENO) < 0)   quit();

      char **abc = NULL;
      execv(PATH.c_str(), abc);
   }
   else {
      close(pipefd[child][0].fd[1]);
      close(pipefd[child][1].fd[0]);
   }

   nowpos[occupied[child]] = boundary[occupied[child]];
   run_time[child] = -1;

   ev.events = EPOLLOUT;
   ev.data.fd = pipefd[child][1].fd[1]; 
   epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[child][1].fd[1], &ev);
}

void read_broke(int proc){
   doing_r[proc] = false;
   recreate(proc);

   ev.events = EPOLLIN; 
   ev.data.fd = pipefd[proc][0].fd[0]; 
   epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[proc][0].fd[0], &ev);
}

void write_broke(int proc){
   doing_w[proc] = false;
   recreate(proc);

   ev.events = EPOLLOUT;
   ev.data.fd = pipefd[proc][1].fd[1]; 
   epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[proc][1].fd[1], &ev);
}

void my_broke(int SIGNAL){
   fprintf(stderr, "SIGPIPE\n");
   
   int child = -1;
   for (int i=0; i<NUM_P; i++)   if (doing_w[i] == true)   child = i;
   
   if (child != -1)  write_broke(child);
   else {
      for (int i=0; i<NUM_P; i++)   if (doing_r[i] == true)   child = i;
      read_broke(child); 
   }
}

void my_alarm(int SIGNAL){fprintf(stderr, "SIGALRM\n");}
int Min(int a, int b){return a<b ?a:b;}

int my_read(int fd, char *pos, int num){
   int size = 0, subsize;
   
   while(size < num){
      while ((subsize = read(fd, pos + size, Min(num - size, 4096))) < 0){
         if (errno == EINTR)  continue;
         else  return -1;
      }
      size += subsize;
   }
   return 0;
}

int my_write(int fd, char *pos, int num){
   int size = 0, subsize;
   
   while(size < num){
      while ((subsize = write(fd, pos + size, Min(num - size, 4096))) < 0){
         if (errno == EINTR)  continue;
         else  return -1;
      }
      size += subsize;
   }
   return 0;
}

int my_spe_read(int fd, char *pos, int num, int proc){
   int size;
   while ((size = read(fd, pos, num)) < 0){
      if (errno == EINTR)  continue;
      else  return -1;
   }
   if (gettimeofday(&curr_clock, NULL) != 0)   quit();
   run_time[proc] = (long long)curr_clock.tv_sec * 1000 + curr_clock.tv_usec / 1000;
   return 0;
}

int my_spe_write(int fd, char *pos, int num, int proc){
   int size;
   while ((size = write(fd, pos, num)) < 0){
      if (errno == EINTR)  continue;
      else  return -1;
   }
   if (gettimeofday(&curr_clock, NULL) != 0)   quit();
   run_time[proc] = (long long)curr_clock.tv_sec * 1000 + curr_clock.tv_usec / 1000;
   return 0;
}

void create_child(){
   for (int i=0; i<NUM_P; i++){
      if (pipe(pipefd[i][0].fd) || pipe(pipefd[i][1].fd))   quit();

      int arg1, arg2;
      arg1 = fcntl(pipefd[i][0].fd[0], F_GETFL);
      arg2 = fcntl(pipefd[i][1].fd[1], F_GETFL);
      if (fcntl(pipefd[i][0].fd[0], F_SETFL, arg1 | O_NONBLOCK) < 0)  quit();
      if (fcntl(pipefd[i][1].fd[1], F_SETFL, arg2 | O_NONBLOCK) < 0)  quit();

      cpid[i] = fork();
      if (cpid[i] < 0)  quit();
      else if (cpid[i] == 0){
         close(pipefd[i][0].fd[0]);
         close(pipefd[i][1].fd[1]);
         if (dup2(pipefd[i][1].fd[0], STDIN_FILENO) < 0) quit();
         if (dup2(pipefd[i][0].fd[1], STDOUT_FILENO) < 0)   quit();

         char **abc = NULL;
         if (execv(PATH.c_str(), abc) < 0)   quit();
      }
      else {
         close(pipefd[i][0].fd[1]);
         close(pipefd[i][1].fd[0]);
      }
      run_time[i] = -1;

      ev.events = EPOLLOUT;
      ev.data.fd = pipefd[i][1].fd[1];
      epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[i][1].fd[1], &ev);
   }
}

void init(int argc, char **argv){
   if (argc != 9){
      fprintf(stderr, "ARGUMENT_NUM ERROR\n");
      exit(0);
   }

   for (int i=1; i<9; i+=2){
      if (argv[i][1] == 'p')  NUM_P = strtol(argv[i+1], 0, 10); 
      else if (argv[i][1] == 'n')   NUM_J = strtol(argv[i+1], 0, 10);
      else if (argv[i][1] == 'e')   PATH = ST(argv[i+1]);
      else if (argv[i][1] == 'k')   NUM_O = strtol(argv[i+1], 0, 10);
      else  fprintf(stderr, "ARGUMENT ERROR\n");
   }

   my_epoll = epoll_create(20);
   if (my_epoll < 0) quit();

   my_read(STDIN_FILENO, (char*)&NUM_I, sizeof(int));

   if ((my_data = open("data", O_RDWR | O_CREAT | O_TRUNC, 0644)) < 0)   quit();
   patch = NUM_I / NUM_J;  left = NUM_I % NUM_J;

   int sum = 0;
   for (int i=0; i<NUM_J; i++){
      int size = (i < left ?patch + 1 :patch);
      nowpos[i] = boundary[i] = sum;
      sum += (size + 1) * 4;

      my_read(STDIN_FILENO, (char*)con, size * sizeof(int));
      my_write(my_data, (char*)&size, sizeof(int));
      my_write(my_data, (char*)con, size * sizeof(int));

      vis[i] = -2;
   }
   boundary[NUM_J] = sum;
   create_child();

   signal(SIGPIPE, my_broke);
   signal(SIGALRM, my_alarm);
}

int my_find(){
   for (int i=0; i<NUM_J; i++)   nowpos[i] = boundary[i] + 4;
   
   int value;
   std::priority_queue<my_item> my_heap;

   for (int i=0; i<NUM_J; i++){
      if (nowpos[i] >= boundary[i + 1])  continue;
      
      if (lseek(my_data, nowpos[i], SEEK_SET) < 0) quit();
      nowpos[i] += sizeof(int);

      my_read(my_data, (char*)&value, sizeof(int));
      my_heap.push(my_item(value, i));
   }

   int flag = 1;
   while(flag < NUM_O && my_heap.size()){
      things = my_heap.top(); my_heap.pop(); flag++;
      if (nowpos[things.t] + 1 >= boundary[things.t + 1])  continue;

      if (lseek(my_data, nowpos[things.t], SEEK_SET) < 0)   quit();
      nowpos[things.t] += sizeof(int);

      my_read(my_data, (char*)&value, sizeof(int));
      my_heap.push(my_item(value, things.t));
   }

   if (my_heap.size() == 0){
      fprintf(stderr, "Your target is too far!!!\n");
      exit(0);
   }
   things = my_heap.top();
   return things.c;
}

int main(int argc, char **argv){
   init(argc, argv);

   while(ac < NUM_J){
      int n_ready = epoll_wait(my_epoll, ready_list, 20, 100);

      for (int i=0; i<n_ready; i++){
         if (ready_list[i].events & EPOLLIN){
            int child = -1;
            for (int j=0; j<NUM_P; j++)   if (ready_list[i].data.fd == pipefd[j][0].fd[0])   child = j;
            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[child][0].fd[0], &ev);
            
            int s_flag = occupied[child];
            doing_r[child] = true;

            int size = Min(boundary[s_flag + 1] - nowpos[s_flag] - 4, 4096);
            if (my_spe_read(ready_list[i].data.fd, (char*)con, size, child) < 0) continue;

            doing_r[child] = false;

            if (lseek(my_data, nowpos[s_flag] + 4, SEEK_SET) < 0)   quit();
            my_write(my_data, (char*)con, size);

            nowpos[s_flag] += size;
            if (nowpos[s_flag] + 4 == boundary[s_flag + 1]){
               ev.events = EPOLLOUT;
               ev.data.fd = pipefd[child][1].fd[1]; 
               epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[child][1].fd[1], &ev);
               ac++;
               vis[s_flag] = -1;
               run_time[child] = -1;
            }
            else {
               ev.events = EPOLLIN;
               ev.data.fd = pipefd[child][0].fd[0]; 
               epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[child][0].fd[0], &ev);
            }
         }
         else if (ready_list[i].events & EPOLLOUT){
            int child = -1;
            for (int j=0; j<NUM_P; j++)   if (ready_list[i].data.fd == pipefd[j][1].fd[1])   child = j;
            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[child][1].fd[1], &ev);
            
            t_flag = -1;
            for (int j=0; j<NUM_J; j++){
               if (vis[j] == -2 || vis[j] == child){
                  vis[j] = child;
                  occupied[child] = t_flag = j;
                  break;
               }
            }
            if (t_flag == -1) continue;

            int size = Min(boundary[t_flag + 1] - nowpos[t_flag], 4096);

            if (lseek(my_data, nowpos[t_flag], SEEK_SET) < 0)  quit();
            my_read(my_data, (char*)con, size);

            doing_w[child] = true;
            if (my_spe_write(ready_list[i].data.fd, (char*)con, size, child) < 0)   continue;
            doing_w[child] = false;

            nowpos[t_flag] += size;
            if (nowpos[t_flag] == boundary[t_flag + 1]){
               nowpos[t_flag] = boundary[t_flag];
               ev.events = EPOLLIN;
               ev.data.fd = pipefd[child][0].fd[0]; 
               epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[child][0].fd[0], &ev);
            }
            else {
               ev.events = EPOLLOUT;
               ev.data.fd = pipefd[child][1].fd[1]; 
               epoll_ctl(my_epoll, EPOLL_CTL_ADD, pipefd[child][1].fd[1], &ev);
            }
         }
         else{
            int child = -1;
            for (int j=0; j<NUM_P; j++)   if (ready_list[i].data.fd == pipefd[j][1].fd[1])   child = j;
            for (int j=0; j<NUM_P; j++)   if (ready_list[i].data.fd == pipefd[j][0].fd[0])   child = j;

            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[child][0].fd[0], &ev);
            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[child][1].fd[1], &ev);
            recreate(child);
         }
      }
      if (gettimeofday(&curr_clock, NULL) != 0)   quit();
      for (int j=0; j<NUM_P; j++){
         if (run_time[j] != -1 && (long long)curr_clock.tv_sec * 1000 + curr_clock.tv_usec / 1000 - run_time[j] > 15000){
            fprintf(stderr, "SIGALRM\n"); 

            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[j][0].fd[0], &ev);
            epoll_ctl(my_epoll, EPOLL_CTL_DEL, pipefd[j][1].fd[1], &ev);
            recreate(j);
         }
      }
   }
   int ans = my_find();
   printf("%d\n", ans);
   for (int i=0; i<NUM_P; i++){
      if (kill(cpid[i], SIGKILL) < 0){
         if (errno == ESRCH)  continue;
         else  perror("");
      }
   }
}
