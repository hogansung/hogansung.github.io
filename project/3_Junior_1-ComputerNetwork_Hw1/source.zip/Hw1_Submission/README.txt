**  Following are the short intro about how to compile and run my code:


**  Server Part
    1.  Key in "make server" to compile "rsh-server".
    2.  Key in "make executor" to compile "executor".

    * The port is default set to be "8800", you can change it in "parameters.h", and then "make" again.

    3.  Run rsh-server and wait for connection from clients. (Support multi-clients.)

    * Needed component:
        a.  rsh-server.cpp
        b.  executor.cpp
        c.  rsh-internet.h
        d.  parameters.h
        e.  MSTL.h


**  Client Part
    1.  Key in "make client" to compile "rsh-client".
    
    * The port is default set to be "8800", you can change it in "parameters.h", and then "make" again.
    
    2.  Run rsh-client with target-server hostname or target-server IP address and port number.

    * Needed component:
        a.  rsh-client.cpp
        b.  rsh-internet.h
        c.  parameters.h
        d.  MSTL.h
