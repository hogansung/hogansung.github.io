#include "rsh-internet.h"

int main(int argc, char *argv[]) {
    char serverName[BUF_SIZE] = SERVER_IP, buffer[BUF_SIZE];
    int sock, port = FIX_PORT;


    /* Parsing the arguments */
    ParseArg(argc, argv, serverName, port);


    /* Get socket and connect to the server */
    GetSocket(sock); 
    Connect(sock, serverName, port);


    memset(buffer, 0, sizeof(char) * BUF_SIZE);
    recv(sock, buffer, sizeof(char) * BUF_SIZE, 0);
    printf("%s", buffer);


    struct epoll_event ev, events[2];

    int epollFd = epoll_create(2);
    if (epollFd == -1) {
        fprintf(stderr, "Create epoll failed.\n");
        exit(EXIT_FAILURE);
    }
    
    ev.events = EPOLLIN;
    ev.data.fd = fileno(stdin);
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, fileno(stdin), &ev) == -1) {
        fprintf(stderr, "Add stdin fd failed.\n");
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN | EPOLLRDHUP;
    ev.data.fd = sock;
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, sock, &ev) == -1) {
        fprintf(stderr, "Add send sock failed.\n");
        exit(EXIT_FAILURE);
    }

    bool keepConnect = true;
    while (keepConnect) {
        int num = epoll_wait(epollFd, events, 2, -1);
        if (num == -1) {
            fprintf(stderr, "Epoll_wait failed.\n");
            exit(EXIT_FAILURE);
        }

        for (int i = 0; i < num; i++) {
            if (events[i].events & EPOLLRDHUP) {
                fprintf(stderr, "Server shutdown suddently.\n");
                keepConnect = false;
                break;
            }
            else if (events[i].data.fd == fileno(stdin)) {
                fgets(buffer, BUF_SIZE, stdin);
                if (strcmp(buffer, "exit\n") == 0) {
                    fprintf(stderr, "Client quit normally.\n");
                    shutdown(sock, SHUT_RDWR);
                    keepConnect = false;
                    break;
                }
                send(sock, buffer, sizeof(char) * strlen(buffer), 0);
            }
            else {
                int cnt = read(sock, buffer, sizeof(char) * BUF_SIZE);
                for (int i = 0; i < cnt; i++) {
                    printf("%c", buffer[i]);
                }
            }
        }
    }
}

void ParseArg(int argc, char *argv[], char serverName[], int &port) {
    if (argc > 3) {
        fprintf(stderr, "\nUsage: rsh-client [server hostname] [port number]\n\n");
        exit(EXIT_FAILURE);
    }
    if (argc >= 2) strcpy(serverName, argv[1]);
    if (argc >= 3) port = strtol(argv[2], 0, 10);
}

void GetSocket(int &sock) {
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        fprintf(stderr, "Create socket failed.\n");
        exit(EXIT_FAILURE);
    }
}

void Connect(int sock, char serverName[], int port) {
    struct sockaddr_in addr;
    struct hostent *hptr = gethostbyname(serverName);

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(serverName);

    if (addr.sin_addr.s_addr == -1) {
        fprintf(stderr, "It is not an IP, try DNS.\n");
        hptr = gethostbyname(serverName);
        if (hptr == NULL) {
            fprintf(stderr, "Transfer domain name failed.\n");
            exit(EXIT_FAILURE);
        }
        
        addr.sin_family = hptr->h_addrtype;
        memcpy(&(addr.sin_addr.s_addr), hptr->h_addr, hptr->h_length);
    }

    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        fprintf(stderr, "Create connection failed.\n");
        exit(EXIT_FAILURE);
    }
}
