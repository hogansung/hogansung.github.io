#include "rsh-internet.h"

struct Node {
    Node() {};
    Node(int conn) {
        fd = conn;
        flag = 0;
        path = DEFAULT_PATH;
        send(fd, WELCOME.c_str(), WELCOME.length(), 0);
    }
    void addPipe(int t, int pipefd) {
        pipeSet[t].push_back(pipefd);
    }
    void addExec(int t, int execfd) {
        execSet[t].push_back(execfd);
    }
    void MoveForward() {
        for (int i = 1; i < MAX_DELAY; i++) {
            pipeSet[i - 1] = pipeSet[i];
        }
        for (int i = 1; i < MAX_DELAY; i++) {
            execSet[i - 1] = execSet[i];
        }
    }

    int fd, flag;
    string path;
    vector<int> pipeSet[MAX_DELAY];
    vector<int> execSet[MAX_DELAY];
};
Node *node[10];

int main() {
    char buffer[BUF_SIZE];
    int sock, port = FIX_PORT;
    struct sockaddr_in client;
    struct epoll_event ev, events[MAX_SOCK];

    
    /* Get socket and bind to the port */
    GetSocket(sock);
    Bind(sock, port);


    /* Listen to socket */
    Listen(sock);


    int epollFd = epoll_create(MAX_EVENT);
    if (epollFd == -1) {
        fprintf(stderr, "Create epoll failed.\n");
        exit(EXIT_FAILURE);
    }
    
    ev.events = EPOLLIN;
    ev.data.fd = sock;
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, sock, &ev) == -1) {
        fprintf(stderr, "Add listen sock failed.\n");
        exit(EXIT_FAILURE);
    }


    bool keepConnect = true;
    while (keepConnect) {
        int num = epoll_wait(epollFd, events, MAX_EVENT, -1);
        if (num == -1) {
            fprintf(stderr, "Epoll_wait failed.\n");
            exit(EXIT_FAILURE);
        }

        for (int i = 0; i < num; i++) {
            if (events[i].events & EPOLLRDHUP) {
                fprintf(stderr, "Conn #%d is leaving.\n", events[i].data.fd);
                for (int j = 0; j < MAX_CLIENT; j++) {
                    if (node[j] && node[j]->fd == events[i].data.fd) {
                        delete node[j];
                        break;
                    }
                }
            }
            else if (events[i].data.fd == sock) {
                socklen_t len = sizeof(client);
                int conn = accept(sock, (struct sockaddr*)&client, &len);
                if (conn == -1) {
                    fprintf(stderr, "Accept conn failed.\n");
                    exit(EXIT_FAILURE);
                }

                fprintf(stderr, "Conn #%d is coming.\n", conn);
                for (int j = 0; j < MAX_CLIENT; j++) {
                    if (node[j] == NULL) {
                        node[j] = new Node(conn);
                        break;
                    }
                }
                
                ev.events = EPOLLIN | EPOLLET | EPOLLRDHUP;
                ev.data.fd = conn;

                if (epoll_ctl(epollFd, EPOLL_CTL_ADD, conn, &ev) == -1) {
                    fprintf(stderr, "Add conn %d sock failed.\n", conn);
                    exit(EXIT_FAILURE);
                }
            }
            else {
                memset(buffer, 0, sizeof(char) * BUF_SIZE);
                recv(events[i].data.fd, buffer, sizeof(char) * BUF_SIZE, 0);
                Handler(events[i].data.fd, buffer);
            }
        }
    }
}

void Handler(int fd, char buffer[]) {
    Node *curNode = NULL;
    for (int i = 0; i < MAX_CLIENT; i++) {
        if (node[i] && node[i]->fd == fd) curNode = node[i];
    }
    curNode->MoveForward();


    int post;
    string output;
    vector<string> vct = vector<string>();
    ParseString(buffer, vct, post, output);


    if (vct.size() == 0) return;

    if (vct[0] == PRINT_ENV) {
        if (vct.size() == 2) {
            string message = string("PATH=") + curNode->path + "\n";
            send(fd, message.c_str(), message.length(), 0);
        }
        else {
            string message = string("Usage: printenv PATH\n");
            send(fd, message.c_str(), message.length(), 0);
        }
    }
    else if (vct[0] == SET_ENV) {
        if (vct.size() == 3) {
            curNode->path = vct[2];
        }
        else {
            string message = string("Usage: setenv PATH [path]\n");
            send(fd, message.c_str(), message.length(), 0);
        }
    }
    else if (curNode->pipeSet[curNode->flag].size()) {
        int size = curNode->pipeSet[curNode->flag].size(); 
        for (int i = 0; i < size; i++) {
            int pipefd[2];
            makePipe(fd, post, pipefd);
            Exec(fd, post, pipefd, vct, output, i);
        }
    }
    else {
        int pipefd[2];
        makePipe(fd, post, pipefd);
        Exec(fd, post, pipefd, vct, output, -1);
    }
}

void makePipe(int fd, int post, int pipefd[]) {
    if (pipe(pipefd) == -1) {
        fprintf(stderr, "Pipe failed.\n");
        exit(EXIT_FAILURE);
    }
}

void Exec(int fd, int post, int pipefd[], vector<string> &vct, string &output, int index) {
    Node *curNode = NULL;
    for (int i = 0; i < MAX_CLIENT; i++) {
        if (node[i] && node[i]->fd == fd) curNode = node[i];
    }

    pid_t fpid = fork();
    if (fpid == -1) {
        fprintf(stderr, "Fork failed.\n");
        exit(EXIT_FAILURE);
    }

    if (fpid == 0) {
        if (index >= 0) {
            dup2(curNode->pipeSet[curNode->flag][index], STDIN_FILENO);
            close(curNode->pipeSet[curNode->flag][index]);
        }
        close(pipefd[0]); 
        
        dup2(pipefd[1], STDOUT_FILENO);
        dup2(curNode->fd, STDERR_FILENO);
        close(pipefd[1]);


        char *narg[NUM_ARGC];
        narg[0] = new char[BUF_SIZE];
        strcpy(narg[0], EXEC.c_str());
        narg[1] = new char[BUF_SIZE];
        strcpy(narg[1], (string("PATH=") + curNode->path).c_str());
        for (int i = 0; i < vct.size(); i++) {
            narg[i + 2] = new char[BUF_SIZE];
            strcpy(narg[i + 2], vct[i].c_str());
        }
        narg[vct.size() + 2] = NULL;

        if (execv(EXEC.c_str(), narg) < 0) {
            fprintf(stderr, "%s\n", strerror(errno));
            exit(EXIT_FAILURE);
        }
    }
    else {
        if (index >= 0) {
            WaitChild(curNode->execSet[curNode->flag][index], curNode->fd);
            close(curNode->pipeSet[curNode->flag][index]);
        }
        close(pipefd[1]);

        if (post < 0) {
            FILE *pfile = fopen(output.c_str(), "w");
            char buffer[BUF_SIZE];
            int readin, writeout;

            while ((readin = read(pipefd[0], buffer, BUF_SIZE)) != 0) {
                writeout = 0;
                while (writeout != readin) {
                    writeout += write(fileno(pfile), buffer + writeout, readin - writeout);
                }
            }
            
            fclose(pfile);
            close(pipefd[0]);
            WaitChild(fpid, fd);
        }
        else if (post) {
            curNode->addPipe(curNode->flag + post, pipefd[0]);
            curNode->addExec(curNode->flag + post, fpid);
        }
        else {
            char buffer[BUF_SIZE];
            int readin, writeout;
            
            while ((readin = read(pipefd[0], buffer, BUF_SIZE)) != 0) {
                writeout = 0;
                while (writeout != readin) {
                    writeout += send(fd, buffer + writeout, readin - writeout, 0);
                }
            }
            
            close(pipefd[0]);
            WaitChild(fpid, fd);
        }
    }
}

void WaitChild(int fpid, int fd) {
    int status;
    if (waitpid(fpid, &status, 0) < 0) {
        fprintf(stderr, "waitpid: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
    
    if (WIFEXITED(status)) fprintf(stderr, "Conn #%d executed normally.\n", fd);
    else if (WIFSIGNALED(status)) fprintf(stderr, "Conn #%d aborted.\n", fd);
    else fprintf(stderr, "nothing is done.\n");
}

void GetSocket(int &sock) {
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        fprintf(stderr, "Create socket failed.\n");
        exit(EXIT_FAILURE);
    }
}

void Bind(int sock, int port) {
    struct sockaddr_in addr;

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
        
    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        fprintf(stderr, "Connect socket failed.\n");
        exit(EXIT_FAILURE);
    }
}

void Listen(int sock) {
    if (listen(sock, 1) < 0) {
        fprintf(stderr, "Listen failed.\n");
        exit(EXIT_FAILURE);
    }
}

bool checkNum(string str) {
    for (size_t i = 0; i < str.length(); i++) {
        if (!isdigit(str[i])) return false;
    }
    return true;
}

void ParseString(char buffer[], vector<string> &vct, int &post, string &output) {
    char input[BUF_SIZE];
    bool quote = false;
    bool exist = false;
    int len = strlen(buffer), flag = 0;

    for (int i = 0; i < len; i++) {
        if (quote) {
            exist = true;
            if ((buffer[i] == '\'' || buffer[i] == '\"') && (i == 0 || buffer[i - 1] != '\\')) quote = false;
            else input[flag++] = buffer[i];
        }
        else if (buffer[i] == ' ' || buffer[i] == '\t' || buffer[i] == '\n' || buffer[i] == '|' || buffer[i] == '>') {
            if (flag || exist) {
                flag = input[flag] = 0; 
                vct.push_back(string(input));
                exist = false;
            }
            if (buffer[i] == '|') vct.push_back(PIPE_INSTEAD);
            else if (buffer[i] == '>') vct.push_back(DOUT_INSTEAD);
        }
        else if ((buffer[i] == '\'' || buffer[i] == '\"') && (i == 0 || buffer[i - 1] != '\\')) quote = true;
        else input[flag++] = buffer[i];
    }
    if (flag) {
        flag = input[flag] = 0;
        vct.push_back(string(input));
    }

    if (vct.size() > 2 && vct[vct.size() - 2] == PIPE_INSTEAD && checkNum(vct[vct.size() - 1])) {
        post = strtol(vct[vct.size() - 1].c_str(), 0, 10);
        vct.pop_back();
        vct.pop_back();
    }
    else if (vct.size() > 2 && vct[vct.size() - 2] == DOUT_INSTEAD) {
        post = -1;
        output = vct[vct.size() - 1];
        vct.pop_back();
        vct.pop_back();
    }
    else post = 0;
}
