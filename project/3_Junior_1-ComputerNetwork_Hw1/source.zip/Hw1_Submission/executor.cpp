#include "parameters.h"
#include "MSTL.h"

extern char **environ;

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "\nUsage: executor [ARGUMENTS]\n\n");
        exit(EXIT_FAILURE);
    }


    /* Parse order */
    vector<string> order = vector<string>();
    vector<string> left = vector<string>();
    bool show = false;
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], PIPE_INSTEAD.c_str()) == 0 && !show) show = true;
        else if (!show) order.push_back(string(argv[i]));
        else left.push_back(string(argv[i]));
    }


    pid_t fpid;
    /* Call executor recursively */
    if (left.size()) {
        int pipefd[2];
        if (pipe(pipefd) == -1) {
            fprintf(stderr, "Pipe failed.\n");
            exit(EXIT_FAILURE);
        }

        fpid = fork();
        if (fpid == -1) {
            fprintf(stderr, "Fork failed.\n");
            exit(EXIT_FAILURE);
        }

        if (fpid == 0) {
            dup2(pipefd[0], 0); 
            close(pipefd[0]);
            close(pipefd[1]);

            /* Exec next executor */
            char *narg[NUM_ARGC];
            narg[0] = argv[0];
            narg[1] = argv[1];
            for (int i = 0; i < left.size(); i++) {
                narg[i + 2] = new char[BUF_SIZE];
                strcpy(narg[i + 2], left[i].c_str());
            }
            narg[left.size() + 2] = NULL;

            if (execv(argv[0], narg) < 0) {
                fprintf(stderr, "Fork executor err: %s\n", strerror(errno));
                exit(EXIT_FAILURE);
            }
        }
        else {
            dup2(pipefd[1], STDOUT_FILENO);
            close(pipefd[0]);
            close(pipefd[1]);
        }
    }


    /* Exec shell command */
    if (order.size() == 0) {
        fprintf(stderr, "Illegal empty command.\n");
        exit(EXIT_FAILURE);
    }

    char *narg[NUM_ARGC];
    for (int i = 0; i < order.size(); i++) {
        narg[i] = new char[BUF_SIZE];
        strcpy(narg[i], order[i].c_str());
    }
    narg[order.size()] = NULL;

    char *nevr[2];
    nevr[0] = argv[1];
    nevr[1] = NULL; 
    environ = nevr;

    if (execvp(narg[0], narg) < 0) {
        /* This message will return to server. */
        fprintf(stderr, "Exec shell command err: %s\n", strerror(errno));
        exit(EXIT_FAILURE);
    }
}
