#include <string>
#include <assert.h>

using namespace std;

template <typename T>
struct vector {
    vector() {
        capacity = 1;
        realSize = 0;
        vct = new T[1];
    }

    const T operator[] (int t) {
        assert(t < realSize);
        return vct[t];
    } const
    
    void push_back(T in) {
        if (realSize == capacity) expand();
        vct[realSize++] = in;
    }
    
    void pop_back() {
        realSize--;
    }

    int size() {
        return realSize;
    }
    
    void expand() {
        T *nvct = new T[capacity << 1];
        for (int i = 0; i < capacity; i++) nvct[i] = vct[i];
        delete[] vct;
        vct = nvct;
        capacity <<= 1;
    }

    int capacity;
    int realSize;
    T *vct;
};
