#include "parameters.h"
#include "MSTL.h"


/* For both rsh-server and rsh-client */
void GetSocket(int &sock);


/* For rsh-server */
void Bind(int sock, int port);
void Listen(int sock);
void Handler(int fd, char buffer[]);
void makePipe(int fd, int post, int pipefd[]);
void Exec(int fd, int post, int pipefd[], vector<string> &vct, string &output, int value);
void WaitChild(int fpid, int fd);
bool checkNum(string str);
void ParseString(char buffer[], vector<string> &vct, int &post, string &output);


/* For rsh-client */
void Connect(int sock, char serverName[], int port);
void ParseArg(int argc, char *argv[], char serverName[], int &port);
