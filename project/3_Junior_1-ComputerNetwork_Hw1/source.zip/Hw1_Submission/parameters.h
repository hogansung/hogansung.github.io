/* Parameters for rsh-server, rsh-client, and executor */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include <unistd.h>
#include <fcntl.h>
#include <netdb.h>
#include <errno.h>

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/epoll.h>

#define SERVER_IP "127.0.0.1"

using namespace std;


const int FIX_PORT = 8800;
const int BUF_SIZE = 20500;
const int NUM_ARGC = 150;
const int MAX_CLIENT = 10;
const int MAX_DELAY = 510;
const int MAX_SOCK = 150;
const int MAX_EVENT = 2 * MAX_SOCK + 1;


const string PRINT_ENV = "printenv";
const string SET_ENV = "setenv";
const string WELCOME = "Hey! Apple!\n";
const string DEFAULT_PATH = "bin:.";
const string EXEC = "executor";
const string PATH_PREFIX = "PATH=";
const string PIPE_INSTEAD = string().append(1, (char)1);
const string DOUT_INSTEAD = string().append(1, (char)2);

