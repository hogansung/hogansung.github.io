#include <Eigen/Core>
#include <Eigen/Dense>
#include <typeinfo>
#include <vector>
#include <omp.h>
#include <cmath>
#include <memory>
#include <iostream>
#include <time.h> 
#include <fstream>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <string>
#include "util.h"
using namespace Eigen;
using namespace std;

const char* train_filename = "../../dat/fbank/sub_train.ark";
const char* valid_filename = "../../dat/fbank/valid.ark";
const char* test_filename = "../../dat/fbank/test_new.ark";

const int BATCH_SIZE = 128, max_iteration = 1, overlap = 6;
double learning_rate = 0.001;
const double drop_rate = 0.5; //dropout regularization
const double input_drop_rate = 0.2;
const double max_norm = 0.35; //max norm regularization
double decay_rate = 0.95; //Nesterov momentum
const int label_size = 48;
int feature_size;

inline double ReL(double x){
    return x > 0 ? x : 0;
}

//inverted dropout
inline double drop_out(double x){
    return x;
    if( (double)rand() / RAND_MAX < drop_rate) return 0;
    else return x / (1 - drop_rate);
}

inline double input_drop_out(double x){
    return x;
    if( (double)rand() / RAND_MAX < input_drop_rate) return 0;
    else return x / (1 - drop_rate);
}

inline void pprint(const VectorXd &v){
    for (int i = 0; i < v.rows(); i += 1){
        cout << i << ":" << v(i) << " "; 
    }
    puts("");
}

enum State{
    TRAIN, PREDICT
};

class Layer
{
public:
    Layer(){}
    Layer(int, int);
    virtual void output(MatrixXd &);
	virtual void output_test(MatrixXd &);
    void backing(MatrixXd &, MatrixXd &);
    void setState(State s){
        state = s;
    }
    void setTestSize(int s);

    State state;
    MatrixXd W, a, delta, vW, test_a;
};

Layer::Layer(int num_node, int num_pre){
    W.resize(num_node, num_pre + 1);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::normal_distribution<> d(0, sqrt(2.0 / num_pre));
    for(int i = 0; i < num_node; i++){
        for(int j = 0; j < num_pre + 1; j++){
            W(i, j) = d(gen);
        }
    }
    vW = MatrixXd::Zero(num_node, num_pre + 1);
    a = MatrixXd::Ones(num_node + 1, BATCH_SIZE);
    delta.resize(num_node, BATCH_SIZE);
}

inline void Layer::output(MatrixXd &x){
    if(state == TRAIN){
        a.topRows(a.rows()-1) = (W * x).unaryExpr(ptr_fun(ReL)).unaryExpr(ptr_fun(drop_out));
    }else{
        a.topRows(a.rows()-1) = (W * x).unaryExpr(ptr_fun(ReL));
    }
}

inline void Layer::setTestSize(int s){
    test_a.resize(a.rows(), s);
    test_a.row(test_a.rows()-1).fill(1);
}

inline void Layer::output_test(MatrixXd &x){
    test_a.topRows(test_a.rows()-1) = (W * x).unaryExpr(ptr_fun(ReL));
}

inline void Layer::backing(MatrixXd &delta_next, MatrixXd &W_next){
    delta = (W_next.transpose() * delta_next).binaryExpr(a, 
      [](double first, double second){ 
        return second > 0 ? first : 0; 
      }
    ).topRows(delta.rows());
}

//use softmax rather than ReLU
class OutputLayer : public Layer{
public:
    OutputLayer(int num_node, int num_pre) : Layer(num_node, num_pre){
        a.resize(num_node, BATCH_SIZE);
    }
    
    virtual void output(MatrixXd& x){
        a = W * x;
        for(int i = 0; i < BATCH_SIZE; i++){
            a.col(i).array() -= a.col(i).maxCoeff();
            a.col(i) = a.col(i).array().exp().matrix();
            a.col(i) /= a.col(i).sum();
        }
    }
 
    virtual void output_test(MatrixXd &x){
        test_a = W * x;
        for(int i = 0; i < test_a.cols(); i++){ 
            test_a.col(i).array() -= test_a.col(i).maxCoeff();
            test_a.col(i) = test_a.col(i).array().exp().matrix();
            test_a.col(i) /= test_a.col(i).sum();
        }
    }
};

//a sweet wrapper
class InputLayer : public Layer{
public:
    InputLayer(int input_len){
        a.resize(input_len + 1, BATCH_SIZE);
        a.row(a.rows()-1).fill(1);
    }

    virtual void output(MatrixXd& x){
        if(state == TRAIN){
            a.topRows(a.rows()-1) = x.unaryExpr(ptr_fun(input_drop_out));
        }else{
            a.topRows(a.rows()-1) = x;
        }
    }

    virtual void output_test(MatrixXd& x){
        test_a.topRows(test_a.rows()-1) = x;
    }
};

class mynn
{
public:
    mynn(vector<int>&);
    void predict(MatrixXd &, MatrixXd &);
	void predict_test(MatrixXd &, MatrixXd &);
    void back_prop(MatrixXd& err);
    void update(MatrixXd& x);
    void setState(State s);
    void setTestSize(int s);
    int num_layers;
    vector<unique_ptr<Layer>> Layers;
};

mynn::mynn(vector<int>& nums_node){
    //input layer
    Layers.push_back(unique_ptr<Layer>(new InputLayer(nums_node[0])));

    //hidden layers
    for(size_t i = 0; i < nums_node.size() - 2 ; i += 1){
        Layers.push_back( unique_ptr<Layer>(new Layer(nums_node[i + 1], nums_node[i])) );
    }
    //output layer
    Layers.push_back( unique_ptr<Layer>(new OutputLayer(nums_node.back(), nums_node[nums_node.size() - 2])) );
}

void mynn::predict(MatrixXd &x, MatrixXd &output){
    Layers[0]->output(x);

    for(size_t i = 1; i < Layers.size(); i += 1){
        Layers[i]->output(Layers[i-1]->a);
    }
    output = Layers.back()->a; 
}

void mynn::predict_test(MatrixXd &x, MatrixXd &output){
    Layers[0]->output_test(x);

    for(size_t i = 1; i < Layers.size(); i += 1){
        Layers[i]->output_test(Layers[i-1]->test_a);
    }
    output = Layers.back()->test_a; 
}

void mynn::back_prop(MatrixXd& err){
    Layers.back()->delta = err;

    for(int i = Layers.size()-2; i > 0; i--){
        Layers[i]->backing(Layers[i+1]->delta, Layers[i+1]->W);
    }
}

//slow
void mynn::update(MatrixXd& x){
    for(size_t i = 1; i < Layers.size(); i += 1){
        MatrixXd old_v = Layers[i]->vW;
        Layers[i]->vW = Layers[i]->vW * decay_rate - learning_rate / BATCH_SIZE * (Layers[i]->delta * Layers[i-1]->a.transpose());
        Layers[i]->W += -decay_rate * old_v + (1 + decay_rate) * Layers[i]->vW;
        
        //cout << getTime() - tt << endl;
        /*
        for(int j = 0; j < Layers[i]->W.rows(); j++){
            double norm = Layers[i]->W.row(j).norm();
            if(norm > max_norm)
                Layers[i]->W.row(j) *= max_norm / norm;
        }
        */    
    }
}

void mynn::setState(State s){
    for(auto& ptr : Layers) ptr->setState(s);
}

void mynn::setTestSize(int s){
    for(auto& ptr : Layers) ptr->setTestSize(s);
}

inline int maxIndex(const VectorXd& x){
    MatrixXd::Index maxIndex;
    x.maxCoeff(&maxIndex);
    return maxIndex;
}

void dumpParameter(std::vector<int>& v){
    fprintf(stderr, "learning_rate: %f\n", learning_rate);
    fprintf(stderr, "drop_rate: %f\n", drop_rate);
    fprintf(stderr, "input_drop_rate: %f\n", input_drop_rate);
    fprintf(stderr, "batch_size: %d\n", BATCH_SIZE);
    fprintf(stderr, "max-norm: %f\n", max_norm);

    fprintf(stderr, "network layers:");
    for(auto& l : v) fprintf(stderr, " %d", l);
    fprintf(stderr, "\n");
}

int main(){
    int t = getTime();
    std::vector<Sequence> train_seqs, valid_seqs, test_seqs;
    readSequences(train_seqs, train_filename);
    readSequences(valid_seqs, valid_filename);
    readSequences(test_seqs, test_filename);
    cout << (getTime() - t) / 1000.0 << "s done reading file" << endl;
    MatrixXd train_x, valid_x, test_x;
    std::vector<int> train_y, valid_y, test_y;
    concatSeq(train_seqs, train_x, train_y, overlap);
    concatSeq(valid_seqs, valid_x, valid_y, overlap);
    concatSeq(test_seqs, test_x, test_y, overlap);
    cout << (getTime() - t) / 1000.0 << "s done concatenating seqs" << endl;

    int train_size = train_y.size(), valid_size = valid_y.size(), test_size = test_y.size();
    feature_size = train_x.rows();
    std::vector<int> v = {feature_size, 512, label_size};
    dumpParameter(v);
    srand (time(NULL));
    mynn m_mynn(v);
    m_mynn.setTestSize(valid_size);
    MatrixXd x, o, y;//x=instance, o=prediction, y=real label

    puts("start training...");
    for(int i = 1; i <= max_iteration; i += 1){
        cout << "epoch:" << i << endl;
        double errsum = 0.0, acu_sum = 0.0, epoch_time = getTime();
        m_mynn.setState(TRAIN);
        for(int j = 0; j + BATCH_SIZE - 1 < train_size; j += BATCH_SIZE){
            if(j % 1000 == 0) cout << '.' << flush;
            x = train_x.block(0, j, feature_size, BATCH_SIZE);
            //puts("predict");
            m_mynn.predict(x, o);

            //puts("cal entropy");
            double batch_entropy = 0;
            for(int k = 0; k < BATCH_SIZE; k++)
                batch_entropy -= log(o(train_y[j + k], k));
            int batch_acu = 0;
            for (int k = 0; k < BATCH_SIZE; k++){
                batch_acu += (maxIndex(o.col(k)) == train_y[j + k]) ? 1 : 0;
            }
            //cout << "entropy: " << batch_entropy;
            //cout << " batch_acu: " << batch_acu << endl;
            acu_sum += batch_acu;
            errsum += batch_entropy;

            //puts("back_prop");
            for(int k = 0; k < BATCH_SIZE; k++)
                o(train_y[j + k], k) -= 1;
            m_mynn.back_prop(o);

            //puts("udpate");
            m_mynn.update(x);

        }
        cout << "\ntrain entropy: " << errsum / train_size;
        cout << " acu: " << acu_sum / train_size;
        cout << " time: " << (getTime() - epoch_time) / 1000.0 << endl;
        
        double valid_e = 0, valid_a = 0;
        m_mynn.setState(PREDICT);
        m_mynn.predict_test(valid_x, o);
        for(int k = 0; k < valid_size; k++)
            valid_e -= log(o(valid_y[k], k));
        for(int k = 0; k < valid_size; k++){
            valid_a += (maxIndex(o.col(k)) == valid_y[k]) ? 1 : 0;
        }
        cout << "valid entropy: " << valid_e / valid_size << " acu: " << valid_a / valid_size;
        cout << " time: " << (getTime() - epoch_time) / 1000.0 << endl;
    
        learning_rate *= 0.97;

    }

    //puts("no test");
    //return 0;
    //

    //HMM

    double trans_cnt[label_size][label_size];
    memset(trans_cnt, 0, sizeof(trans_cnt));
    for(auto& seq : train_seqs){
        for(int i = 1; i < (int)seq.Y.size(); i++){
            trans_cnt[seq.Y[i-1]][seq.Y[i]] += 1;
        }
    }

    //scale
    for(int i = 0; i < label_size; i++){
        for(int j = 0; j < label_size; j++){
            if(i == j)
                trans_cnt[i][j] = log(log(sqrt(trans_cnt[i][j] + 1)));
            trans_cnt[i][j] = log(log(trans_cnt[i][j] + 1));
        }
    }

    puts("start predict test");
    m_mynn.setTestSize(test_size);
    fstream test_label_output;
    test_label_output.open("test.output", ios::out);
	MatrixXd t_o;
	m_mynn.predict_test(test_x, t_o);
	double omax[label_size], nmax[label_size];
	int update_from[10000][label_size];
    for(int i = 0, name_cnt = 0, c_s = 0; i <= t_o.cols(); i++, name_cnt++){
        if(name_cnt >= (int)test_seqs[c_s].X.size()){
            double m = -1e18;
            int idx = -1;
            for(int j = 0; j < label_size; j++){
                if(omax[j] > m){
                    idx = j;
                    m = omax[j];
                }
            }
            assert(idx != -1);
            test_seqs[c_s].Y.clear();
            test_seqs[c_s].Y.push_back(idx);
            for(int j = name_cnt - 1; j > 0; j--){
                idx = update_from[j][idx];
                assert(idx != -1);
                test_seqs[c_s].Y.push_back(idx);
            }
            
            name_cnt = 0;
            c_s++;
        }
        if(i == t_o.cols()) break;
        if(name_cnt == 0){
            for(int j = 0; j < label_size; j++)
                nmax[j] = log(t_o(j, i));
        }else{
            for(int j = 0; j < label_size; j++){
                nmax[j] = -1e18;
                for(int k = 0; k < label_size; k++){
                    if(omax[k] + log(t_o(j, i)) > nmax[j]){
                        update_from[name_cnt][j] = k;
                        nmax[j] = omax[k] + log(t_o(j, i));
                    }
                }
            }
        }
        swap(omax, nmax);
    }

    for(auto& s : test_seqs){
        int i = 1;
        for(auto it = s.Y.rbegin(); i <= (int)s.Y.size(); i++, it++){
            test_label_output << s.name << "_" << i << " " << *it << endl;
        }
    }
    test_label_output.close();
}
