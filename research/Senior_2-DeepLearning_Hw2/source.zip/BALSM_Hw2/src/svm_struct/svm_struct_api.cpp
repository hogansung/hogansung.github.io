/***********************************************************************/
/*                                                                     */
/*   svm_struct_api.c                                                  */
/*                                                                     */
/*   Definition of API for attaching implementing SVM learning of      */
/*   structures (e.g. parsing, multi-label classification, HMM)        */ 
/*                                                                     */
/*   Author: Thorsten Joachims                                         */
/*   Date: 03.07.04                                                    */
/*                                                                     */
/*   Copyright (c) 2004  Thorsten Joachims - All rights reserved       */
/*                                                                     */
/*   This software is available for non-commercial use only. It must   */
/*   not be modified and distributed without prior permission of the   */
/*   author. The author is not responsible for implications from the   */
/*   use of this software.                                             */
/*                                                                     */
/***********************************************************************/

#include "svm_struct_api.h"
#include "./svm_struct/svm_struct_common.h"
#include "./svm_struct_api_types.h"

map<string, string> feTch;
map<string, string> feMap;      // 48 mapping
map<string, int> feID;
string idFE[48];

bool TRAIN_FLAG;

void        read_label_mapping() {
  FILE *pfile = fopen("../dat/48_idx_chr.map_b", "r");
  if (pfile == NULL) {
    fprintf(stderr, "cannot open label mapping file\n");
    exit(EXIT_FAILURE);
  }

  char fe[3];
  char ch[2];
  int tag;
  while (fscanf(pfile, "%s%d%s", fe, &tag, ch) != EOF) {
    feTch[fe] = ch;
    feID[fe] = tag;
    idFE[tag] = fe;
  }
  fclose(pfile);
}

/* read_label_mapping() should be called before read_label() */
void        read_label() {
  FILE *pfile = fopen("../dat/label/train.lab", "r");
  if (pfile == NULL) {
    fprintf(stderr, "cannot open label file\n");
    exit(EXIT_FAILURE);
  }

  char id[STR_LEN];
  char lb[STR_LEN];
  while (fscanf(pfile, "%[a-z0-9_],%[a-z0-9_]\n", id, lb) != EOF) {
    feMap[id] = lb;
  }
  fclose(pfile);
}

void        svm_struct_learn_api_init(int argc, char* argv[])
{
  /* Called in learning part before anything else is done to allow
     any initializations that might be necessary. */
  read_label_mapping();
  read_label();

  TRAIN_FLAG = true;
}

void        svm_struct_learn_api_exit()
{
  /* Called in learning part at the very end to allow any clean-up
     that might be necessary. */
}

void        svm_struct_classify_api_init(int argc, char* argv[])
{
  /* Called in prediction part before anything else is done to allow
     any initializations that might be necessary. */
  read_label_mapping();
  read_label();
}

void        svm_struct_classify_api_exit()
{
  /* Called in prediction part at the very end to allow any clean-up
     that might be necessary. */
}

SAMPLE      read_struct_examples(char *file, STRUCT_LEARN_PARM *sparm)
{
  /* Reads struct examples and returns them in sample. The number of
     examples must be written into sample.n */
  SAMPLE   sample;  /* sample */
  EXAMPLE  example = EXAMPLE();

  /* fill in your code here */
  FILE *pfile = fopen(file, "r");
  if (pfile == NULL) {
    fprintf(stderr, "cannot open file: %s\n", file);
    exit(EXIT_FAILURE);
  }

  string pre = string("");
  char in[STR_LEN];
  while (fscanf(pfile, "%s", in) != EOF) {
    char gender[STR_LEN];
    char phone[STR_LEN];
    int seqNum;
    sscanf(in, "%[a-z0-9]_%[a-z0-9]_%d", gender, phone, &seqNum);
    
    if (pre != phone) {
        if (pre.length() > 0) sample.examples.emplace_back(example);
        example = EXAMPLE();
        pre = phone;
    }

    if (TRAIN_FLAG) {
        assert(feID.count(feMap[in]));
        example.y.lb.emplace_back(feID[feMap[in]]);
    }

    array<double, FEATURE_LEN> arr;
    for (int i = 0; i < FEATURE_LEN - 1; i++) {
        fscanf(pfile, "%lf", &arr[i]);
    }
    arr[FEATURE_LEN - 1] = 1.0;
    example.x.val.emplace_back(arr);
  }
  fclose(pfile);

  sample.examples.emplace_back(example);
  sample.n=sample.examples.size();
  return(sample);
}

void        init_struct_model(SAMPLE sample, STRUCTMODEL *sm, 
			      STRUCT_LEARN_PARM *sparm, LEARN_PARM *lparm, 
			      KERNEL_PARM *kparm)
{
  /* Initialize structmodel sm. The weight vector w does not need to be
     initialized, but you need to provide the maximum size of the
     feature space in sizePsi. This is the maximum number of different
     weights that can be learned. Later, the weight vector w will
     contain the learned weights for the model. */

  sm->sizePsi=VECTOR_LEN; /* replace by appropriate number of features */
  fprintf(stderr, "size = %d\n", int(sm->sizePsi));
}

CONSTSET    init_struct_constraints(SAMPLE sample, STRUCTMODEL *sm, 
				    STRUCT_LEARN_PARM *sparm)
{
  /* Initializes the optimization problem. Typically, you do not need
     to change this function, since you want to start with an empty
     set of constraints. However, if for example you have constraints
     that certain weights need to be positive, you might put that in
     here. The constraints are represented as lhs[i]*w >= rhs[i]. lhs
     is an array of feature vectors, rhs is an array of doubles. m is
     the number of constraints. The function returns the initial
     set of constraints. */
  CONSTSET c;
  long     sizePsi=sm->sizePsi;
  long     i;
  WORD     words[2];

  if(1) { /* normal case: start with empty set of constraints */
    c.lhs=NULL;
    c.rhs=NULL;
    c.m=0;
  }
  else { /* add constraints so that all learned weights are
            positive. WARNING: Currently, they are positive only up to
            precision epsilon set by -e. */
    c.lhs=(DOC **)my_malloc(sizeof(DOC *)*sizePsi);
    c.rhs=(double *)my_malloc(sizeof(double)*sizePsi);
    for(i=0; i<sizePsi; i++) {
      words[0].wnum=i+1;
      words[0].weight=1.0;
      words[1].wnum=0;
      /* the following slackid is a hack. we will run into problems,
         if we have move than 1000000 slack sets (ie examples) */
      c.lhs[i]=create_example(i,0,1000000+i,1,create_svector(words,"",1.0));
      c.rhs[i]=0.0;
    }
  }
  return(c);
}

int         findF(int x, int y)
{
    assert(x >= 0 && x < FEATURE_LEN);
    assert(y >= 0 && y < LABEL_LEN + 1);
    int v = y * FEATURE_LEN + x;
    return v; 
}

int         findL(int y1, int y2)
{
    assert(y1 >= 0 && y1 <= LABEL_LEN + 1);
    assert(y2 >= 0 && y2 <= LABEL_LEN + 1);
    int v = FEATURE_LEN * (LABEL_LEN + 1) + y1 * (LABEL_LEN + 2) + y2;
    return v;
}

LABEL       classify_struct_example(PATTERN x, STRUCTMODEL *sm, 
				    STRUCT_LEARN_PARM *sparm)
{
  /* Finds the label yhat for pattern x that scores the highest
     according to the linear evaluation function in sm, especially the
     weights sm.w. The returned label is taken as the prediction of sm
     for the pattern x. The weights correspond to the features defined
     by psi() and range from index 1 to index sm->sizePsi. If the
     function cannot find a label, it shall return an empty label as
     recognized by the function empty_label(y). */
  int frameLen = x.val.size();

  int backRcd[LABEL_LEN][frameLen];
  memset(backRcd, 0, sizeof(backRcd));

  double sum[LABEL_LEN][frameLen];
  memset(sum, 0, sizeof(sum));

  /* from start to each ylabel */
  for (int j = 0; j < LABEL_LEN; j++) {
    double val = 0;
    for (int k = 0; k < FEATURE_LEN; k++) {
        val += (sm->w[findF(k, j) + 1] + sm->w[findF(k, LABEL_LEN) + 1]) * x.val[0][k];
    }
    backRcd[j][0] = LABEL_LEN;
    sum[j][0] = sm->w[findL(LABEL_LEN, j) + 1] + val;
  }

  /* from each ylabel to each ylabel */
  for (int i = 1; i < frameLen; i++) {
    for (int j = 0; j < LABEL_LEN; j++) {              // now
        double dMax = -1e8;
        int past = -1;
        for (int k = 0; k < LABEL_LEN; k++ ){          // previous
            double val = sum[k][i - 1] + sm->w[findL(k, j) + 1];
            if (val > dMax) {
                dMax = val;
                past = k;
            }
        }
        assert(past >= 0 && past < LABEL_LEN);
        backRcd[j][i] = past;

        double val = 0;
        for (int k = 0; k < FEATURE_LEN; k++) {
            val += (sm->w[findF(k, j) + 1] + sm->w[findF(k, LABEL_LEN) + 1]) * x.val[i][k]; 
        }
        sum[j][i] = dMax + val;
    }
  }

  /* from each ylabel to end */
  double dMax = -1e8;
  int past = -1;
  for (int k = 0; k < LABEL_LEN; k++) {
    double val = sum[k][frameLen - 1] + sm->w[findL(k, LABEL_LEN + 1) + 1];
    if (val > dMax) {
        dMax = val;
        past = k;
    }
  }
  assert(past >= 0 && past < LABEL_LEN);

  /* trace back */
  LABEL y = LABEL();
  for (int i = frameLen - 1; i >= 0; i--) {
    y.lb.push_back(past);
    past = backRcd[past][i];
  }
  assert(past == LABEL_LEN);
  reverse(y.lb.begin(), y.lb.end());
  return(y);
}

LABEL       find_most_violated_constraint_slackrescaling(PATTERN x, LABEL y, 
						     STRUCTMODEL *sm, 
						     STRUCT_LEARN_PARM *sparm)
{
  /* Finds the label ybar for pattern x that that is responsible for
     the most violated constraint for the slack rescaling
     formulation. For linear slack variables, this is that label ybar
     that maximizes

            argmax_{ybar} loss(y,ybar)*(1-psi(x,y)+psi(x,ybar)) 

     Note that ybar may be equal to y (i.e. the max is 0), which is
     different from the algorithms described in
     [Tschantaridis/05]. Note that this argmax has to take into
     account the scoring function in sm, especially the weights sm.w,
     as well as the loss function, and whether linear or quadratic
     slacks are used. The weights in sm.w correspond to the features
     defined by psi() and range from index 1 to index
     sm->sizePsi. Most simple is the case of the zero/one loss
     function. For the zero/one loss, this function should return the
     highest scoring label ybar (which may be equal to the correct
     label y), or the second highest scoring label ybar, if
     Psi(x,ybar)>Psi(x,y)-1. If the function cannot find a label, it
     shall return an empty label as recognized by the function
     empty_label(y). */
  LABEL ybar = classify_struct_example(x, sm, sparm);

  /* insert your code for computing the label ybar here */

  return(ybar);
}

LABEL       find_most_violated_constraint_marginrescaling(PATTERN x, LABEL y, 
						     STRUCTMODEL *sm, 
						     STRUCT_LEARN_PARM *sparm)
{
  /* Finds the label ybar for pattern x that that is responsible for
     the most violated constraint for the margin rescaling
     formulation. For linear slack variables, this is that label ybar
     that maximizes

            argmax_{ybar} loss(y,ybar)+psi(x,ybar)

     Note that ybar may be equal to y (i.e. the max is 0), which is
     different from the algorithms described in
     [Tschantaridis/05]. Note that this argmax has to take into
     account the scoring function in sm, especially the weights sm.w,
     as well as the loss function, and whether linear or quadratic
     slacks are used. The weights in sm.w correspond to the features
     defined by psi() and range from index 1 to index
     sm->sizePsi. Most simple is the case of the zero/one loss
     function. For the zero/one loss, this function should return the
     highest scoring label ybar (which may be equal to the correct
     label y), or the second highest scoring label ybar, if
     Psi(x,ybar)>Psi(x,y)-1. If the function cannot find a label, it
     shall return an empty label as recognized by the function
     empty_label(y). */

  /* WARNING: omit loss error */
  return classify_struct_example(x, sm, sparm);

  int frameLen = x.val.size();

  int backRcd[LABEL_LEN][frameLen];
  memset(backRcd, 0, sizeof(backRcd));

  double sum[LABEL_LEN][frameLen];
  memset(sum, 0, sizeof(sum));

  /* from start to each ylabel */
  for (int j = 0; j < LABEL_LEN; j++) {
    double val = 0;
    for (int k = 0; k < FEATURE_LEN; k++) {
        val += sm->w[findF(k, j) + 1] * x.val[0][k];
    }
    backRcd[j][0] = LABEL_LEN;
    sum[j][0] = sm->w[findL(LABEL_LEN, j) + 1] + val + (y.lb[0] != j);
  }

  /* from each ylabel to each ylabel */
  for (int i = 1; i < frameLen; i++) {
    for (int j = 0; j < LABEL_LEN; j++) {              // now
        double dMax = -1e8;
        int past = -1;
        for (int k = 0; k < LABEL_LEN; k++ ){          // previous
            double val = sum[k][i - 1] + sm->w[findL(k, j) + 1];
            if (val > dMax) {
                dMax = val;
                past = k;
            }
        }
        assert(past >= 0 && past < LABEL_LEN);
        backRcd[j][i] = past;

        double val = 0;
        for (int k = 0; k < FEATURE_LEN; k++) {
            val += sm->w[findF(k, j) + 1] * x.val[i][k]; 
        }
        sum[j][i] = dMax + val + (y.lb[i] != j);
    }
  }

  /* from each ylabel to end */
  double dMax = -1e8;
  int past = -1;
  for (int k = 0; k < LABEL_LEN; k++) {
    double val = sum[k][frameLen - 1] + sm->w[findL(k, LABEL_LEN + 1) + 1];
    if (val > dMax) {
        dMax = val;
        past = k;
    }
  }
  assert(past >= 0 && past < LABEL_LEN);

  /* trace back */
  LABEL ybar = LABEL();
  for (int i = frameLen - 1; i >= 0; i--) {
    ybar.lb.push_back(past);
    past = backRcd[past][i];
  }
  assert(past == LABEL_LEN);
  reverse(ybar.lb.begin(), ybar.lb.end());
  return(ybar);
}

int         empty_label(LABEL y)
{
  /* Returns true, if y is an empty label. An empty label might be
     returned by find_most_violated_constraint_???(x, y, sm) if there
     is no incorrect label that can be found for x, or if it is unable
     to label x at all */
  return(0);
}

SVECTOR     *psi(PATTERN x, LABEL y, STRUCTMODEL *sm,
		 STRUCT_LEARN_PARM *sparm)
{
  /* Returns a feature vector describing the match between pattern x
     and label y. The feature vector is returned as a list of
     SVECTOR's. Each SVECTOR is in a sparse representation of pairs
     <featurenumber:featurevalue>, where the last pair has
     featurenumber 0 as a terminator. Featurenumbers start with 1 and
     end with sizePsi. Featuresnumbers that are not specified default
     to value 0. As mentioned before, psi() actually returns a list of
     SVECTOR's. Each SVECTOR has a field 'factor' and 'next'. 'next'
     specifies the next element in the list, terminated by a NULL
     pointer. The list can be though of as a linear combination of
     vectors, where each vector is weighted by its 'factor'. This
     linear combination of feature vectors is multiplied with the
     learned (kernelized) weight vector to score label y for pattern
     x. Without kernels, there will be one weight in sm.w for each
     feature. Note that psi has to match
     find_most_violated_constraint_???(x, y, sm) and vice versa. In
     particular, find_most_violated_constraint_???(x, y, sm) finds
     that ybar!=y that maximizes psi(x,ybar,sm)*sm.w (where * is the
     inner vector product) and the appropriate function of the
     loss + margin/slack rescaling method. See that paper for details. */

  double* wordsList = new double[VECTOR_LEN];
  memset(wordsList, 0, sizeof(double) * VECTOR_LEN);

  int st = LABEL_LEN;
  for (size_t i = 0; i < x.val.size(); i++) {
    int nt = y.lb[i];
    assert(nt >= 0 && nt < LABEL_LEN);

    for (int j = 0; j < FEATURE_LEN; j++) {
        wordsList[findF(j, nt)] += x.val[i][j];
        wordsList[findF(j, LABEL_LEN)] += x.val[i][j];          // dummy feature
    }
    wordsList[findL(st, nt)] += 1;
    st = nt;
  }
  wordsList[findL(st, LABEL_LEN + 1)] += 1;

  int cnt = 0;
  for (int i = 0; i < VECTOR_LEN; i++) {
    if (wordsList[i] != 0) cnt++; 
  }

  SVECTOR *vec = new SVECTOR();
  vec->twonorm_sq = -1;
  vec->userdefined = NULL;
  vec->kernel_id = 0;
  vec->next = NULL;
  vec->factor = 1.0;
  vec->words = new WORD[cnt + 1];
  for (int i = 0, flag = 0; i < VECTOR_LEN; i++) {
    if (wordsList[i] != 0) {
        vec->words[flag].wnum = i + 1;
        vec->words[flag].weight = wordsList[i];
        flag++;
    }
    vec->words[cnt].wnum = 0;
  }

  return(vec);
}

double      loss(LABEL y, LABEL ybar, STRUCT_LEARN_PARM *sparm)
{
  /* loss for correct label y and predicted label ybar. The loss for
     y==ybar has to be zero. sparm->loss_function is set with the -l option. */
  if(sparm->loss_function == 0) { /* type 0 loss: 0/1 loss */
                                  /* return 0, if y==ybar. return 1 else */
      if (TRAIN_FLAG) {
          int err = 0;
          for (size_t i = 0; i < y.lb.size(); i++) {
            if (y.lb[i] != ybar.lb[i]) err++;
          }
          return err;
      }
      else {
        return 0;
      }
  }
  else {
    /* Put your code for different loss functions here. But then
       find_most_violated_constraint_???(x, y, sm) has to return the
       highest scoring label with the largest loss. */
      assert(false);
  }
}

int         finalize_iteration(double ceps, int cached_constraint,
			       SAMPLE sample, STRUCTMODEL *sm,
			       CONSTSET cset, double *alpha, 
			       STRUCT_LEARN_PARM *sparm)
{
  /* This function is called just before the end of each cutting plane iteration. ceps is the amount by which the most violated constraint found in the current iteration was violated. cached_constraint is true if the added constraint was constructed from the cache. If the return value is FALSE, then the algorithm is allowed to terminate. If it is TRUE, the algorithm will keep iterating even if the desired precision sparm->epsilon is already reached. */
  return(0);
}

void        print_struct_learning_stats(SAMPLE sample, STRUCTMODEL *sm,
					CONSTSET cset, double *alpha, 
					STRUCT_LEARN_PARM *sparm)
{
  /* This function is called after training and allows final touches to
     the model sm. But primarly it allows computing and printing any
     kind of statistic (e.g. training error) you might want. */
  
  double err = 0;
  for (auto &example : sample.examples) {
    LABEL ybar = classify_struct_example(example.x, sm, sparm);
    err += loss(example.y, ybar, sparm);
  }
  fprintf(stderr, "Average err: %f\n", err / sample.n);
}

void        print_struct_testing_stats(SAMPLE sample, STRUCTMODEL *sm,
				       STRUCT_LEARN_PARM *sparm, 
				       STRUCT_TEST_STATS *teststats)
{
  /* This function is called after making all test predictions in
     svm_struct_classify and allows computing and printing any kind of
     evaluation (e.g. precision/recall) you might want. You can use
     the function eval_prediction to accumulate the necessary
     statistics for each prediction. */
}

void        eval_prediction(long exnum, EXAMPLE ex, LABEL ypred, 
			    STRUCTMODEL *sm, STRUCT_LEARN_PARM *sparm, 
			    STRUCT_TEST_STATS *teststats)
{
  /* This function allows you to accumlate statistic for how well the
     predicition matches the labeled example. It is called from
     svm_struct_classify. See also the function
     print_struct_testing_stats. */
  if(exnum == 0) { /* this is the first time the function is
		      called. So initialize the teststats */
    return;
  }
}

void        write_struct_model(char *file, STRUCTMODEL *sm, 
			       STRUCT_LEARN_PARM *sparm)
{
  /* Writes structural model sm to file file. */
  FILE *pfile = fopen(file, "w");
  if (pfile == NULL) {
    fprintf(stderr, "cannot write model into file: %s\n", file);
    exit(EXIT_FAILURE);
  }

  fprintf(pfile, "%ld\n", sm->sizePsi);
  for (int i = 1; i <= sm->sizePsi; i++) {
    fprintf(pfile, "%f\n", sm->w[i]);
  }

  fprintf(stderr, "walpha = %f\n", sm->walpha);

  fclose(pfile);
}

STRUCTMODEL read_struct_model(char *file, STRUCT_LEARN_PARM *sparm)
{
  /* Reads structural model sm from file file. This function is used
     only in the prediction module, not in the learning module. */

  FILE *pfile = fopen(file, "r");
  if (pfile == NULL) {
    fprintf(stderr, "cannot read model from file: %s\n", file);
    exit(EXIT_FAILURE);
  }

  STRUCTMODEL sm;
  sm.svm_model = NULL;
  sm.walpha = 0;

  fscanf(pfile, "%ld", &sm.sizePsi);
  sm.w = new double[sm.sizePsi + 1];
  for (int i = 1; i <= sm.sizePsi; i++) {
    fscanf(pfile, "%lf", &sm.w[i]);
  }

  fclose(pfile);
  return sm;
}

void        write_label(FILE *fp, LABEL y)
{
  /* Writes label y to file handle fp. */
    for (auto &v : y.lb) {
        fprintf(fp, "%s ", feTch[idFE[v]].c_str());
    }
    fprintf(fp, "\n");
    return;
} 

void        free_pattern(PATTERN x) {
  /* Frees the memory of x. */
    return;
}

void        free_label(LABEL y) {
  /* Frees the memory of y. */
    return;
}

void        free_struct_model(STRUCTMODEL sm) 
{
  /* Frees the memory of model. */
  /* if(sm.w) free(sm.w); */ /* this is free'd in free_model */
  if(sm.svm_model) free_model(sm.svm_model,1);
  /* add free calls for user defined data here */
}

void        free_struct_sample(SAMPLE s)
{
  /* Frees the memory of sample s. */
  int i;
  for(i=0;i<s.n;i++) { 
    free_pattern(s.examples[i].x);
    free_label(s.examples[i].y);
  }
  //free_example(s.examples);
}

void        print_struct_help()
{
  /* Prints a help text that is appended to the common help text of
     svm_struct_learn. */
  printf("         --* string  -> custom parameters that can be adapted for struct\n");
  printf("                        learning. The * can be replaced by any character\n");
  printf("                        and there can be multiple options starting with --.\n");
}

void         parse_struct_parameters(STRUCT_LEARN_PARM *sparm)
{
  /* Parses the command line parameters that start with -- */
  int i;

  for(i=0;(i<sparm->custom_argc) && ((sparm->custom_argv[i])[0] == '-');i++) {
    switch ((sparm->custom_argv[i])[2]) 
      { 
      case 'a': i++; /* strcpy(learn_parm->alphafile,argv[i]); */ break;
      case 'e': i++; /* sparm->epsilon=atof(sparm->custom_argv[i]); */ break;
      case 'k': i++; /* sparm->newconstretrain=atol(sparm->custom_argv[i]); */ break;
      default: printf("\nUnrecognized option %s!\n\n",sparm->custom_argv[i]);
	       exit(0);
      }
  }
}

void        print_struct_help_classify()
{
  /* Prints a help text that is appended to the common help text of
     svm_struct_classify. */
  printf("         --* string -> custom parameters that can be adapted for struct\n");
  printf("                       learning. The * can be replaced by any character\n");
  printf("                       and there can be multiple options starting with --.\n");
}

void         parse_struct_parameters_classify(STRUCT_LEARN_PARM *sparm)
{
  /* Parses the command line parameters that start with -- for the
     classification module */
  int i;

  for(i=0;(i<sparm->custom_argc) && ((sparm->custom_argv[i])[0] == '-');i++) {
    switch ((sparm->custom_argv[i])[2]) 
      { 
      /* case 'x': i++; strcpy(xvalue,sparm->custom_argv[i]); break; */
      default: printf("\nUnrecognized option %s!\n\n",sparm->custom_argv[i]);
	       exit(0);
      }
  }
}

