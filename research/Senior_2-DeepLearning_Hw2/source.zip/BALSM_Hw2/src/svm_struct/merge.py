testFile = '../../dat/fbank/test_2048.ark'
predFile = 'test.out'
resFile = '../../output.kaggle'

LIMITS = 1

# merge unique instances
uniList = []
with open(testFile) as fin:
    pre = ''
    for line in fin.readlines():
        instID = line.strip().split()[0]
        uniID = instID[:instID.rfind('_')]

        if pre != uniID:
            if len(pre) > 0: uniList.append(pre)
            pre = uniID
    uniList.append(pre)


aveLen = 0
instCnt = 0
with open(resFile, 'w') as fout:
    fout.write('id,phone_sequence\n')
    with open(predFile) as fin:
        for line, uniID in zip(fin.readlines(), uniList):
            inst = line.strip().split()

            outList = []
            pre = ''
            cnt = 0

            # remove duplicate
            for e in inst:
                if pre != e:
                    if len(pre) > 0 and cnt >= LIMITS: outList.append(pre)
                    pre = e
                    cnt = 1
                else:
                    cnt += 1
            if (cnt >= LIMITS): outList.append(pre)

            # remove sil from start
            while (outList[0] == 'L'):
                outList = outList[1:]

            # remove sil from end
            while (outList[-1] == 'L'):
                outList = outList[:-1]

            aveLen += len(outList)
            instCnt += 1
            fout.write(uniID + ',' + ''.join(outList) + '\n') 

print instCnt, 1.0 * aveLen / instCnt
