
if __name__ == "__main__":
    train_dict = {}
    state_48_dict = {}
    phones = set()
    phones_48_dict = {}

    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/phones/48_idx_chr.map_b') as state_48_file:
        for line in state_48_file:
            tokens = line.split()
            state_48_dict[tokens[0]] = tokens[1]
    
    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/label/train.lab') as train_labels:
        with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/label/train_48.lab', 'w') as train_39s:
            for line in train_labels:
                tokens = line.strip().split(',')
                train_39s.write(' '.join([tokens[0], state_48_dict[tokens[1]]]))
                train_39s.write('\n')
