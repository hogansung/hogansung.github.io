import random
if __name__ == '__main__':
    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/standardized_train.ark') as o_train_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/label/sorted_train_48.lab') as label_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/sub_train.ark', 'w') as sub_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/valid.ark', 'w') as val_f:
        data = []
        names = []
        for line, lab in zip(o_train_f, label_f):
            inst = line.strip().split()
            lab = lab.strip().split()
            assert(lab[0] == inst[0])
            name = '_'.join(inst[0].split('_')[0:2])
            if(names == [] or names[-1] != name):
                names.append(name)
                data.append([])
            data[-1].append([lab[1]] + inst[1:])
        
        d = zip(names, data)
        random.shuffle(d)
        train_len = len(d)
        sub_train_len = int(train_len * 0.9)
        for i in range(sub_train_len):
            sub_f.write('#' + d[i][0] + '\n')
            for frame in d[i][1]:
                sub_f.write(' '.join(frame))
                sub_f.write('\n')
        for i in range(sub_train_len, train_len):
            val_f.write('#' + d[i][0] + '\n')
            for frame in d[i][1]:
                val_f.write(' '.join(frame))
                val_f.write('\n')
