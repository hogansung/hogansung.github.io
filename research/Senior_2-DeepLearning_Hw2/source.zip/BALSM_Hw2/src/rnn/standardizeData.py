import math
if __name__ == '__main__':
    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/sorted_train.ark') as train_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/test.ark') as test_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/standardized_train.ark', 'w') as s_train_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/standardized_test.ark', 'w') as s_test_f:
        train_data = [line.strip().split() for line in train_f]
        feature_list = [map(float, l) for l in zip(*train_data)[1:]]
        names = list(zip(*train_data)[0])
        means = [sum(l) / len(l) for l in feature_list]
        feature_list = [map(lambda x: x - m, l) for m, l in zip(means, feature_list)]
        stds = [sum([e**2 for e in l]) / len(l) for l in feature_list]
        stds = list(map(math.sqrt, stds))
        feature_list = [list(map(lambda x: x / s, l)) for s, l in zip(stds, feature_list)]
        for t in zip(names, *feature_list):
            s_train_f.write(' '.join([t[0]] + list(map(str, t[1:]))))
            s_train_f.write('\n')

        for line in test_f:
            inst = line.strip().split()
            new_inst = [inst[0]]
            for num, mean, std in zip(list(map(float, inst[1:])), means, stds):
                new_inst.append(str((num - mean) / std))
            s_test_f.write(' '.join(new_inst))
            s_test_f.write('\n')
