if __name__ == '__main__':
    with open('test.output') as of, open('../../output.kaggle', 'w') as nf, open('../../dat/MLDS_HW1_RELEASE_v1/phones/48_idx_chr.map_b') as map_file:
        mmap = {}
        for line in map_file:
            inst = line.strip().split()
            mmap[inst[1]] = inst[2]
        
        nf.write('id,phone_sequence\n');
        oname = ''
        temp_list = ''
        pre = ''
        cnt = 0
        flag = 1
        for line in of:
            if flag == 0:
                flag += 1
                continue
            inst = line.strip().split(' ')
            name = inst[0].split('_')
            name = name[0] + '_' + name[1]
            if oname == '':
                oname = name
            if name != oname:
                nf.write(oname + ',') 
                if temp_list[0] == 'L':
                    temp_list = temp_list[1:]
                if temp_list[-1] == 'L':
                    temp_list = temp_list[0:-1]
                for e in temp_list:
                    nf.write(e)
                nf.write('\n')
                oname = name
                temp_list = ''
            if mmap[inst[1]] == pre:
                cnt += 1
            else:
                cnt = 1
                pre = mmap[inst[1]]
            if cnt > 3 and (len(temp_list) == 0 or mmap[inst[1]] != temp_list[-1]):
                temp_list += mmap[inst[1]]
        
        nf.write(oname + ',') 
        if temp_list[0] == 'L':
            temp_list = temp_list[1:]
        if temp_list[-1] == 'L':
            temp_list = temp_list[0:-1]
        for e in temp_list:
            nf.write(e)
        nf.write('\n')
