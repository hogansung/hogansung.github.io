#include <Eigen/Dense>
#include <typeinfo>
#include <vector>
#include <omp.h>
#include <cmath>
#include <memory>
#include <iostream>
#include <time.h> 
#include <fstream>
#include <cassert>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <string>
#include "util.h"
using namespace Eigen;
using namespace std;

const int BATCH_SIZE = 1024, feature_size = 972, label_size = 48;
const int max_iteration = 200;
double learning_rate = 0.001;
const double drop_rate = 0; //dropconnect
const double mu = 1e-8, rmsprop_decay_rate = 0.9;  //rmsprop
const double max_norm = 4; //max norm regularization
const double step_gain_rate = 0.05, max_step_gain = 100, min_step_gain = 0.01; //adaptive lr
double decay_rate = 0.9, momentum_decay_rate = 1 - 1e-6; //Nesterov momentum

const int N = 1124823, test_size = 180406;
//int N = 100;
int train_size = 1000064, valid_size = (N - train_size) / BATCH_SIZE * BATCH_SIZE;
//int train_size = 100, valid_size = 0;

vector<string> phones;
vector<string> split(string a, string b){
    vector<string> output;
    string tmp;
    int found=0;
    int curr=0;
    int len=a.size();
    while(curr < len){
        found = a.find(b, curr);
        if(found == -1){
            found = len;
        }
        tmp = a.substr(curr, found - curr);
        output.push_back(tmp);
        curr = found + b.size();
        // cout<<curr<<endl;
    }
    return output;
}

map<string, int> read_map(fstream& input_file){
    map<string, int> lab_map;
    vector<string> output;
    string tmp;
    string k;
    int cnt=0;

    while(getline(input_file,tmp)){
        if(tmp[tmp.size()-1]=='\n')
			tmp.pop_back();
        k = "\t";
        output = split(tmp,k);
        lab_map[output[0]] = cnt;
		phones.push_back(output[1]);
        // lab_map[output[1]] = cnt;
        cnt += 1;
        // cout<<cnt;
        // puts("");
    }

    return lab_map;

}
map<string, int> read_state_map(fstream& input_file){
    map<string, int> lab_map;
    vector<string> output;
    string tmp;
    string k;
    int cnt=0;

    while(getline(input_file,tmp)){
        if(tmp[tmp.size()-1]=='\n')
			tmp.pop_back();
        k = "\t";
        output = split(tmp,k);
        lab_map[output[0]] = cnt;
		lab_map[output[1]] = cnt;
		phones.push_back(output[2]);
        // lab_map[output[1]] = cnt;
        cnt += 1;
        // cout<<cnt;
        // puts("");
    }

    return lab_map;

}

int read_fbank(fstream& input_file, vector<string> &id, MatrixXd &X){
    vector<string> output;
    string tmp;
    int i;
    int cnt = 0;
    string k;
    while(getline(input_file, tmp))
    {
        k = " ";
        output=split(tmp,k);
        id.push_back(output[0]);
        int output_size = output.size();
        for(i = 1; i < output_size ; i += 1)
        {
            //X(cnt,i-1)=string.atof(output[i]);
            X(cnt,i-1) = atof(output[i].c_str());
        }

        cnt += 1;
    }
    cout << cnt << endl;
    return cnt;
}

MatrixXd read_lab(fstream& input_file, map<string, int> lab_map, vector<string> x_id, MatrixXd &Y){
    map<string, VectorXd> label;
    vector<string> output;
    int i;
    string tmp;
    string k;

    while(getline(input_file,tmp)){
        k = '\n';
        output = split(tmp,k);
        tmp = output[0];
        k = ',';
        output = split(tmp,k);
        VectorXd lab = VectorXd::Zero(label_size);
        lab(lab_map[output[1]]) = 1;
        label[output[0]] = lab;
    }

    int x_id_size = x_id.size();
    for(i = 0; i < x_id_size ; i += 1){
        Y.row(i) = label[x_id[i]];
    }
    return Y;

}

int read_train(MatrixXd &train_x, MatrixXd &train_y){
    fstream map_file;
    map_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/phones/48_39.map", ios::in );
	//map_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/phones/state_48_39.map", ios::in );
    fstream fbank_file, mfcc_file;
    //fbank_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/train.ark", ios::in );
    //mfcc_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/mfcc/train.ark", ios::in );
    fbank_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/train_972.ark", ios::in );
    //fbank_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/train_621.ark", ios::in );
    fstream train_y_file;
    train_y_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/label/train.lab", ios::in );  
    map<string, int> lab_map;
    vector<string> x_id;
    lab_map = read_map(map_file);
	//lab_map = read_state_map(map_file);
    map_file.close();

    read_fbank(fbank_file, x_id, train_x);
    fbank_file.close();
    //read_mfcc(mfcc_file, x_id, train_x);
    //mfcc_file.close();
    read_lab(train_y_file, lab_map, x_id, train_y);
    train_y_file.close();

    train_x.transposeInPlace();
    train_y.transposeInPlace();

    return train_x.cols();
}

inline double sigmoid(double x){
    return 1 / (1 + exp(-x));
}

inline double stepGain(double a, double b){
    if(b > 0) return min(a + step_gain_rate, max_step_gain);
    else return max(a * (1 - step_gain_rate), min_step_gain);
}

inline double random_assign(double x){
    if(rand() % 10 < drop_rate * 10) return 0;
    else return 1;
}

inline double update_rms(double a, double b){
    if(b == 0) return a;
    else return rmsprop_decay_rate * a + (1 - rmsprop_decay_rate) * b * b;
}

inline void pprint(const VectorXd &v){
    for (int i = 0; i < v.rows(); i += 1){
        cout << i << ":" << v(i) << " "; 
    }
    puts("");
}

enum State{
    TRAIN, PREDICT
};

class Layer
{
public:
    Layer(){}
    Layer(int, int);
    virtual void output(MatrixXd &);
	virtual void output_test(MatrixXd &);
    void backing(MatrixXd &, MatrixXd &, MatrixXd &);
    void setState(State s){
        state = s;
    }

    int _num_node;
    State state;
    MatrixXd W, a, delta, vW, test_a, d_mask;
    ArrayXXd step_gain_w, msw;
};

Layer::Layer(int num_node, int num_pre){
    _num_node = num_node;
    W = MatrixXd::Random(num_node, num_pre + 1) / 10;
    vW = MatrixXd::Zero(num_node, num_pre + 1);
    step_gain_w = ArrayXXd::Ones(num_node, num_pre + 1);
    msw = ArrayXXd::Zero(num_node, num_pre + 1);
    a.resize(num_node + 1, BATCH_SIZE);
    test_a.resize(num_node + 1, test_size);
    delta.resize(num_node, BATCH_SIZE);
    d_mask = MatrixXd::Ones(num_node, num_pre + 1);
}

inline void Layer::output(MatrixXd &x){
    if(state == TRAIN){
        d_mask = d_mask.unaryExpr(ptr_fun(random_assign));
    }else{
        d_mask.fill(1 - drop_rate);
    }
    a.block(0, 0, a.rows()-1, a.cols()) = (W.cwiseProduct(d_mask) * x).unaryExpr(ptr_fun(sigmoid));
}

inline void Layer::output_test(MatrixXd &x){
    test_a.block(0, 0, test_a.rows()-1, test_a.cols()) = (W * x).unaryExpr(ptr_fun(sigmoid));
}

inline void Layer::backing(MatrixXd &delta_next, MatrixXd &W_next, MatrixXd &mask_next){
    delta = (a.array() * (1 - a.array()) * (W_next.cwiseProduct(mask_next).transpose() * delta_next).array()).matrix().block(0, 0, a.rows()-1, a.cols());
}

//use softmax rather than sigmoid
class OutputLayer : public Layer{
public:
    OutputLayer(int num_node, int num_pre) : Layer(num_node, num_pre){
        a.resize(num_node, BATCH_SIZE);
    }
    virtual void output(MatrixXd& x){
        a = (W * x).array().exp().matrix();
        for(int i = 0; i < BATCH_SIZE; i++) a.col(i) /= a.col(i).sum();
    }
    virtual void output_test(MatrixXd &x){
        if(state == TRAIN){
            d_mask = d_mask.unaryExpr(ptr_fun(random_assign));
        }else{
            d_mask.fill(1 - drop_rate);
        }
        test_a.block(0, 0, test_a.rows()-1, test_a.cols()) = (W.cwiseProduct(d_mask) * x).array().exp().matrix();
        for(int i = 0; i < test_size; i++) test_a.col(i) /= test_a.col(i).sum();
    }
};

//a sweet wrapper
class InputLayer : public Layer{
public:
    InputLayer(){}
};

class mynn
{
public:
    mynn(vector<int>&);
    void predict(MatrixXd &, MatrixXd &);
	void predict_test(MatrixXd &, MatrixXd &);
    void back_prop(MatrixXd& err);
    void jump();
    void update(MatrixXd& x);
    void setState(State s);
    int num_layers;
    vector<unique_ptr<Layer>> Layers;
};

mynn::mynn(vector<int>& nums_node){
    //input layer
    Layers.push_back(unique_ptr<Layer>(new InputLayer()));

    //hidden layers
    for(size_t i = 0; i < nums_node.size() - 2 ; i += 1){
        Layers.push_back( unique_ptr<Layer>(new Layer(nums_node[i + 1], nums_node[i])) );
    }
    //output layer
    Layers.push_back( unique_ptr<Layer>(new OutputLayer(nums_node.back(), nums_node[nums_node.size() - 2])) );
}

void mynn::predict(MatrixXd &x, MatrixXd &output){
    Layers[0]->a = x;

    for(size_t i = 1; i < Layers.size(); i += 1){
        Layers[i]->output(Layers[i-1]->a);
    }
    output = Layers.back()->a; 
}

void mynn::predict_test(MatrixXd &x, MatrixXd &output){
    Layers[0]->test_a = x;

    for(size_t i = 1; i < Layers.size(); i += 1){
        Layers[i]->output_test(Layers[i-1]->test_a);
    }
    output = Layers.back()->test_a; 
}

void mynn::back_prop(MatrixXd& err){
    Layers.back()->delta = err;

    for(int i = Layers.size()-2; i > 0; i--){
        Layers[i]->backing(Layers[i+1]->delta, Layers[i+1]->W, Layers[i+1]->d_mask);
    }
}

void mynn::update(MatrixXd& x){
    for(auto it = Layers.begin() + 1; it != Layers.end(); it++){
        (*it)->W -= decay_rate * (*it)->vW;
    }
    for(size_t i = 1; i < Layers.size(); i += 1){
        MatrixXd temp2 = -1.0 / BATCH_SIZE * Layers[i]->delta * Layers[i-1]->a.transpose();
        temp2 = temp2.cwiseProduct(Layers[i]->d_mask);
        Layers[i]->msw = Layers[i]->msw.binaryExpr(temp2.array(), ptr_fun(update_rms));
        Layers[i]->step_gain_w = Layers[i]->step_gain_w.binaryExpr(temp2.cwiseProduct(Layers[i]->vW).array(), ptr_fun(stepGain));
        Layers[i]->vW = Layers[i]->vW * decay_rate + (learning_rate * Layers[i]->step_gain_w * temp2.array() / (Layers[i]->msw.sqrt() + mu)).matrix();
        Layers[i]->W += Layers[i]->vW;
        for(int i = 0; i < Layers[i]->W.rows(); i++){
            double norm = Layers[i]->W.row(i).norm();
            if(norm > max_norm)
                Layers[i]->W.row(i) *= max_norm / norm;
        }
    }
}

void mynn::jump(){
    for(auto it = Layers.begin() + 1; it != Layers.end(); it++){
        (*it)->W += decay_rate * (*it)->vW;
    }
}

void mynn::setState(State s){
    for(auto& ptr : Layers) ptr->setState(s);
}

int acu(const VectorXd& o, const VectorXd& y){
   MatrixXd::Index maxRow, maxCol;
   MatrixXd::Index maxRow2, maxCol2;
   o.maxCoeff(&maxRow, &maxCol);
   y.maxCoeff(&maxRow2, &maxCol2);

  //  if (y(maxRow) == y.maxCoeff()){
	if (phones[maxRow].compare(phones[maxRow2])==0){
        return 1;
    }
    else{
        return 0;
    }
}

int main(){
    
    std::vector<int> v = {feature_size, 1024, 1024, 1024, label_size};
    srand (time(NULL));
    mynn m_mynn(v);

    MatrixXd train_x(feature_size+1, N), train_y(N, v.back()), temp(N, v[0]);
    
    int t = getTime();
    read_train(temp, train_y);
    cout << (getTime() - t) / 1000.0 << "s done reading train file" << endl;
    // cout<<"train cols "<< train_x.cols()<<endl;

    //normalize train_x
    //temp.rowwise().normalize();

    train_x.block(0, 0, feature_size, N) = temp;
    train_x.row(train_x.rows()-1).fill(1);

    MatrixXd x, o, y;//x=instance, o=prediction, y=real label

    //puts("ho");
    PermutationMatrix<Dynamic,Dynamic> perm(N);
    perm.setIdentity();
    std::random_shuffle(perm.indices().data(), perm.indices().data()+perm.indices().size());
    train_x = train_x * perm; // permute columns
    train_y = train_y * perm;

    puts("start training...");
    for(int i = 0; i < max_iteration; i += 1){
        double errsum = 0.0, acu_sum = 0.0, epoch_time = getTime();
        m_mynn.setState(TRAIN);
        for(int j = 0; j + BATCH_SIZE - 1 < train_size; j += BATCH_SIZE){
            x = train_x.block(0, j, feature_size + 1, BATCH_SIZE);
            y = train_y.block(0, j, label_size, BATCH_SIZE);

            m_mynn.jump();

            //puts("predict");
            m_mynn.predict(x, o);

            //puts("cal entropy");
            double batch_entropy = -(o.array().log() * y.array()).sum();
            int batch_acu = 0;
            for (int k = 0; k < BATCH_SIZE; k++){
                batch_acu += acu(o.col(k), y.col(k));
            }
            //cout << "entropy: " << batch_entropy;
            //cout << " batch_acu: " << batch_acu << endl;
            acu_sum += batch_acu;
            errsum += batch_entropy;

            //puts("back_prop");
            o -= y;
            m_mynn.back_prop(o);

            //puts("udpate");
            m_mynn.update(x);

            //learning_rate *= learning_rate_decay;
            decay_rate *= momentum_decay_rate;
        }
        cout << "epoch:" << i << endl;
        cout << "train entropy: " << errsum / train_size;
        cout << " acu: " << acu_sum / train_size;
        cout << " time: " << (getTime() - epoch_time) / 1000.0 << endl;
        double valid_e = 0, valid_a = 0;
        m_mynn.setState(PREDICT);
        for(int j = 0; j < valid_size; j += BATCH_SIZE){
            x = train_x.block(0, j + train_size, feature_size + 1, BATCH_SIZE);
            y = train_y.block(0, j + train_size, label_size, BATCH_SIZE);

            m_mynn.predict(x, o);
            valid_e -= (o.array().log() * y.array()).sum();
            for (int k = 0; k < BATCH_SIZE; k++){
                valid_a += acu(o.col(k), y.col(k));
            }
        }
        cout << "valid entropy: " << valid_e / valid_size << " acu: " << valid_a / valid_size <<endl;
    }

    puts("start predict test");
    fstream test_x_file, test_mfcc_file;
    test_x_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/test_972.ark", ios::in );
    //test_mfcc_file.open("../../Hw1/dat/MLDS_HW1_RELEASE_v1/mfcc/test.ark", ios::in );
    fstream test_output;
    test_output.open("test_972_1024x3_48_bs1024_drop_lr001_m099.output", ios::out );
    vector<string> test_x_id;
	MatrixXd test_x(feature_size+1, test_size),  test_temp(test_size, feature_size);
    read_fbank(test_x_file, test_x_id, test_temp);
    //read_mfcc(test_mfcc_file, test_x_id, test_temp);
    test_temp.transposeInPlace();
	puts("read done");
	test_x.block(0, 0, feature_size, test_size) = test_temp;
    test_x.row(test_x.rows()-1).fill(1);
	MatrixXd t_o;
	test_output<<"Id,Prediction"<<endl;
	m_mynn.predict_test(test_x, t_o);
    for(int i=0;i<test_size;i++)
    {
        MatrixXd::Index maxRow, maxCol;
        t_o.col(i).maxCoeff(&maxRow, &maxCol);
        test_output<<test_x_id[i]<<','<<phones[maxRow]<<endl;
    }
    test_output.close();
}
