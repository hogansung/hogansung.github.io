if __name__ == '__main__':
    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/standardized_test.ark') as test_f, open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/fbank/test_new.ark', 'w') as ntest_f:
        cur_name = ''
        for line in test_f:
            inst = line.strip().split()
            name = '_'.join(inst[0].split('_')[0:2])
            if name != cur_name:
                ntest_f.write('#' + name + '\n')
                cur_name = name
            ntest_f.write(' '.join(['-1'] + inst[1:]))
            ntest_f.write('\n')
