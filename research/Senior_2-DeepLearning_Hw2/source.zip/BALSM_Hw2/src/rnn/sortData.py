if __name__ == '__main__':
    with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/label/train_48.lab') as t:
        with open('/home/wrangle1005/DeepLearning/Hw1/dat/MLDS_HW1_RELEASE_v1/label/sorted_train_48.lab', 'w+') as ot:
            for line in sorted(t, cmp=lambda x, y: cmp(''.join(x.split()[0].split('_')[0:2]), ''.join(y.split()[0].split('_')[0:2]))):
                ot.write(line)
