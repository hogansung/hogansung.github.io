#ifndef __UTILS
#define __UTILS
#include <iostream>
#include <sys/time.h>
#include <Eigen/Dense>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>

using namespace Eigen;

const int feature_length = 69;

struct Sequence{
    Sequence(){}
    std::vector<VectorXd> X;
    std::vector<int> Y;
    char name[100] = {0};
};

//milisec
unsigned int getTime(){
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void readSequences(std::vector<Sequence>& seqs, const char* filename){
    FILE* f = fopen(filename, "r");
    char buf[10000];
    std::vector<double> temp_v;
    while(fgets(buf, 10000, f) != NULL){
        temp_v.clear();
        if(buf[0] == '#'){
            seqs.push_back(Sequence());
            strcpy(seqs.back().name, buf + 1);
            seqs.back().name[strlen(seqs.back().name)-1] = '\0';
        }else{
            char* token = strtok(buf, " ");
            seqs.back().Y.push_back(atoi(token));

            while((token = strtok(NULL, " ")) != NULL){
                temp_v.push_back(atof(token));
            }
            seqs.back().X.push_back(VectorXd(temp_v.size()));
            for(size_t i = 0; i < temp_v.size(); i++){
                seqs.back().X.back()(i) = temp_v[i];
            }
        }
    }
    fclose(f);
}

void concatSeq(std::vector<Sequence>& seqs, MatrixXd& X, std::vector<int>& Y, int overlap){
    int sum = 0;
    for(auto& seq : seqs) sum += seq.Y.size();
    int rows = seqs.front().X.front().size();
    X.resize(rows * (2 * overlap + 1), sum);
    X.fill(0);

    int cnt = 0;
    for(auto& seq : seqs){
        for(auto& label : seq.Y) Y.push_back(label);
        for(int i = 0; i < (int)seq.X.size(); i++){
            for(int j = 0; j <= overlap && i + j < (int)seq.X.size(); j++){
                X.col(cnt + j).segment(rows * (overlap - j), rows) = seq.X[i];
            }
            for(int j = 1; j <= overlap && i - j >= 0; j++){
                X.col(cnt - j).segment(rows * (overlap + j), rows) = seq.X[i];
            }
            cnt++;
        }
    }
}

#endif
