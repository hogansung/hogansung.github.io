#ifndef __MLDS_NETWORK__
#define __MLDS_NETWORK__

#include <Eigen/Dense>
#include <cassert>

using namespace Eigen;

template<int nLayer> 
class Network{
public:
    //const int layers[nLayer];
    MatrixXd w[nLayer-1];
    VectorXd b[nLayer-1], a[nLayer];
    Network(const int l[nLayer]){
        assert(nLayer > 1);
        for(int i = 0; i < nLayer-1; i++){
            w[i] = MatrixXd::Zero(l[i], l[i+1]);
            b[i] = VectorXd::Zero(l[i+1]);
            a[i] = VectorXd::Zero(l[i]);
        }
        a[nLayer-1] = VectorXd::Zero(l[nLayer-1]);
    }
    void feed(VectorXd& x){
        a[0] = x;
        for(int i = 1; i < nLayer; i++){
            a[i] = w[i-1].transpose() * a[i-1] + b[i-1]; 
        }
    }

    void backProp(VectorXd& e){}
};

#endif
