#include "common.h"

char fileName[BUFFER_SIZE], receiverName[BUFFER_SIZE], agentName[MAX_AGENT][BUFFER_SIZE];
int receiverAddr, receiverPort;
int agentAddr[MAX_AGENT], agentPort[MAX_AGENT];

double agentReal[MAX_AGENT];
double agentRate[MAX_AGENT];

int seqNum, ackNum;

char fileContent[FILE_BUFFER_SIZE];
int fileCheck[BLOCK_NUM];  // true, if has sent
int fileTag[BLOCK_NUM];    // tag with agent id

int myPort;
int sock, epollFd, timerFd;
int numOfAgent, fileSize;
int realSize, windowSize, threshold, windowFront, getNum;
int keepConnect = 1;

struct sockaddr_in mySock, inSock, agentSock[MAX_AGENT], receiverSock;
struct epoll_event ev, events[2];
struct itimerspec oldValue, armValue, disarmValue;

int max(int a, int b) { return a < b ?b :a; }
int min(int a, int b) { return a < b ?a :b; }

void init() {
    strcpy(fileName, "in.txt");
    numOfAgent = 3;
    windowSize = 1;
    threshold = 16;
    windowFront = 0;

    srand(time(NULL));

    strcpy(receiverName, "127.0.0.1");
    myPort = 8060;
    receiverPort = 8080;

    for (int i = 0; i < numOfAgent; i++) {
        strcpy(agentName[i], "127.0.0.1");
        agentPort[i] = 8800 + i;
        agentReal[i] = DICE_FACE;
    }
}

void parseArg(int argc, char *argv[]) {
    if (argc > MAX_AGENT * 2 + 4) {
        fprintf(stderr, "Usage: ./client [fileName] [receiver address] [receiver port] [agent1 address] [agent1 ip] ... (at most 3)\n");
        exit(EXIT_FAILURE);
    }
    
    if (argc >= 2) strcpy(fileName, argv[1]);
    if (argc >= 3) strcpy(receiverName, argv[2])  ;
    if (argc >= 4) receiverPort = strtol(argv[3], 0, 10);

    
    if (argc < 5) return;
    for (int i = 4; i < argc; i++) {
        if (i % 2 == 0) strcpy(agentName[(i - 4) / 2], argv[i]);
        else agentPort[(i - 4) / 2] = strtol(argv[i], 0, 10);
    }
    numOfAgent = (argc - 4) / 2;
}

void getSocket() {
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        fprintf(stderr, "Create socket failed.\n");
        exit(EXIT_FAILURE); 
    }
}

void bindMyself() {
    memset((char*)&mySock, 0, sizeof(mySock));
    mySock.sin_family = AF_INET;
    mySock.sin_addr.s_addr = htonl(INADDR_ANY);
    mySock.sin_port = htons(myPort);

    if (bind(sock, (struct sockaddr*)&mySock, sizeof(mySock)) < 0) {
        fprintf(stderr, "Bind myself failed.\n");
        exit(EXIT_FAILURE);
    }
}

void transferSockAddr() {
    struct hostent *hptr;

    for (int i = 0; i < numOfAgent; i++) {
        memset((char*)&agentSock[i], 0, sizeof(agentSock[i]));
        agentSock[i].sin_family = AF_INET;
        agentSock[i].sin_port = htons(agentPort[i]);

        if ((inet_aton(agentName[i], &agentSock[i].sin_addr)) == 0) {
            fprintf(stderr, "Address of agent #%d is not an IP, try DNS.\n", i);
            hptr = gethostbyname(agentName[i]);
            if (hptr == NULL) {
                fprintf(stderr, "Transfer domain name failed\n");
                exit(EXIT_FAILURE);
            }
            memcpy(&agentSock[i].sin_addr.s_addr, hptr->h_addr, hptr->h_length);
        }
        agentAddr[i] = agentSock[i].sin_addr.s_addr;
    }

    memset((char*)&receiverSock, 0, sizeof(receiverSock));
    receiverSock.sin_family = AF_INET;
    receiverSock.sin_port = htons(receiverPort);

    if ((inet_aton(receiverName, &receiverSock.sin_addr)) == 0) {
        fprintf(stderr, "Address of receiver is not an IP, try DNS.\n");
        hptr = gethostbyname(receiverName);
        if (hptr == NULL) {
            fprintf(stderr, "Transfer domain name failed\n");
            exit(EXIT_FAILURE);
        }
        memcpy(&receiverSock.sin_addr.s_addr, hptr->h_addr, hptr->h_length);
    }
    receiverAddr = receiverSock.sin_addr.s_addr;
}

void readFile() {
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        fprintf(stderr, "Open file failed.\n");
        exit(EXIT_FAILURE);
    }

    fseek(pFile, 0, SEEK_END);
    fileSize = ftell(pFile);
    rewind(pFile);

    int num = fread(fileContent, 1, fileSize, pFile);
    if (fileSize != num) {
        fprintf(stderr, "Read file failed.\n");
        exit(EXIT_FAILURE);
    }
    fclose(pFile);
}

void createEpoll() {
    epollFd = epoll_create(2);
    if (epollFd == -1) {
        fprintf(stderr, "Create epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

void initEpoll() {
    ev.events = EPOLLIN | EPOLLRDHUP;
    ev.data.fd = sock; 
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, sock, &ev) == -1) {
        fprintf(stderr, "Add sock epoll failed.\n");
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN | EPOLLET;
    ev.data.fd = timerFd;
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, timerFd, &ev) == -1) {
        fprintf(stderr, "Add timer epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

void setTimer() {
    if ((timerFd = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK)) < 0) {
        fprintf(stderr, "Create timer failed.\n");
        exit(EXIT_FAILURE);
    }

    struct timespec initTs, intvTs;

    /* Armed clock */
    initTs.tv_sec = 1, initTs.tv_nsec = 0;  // because of execution time
    intvTs.tv_sec = intvTs.tv_nsec = 0;
    armValue.it_value = initTs;
    armValue.it_interval = intvTs;

    /* Disarmed clock */
    initTs.tv_sec = initTs.tv_nsec = 0;
    intvTs.tv_sec = intvTs.tv_nsec = 0;
    disarmValue.it_value = initTs;
    disarmValue.it_interval = intvTs;
}

void disarmTimer() {
    if (timerfd_settime(timerFd, 0, &disarmValue, &oldValue) < 0) {
        fprintf(stderr, "Set timer failed.\n");
        exit(EXIT_FAILURE);
    }
}

void armTimer() {
    if (timerfd_settime(timerFd, 0, &armValue, &oldValue) < 0) {
        fprintf(stderr, "Set timer failed.\n");
        exit(EXIT_FAILURE);
    }
}

int char2int(unsigned char tmp[]) {
    int res = 0;
    for (int i = 0; i < 4; i++) {
        res <<= 8;
        res |= tmp[i];
    }
    return res;
}

void int2char(int t, unsigned char tmp[]) {
    tmp[0] = (t >> 24) & 0xFF; 
    tmp[1] = (t >> 16) & 0xFF; 
    tmp[2] = (t >> 8) & 0xFF; 
    tmp[3] = t & 0xFF; 
}

void getData(char buffer[], int length) {
    char *nowFlag = buffer;
    
    /* dest addr */
    assert(char2int((unsigned char*)nowFlag) == receiverSock.sin_addr.s_addr);
    nowFlag += 4;

    /* dest port */
    assert(char2int((unsigned char*)nowFlag) == receiverPort);
    nowFlag += 4;

    /* seq number, start from 1 */
    // seqNum = char2int(nowFlag); nowFlag += 4;
    nowFlag += 4;

    /* ack number, start from 1 */
    ackNum = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* Show receive message */
    if (ackNum == -1) {
        fprintf(stderr, "End of sending service.\n");
        keepConnect = 0;
    }
    else if (ackNum) {     // sender to receiver 
        if (fileCheck[ackNum - 1]) {
            fprintf(stderr, "Receiver with [ip %d] and [port %d] send [replicate ack #%d].\n", receiverAddr, receiverPort, ackNum);
        }
        else {
            fprintf(stderr, "Receiver with [ip %d] and [port %d] send [ack #%d].\n", receiverAddr, receiverPort, ackNum);
            fileCheck[ackNum - 1] = 1;
        }

        /* increase getNum */
        if (ackNum - 1 >= windowFront && ackNum - 1 < windowFront + realSize) getNum++;
    }
    else {
        /* will not happen */
    }
}

int getAgentNo() {
    int res = rand() % DICE_FACE; 
    
    /* sum of agentRate should be 1 */
    for (int i = 0, sum = 0; i < numOfAgent; i++) {
        sum += DICE_FACE * agentRate[i];
        if (res < sum) return i;
    }
    return numOfAgent - 1;
}

void sendData(int who, int which, char buffer[], char *pos, int length) {

    /* Deal with TCP header */
    char *nowFlag = buffer;
    unsigned char tmp[4];

    /* dest addr */
    int2char(receiverSock.sin_addr.s_addr, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* dest port */
    int2char(receiverPort, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* seq num, start form 1 */
    int2char(which, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* ack num = 0 */
    int2char(0, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* data */
    if (which >= 0) memcpy(nowFlag, pos, length); nowFlag += length; 

    /* Send message */
    if (sendto(sock, buffer, nowFlag - buffer, 0, &agentSock[who], sizeof(agentSock[who])) < 0) {
        fprintf(stderr, "Send to agent #%d failed.\n", who);
        exit(EXIT_FAILURE);
    }

    /* Show send message */
    if (which >= 0) fprintf(stderr, "Send [data #%d] to [agent #%d] at [prop %f] with [windowSize %d].\n", 
      which, who, agentRate[who], windowSize);
    else fprintf(stderr, "Send EOF flag to [agent #%d] at [prop %f].\n", who, agentRate[who]);
}

void tuneAgentRate() {
    double res = 0;
    for (int i = 0; i < numOfAgent; i++) {
        res += agentReal[i];
    }
    for (int i = 0; i < numOfAgent; i++) {
        agentRate[i] = agentReal[i] / res;
    }
}

void sendToAgents(char buffer[]) {

    /* Tune agent rate */
    tuneAgentRate();

    /* Reset getNum */
    getNum = 0;

    realSize = 0;
    for (int nowFlag = windowFront * BLOCK_SIZE; realSize < windowSize && nowFlag < fileSize; realSize++, nowFlag += BLOCK_SIZE) {
        int who = getAgentNo();
        fileTag[windowFront + realSize] = who;
        sendData(who, windowFront + realSize + 1, buffer, fileContent + nowFlag, min(BLOCK_SIZE, fileSize - nowFlag));
    }

    /* End of data */
    if (realSize == 0) {
        fprintf(stderr, "Send data completely.\n");
        int who = getAgentNo();
        sendData(who, -1, buffer, 0, 0);
    }
}

void increaseRate(int who) {
    agentReal[who] = pow(agentReal[who], 1.000005);
}

void decreaseRate(int who) {
    agentReal[who] = pow(agentReal[who], 0.999995);
}

int main(int argc, char *argv[]) {
    char buffer[BUFFER_SIZE];

    /* Initialize arguments */
    init();

    /* Parse arguments */
    parseArg(argc, argv);

    /* Bind myself */
    getSocket();
    bindMyself();
    
    /* Transfer socket addr */
    transferSockAddr();
    
    /* Open file for reading */
    readFile();

    /* Set epoll */
    createEpoll();

    /* Set clock, first 0s, interval 5s */
    setTimer();

    /* Initialize epoll */
    initEpoll();

    /* Start message */
    fprintf(stderr, "\nSender start with [port %d].\n\n", myPort);

    /* Send first block */
    sendToAgents(buffer);
    armTimer();

    /* Begin sending */
    while (keepConnect) {
        int num = epoll_wait(epollFd, events, 2, -1);
        if (num == -1) {
            fprintf(stderr, "Epoll wait failed.\n");
            exit(EXIT_FAILURE);
        }

        socklen_t size = sizeof(inSock);
        for (int i = 0; i < num; i++) {
            if (events[i].data.fd == sock) {    // Someone write ack back
                int val = recvfrom(sock, &buffer, sizeof(buffer), 0, &inSock, &size);
                if (val < 0) {
                    fprintf(stderr, "Recv data failed.\n");
                    exit(EXIT_FAILURE);
                }

                /* Get info from data */
                getData(buffer, val);
                if (!keepConnect) {
                    disarmTimer();
                    break;
                }

                /* tune agent rate */
                increaseRate(fileTag[seqNum]);

                /* receive data completely */
                if (getNum == realSize) {
                    disarmTimer();

                    /* Tune window, threshold */
                    windowFront += realSize;

                    /* send to agents */
                    //fprintf(stderr, "aa windowfront %d, realsize %d, windowSize %d, threshold %d, getnum %d\n", 
                      //windowFront, realSize, windowSize, threshold, getNum);
                    if (2 * windowSize > threshold) windowSize++;
                    else windowSize <<= 1;

                    sendToAgents(buffer);
                    armTimer();
                }
            }
            else {      // clock alarm
                //fprintf(stderr, "bb windowfront %d, realsize %d, windowSize %d, threshold %d, getnum %d\n", 
                  //windowFront, realSize, windowSize, threshold, getNum);
                int first = -1;
                for (int j = 0; j < realSize; j++) {
                    if (fileCheck[windowFront + j] == 0) {
                        if (first == -1) first = windowFront + j;
                        decreaseRate(fileTag[windowFront + j]);
                    }
                }
                tuneAgentRate();

                /* Tune window, threshold */
                if (first >= 0) {
                    threshold = max(windowSize / 2, 1);
                    windowSize = 1;
                    windowFront = first;
                }
                else {
                    /* EOF flag send fail */
                }

                /* Read alarm */
                uint64_t value;
                read(timerFd, &value, 8);
                fprintf(stderr, "Clock alarm.\n");

                /* Send to agents */
                sendToAgents(buffer);
                armTimer();
            }
        }
    }

    return 0;
}
