#include "common.h"

int myPort;
int sock, epollFd;

int senderAddr, senderPort;
int agentAddr, agentPort;
int seqNum, ackNum;

int keepConnect = 1;
int bufferFull;

char fileName[BUFFER_SIZE];
char fileContent[FILE_BUFFER_SIZE];
int fileSize;
int fileCheck[BLOCK_NUM];
int windowFront, getNum;

struct sockaddr_in mySock, senderSock, agentSock;
struct epoll_event ev, events[1];

void init() {
    strcpy(fileName, "out.txt");
    myPort = 8080;
}

void parseArg(int argc, char *argv[]) {
    if (argc >= 4) {
        fprintf(stderr, "Usage ./receiver [filename] [port]\n");
        exit(EXIT_FAILURE);
    }
    if (argc >= 2) strcpy(fileName, argv[1]);
    if (argc >= 3) myPort = strtol(argv[2], 0, 10);
}

void getSocket() {
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        fprintf(stderr, "Create socket failed.\n");
        exit(EXIT_FAILURE); 
    }
}

void bindMyself() {
    memset((char*)&mySock, 0, sizeof(mySock));
    mySock.sin_family = AF_INET;
    mySock.sin_addr.s_addr = htonl(INADDR_ANY);
    mySock.sin_port = htons(myPort);

    if (bind(sock, (struct sockaddr*)&mySock, sizeof(mySock)) < 0) {
        fprintf(stderr, "Bind myself failed.\n");
        exit(EXIT_FAILURE);
    }
}

void createEpoll() {
    epollFd = epoll_create(1);
    if (epollFd == -1) {
        fprintf(stderr, "Create epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

void initEpoll() {
    ev.events = EPOLLIN | EPOLLRDHUP;
    ev.data.fd = sock; 
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, sock, &ev) == -1) {
        fprintf(stderr, "Add sock epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

int char2int(unsigned char tmp[]) {
    int res = 0;
    for (int i = 0; i < 4; i++) {
        res <<= 8;
        res |= tmp[i];
    }
    return res;
}

void int2char(int t, unsigned char tmp[]) {
    tmp[0] = (t >> 24) & 0xFF; 
    tmp[1] = (t >> 16) & 0xFF; 
    tmp[2] = (t >> 8) & 0xFF; 
    tmp[3] = t & 0xFF; 
}

void getData(char buffer[], int length) {
    char *nowFlag = buffer;

    /* dest addr */
    senderAddr = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* dest port */
    senderPort = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* seq number, start from 1 */
    seqNum = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* ack number, start from 1 */
    ackNum = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* Show receive message */
    if (seqNum == -1) {
        fprintf(stderr, "Receive EOF flag.\n");
        keepConnect = 0;
    }
    else if (seqNum) {     // sender to receiver
        if (fileCheck[seqNum - 1]) {
            fprintf(stderr, "Sender with [ip %d] and [port %d] send [replicate data #%d].\n", senderAddr, senderPort, seqNum);
        }
        else if (seqNum - 1 < windowFront + RECEIVER_BUFFER_NUM) {
            fprintf(stderr, "Sender with [ip %d] and [port %d] send [data #%d].\n", senderAddr, senderPort, seqNum);   
            fileCheck[seqNum - 1] = 1;
            getNum++;
            
            memcpy(fileContent + (seqNum - 1) * BLOCK_SIZE, nowFlag, buffer + length - nowFlag);
            fileSize += buffer + length - nowFlag;

            /* If buffer full, move forward */
            if (getNum == RECEIVER_BUFFER_NUM) {
                windowFront += RECEIVER_BUFFER_NUM;
                getNum = 0;
            }
        }
        else {
            /* Beyond receiver buffer num */
            fprintf(stderr, "Buffer is full.\n");
            bufferFull = 1;
        }
    }
    else {
        /* will not happen */
    }
}

void sendData(char buffer[], int length) {

    /* Deal with TCP header */
    char *nowFlag = buffer;
    unsigned char tmp[4];

    /* dest addr */
    nowFlag += 4;

    /* dest port */
    nowFlag += 4;

    /* seq number = 0 */
    int2char(0, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* ack number, start from 1 */
    int2char(seqNum, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* Send back ack */
    if (sendto(sock, buffer, nowFlag - buffer, 0, &agentSock, sizeof(agentSock)) < 0) {
        fprintf(stderr, "Send to agent failed.\n");
        exit(EXIT_FAILURE);
    }

    /* Show send message */
    if (seqNum > 0) fprintf(stderr, "Receiver send back [ack #%d].\n", seqNum);
    else fprintf(stderr, "End of receiving service.\n");
}

void writeFile() {
    FILE *pFile = fopen(fileName, "w");
    if (pFile == NULL) {
        fprintf(stderr, "Open file failed.\n");
        exit(EXIT_FAILURE);
    }

    int num = fwrite(fileContent, 1, fileSize, pFile);
    if (fileSize != num) {
        fprintf(stderr, "Read file failed.\n");
        exit(EXIT_FAILURE);
    }
    fclose(pFile);
}

int main(int argc, char *argv[]) {

    /* Initialize arguments */
    init();

    /* Parse arguments */
    parseArg(argc, argv);
    
    /* Bind myself */
    getSocket();
    bindMyself();

    /* Create epoll */
    createEpoll();

    /* Initialize epoll */
    initEpoll();

    /* Start massage */
    fprintf(stderr, "\nReceiver start with [port %d].\n\n", myPort);

    while (keepConnect) {
        int num = epoll_wait(epollFd, events, 1, -1);
        if (num == -1) {
            fprintf(stderr, "Epoll wait failed.\n");
            exit(EXIT_FAILURE);
        }

        socklen_t size = sizeof(agentSock);
        for (int i = 0; i < num; i++) {
            if (events[i].data.fd == sock) {    // someone ask you to receive something
                char buffer[BUFFER_SIZE];
                int val = recvfrom(sock, &buffer, sizeof(buffer), 0, &agentSock, &size);
                if (val < 0) {
                    fprintf(stderr, "Recv data failed.\n");
                    exit(EXIT_FAILURE);
                }

                /* Get info from data */
                bufferFull = 0;
                getData(buffer, val);

                /* Send data back */
                if (!bufferFull) sendData(buffer, val);

                if (keepConnect == 0) break;
            }
        }
    }

    writeFile();
}
