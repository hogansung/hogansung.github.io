**  Following are the short intro about how to compile and run my code:


**  Receiver Part

    1.  Key in "make receiver" to compile "receiver.c" into "receiver".

    2.  You can change the settings of address and port for receiver in Makefile.

    3.  Key in "make receiverRun" to run up the receiver.
        Or, you can run the receiver with self-determined arguments.

    * Needed component:
        a.  sender.cpp
        b.  common.h



**  Agent Part

    1.  Key in "make agent" to compile "agent.c" into "agent".

    2.  You can change the settings of address and port for three agents in Makefile.
        Or, you can add any number of agents with proper settings.

    3.  Key in "make agentRun{NUM}" to run up the {NUM} agent. (NUM = 1, 2, 3, ...)
        Or you can run the agents with self-determined arguments.

    * Needed component:
        a.  agent.cpp
        b.  common.h



**  Sender Part

    1.  Key in "make sender" to compile "sender.c" into "sender".
    
    2.  You can change the settings of address and port for sender in Makefile.

    3.  Key in "make senderRun" to run up the receiver.
        Or, you can run the sender with self-determined arguments.

    * Needed component:
        a.  sender.cpp
        b.  common.h



**  Others

    1.  Key in "make killall" to clean up running agents or server processes.
    
    2.  Key in "make clean" to remove all executable files.
    
