#include "common.h"

int myPort;
int sock, epollFd;

int inAddr, inPort;
int outAddr, outPort;
int seqNum, ackNum;

double dropRate;

struct sockaddr_in mySock, inSock, outSock;
struct epoll_event ev, events[1];

void init() {
    myPort = 8800;
    dropRate = 0.01;

    srand(time(NULL));
}

void parseArg(int argc, char *argv[]) {
    if (argc >= 4) {
        fprintf(stderr, "Usage ./agent [port] [dropRate]\n");
        exit(EXIT_FAILURE);
    }
    if (argc >= 2) myPort = strtol(argv[1], 0, 10);
    if (argc >= 3) dropRate = strtod(argv[2], NULL);
}

void getSocket() {
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        fprintf(stderr, "Create socket failed.\n");
        exit(EXIT_FAILURE); 
    }
}

void bindMyself() {
    memset((char*)&mySock, 0, sizeof(mySock));
    mySock.sin_family = AF_INET;
    mySock.sin_addr.s_addr = htonl(INADDR_ANY);
    mySock.sin_port = htons(myPort);

    if (bind(sock, (struct sockaddr*)&mySock, sizeof(mySock)) < 0) {
        fprintf(stderr, "Bind myself failed.\n");
        exit(EXIT_FAILURE);
    }
}

void createEpoll() {
    epollFd = epoll_create(1);
    if (epollFd == -1) {
        fprintf(stderr, "Create epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

void initEpoll() {
    ev.events = EPOLLIN | EPOLLRDHUP;
    ev.data.fd = sock; 
    if (epoll_ctl(epollFd, EPOLL_CTL_ADD, sock, &ev) == -1) {
        fprintf(stderr, "Add sock epoll failed.\n");
        exit(EXIT_FAILURE);
    }
}

int char2int(unsigned char tmp[]) {
    int res = 0;
    for (int i = 0; i < 4; i++) {
        res <<= 8;
        res |= tmp[i];
    }
    return res;
}

void int2char(int t, unsigned char tmp[]) {
    tmp[0] = (t >> 24) & 0xFF; 
    tmp[1] = (t >> 16) & 0xFF; 
    tmp[2] = (t >> 8) & 0xFF; 
    tmp[3] = t & 0xFF; 
}

void changeSock() {
    memset((char*)&outSock, 0, sizeof(outSock));
    outSock.sin_family = AF_INET;
    outSock.sin_addr.s_addr = outAddr;
    outSock.sin_port = htons(outPort);
}

void getData(char buffer[], int length) {
    char *nowFlag = buffer;

    /* source addr */
    inAddr = inSock.sin_addr.s_addr;

    /* source port */
    inPort = ntohs(inSock.sin_port);
    
    /* dest addr */
    outAddr = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* dest port */
    outPort = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* seq number, start from 1 */
    seqNum = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* ack number, start from 1 */
    ackNum = char2int((unsigned char*)nowFlag); nowFlag += 4;

    /* Show message */
    if (seqNum == -1) {
        fprintf(stderr, "Sender with [ip %d] and [port %d] send EOF flag to receiver with [ip %d] and [port %d].\n", 
          inAddr, inPort, outAddr, outPort);
    }
    else if (seqNum) {     // sender to receiver
        fprintf(stderr, "Sender with [ip %d] and [port %d] send [data #%d] to receiver with [ip %d] and [port %d].\n", 
          inAddr, inPort, seqNum, outAddr, outPort);
    }
    else if (ackNum == -1) {
        fprintf(stderr, "Receiver with [ip %d] and [port %d] confirm EOF flag from sender with [ip %d] and [port %d].\n", 
          inAddr, inPort, outAddr, outPort);
    }
    else if (ackNum) {              // receiver to sender
        fprintf(stderr, "Receiver with [ip %d] and [port %d] send [ack #%d] to sender with [ip %d] and [port %d].\n", 
          inAddr, inPort, ackNum, outAddr, outPort);
    }
    else {
        /* will not happen */
    }
}

void sendData(char buffer[], int length) {

    /* Deal with TCP header */
    char *nowFlag = buffer;
    unsigned char tmp[4];

    /* source addr */
    int2char(inAddr, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* source port */
    int2char(inPort, tmp);
    memcpy(nowFlag, tmp, 4); nowFlag += 4;

    /* Replace the front part, remain the left */
    if (sendto(sock, buffer, length, 0, &outSock, sizeof(outSock)) < 0) {
        if (seqNum) fprintf(stderr, "Send to receiver failed.\n");
        else if (ackNum) fprintf(stderr, "Send to sender failed.\n");
        else {
            /* will not happen */
        }
        exit(EXIT_FAILURE);
    }
}

int lossData() {
    int res = rand() % DICE_FACE;    

    if (res < DICE_FACE * dropRate && seqNum) {
        fprintf(stderr, "Data package was dropped!!!\n");
        return 0;
    }
    else return 1;
}

int main(int argc, char *argv[]) {

    /* Initialize arguments */
    init();

    /* Parse arguments */
    parseArg(argc, argv);
    
    /* Bind myself */
    getSocket();
    bindMyself();

    /* Create epoll */
    createEpoll();

    /* Initialize epoll */
    initEpoll();

    /* Start message */
    fprintf(stderr, "\nAgent start with [port %d].\n\n", myPort);

    while (1) {
        int num = epoll_wait(epollFd, events, 1, -1);
        if (num == -1) {
            fprintf(stderr, "Epoll wait failed.\n");
            exit(EXIT_FAILURE);
        }

        socklen_t size = sizeof(inSock);
        for (int i = 0; i < num; i++) {
            if (events[i].data.fd == sock) {   // someone ask you to transmit something
                char buffer[BUFFER_SIZE];
                int val = recvfrom(sock, &buffer, sizeof(buffer), 0, &inSock, &size);
                if (val < 0) {
                    fprintf(stderr, "Recv data failed.\n");
                    exit(EXIT_FAILURE);
                }

                /* Get info from data */
                getData(buffer, val);

                /* Change outSock */
                changeSock();

                /* Loss data */
                int decision = lossData();

                /* Send data */
                if (decision) sendData(buffer, val);
            }
        }
    }

    return 0;
}
