#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/timerfd.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <assert.h>

#define BLOCK_NUM 1024
#define BLOCK_SIZE 1024
#define BUFFER_SIZE 4096
#define FILE_BUFFER_SIZE BLOCK_NUM * BLOCK_SIZE
#define RECEIVER_BUFFER_NUM 128
#define TIME_OUT 5
#define MAX_AGENT 3
#define DICE_FACE 10000000
