#!/usr/bin/python

import sys
import math
import matplotlib.pyplot as plt

xLabel = ['0', '25', '50', '75', '100', '125', '150', '175', '200', '225', '250', '275', '300', '325', '350', '375', '400', '425', '450', '475', '500']
xStick = ['0', '50', '100', '150', '200', '250', '300', '350', '400', '450', '500']

lineType = ['o-', '^-', 's-', 'D-']


def read_gbm():
    timeList = []
    perfList = []

    with open('gbm') as f:
        content = f.readlines()
        for i in range(0, len(content), 3):
            timeList.append(float(content[i].strip().split()[3]) * 16)
            perfList.append(float(content[i + 2].strip()))

    return timeList, perfList


def read_gbm_ex(suffixList):
    r_timeList = []
    r_perfList = []
    o_timeList = []
    o_perfList = []

    for s in suffixList:
        timeList = []
        perfList = []

        with open('gbm_ex_' + s) as f:
            content = f.readlines()
            if (s == '1'):
                for i in range(0, len(content), 8):
                    timeList.append(float(content[i].strip().split()[3]) * 16)
                    o_timeList.append(float(content[i + 2].strip().split()[3]) * 16)
                    perfList.append(float(content[i + 5].strip()))
                    o_perfList.append(float(content[i + 7].strip()))
            else:
                for i in range(0, len(content), 6):
                    timeList.append(float(content[i].strip().split()[3]) * 16)
                    perfList.append(float(content[i + 3].strip()))


        r_timeList.append(timeList)
        r_perfList.append(perfList)

    return r_timeList, r_perfList, o_timeList, o_perfList


def read_mf():
    timeList = []
    perfList = []

    with open('mf') as f:
        content = f.readlines()
        for i in range(0, len(content), 3):
            timeList.append(float(content[i].strip().split()[3]) * 120)
            perfList.append(float(content[i + 2].strip()))

    return timeList, perfList


def read_mean():
    timeList = []
    perfList = []

    with open('mean') as f:
        content = f.readlines()
        for i in range(0, len(content), 3):
            timeList.append(float(content[i].strip().split()[3]) * 16)
            perfList.append(float(content[i + 2].strip()))

    return timeList, perfList


def read_zero():
    return [0.8296537 for i in range(21)]


def draw_gbm_ex_perf(gbm_ex_perfList, gbm_ex_target):
    for i in range(len(gbm_ex_target)):
        plt.plot(range(len(xLabel)), gbm_ex_perfList[i], lineType[i], linestyle='--', lw = 3, markersize=5, label = 'times ' + gbm_ex_target[i])
    plt.xticks(range(0, len(xLabel), 2), xStick)
    #plt.title('GBRT imputation with different iterations')
    plt.legend(loc=2)
    plt.xlabel('Data Missing Rate (x1000)')
    plt.ylabel('Average MAE')
    plt.show()


def draw_gbm_ex_time(gbm_ex_timeList, gbm_ex_target):
    for i in range(len(gbm_ex_target)):
        plt.plot(range(len(xLabel)), gbm_ex_timeList[i], lineType[i], linestyle='--', lw=3, markersize=5, label='times: ' + gbm_ex_target[i])
    plt.xticks(range(0, len(xLabel), 2), xStick)
    #plt.title('GBRT imputation with different iterations')
    plt.legend(loc=2)
    plt.xlabel('Data Missing Rate (x1000)')
    plt.ylabel('Elapse Time (s)')
    plt.show()


def draw_perf(gbm_perfList, gbm_ex_perfList, gbm_ex_o_perfList, mf_perfList, mean_perfList, zero_perfList):
    plt.plot(range(len(xLabel)), gbm_ex_o_perfList, 's-', linestyle='--', lw=3, markersize=5, label='GBDT$_0$')
    plt.plot(range(len(xLabel)), gbm_perfList, 'o-', linestyle='--', lw=3, markersize=5, label='GBDT$_1$')
    plt.plot(range(len(xLabel)), gbm_ex_perfList, '^-', linestyle='--', lw=3, markersize=5, label='GBDT$_2$')
    plt.plot(range(len(xLabel)), mf_perfList, 'D-', linestyle='--', lw=3, markersize=5, label='MF')
    plt.plot(range(len(xLabel)), mean_perfList, 'p-', linestyle='--', lw=3, markersize=5, label='MEAN')
    plt.plot(range(len(xLabel)), zero_perfList, linestyle='--', lw=5, markersize=5, label='ZERO')
    plt.xticks(range(0, len(xLabel), 2), xStick)
    #plt.title('GBM imputation with different iterations')
    plt.legend(loc=2)
    plt.xlabel('Data Missing Rate (x1000)')
    plt.ylabel('Average MAE')
    plt.show()



def draw_time(gbm_timeList, gbm_ex_timeList, gbm_ex_o_timeList, mf_timeList, mean_timeList):
    f,(axLarge,axSmall) = plt.subplots(2,1,sharex=True)
    axSmall.plot(range(len(xLabel)), gbm_ex_o_timeList, 's-', linestyle='--', lw=3, markersize=5, label='GBDT$_0$',color='b')
    axSmall.plot(range(len(xLabel)), gbm_timeList, 'o-', linestyle='--', lw=3, markersize=5, label='GBDT$_1$',color='g')
    axSmall.plot(range(len(xLabel)), gbm_ex_timeList, '^-', linestyle='--', lw=3, markersize=5, label='GBDT$_2$',color='r')
    axLarge.plot(range(len(xLabel)), mf_timeList, 'D-', linestyle='--', lw=3, markersize=5, label='MF',color='c')
    axSmall.plot(range(len(xLabel)), mean_timeList, 'p-', linestyle='--', lw=3, markersize=5, label='MEAN',color='m')

    axLarge.set_ylim(90000, 110000)
    axSmall.set_ylim(0, 20000)

    axLarge.spines['bottom'].set_visible(False)
    axSmall.spines['top'].set_visible(False)
    axLarge.xaxis.tick_top()
    axLarge.tick_params(labeltop='off')
    axSmall.xaxis.tick_bottom()
    

    d = .015 # how big to make the diagonal lines in axes coordinates
    kwargs = dict(transform=axLarge.transAxes, color='k', clip_on=False)
    axLarge.plot((-d,+d),(-d,+d), **kwargs)      # top-left diagonal
    axLarge.plot((1-d,1+d),(-d,+d), **kwargs)    # top-right diagonal

    kwargs.update(transform=axSmall.transAxes)  # switch to the bottom axes
    axSmall.plot((-d,+d),(1-d,1+d), **kwargs)   # bottom-left diagonal
    axSmall.plot((1-d,1+d),(1-d,1+d), **kwargs) # bottom-right diagonal

    plt.xticks(range(0, len(xLabel), 2), xStick)
    #plt.title('GBM imputation with different iterations')
    axSmall.legend(loc=2)
    axLarge.legend(loc=2)
    plt.xlabel('Data Missing Rate (x1000)')
    plt.ylabel('Elapse Time (s)')
    plt.show()


def main():
    # read in data
    gbm_timeList, gbm_perfList = read_gbm()
    gbm_ex_target = ['1', '10', '50']
    gbm_ex_timeList, gbm_ex_perfList, gbm_ex_o_timeList, gbm_ex_o_perfList = read_gbm_ex(gbm_ex_target)
    mf_timeList, mf_perfList = read_mf()
    mean_timeList, mean_perfList = read_mean()
    zero_perfList = read_zero()

    
    # draw pictures
    draw_gbm_ex_perf(gbm_ex_perfList, gbm_ex_target)
    draw_gbm_ex_time(gbm_ex_timeList, gbm_ex_target)
    
    draw_perf(gbm_perfList, gbm_ex_perfList[0], gbm_ex_o_perfList, mf_perfList, mean_perfList, zero_perfList)
    draw_time(gbm_timeList, gbm_ex_timeList[0], gbm_ex_o_timeList, mf_timeList, mean_timeList)


if __name__ == '__main__':
    main()
