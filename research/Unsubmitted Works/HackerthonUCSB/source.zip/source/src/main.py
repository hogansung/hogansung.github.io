import operator

userID = 0
userDICT = dict()

itemID = 0
itemDICT = dict()


with open('../dat/retargeting_ad_data_train.csv000') as f:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = inst[2][1:-1]

        if not userDICT.has_key(user):
            userDICT[user] = userID
            userID += 1


with open('../dat/retargeting_ad_data_test.csv000') as f:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = inst[2][1:-1]

        if not userDICT.has_key(user):
            userDICT[user] = userID
            userID += 1


with open('../dat/site_view_log.csv000') as f:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = inst[3][1:-1]
        item = inst[4][1:-1]

        if not userDICT.has_key(user):
            continue
            userDICT[user] = userID
            userID += 1

        if not itemDICT.has_key(item):
            itemDICT[item] = itemID
            itemID += 1


with open('../dat/site_order_log.csv000') as f:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = inst[3][1:-1]
        item = inst[4][1:-1]

        if not userDICT.has_key(user):
            continue
            userDICT[user] = userID
            userID += 1

        if not itemDICT.has_key(item):
            itemDICT[item] = itemID
            itemID += 1


with open('../dat/n_rating.csv', 'w') as wf:
    with open('../dat/site_view_log.csv000') as f:
        for line in f.readlines():
            inst = line.strip().split(',')
            if not userDICT.has_key(inst[3][1:-1]):
                continue
            user = userDICT[inst[3][1:-1]]
            item = itemDICT[inst[4][1:-1]]
            wf.write(','.join([str(user+1), str(item+1), str(0)]) + '\n')

    with open('../dat/site_order_log.csv000') as f:
        for line in f.readlines():
            inst = line.strip().split(',')
            if not userDICT.has_key(inst[3][1:-1]):
                continue
            user = userDICT[inst[3][1:-1]]
            item = itemDICT[inst[4][1:-1]]
            wf.write(','.join([str(user+1), str(item+1), str(1)]) + '\n')


with open('../dat/retargeting_ad_data_train.csv000') as f, open('../dat/n_train.csv', 'w') as wf:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = userDICT[inst[2][1:-1]]

        wf.write(','.join(inst[:2] + [str(user+1)] + inst[3:]) + '\n')


with open('../dat/retargeting_ad_data_test.csv000') as f, open('../dat/n_test.csv', 'w') as wf:
    for line in f.readlines():
        inst = line.strip().split(',')
        user = userDICT[inst[2][1:-1]]

        wf.write(','.join(inst[:2] + [str(user+1)] + inst[3:]) + '\n')


with open('../dat/map_user.csv', 'w') as wf:
    sorted_x = sorted(userDICT.items(), key=operator.itemgetter(1))
    for i, v in sorted_x:
        wf.write(i + '\n')


with open('../dat/map_item.csv', 'w') as wf:
    sorted_x = sorted(itemDICT.items(), key=operator.itemgetter(1))
    for i, v in sorted_x:
        wf.write(i + '\n')
