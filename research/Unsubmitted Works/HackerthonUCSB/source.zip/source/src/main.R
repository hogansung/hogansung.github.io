library(randomForest)
library(e1071)
library(gbm)
library(LOGIT)

set.seed(514)

# read files
tn_d = read.csv(file='../dat/n_train.csv', header=FALSE, sep=',')
tt_d = read.csv(file='../dat/n_test.csv', header=FALSE, sep=',')

# read features
features = read.csv(file='../dat/features', header=FALSE, sep=',')

tn_n = dim(tn_d)[1]
tt_n = dim(tt_d)[1]

# split x
tn_x = tn_d[,c(2,3,6:9)]
tn_a = tn_d[,10]
tn_y = tn_d[,11]
tt_x = tt_d[,c(2,3,6:9)]

# merge tn and tt
x = rbind(tn_x, tt_x)
time = strptime(x$V2, "%Y-%m-%d %H:%M:%S")
x$hour = as.factor(time$hour)
ft = model.matrix(~x$hour)[,-1]
f7 = model.matrix(~x$V7)[,-1]
f9 = model.matrix(~x$V9)[,-1]

# merge features

#tn_x = data.frame(f7[1:tn_n,], f9[1:tn_n,], features=features[tn_d$V3,])
#tt_x = data.frame(f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),], features=features[tt_d$V3,])

#tn_x = data.frame(f7[1:tn_n,], f9[1:tn_n,])
#tt_x = data.frame(f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),])

#tn_x = data.frame(hour=time$hour[1:tn_n], f7[1:tn_n,], f9[1:tn_n,])
#tt_x = data.frame(hour=time$hour[(tn_n+1):(tn_n+tt_n)], f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),])

#tn_x = data.frame(hour1=time$hour[1:tn_n], hour2=time$hour[1:tn_n]^2, hour3=time$hour[1:tn_n]^3, f7[1:tn_n,], f9[1:tn_n,])
#tt_x = data.frame(hour1=time$hour[(tn_n+1):(tn_n+tt_n)], hour2=time$hour[(tn_n+1):(tn_n+tt_n)]^2, hour3=time$hour[(tn_n+1):(tn_n+tt_n)]^3, f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),])

#tn_x = data.frame(hour1=time$hour[1:tn_n], hour2=time$hour[1:tn_n]^2, hour3=time$hour[1:tn_n]^3, f7[1:tn_n,], f9[1:tn_n,], features=features[tn_d$V3,])
#tt_x = data.frame(hour1=time$hour[(tn_n+1):(tn_n+tt_n)], hour2=time$hour[(tn_n+1):(tn_n+tt_n)]^2, hour3=time$hour[(tn_n+1):(tn_n+tt_n)]^3, f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),], features=features[tt_d$V3,])

#tn_x = data.frame(ft[1:tn_n,], f7[1:tn_n,], f9[1:tn_n,])
#tt_x = data.frame(ft[(tn_n+1):(tn_n+tt_n),], f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),])

tn_x = data.frame(ft[1:tn_n,], f7[1:tn_n,], f9[1:tn_n,], features=features[tn_d$V3,])
tt_x = data.frame(ft[(tn_n+1):(tn_n+tt_n),], f7[(tn_n+1):(tn_n+tt_n),], f9[(tn_n+1):(tn_n+tt_n),], features=features[tt_d$V3,])

tn_x = data.frame(scale(tn_x))
tt_x = data.frame(scale(tt_x))

# partition subtrain, validation
train_ind <- sample(1:tn_n, size = floor(0.632 * tn_n))
stn_x = tn_x[train_ind, ]
stn_y = tn_y[train_ind]
vld_x = tn_x[-train_ind, ]
vld_y = tn_y[-train_ind]
stn = data.frame(stn_x, label=stn_y)
stn$label = as.numeric(stn$label)
vld = data.frame(vld_x, label=vld_y)
vld$label = as.numeric(vld$label)

# logistic regression
glm_m = glm(label~., data=stn, family=binomial())
stn_p = predict(glm_m, stn_x, type="response")
vld_p = predict(glm_m, vld_x, type="response")

#stn_p = as.integer(as.character(stn_p))
#vld_p = as.integer(as.character(vld_p))

#svm_m = svm(as.factor(label) ~ ., data=stn, method="C-classification",
#             kernel="linear", probability=TRUE, cachesize=4000)
#stn_p = predict(svm_m, stn_x, type="response")
#vld_p = predict(svm_m, vld_x, type="response")

#rf_m = randomForest(as.factor(label)~., data=stn, ntree=100)
#stn_p = predict(rf_m, stn_x, type='prob')
#stn_p = stn_p$1
#vld_p = predict(rf_m, vld_x, type='prob')
#vld_p = vld_p$1

# calculate loss
calloss = function(p, y) {
    #assert(length(p) == length(y))
    sum = 0
    for (i in 1:length(p)) {
        sum = sum + y[i] * log(1e-10+p[i]) + (1-y[i]) * log(1e-10+1-p[i])
    }
    -1.0 / length(p) * sum
}

stn_acc = sum((stn_p > 0.5) == stn_y) / length(stn_y)
vld_acc = sum((vld_p > 0.5) == vld_y) / length(vld_y)

stn_err = calloss(stn_p, stn_y)
print(stn_err)
vld_err = calloss(vld_p, vld_y)
print(vld_err)

#print('stn_acc = %f\n', stn_acc);
#print('vld_acc = %f\n', vld_acc);
