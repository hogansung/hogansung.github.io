# read data
#library(Matrix)
library(recommenderlab)
require(data.table)
rating =  fread("../dat/n_rating.csv")
n = dim(rating)[1]


calLoss = function(stn, P, Q) {
    sum = 0
    for (t in 1:dim(stn)[1]) {
        u = stn[t, 1]
        i = stn[t, 2]
        y = stn[t, 3]
        r = t(P[u,]) %*% Q[i,]
        sum = sum + 0.5 * (r-y) ^ 2
    }
    sum = sum + lambda_p * norm(P, type='F')^2 + lambda_p * norm(Q, type='F')^2
}


# split data into 0 and 1
rating_0 = rating[rating$V3 == 0,]
rating_1 = rating[rating$V3 == 1,]
n0 = dim(rating_0)[1]
n1 = dim(rating_1)[1]


# sample rating_1 for validation
rating_1 = sample(rating_1)
vld_1 = rating_1[1:floor(0.25*n1),]
stn_1 = rating_1[(floor(0.25*n1)+1):n1,]

rating_0 = sample(rating_0)
vld_0 = rating_0[1:floor(0.25*n1),]
stn_all0 = rating_0[(floor(0.25*n1)+1):n0,]

vld = rbind(vld_0, vld_1)
#stn = rbind(stn_all0, stn_1)

#bm = as(stn, 'binaryRatingMatrix')
#stn_sp = sparseMatrix(stn[,1], stn[,2], stn[,3])

# create latent vector
nu = 92586;
ni = 132919;
nl = 5;
lambda_p = 0.001;
lambda_q = 0.001;
eta = 0.05
P = matrix(rnorm(nu*nl), nu, nl)
Q = matrix(rnorm(ni*nl), ni, nl)

#stn_all0 = sample(stn_all0)
#stn_0 = stn_all0[1:(n1-floor(0.25*n1)),]

for (tt in 1:20) {
    stn_0 = sample(stn_all0)

    dp = matrix(0, nu, nl)
    dq = matrix(0, ni, nl)

    for (t in 1:5000) {
        u = stn_0[t, 1]
        i = stn_0[t, 2]
        y = stn_0[t, 3]
        r = t(P[u,]) %*% Q[i,]

        dp[u,] = dp[u,] + (r - y) * Q[i,] + 2 * lambda_p * P[u,]
        dq[i,] = dq[i,] + (r - y) * P[u,] + 2 * lambda_q * Q[i,]
    }

    for (t in 1:5000) {
        u = stn_1[t, 1]
        i = stn_1[t, 2]
        y = stn_1[t, 3]
        r = t(P[u,]) %*% Q[i,]

        dp[u,] = dp[u,] + (r - y) * Q[i,] + 2 * lambda_p * P[u,]
        dq[i,] = dq[i,] + (r - y) * P[u,] + 2 * lambda_q * Q[i,]
    }


    P = P - eta / dim(stn)[1] * dp
    Q = Q - eta / dim(stn)[1] * dq

    loss = calLoss(stn, P, Q)
    print(loss)
}

write.table(P, file='../dat/features', row.names=FALSE, col.names=FALSE, sep=',')
